# team404/app_config.py

"""
Application Configuration for SpectraMapper Pro.

This file stores application-level configurations that are typically
set at build/deployment time or are fundamental to the application's
behavior, rather than user-editable preferences.

User-editable preferences are managed by `PreferencesDialog` and stored
separately (e.g., in `app_preferences.json`).
"""

import os
import logging

# --- Application Metadata (can also be in __init__.py or constants.py) ---
# These are duplicated in __init__.py and constants.py for now.
# Choose one central place for these eventually. For this structure,
# constants.py is good for widely used ones, __init__.py for package-level.
APP_NAME: str = "Sparcnyx"
APP_VERSION: str = "0.1.0-alpha" # Ensure this matches __init__.py and constants.py
ORGANIZATION_NAME: str = "Sparcnyx Co" # For QSettings if used
ORGANIZATION_DOMAIN: str = "sparcnyx.com" # For QSettings if used
DEFAULT_PROJECT_SETTINGS_FILENAME = "default_project_params.json"
APP_CONFIGURATION_NAME = "Sparcnyx"

# --- Paths ---
# Relative paths assume the application structure.
# For bundled applications, these might need adjustment or use of resource systems.
# BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) # Team404_LIBS_Analysis/
# ASSETS_DIR = os.path.join(BASE_DIR, "team404", "assets")
# ICONS_DIR = os.path.join(ASSETS_DIR, "icons")
# CONFIG_TEMPLATES_DIR = os.path.join(ASSETS_DIR, "config_templates")

# It's often better to construct paths dynamically where needed using os.path.join
# and relative paths from the current file or a known root,
# or use Qt's QStandardPaths for standard locations.
# Example for icon paths (as used in main_window.py):
# base_path = os.path.dirname(os.path.dirname(os.path.dirname(__file__))) # Up to Team404_LIBS_Analysis/team404
# icon_path = os.path.join(base_path, "assets", "icons", icon_name)


# --- Logging Configuration (Defaults, can be overridden by logging_setup.py arguments) ---
DEFAULT_LOG_LEVEL: str = "INFO"  # overwritten by logging_setup.py if arg passed
LOG_TO_CONSOLE: bool = True
LOG_TO_FILE: bool = True
LOG_MAX_FILE_SIZE_MB: int = 5
LOG_BACKUP_COUNT: int = 3
# LOG_FILENAME and LOG_FORMAT are better in constants.py as they are more "constant"

# --- Database Configuration ---
# Default paths for databases if not found in user preferences.
# These are more like "hints" if user preferences are empty.
# The actual active paths are managed by PreferencesDialog and ProjectManager.
# User's app data directory is dynamically determined by helpers.get_app_data_directory.
# DEFAULT_NIST_SQLITE_DB_NAME = "nist_asd_default.sqlite" # Example name if you bundle one
# DEFAULT_USER_CUSTOM_DB_NAME = "user_lines.sqlite" # From constants.py

# --- Feature Flags (Example) ---
# Allows enabling/disabling experimental features without code changes (if read at startup)
ENABLE_EXPERIMENTAL_CHEMOMETRICS_UI: bool = True
ENABLE_ONLINE_NIST_SEARCH: bool = True # Depends on astroquery

# --- API Keys or External Service URLs (Placeholders) ---
# If your application interacts with external services.
# IMPORTANT: Do NOT commit real API keys to version control. Use environment variables or config files.
# NIST_ASD_BASE_URL = "https://physics.nist.gov/PhysRefData/ASD/lines_form.html" # For reference

# --- Default Analysis Parameters (Fallback if not in project/user prefs) ---
# These are distinct from the defaults in default_project_params.json, which are for *new projects*.
# These app_config defaults could be used if even the default_project_params.json is missing
# or for parts of the app not tied to a project's settings.
APP_DEFAULT_ID_TOLERANCE_NM: float = 0.15
APP_DEFAULT_PEAK_PROMINENCE: float = 0.05

# --- UI Behavior ---
# Example:
# MAX_SPECTRA_IN_MEMORY_BEFORE_WARNING = 1000
# DEFAULT_THEME = "SystemDefault" # Overridden by user preferences


def get_icon_path(icon_name: str) -> str:
    """
    Helper function to get the absolute path to an icon.
    Assumes icons are in team404/assets/icons/
    This should ideally use Qt's QRC resource system for bundled apps.
    """
    # Assuming this file (app_config.py) is in team404/
    current_dir = os.path.dirname(os.path.abspath(__file__)) # team404/
    assets_dir = os.path.join(current_dir, "assets")
    icon_path = os.path.join(assets_dir, "icons", icon_name)
    if not os.path.exists(icon_path):
        logging.getLogger(__name__).warning(f"Icon not found at expected path: {icon_path}")
        return "" # Return empty string or a placeholder icon path
    return icon_path


# --- Load Environment-Specific Config (Advanced) ---
# You could load additional config from a .env file or environment variables
# for sensitive data or deployment-specific settings.
# Example using python-dotenv (requires `pip install python-dotenv`):
# from dotenv import load_dotenv
# load_dotenv() # Loads variables from .env file into environment
# API_KEY = os.getenv("MY_API_KEY")

if __name__ == '__main__':
    # Print some config values for verification
    print(f"Application Name (from app_config): {APP_NAME}")
    print(f"Default Log Level: {DEFAULT_LOG_LEVEL}")
    print(f"Feature Flag - Experimental Chemometrics UI: {ENABLE_EXPERIMENTAL_CHEMOMETRICS_UI}")
    print(f"Icon path for 'app_icon.png': {get_icon_path('app_icon.png')}")

    # Test how paths are constructed if this file is in team404/
    print(f"Current file location: {os.path.abspath(__file__)}")
    print(f"Parent of current file (should be team404/): {os.path.dirname(os.path.abspath(__file__))}")
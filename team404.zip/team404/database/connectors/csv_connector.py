# team404/database/connectors/csv_connector.py

import logging
from typing import List, Dict, Optional, Any
from pathlib import Path
import pandas as pd
from .base_connector import BaseConnector

logger = logging.getLogger(__name__)

class CSVConnector(BaseConnector):
    def __init__(self, path: str, mapping: Dict[str, str], delimiter: str = ','):
        super().__init__(path, mapping)
        self.delimiter = delimiter
        self.data: Optional[pd.DataFrame] = None

    def connect(self) -> bool:
        # ... (this method is unchanged) ...
        try:
            self.data = pd.read_csv(self.db_path, delimiter=self.delimiter, comment='#', skipinitialspace=True)
            self.data.columns = [str(col).strip().lower() for col in self.data.columns]
            self.column_mapping = {k: v.strip().lower() for k, v in self.column_mapping.items()}
            self._is_connected = True
            logger.info(f"Successfully loaded CSV data from: {self.db_path}")
            return True
        except Exception as e:
            logger.error(f"Error loading CSV file {self.db_path}: {e}"); self.close(); return False

    def close(self) -> None:
        # ... (this method is unchanged) ...
        self.data = None; self._is_connected = False
        logger.info(f"CSV data released for: {self.db_path}")

    def get_schema(self) -> List[str]:
        # ... (this method is unchanged) ...
        if self.data is not None: return list(self.data.columns)
        try: return list(pd.read_csv(self.db_path, delimiter=self.delimiter, nrows=0, comment='#').columns)
        except Exception: return []

    # ADDED: Implementation of the new required method for CSV files.
    def get_available_elements_stages(self) -> Dict[str, List[str]]:
        """Finds unique element/stage combinations from the mapped columns."""
        if not self.is_connected() or self.data is None:
            return {}

        el_col = self.column_mapping.get('element')
        stage_col = self.column_mapping.get('ion_stage')

        if not el_col or el_col not in self.data.columns or \
           not stage_col or stage_col not in self.data.columns:
            logger.warning("Cannot get elements/stages from CSV: Element or Ion Stage columns are not mapped or do not exist.")
            return {}

        try:
            # Get unique pairs, drop any rows where element or stage is missing
            unique_pairs = self.data[[el_col, stage_col]].dropna().drop_duplicates()
            
            # Group by element and aggregate stages into a list
            grouped = unique_pairs.groupby(el_col)[stage_col].apply(list)
            
            # Convert to a standard dictionary and sort stages
            available = grouped.to_dict()
            for el in available:
                available[el].sort()
            return dict(sorted(available.items()))
        except Exception as e:
            logger.error(f"Error extracting elements/stages from CSV data: {e}")
            return {}

    def query_lines(self, wavelength_center: float, tolerance_nm: float,
                    elements_filter: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        # ... (this method is unchanged) ...
        if not self.is_connected() or self.data is None: return []
        wl_col = self.column_mapping.get('wavelength_nm'); el_col = self.column_mapping.get('element')
        if not wl_col or wl_col not in self.data.columns: logger.warning(f"Query failed: Wavelength column '{wl_col}' not in CSV."); return []
        
        self.data[wl_col] = pd.to_numeric(self.data[wl_col], errors='coerce')
        wl_min = wavelength_center - tolerance_nm; wl_max = wavelength_center + tolerance_nm
        mask = self.data[wl_col].between(wl_min, wl_max)
        if elements_filter and el_col and el_col in self.data.columns:
            element_mask = self.data[el_col].astype(str).str.lower().isin([el.lower() for el in elements_filter])
            mask &= element_mask
        filtered_df = self.data[mask]
        results = [line_data for _, row in filtered_df.iterrows() if (line_data := self._row_to_dict(row))]
        return results
        
    def _row_to_dict(self, row: pd.Series) -> Optional[Dict[str, Any]]:
        # ... (this method is unchanged) ...
        from ...utils.helpers import robust_float_conversion, robust_int_conversion
        line_data = {"source_db": f"CSV ({Path(self.db_path).name})"}
        for key, col_name in self.column_mapping.items():
            if col_name in row.index and not pd.isna(value := row[col_name]):
                if key in ['wavelength_nm', 'Aki', 'Ek_ev', 'Ei_ev']: line_data[key] = robust_float_conversion(value)
                elif key in ['gk', 'gi']: line_data[key] = robust_int_conversion(value)
                else: line_data[key] = str(value)
        if not line_data.get('wavelength_nm') or not line_data.get('element'): return None
        return line_data
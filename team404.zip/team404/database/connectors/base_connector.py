# team404/database/connectors/base_connector.py

import logging
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

class BaseConnector(ABC):
    def __init__(self, path: str, mapping: Dict[str, str]):
        self.db_path = path
        self.column_mapping = mapping
        self._is_connected = False
        logger.info(f"Initialized {self.__class__.__name__} for path: {path}")

    @abstractmethod
    def connect(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def close(self) -> None:
        raise NotImplementedError

    def is_connected(self) -> bool:
        return self._is_connected

    @abstractmethod
    def get_schema(self) -> List[str]:
        raise NotImplementedError

    # ADDED: New abstract method required for all connectors.
    @abstractmethod
    def get_available_elements_stages(self) -> Dict[str, List[str]]:
        """
        Scans the database and returns a dictionary of all unique elements
        and their available ionization stages.
        Example: {"Fe": ["I", "II"], "Ca": ["II"]}
        """
        raise NotImplementedError

    @abstractmethod
    def query_lines(self, wavelength_center: float, tolerance_nm: float,
                    elements_filter: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        raise NotImplementedError
# team404/database/connectors/sqlite_connector.py

import sqlite3
import logging
from typing import List, Dict, Optional, Any
from pathlib import Path
from .base_connector import BaseConnector

logger = logging.getLogger(__name__)

class SQLiteConnector(BaseConnector):
    def __init__(self, path: str, mapping: Dict[str, str]):
        super().__init__(path, mapping)
        self.conn: Optional[sqlite3.Connection] = None
        self.cursor: Optional[sqlite3.Cursor] = None
        self.available_tables: List[str] = []

    def connect(self) -> bool:
        # ... (this method is unchanged) ...
        if self._is_connected and self.conn: return True
        try:
            self.conn = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True); self.conn.row_factory = sqlite3.Row
            self.cursor = self.conn.cursor(); self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            self.available_tables = [row[0] for row in self.cursor.fetchall()]
            if not self.available_tables: raise ConnectionError("SQLite database contains no tables.")
            self._is_connected = True
            logger.info(f"Successfully connected to SQLite DB: {self.db_path}. Found tables: {self.available_tables}")
            return True
        except sqlite3.Error as e:
            logger.error(f"Error connecting to SQLite database {self.db_path}: {e}"); self.close(); return False

    def close(self) -> None:
        # ... (this method is unchanged) ...
        if self.conn: self.conn.close()
        self._is_connected = False; self.conn = None; self.cursor = None
        logger.info(f"SQLite connection closed for: {self.db_path}")

    def get_schema(self) -> List[str]:
        # ... (this method is unchanged) ...
        if not self.is_connected() or not self.cursor or not self.available_tables: return []
        try:
            table_name = self.available_tables[0]
            self.cursor.execute(f'PRAGMA table_info("{table_name}")')
            return [row['name'] for row in self.cursor.fetchall()]
        except sqlite3.Error as e:
            logger.error(f"Error getting schema from SQLite DB: {e}"); return []

    # ADDED: Implementation of the new required method.
    def get_available_elements_stages(self) -> Dict[str, List[str]]:
        """Parses table names (e.g., 'Fe_I', 'Ca_II') to find available elements and stages."""
        if not self.is_connected():
            return {}
        
        available = {}
        for table_name in self.available_tables:
            parts = table_name.split('_')
            if len(parts) >= 2:
                el, stage = parts[0], parts[1]
                if el not in available:
                    available[el] = []
                if stage not in available[el]:
                    available[el].append(stage)
        
        for el in available:
            available[el].sort()
        return dict(sorted(available.items()))

    def query_lines(self, wavelength_center: float, tolerance_nm: float,
                    elements_filter: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        # ... (this method is unchanged) ...
        if not self.is_connected() or not self.cursor: return []
        wl_col = self.column_mapping.get('wavelength_nm'); el_col = self.column_mapping.get('element')
        if not wl_col: logger.warning("Query failed: 'wavelength_nm' is not mapped."); return []
        results: List[Dict[str, Any]] = []; wl_min = wavelength_center - tolerance_nm; wl_max = wavelength_center + tolerance_nm
        for table_name in self.available_tables:
            try:
                query = f'SELECT * FROM "{table_name}" WHERE "{wl_col}" BETWEEN ? AND ?'; params: List[Any] = [wl_min, wl_max]
                if elements_filter and el_col:
                    # This logic could be improved to only query relevant tables, but it works for filtering.
                    placeholders = ', '.join('?' for _ in elements_filter)
                    query += f' AND "{el_col}" IN ({placeholders})'; params.extend(elements_filter)
                self.cursor.execute(query, tuple(params))
                for row in self.cursor.fetchall():
                    if line_data := self._row_to_dict(row): results.append(line_data)
            except sqlite3.Error as e:
                logger.error(f"Error querying table {table_name} in SQLite DB: {e}"); continue
        return results

    def _row_to_dict(self, row: sqlite3.Row) -> Optional[Dict[str, Any]]:
        # ... (this method is unchanged) ...
        from ...utils.helpers import robust_float_conversion, robust_int_conversion
        line_data = {"source_db": f"SQLite ({Path(self.db_path).name})"}
        for key, col_name in self.column_mapping.items():
            if col_name in row.keys():
                value = row[col_name]
                if key in ['wavelength_nm', 'Aki', 'Ek_ev', 'Ei_ev']: line_data[key] = robust_float_conversion(value)
                elif key in ['gk', 'gi']: line_data[key] = robust_int_conversion(value)
                else: line_data[key] = str(value) if value is not None else None
        if not line_data.get('wavelength_nm') or not line_data.get('element'): return None
        return line_data
# team404/database/user_custom_db.py

"""
Manages a user-specific custom spectral line database.
Allows users to add, edit, and query their own curated lines.
This database is stored as an SQLite file.
"""

import sqlite3
import os
import logging
from typing import List, Dict, Optional, Any
from datetime import datetime

# Import from data_models using TYPE_CHECKING for hints
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ..core.data_models import ElementalLine # For type hinting and data structure

logger = logging.getLogger(__name__)

# Define the schema for the user's custom database table
USER_DB_TABLE_NAME = "user_spectral_lines"
USER_DB_SCHEMA = f"""
CREATE TABLE IF NOT EXISTS {USER_DB_TABLE_NAME} (
    line_id INTEGER PRIMARY KEY AUTOINCREMENT,
    wavelength_nm REAL NOT NULL,
    element TEXT NOT NULL,
    ion_stage TEXT NOT NULL, -- e.g., "I", "II"
    Aki REAL,
    Ei_ev REAL,
    Ek_ev REAL,
    gi INTEGER,
    gk INTEGER,
    relative_intensity_user REAL, -- User's estimate or observation
    source_reference TEXT, -- Where the user got this line data from
    notes TEXT,
    date_added TEXT,
    date_modified TEXT,
    is_override INTEGER DEFAULT 0, -- 0 for supplemental, 1 to potentially override main DB
    user_flags TEXT, -- e.g., "verified", "tentative"
    UNIQUE (wavelength_nm, element, ion_stage) -- Prevent exact duplicates
);
"""

class UserCustomDB:
    """
    Manages a user's custom SQLite database for spectral lines.
    """
    def __init__(self, db_filepath: str):
        """
        Initializes the UserCustomDB.

        Args:
            db_filepath: Path to the SQLite file for the user's custom database.
                         It will be created if it doesn't exist.
        """
        self.db_filepath = db_filepath
        self.conn: Optional[sqlite3.Connection] = None
        self.cursor: Optional[sqlite3.Cursor] = None
        self._is_connected: bool = False
        self._ensure_db_and_table_exists()

    def _ensure_db_and_table_exists(self) -> bool:
        """Ensures the database file and the required table exist."""
        if not self.connect():
            return False
        try:
            if self.cursor:
                self.cursor.execute(USER_DB_SCHEMA)
                self.conn.commit()
                logger.info(f"Ensured table '{USER_DB_TABLE_NAME}' exists in {self.db_filepath}.")
                return True
        except sqlite3.Error as e:
            logger.error(f"Error ensuring table in user custom DB {self.db_filepath}: {e}")
            return False
        # No need to close connection here, it's managed by connect/close methods
        return False # Should not reach here if connect() succeeded

    def connect(self) -> bool:
        """Establishes connection to the SQLite database."""
        if self._is_connected and self.conn:
            return True
        try:
            # Create directory if it doesn't exist
            db_dir = os.path.dirname(self.db_filepath)
            if db_dir and not os.path.exists(db_dir):
                os.makedirs(db_dir, exist_ok=True)

            self.conn = sqlite3.connect(self.db_filepath)
            self.conn.row_factory = sqlite3.Row # Access columns by name
            self.cursor = self.conn.cursor()
            self._is_connected = True
            logger.debug(f"Successfully connected to user custom DB: {self.db_filepath}")
            return True
        except sqlite3.Error as e:
            logger.error(f"Error connecting to user custom DB {self.db_filepath}: {e}")
            self.conn = None
            self.cursor = None
            self._is_connected = False
            return False

    def close(self):
        """Closes the SQLite database connection."""
        if self.conn:
            self.conn.close()
            self._is_connected = False
            self.conn = None
            self.cursor = None
            logger.debug("User custom DB connection closed.")

    def is_connected(self) -> bool:
        return self._is_connected

    def add_line(self, line_data: 'ElementalLine',
                 source_reference: Optional[str] = None,
                 notes: Optional[str] = None,
                 is_override: bool = False,
                 user_flags: Optional[str] = None,
                 relative_intensity_user: Optional[float] = None
                 ) -> Optional[int]:
        """
        Adds a new spectral line to the user's custom database.

        Args:
            line_data: An ElementalLine object containing the core atomic data.
            source_reference: Reference for the data source (e.g., "NIST Online ASD", "Paper XYZ").
            notes: User's personal notes about this line.
            is_override: If True, this line might be prioritized over main DB lines.
            user_flags: Custom flags (e.g., comma-separated string like "verified, strong").
            relative_intensity_user: User's observed/estimated relative intensity for this line.

        Returns:
            The row ID of the newly inserted line, or None if insertion failed.
        """
        if not self.connect() or not self.cursor:
            return None

        now_iso = datetime.now().isoformat()
        sql = f"""
        INSERT INTO {USER_DB_TABLE_NAME} (
            wavelength_nm, element, ion_stage, Aki, Ei_ev, Ek_ev, gi, gk,
            relative_intensity_user, source_reference, notes, date_added, date_modified,
            is_override, user_flags
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        params = (
            line_data.wavelength_nm, line_data.element, line_data.ion_stage,
            line_data.Aki, line_data.Ei_ev, line_data.Ek_ev, line_data.gi, line_data.gk,
            relative_intensity_user, source_reference, notes, now_iso, now_iso,
            1 if is_override else 0, user_flags
        )
        try:
            self.cursor.execute(sql, params)
            self.conn.commit()
            last_row_id = self.cursor.lastrowid
            logger.info(f"Added line for {line_data.element} {line_data.ion_stage} at {line_data.wavelength_nm:.3f} nm to user DB. ID: {last_row_id}")
            return last_row_id
        except sqlite3.IntegrityError: # Handles UNIQUE constraint violation
            logger.warning(f"Line for {line_data.element} {line_data.ion_stage} at {line_data.wavelength_nm:.3f} nm already exists in user DB. Not added.")
            return None
        except sqlite3.Error as e:
            logger.error(f"Error adding line to user DB: {e}")
            return None

    def update_line(self, line_id: int, updates: Dict[str, Any]) -> bool:
        """
        Updates an existing line in the user's custom database.

        Args:
            line_id: The ID of the line to update.
            updates: A dictionary where keys are column names and values are new values.
                     'date_modified' will be updated automatically.

        Returns:
            True if update was successful, False otherwise.
        """
        if not self.connect() or not self.cursor:
            return False
        if not updates:
            logger.warning("No updates provided for line.")
            return False

        # Ensure line_id is not updated, and update date_modified
        updates.pop('line_id', None)
        updates['date_modified'] = datetime.now().isoformat()

        set_clauses = ", ".join([f"{key} = ?" for key in updates.keys()])
        sql = f"UPDATE {USER_DB_TABLE_NAME} SET {set_clauses} WHERE line_id = ?"
        
        params = list(updates.values()) + [line_id]
        
        try:
            self.cursor.execute(sql, tuple(params))
            self.conn.commit()
            if self.cursor.rowcount == 0:
                logger.warning(f"No line found with ID {line_id} to update in user DB.")
                return False
            logger.info(f"Updated line ID {line_id} in user DB.")
            return True
        except sqlite3.Error as e:
            logger.error(f"Error updating line ID {line_id} in user DB: {e}")
            return False

    def delete_line(self, line_id: int) -> bool:
        """Deletes a line from the user's custom database by its ID."""
        if not self.connect() or not self.cursor:
            return False
        
        sql = f"DELETE FROM {USER_DB_TABLE_NAME} WHERE line_id = ?"
        try:
            self.cursor.execute(sql, (line_id,))
            self.conn.commit()
            if self.cursor.rowcount == 0:
                logger.warning(f"No line found with ID {line_id} to delete in user DB.")
                return False
            logger.info(f"Deleted line ID {line_id} from user DB.")
            return True
        except sqlite3.Error as e:
            logger.error(f"Error deleting line ID {line_id} from user DB: {e}")
            return False

    def _row_to_elementalline_dict(self, row: sqlite3.Row) -> Dict[str, Any]:
        """Converts a SQLite row to a dictionary compatible with ElementalLine creation,
           and includes user DB specific fields."""
        from ..core.data_models import ElementalLine # Delayed import for runtime
        
        # Map DB columns to ElementalLine fields + user_db specific fields
        line_dict = {
            # ElementalLine core fields
            "wavelength_nm": row["wavelength_nm"],
            "element": row["element"],
            "ion_stage": row["ion_stage"],
            "Aki": row["Aki"],
            "Ei_ev": row["Ei_ev"],
            "Ek_ev": row["Ek_ev"],
            "gi": row["gi"],
            "gk": row["gk"],
            "relative_intensity_db": row["relative_intensity_user"], # Use user's intensity here
            "source_db": "UserCustomDB", # Mark source
            # User DB specific fields
            "user_db_line_id": row["line_id"],
            "user_db_source_reference": row["source_reference"],
            "user_db_notes": row["notes"],
            "user_db_date_added": row["date_added"],
            "user_db_date_modified": row["date_modified"],
            "user_db_is_override": bool(row["is_override"]),
            "user_db_user_flags": row["user_flags"],
        }
        return line_dict


    def query_lines_by_wavelength(
        self, wavelength_center: float, tolerance_nm: float,
        elements_list: Optional[List[str]] = None,
        ion_stages_dict: Optional[Dict[str, List[str]]] = None,
        only_overrides: bool = False
    ) -> List[Dict[str, Any]]: # Returns list of dicts matching ElementalLine structure + user fields
        """
        Queries lines from the user's custom database within a wavelength range.

        Args:
            wavelength_center: Center of the wavelength window.
            tolerance_nm: Half-width of the window (± nm).
            elements_list: Optional list of element symbols.
            ion_stages_dict: Optional dict of element: [stages].
            only_overrides: If True, only return lines marked as 'is_override'.

        Returns:
            A list of dictionaries, each representing a line compatible with ElementalLine
            plus user DB specific fields.
        """
        if not self.connect() or not self.cursor:
            return []

        wl_min = wavelength_center - tolerance_nm
        wl_max = wavelength_center + tolerance_nm
        
        base_query = f"SELECT * FROM {USER_DB_TABLE_NAME} WHERE wavelength_nm BETWEEN ? AND ?"
        params: List[Any] = [wl_min, wl_max]

        conditions = []
        if elements_list:
            el_conditions = []
            for el in elements_list:
                if ion_stages_dict and el in ion_stages_dict and ion_stages_dict[el]:
                    stage_placeholders = ', '.join(['?'] * len(ion_stages_dict[el]))
                    el_conditions.append(f"(element = ? AND ion_stage IN ({stage_placeholders}))")
                    params.append(el)
                    params.extend(ion_stages_dict[el])
                else: # All stages for this element
                    el_conditions.append("element = ?")
                    params.append(el)
            if el_conditions:
                conditions.append(f"({' OR '.join(el_conditions)})")
        
        if only_overrides:
            conditions.append("is_override = 1")

        if conditions:
            base_query += " AND " + " AND ".join(conditions)
        
        query_results = []
        try:
            self.cursor.execute(base_query, tuple(params))
            for row in self.cursor.fetchall():
                query_results.append(self._row_to_elementalline_dict(row))
        except sqlite3.Error as e:
            logger.error(f"Error querying user custom DB: {e}")
        
        return query_results

    def get_all_lines(self) -> List[Dict[str, Any]]:
        """Retrieves all lines from the user's custom database."""
        if not self.connect() or not self.cursor: return []
        
        query_results = []
        try:
            self.cursor.execute(f"SELECT * FROM {USER_DB_TABLE_NAME} ORDER BY element, ion_stage, wavelength_nm")
            for row in self.cursor.fetchall():
                query_results.append(self._row_to_elementalline_dict(row))
        except sqlite3.Error as e:
            logger.error(f"Error retrieving all lines from user custom DB: {e}")
        return query_results


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
    
    test_db_file = "test_user_custom_db.sqlite"
    if os.path.exists(test_db_file):
        os.remove(test_db_file)

    # Requires ElementalLine from data_models for instantiation
    from ..core.data_models import ElementalLine as ElementalLineDM

    user_db = UserCustomDB(db_filepath=test_db_file)
    assert user_db.is_connected()

    print("\n--- Testing User Custom DB ---")

    # Add lines
    line1_data = ElementalLineDM(wavelength_nm=404.581, element="Hg", ion_stage="I", Aki=1.0e7, Ek_ev=5.0)
    line1_id = user_db.add_line(line1_data, source_reference="Manual Entry", notes="Strong Hg line", relative_intensity_user=1000.0)
    assert line1_id is not None
    print(f"Added line 1, ID: {line1_id}")

    line2_data = ElementalLineDM(wavelength_nm=253.652, element="Hg", ion_stage="I", Aki=8.0e7, Ek_ev=4.886)
    line2_id = user_db.add_line(line2_data, source_reference="NIST Online", notes="Resonance line", is_override=True, user_flags="verified,intense")
    assert line2_id is not None
    print(f"Added line 2, ID: {line2_id}")
    
    # Try adding a duplicate
    line_dup_id = user_db.add_line(line1_data) # Same wl, el, ion
    assert line_dup_id is None # Should fail due to UNIQUE constraint
    print("Tried adding duplicate line (expected failure): OK")


    # Query lines
    print("\nQuerying Hg lines around 404.6 nm:")
    hg_lines = user_db.query_lines_by_wavelength(404.6, 0.1, elements_list=["Hg"], ion_stages_dict={"Hg":["I"]})
    assert len(hg_lines) == 1
    print(f"  Found: {hg_lines[0]['element']} {hg_lines[0]['ion_stage']} at {hg_lines[0]['wavelength_nm']:.3f} nm, Notes: {hg_lines[0]['user_db_notes']}")
    assert hg_lines[0]['user_db_line_id'] == line1_id

    print("\nQuerying only override lines around 253.0 nm:")
    override_lines = user_db.query_lines_by_wavelength(253.0, 1.0, only_overrides=True)
    assert len(override_lines) == 1
    print(f"  Found override: {override_lines[0]['element']} {override_lines[0]['ion_stage']} {override_lines[0]['wavelength_nm']:.3f} nm")
    assert override_lines[0]['user_db_line_id'] == line2_id


    # Update a line
    print("\nUpdating line ID 1 notes:")
    update_success = user_db.update_line(line1_id, {"notes": "Very strong Hg line (updated)", "relative_intensity_user": 1200.0})
    assert update_success
    updated_lines = user_db.query_lines_by_wavelength(404.6, 0.1)
    assert updated_lines[0]['user_db_notes'] == "Very strong Hg line (updated)"
    assert updated_lines[0]['relative_intensity_db'] == 1200.0
    print(f"  Updated notes: {updated_lines[0]['user_db_notes']}")


    # Get all lines
    print("\nGetting all lines:")
    all_user_lines = user_db.get_all_lines()
    assert len(all_user_lines) == 2
    for l_dict in all_user_lines:
        print(f"  ID: {l_dict['user_db_line_id']}, El: {l_dict['element']}, Wl: {l_dict['wavelength_nm']:.3f}, Override: {l_dict['user_db_is_override']}")

    # Delete a line
    print(f"\nDeleting line ID {line1_id}:")
    delete_success = user_db.delete_line(line1_id)
    assert delete_success
    all_user_lines_after_delete = user_db.get_all_lines()
    assert len(all_user_lines_after_delete) == 1
    assert all_user_lines_after_delete[0]['user_db_line_id'] == line2_id
    print("  Line deleted.")

    user_db.close()
    assert not user_db.is_connected()

    # Clean up test file
    if os.path.exists(test_db_file):
        os.remove(test_db_file)
    print("\nUser Custom DB tests completed.")
# team404/database/nist_db_connector.py

"""
Provides connectivity and querying capabilities for NIST-like spectral line databases,
supporting both SQLite and CSV file sources.
"""

import sqlite3
import csv
import os
import logging
from typing import List, Dict, Optional, Any, Union
import numpy as np
import pandas as pd # For easier CSV handling and potential in-memory indexing

# Import from data_models using TYPE_CHECKING for hints
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ..core.data_models import ElementalLine


logger = logging.getLogger(__name__)

# Standard NIST ASD column names (can be customized or expanded)
# These are typical column names users might have in their SQLite DB or CSVs.
# The exact names might vary based on how users prepared their data.
# We'll try to be somewhat flexible or require users to match common ones.
NIST_COMMON_COLUMNS = [
    "ritz_wavelength_vac_nm", # Preferred for vacuum wavelengths
    "obs_wavelength_air_nm",  # Observed air wavelengths
    "element",
    "spectrum", # Ionization stage (e.g., I, II, III)
    "aki",      # Transition probability (s^-1)
    "ei_ev",    # Lower energy level (eV)
    "ek_ev",    # Upper energy level (eV)
    "gi",       # Statistical weight of lower level
    "gk",       # Statistical weight of upper level
    "type",     # Line type (e.g., 'L', 'Ls')
    "intensity_estimate" # Relative intensity string from NIST (e.g., "1000", "50 bl")
]
# Map common user column names to our internal 'ElementalLine' attribute names
# This allows some flexibility in user's database/CSV column naming.
COLUMN_MAPPING = {
    # ElementalLine attribute : [list of possible user column names (lowercase)]
    "wavelength_nm": ["ritz_wavelength_vac_nm", "obs_wavelength_air_nm", "wavelength", "wl", "lambda"],
    "element": ["element", "el"],
    "ion_stage": ["spectrum", "ion", "ionization_stage", "stage"],
    "Aki": ["aki", "a_ki", "transition_probability"],
    "Ei_ev": ["ei_ev", "ei(ev)", "e_i_ev", "lower_energy_level_ev"],
    "Ek_ev": ["ek_ev", "ek(ev)", "e_k_ev", "upper_energy_level_ev"],
    "gi": ["gi", "g_i", "lower_stat_weight", "stat_weight_lower"],
    "gk": ["gk", "g_k", "upper_stat_weight", "stat_weight_upper"],
    "relative_intensity_db_str": ["intensity_estimate", "relative_intensity", "rel_int", "intensity"] # Store as string first
}


def _try_cast_float(value: Any, default: Optional[float] = None) -> Optional[float]:
    if value is None: return default
    try:
        return float(value)
    except (ValueError, TypeError):
        # Try to remove non-numeric characters like 'bl', 'sh', 'w' from intensity strings
        if isinstance(value, str):
            cleaned_value = ''.join(filter(lambda x: x.isdigit() or x == '.', value.split()[0]))
            try:
                return float(cleaned_value)
            except (ValueError, TypeError):
                return default
        return default

def _try_cast_int(value: Any, default: Optional[int] = None) -> Optional[int]:
    if value is None: return default
    try:
        return int(float(value)) # float() first to handle "10.0"
    except (ValueError, TypeError):
        return default


class NISTDBConnector:
    """
    Connects to and queries NIST-like spectral line data from SQLite or CSV sources.
    """
    def __init__(self, db_type: str = "sqlite", db_path: Optional[str] = None):
        """
        Initializes the connector.

        Args:
            db_type: "sqlite" or "csv".
            db_path: Path to the SQLite file or the root directory of CSV files.
        """
        self.db_type = db_type.lower()
        self.db_path = db_path
        self.conn: Optional[sqlite3.Connection] = None
        self.cursor: Optional[sqlite3.Cursor] = None
        self._is_connected: bool = False

        # For CSV type, we might load data into memory (e.g., pandas DataFrames)
        self.csv_data_cache: Dict[str, pd.DataFrame] = {} # Key: "element_ionstage" (e.g., "Fe_I")

        if self.db_path:
            if self.db_type == "sqlite":
                self.connect()
            elif self.db_type == "csv":
                self._preload_csv_data_if_path_valid() # Optional: preload or load on demand
        else:
            logger.warning("NISTDBConnector initialized without a db_path. Queries will fail.")


    def connect(self) -> bool:
        """Establishes connection to the SQLite database."""
        if self.db_type != "sqlite" or not self.db_path:
            logger.error("Cannot connect: DB type is not SQLite or path is not set.")
            return False
        if self._is_connected and self.conn:
            return True
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row # Access columns by name
            self.cursor = self.conn.cursor()
            self._is_connected = True
            logger.info(f"Successfully connected to SQLite database: {self.db_path}")
            return True
        except sqlite3.Error as e:
            logger.error(f"Error connecting to SQLite database {self.db_path}: {e}")
            self.conn = None
            self.cursor = None
            self._is_connected = False
            return False

    def close(self):
        """Closes the SQLite database connection."""
        if self.db_type == "sqlite" and self.conn:
            self.conn.close()
            self._is_connected = False
            self.conn = None
            self.cursor = None
            logger.info("SQLite database connection closed.")

    def is_connected(self) -> bool:
        return self._is_connected if self.db_type == "sqlite" else (bool(self.csv_data_cache) if self.db_type == "csv" else False)


    def _get_db_column_name(self, table_columns: List[str], target_elemental_line_attr: str) -> Optional[str]:
        """Finds the actual column name in the DB/CSV that maps to our ElementalLine attribute."""
        if target_elemental_line_attr not in COLUMN_MAPPING:
            return None
        possible_db_names = COLUMN_MAPPING[target_elemental_line_attr]
        for db_name in possible_db_names:
            if db_name in table_columns:
                return db_name
            # Try case-insensitive match for flexibility
            for col in table_columns:
                if col.lower() == db_name.lower():
                    return col
        return None


    def _query_sqlite(
        self, wavelength_center: float, tolerance_nm: float,
        elements_list: Optional[List[str]] = None,
        ion_stages_dict: Optional[Dict[str, List[str]]] = None,
        min_aki: Optional[float] = None, min_rel_intensity: Optional[float] = None
    ) -> List['ElementalLine']:
        """Helper for querying SQLite database."""
        if not self.is_connected() or not self.cursor:
            logger.error("SQLite database not connected. Cannot query.")
            if not self.connect(): return [] # Attempt to reconnect

        # Dynamically import ElementalLine to avoid issues during module loading
        from ..core.data_models import ElementalLine as ElementalLineDM

        results: List[ElementalLineDM] = []
        wl_min = wavelength_center - tolerance_nm
        wl_max = wavelength_center + tolerance_nm

        # Determine tables to query (e.g., "Fe_I", "Ca_II", or all tables if elements_list is None)
        tables_to_query = []
        if elements_list:
            for el in elements_list:
                if ion_stages_dict and el in ion_stages_dict:
                    for stage_roman in ion_stages_dict[el]:
                        tables_to_query.append(f"{el}_{stage_roman}") # Assumes table names like Fe_I, Ca_II
                else: # All stages for this element
                    # Need to get all tables matching el_*
                    self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                    all_tables = [row[0] for row in self.cursor.fetchall()]
                    for table_name in all_tables:
                        if table_name.lower().startswith(el.lower() + "_"):
                            tables_to_query.append(table_name)
        else: # Query all tables (could be slow, better to list elements or have an 'all_lines' table)
            self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables_to_query = [row[0] for row in self.cursor.fetchall()]
            if not tables_to_query:
                logger.warning("No tables found in the SQLite database.")
                return []
        
        if not tables_to_query:
             logger.debug(f"No specific tables matched for query elements: {elements_list}, stages: {ion_stages_dict}")
             return []


        for table_name in set(tables_to_query): # Use set to avoid duplicate queries
            try:
                self.cursor.execute(f"PRAGMA table_info('{table_name}')")
                table_cols_info = self.cursor.fetchall()
                if not table_cols_info:
                    logger.debug(f"Table '{table_name}' not found or empty. Skipping.")
                    continue
                
                actual_table_column_names = [col_info['name'] for col_info in table_cols_info]

                # Determine actual column names for querying based on COLUMN_MAPPING
                wl_col_db = self._get_db_column_name(actual_table_column_names, "wavelength_nm")
                aki_col_db = self._get_db_column_name(actual_table_column_names, "Aki")
                rel_int_col_db = self._get_db_column_name(actual_table_column_names, "relative_intensity_db_str")

                if not wl_col_db:
                    logger.warning(f"Could not find a suitable wavelength column in table '{table_name}'. Skipping.")
                    continue

                query = f"SELECT * FROM \"{table_name}\" WHERE \"{wl_col_db}\" BETWEEN ? AND ?"
                params: List[Any] = [wl_min, wl_max]

                if min_aki is not None and aki_col_db:
                    query += f" AND \"{aki_col_db}\" >= ?"
                    params.append(min_aki)
                
                # Relative intensity filtering is tricky due to string format (e.g., "1000 bl")
                # If min_rel_intensity is used, it assumes the column is numeric or pre-cleaned
                # For now, this is a simple numeric comparison if the column is found and numeric
                if min_rel_intensity is not None and rel_int_col_db:
                    # This part is simplified. Robust rel_int filtering needs parsing the string.
                    # We try to cast to float here for simplicity, but a dedicated parsing logic is better.
                    # The query should ideally handle this by pre-cleaning the column if possible.
                    # query += f" AND CAST(\"{rel_int_col_db}\" AS REAL) >= ?" # This might not work for "1000 bl"
                    # For now, we will filter post-query based on the parsed float from rel_int_col_db
                    pass


                self.cursor.execute(query, tuple(params))
                for row_dict in self.cursor.fetchall(): # sqlite3.Row objects behave like dicts
                    # Create ElementalLine object by mapping columns
                    line_data = {}
                    for el_attr, possible_db_names in COLUMN_MAPPING.items():
                        found_val = None
                        for db_name_variant in possible_db_names:
                            if db_name_variant in row_dict: # Check if key exists (case sensitive from sqlite.Row)
                                found_val = row_dict[db_name_variant]
                                break
                            # Check case-insensitive as well (sqlite.Row keys are case sensitive as per column def)
                            for actual_col_name_in_row in row_dict.keys():
                                if actual_col_name_in_row.lower() == db_name_variant.lower():
                                    found_val = row_dict[actual_col_name_in_row]
                                    break
                            if found_val is not None: break
                        
                        # Type casting
                        if el_attr == "wavelength_nm": line_data[el_attr] = _try_cast_float(found_val)
                        elif el_attr in ["Aki", "Ei_ev", "Ek_ev"]: line_data[el_attr] = _try_cast_float(found_val)
                        elif el_attr in ["gi", "gk"]: line_data[el_attr] = _try_cast_int(found_val)
                        elif el_attr == "relative_intensity_db_str": line_data["relative_intensity_db_str"] = str(found_val) if found_val else None # Store original string
                        else: line_data[el_attr] = str(found_val) if found_val is not None else None # Element, IonStage as str

                    # Post-query filter for relative intensity if requested
                    if min_rel_intensity is not None:
                        rel_int_val_parsed = _try_cast_float(line_data.get("relative_intensity_db_str"))
                        if rel_int_val_parsed is None or rel_int_val_parsed < min_rel_intensity:
                            continue # Skip this line

                    # Ensure essential fields are present
                    if line_data.get("wavelength_nm") is None or line_data.get("element") is None or line_data.get("ion_stage") is None:
                        logger.debug(f"Skipping row due to missing essential fields (wl, el, ion): {row_dict}")
                        continue

                    # Add relative_intensity_db (float) after parsing the string
                    line_data["relative_intensity_db"] = _try_cast_float(line_data.get("relative_intensity_db_str"))


                    results.append(ElementalLineDM(**line_data)) # Use ** to unpack dict into dataclass fields

            except sqlite3.Error as e:
                logger.error(f"Error querying table {table_name}: {e}")
            except Exception as ex: # Catch other potential errors like casting
                logger.error(f"Unexpected error processing table {table_name}: {ex}")
        return results


    def _preload_csv_data_if_path_valid(self):
        """Loads all CSV files from the specified directory structure into memory."""
        if not self.db_path or not os.path.isdir(self.db_path):
            logger.warning(f"CSV data path '{self.db_path}' is not a valid directory. Cannot preload CSV data.")
            return

        logger.info(f"Preloading CSV data from directory: {self.db_path}")
        self.csv_data_cache = {}
        try:
            for element_folder in os.listdir(self.db_path):
                element_folder_path = os.path.join(self.db_path, element_folder)
                if os.path.isdir(element_folder_path):
                    for csv_filename in os.listdir(element_folder_path):
                        if csv_filename.lower().endswith(".csv"):
                            ion_stage_name = os.path.splitext(csv_filename)[0] # e.g., Fe_I from Fe_I.csv
                            cache_key = f"{element_folder}_{ion_stage_name}" # e.g. Fe_Fe_I - could be just ion_stage_name if unique
                                                                            # Using element_folder for clarity in cache key e.g. Fe_I
                            
                            # More robust key: element_folder is 'Fe', ion_stage_name is 'Fe_I'. Key should be 'Fe_I'
                            # Assuming ion_stage_name from filename is like "ElementSymbol_RomanNumeral" e.g. "Fe_I"
                            # If filename is just "I.csv" inside "Fe" folder, then key is "Fe_I"
                            
                            # Let's assume filename itself is descriptive like "Fe_I.csv"
                            # So ion_stage_name derived (Fe_I) IS the cache key
                            
                            # Standardize cache key based on common formats like Fe_I, Ca_II
                            # Filename like "I.csv" inside "Fe" folder -> "Fe_I"
                            # Filename like "Fe_I.csv" inside "Fe" folder or root -> "Fe_I"
                            
                            # Simplified: assume filename = "Element_Stage.csv" e.g., "Fe_I.csv"
                            # Then cache_key will be "Fe_I"
                            # If filename is "I.csv" inside "Fe" folder, then cache key could be "Fe_I"
                            
                            # For now, using the filename (without .csv) as a part of the key, prefixed by element folder
                            # Example: db_path/Fe/I.csv -> cache_key Fe_I
                            # Example: db_path/Fe/Fe_I.csv -> cache_key Fe_Fe_I (This is a bit redundant)
                            # Let's refine cache key generation:
                            
                            # If ion_stage_name (from filename, e.g., "I", "II", or "Fe_I")
                            # If it already contains element symbol, use it. Otherwise, prefix.
                            if element_folder.lower() in ion_stage_name.lower(): # e.g. filename "Fe_I" in folder "Fe"
                                cache_key = ion_stage_name 
                            else: # e.g. filename "I" in folder "Fe"
                                cache_key = f"{element_folder}_{ion_stage_name}"


                            csv_file_path = os.path.join(element_folder_path, csv_filename)
                            try:
                                df = pd.read_csv(csv_file_path, comment='#', skipinitialspace=True)
                                # Normalize column names to lowercase for easier mapping
                                df.columns = [col.lower().strip() for col in df.columns]
                                self.csv_data_cache[cache_key] = df
                                logger.debug(f"Loaded and cached CSV: {csv_file_path} as {cache_key}")
                            except Exception as e:
                                logger.error(f"Error reading CSV file {csv_file_path}: {e}")
            logger.info(f"Finished preloading CSV data. Cached {len(self.csv_data_cache)} dataframes.")
        except Exception as e:
            logger.error(f"Error during CSV preloading process for path {self.db_path}: {e}")


    def _query_csv(
        self, wavelength_center: float, tolerance_nm: float,
        elements_list: Optional[List[str]] = None,
        ion_stages_dict: Optional[Dict[str, List[str]]] = None,
        min_aki: Optional[float] = None, min_rel_intensity: Optional[float] = None
    ) -> List['ElementalLine']:
        """Helper for querying preloaded CSV data (pandas DataFrames)."""
        if not self.csv_data_cache:
            logger.warning("CSV data cache is empty. Attempting to preload.")
            self._preload_csv_data_if_path_valid()
            if not self.csv_data_cache:
                logger.error("CSV data cache is still empty after preload attempt. Cannot query.")
                return []

        from ..core.data_models import ElementalLine as ElementalLineDM # Delayed import

        results: List[ElementalLineDM] = []
        wl_min = wavelength_center - tolerance_nm
        wl_max = wavelength_center + tolerance_nm

        # Determine which cache keys (dataframes) to query
        dfs_to_query: Dict[str, pd.DataFrame] = {} # cache_key: dataframe
        if elements_list:
            for el_query in elements_list: # e.g., "Fe" or "Ca"
                for stage_roman_query in (ion_stages_dict.get(el_query) if ion_stages_dict else [None]): # e.g., "I", "II", or None for all stages
                    for cache_key, df in self.csv_data_cache.items():
                        # Cache key might be "Fe_I", "Ca_II", etc.
                        # el_query "Fe", stage_roman_query "I" -> matches "Fe_I"
                        # el_query "Fe", stage_roman_query None -> matches "Fe_I", "Fe_II", etc.
                        parts = cache_key.split('_')
                        df_element = parts[0]
                        df_stage = parts[1] if len(parts) > 1 else None

                        if df_element.lower() == el_query.lower():
                            if stage_roman_query is None or (df_stage and df_stage.lower() == stage_roman_query.lower()):
                                dfs_to_query[cache_key] = df
        else: # Query all cached dataframes
            dfs_to_query = self.csv_data_cache
        
        if not dfs_to_query:
             logger.debug(f"No specific CSV dataframes matched for query elements: {elements_list}, stages: {ion_stages_dict}")
             return []

        for cache_key, df in dfs_to_query.items():
            actual_df_column_names = [col.lower() for col in df.columns] # Already lowercased during preload

            wl_col_df = self._get_db_column_name(actual_df_column_names, "wavelength_nm")
            aki_col_df = self._get_db_column_name(actual_df_column_names, "Aki")
            rel_int_col_df = self._get_db_column_name(actual_df_column_names, "relative_intensity_db_str")

            if not wl_col_df:
                logger.warning(f"Could not find a wavelength column in cached CSV '{cache_key}'. Skipping.")
                continue

            # Ensure wavelength column is numeric for filtering
            try:
                df_filtered = df[pd.to_numeric(df[wl_col_df], errors='coerce').between(wl_min, wl_max, inclusive='both')]
            except KeyError:
                 logger.warning(f"Wavelength column '{wl_col_df}' not found in dataframe for '{cache_key}' during numeric conversion. Skipping.")
                 continue


            if min_aki is not None and aki_col_df and aki_col_df in df_filtered.columns:
                df_filtered = df_filtered[pd.to_numeric(df_filtered[aki_col_df], errors='coerce') >= min_aki]
            
            # Post-query filter for relative intensity
            if min_rel_intensity is not None and rel_int_col_df and rel_int_col_df in df_filtered.columns:
                # Parse the relative intensity string to a float for comparison
                parsed_rel_int = df_filtered[rel_int_col_df].apply(lambda x: _try_cast_float(x, default=np.nan))
                df_filtered = df_filtered[parsed_rel_int >= min_rel_intensity]


            for _, row in df_filtered.iterrows():
                line_data = {}
                for el_attr, possible_db_names in COLUMN_MAPPING.items():
                    found_val = None
                    for db_name_variant in possible_db_names: # db_name_variant is already lowercase
                        if db_name_variant in actual_df_column_names: # df columns are lowercase
                            try:
                                found_val = row[db_name_variant]
                                break
                            except KeyError: # Should not happen if db_name_variant in actual_df_column_names
                                pass 
                    
                    # Type casting
                    if el_attr == "wavelength_nm": line_data[el_attr] = _try_cast_float(found_val)
                    elif el_attr in ["Aki", "Ei_ev", "Ek_ev"]: line_data[el_attr] = _try_cast_float(found_val)
                    elif el_attr in ["gi", "gk"]: line_data[el_attr] = _try_cast_int(found_val)
                    elif el_attr == "relative_intensity_db_str": line_data["relative_intensity_db_str"] = str(found_val) if not pd.isna(found_val) else None
                    else: line_data[el_attr] = str(found_val) if not pd.isna(found_val) else None # Element, IonStage as str

                if line_data.get("wavelength_nm") is None or line_data.get("element") is None or line_data.get("ion_stage") is None:
                    continue
                
                line_data["relative_intensity_db"] = _try_cast_float(line_data.get("relative_intensity_db_str"))
                results.append(ElementalLineDM(**line_data))
        return results


    def query_lines_by_wavelength(
        self, wavelength_center: float, tolerance_nm: float,
        elements_list: Optional[List[str]] = None, # e.g. ["Fe", "Ca"]
        ion_stages_dict: Optional[Dict[str, List[str]]] = None, # e.g. {"Ca": ["II"], "Fe": ["I", "II"]}
        min_aki: Optional[float] = None,
        min_rel_intensity: Optional[float] = None
    ) -> List['ElementalLine']: # Actually List[data_models.ElementalLine]
        """
        Queries spectral lines within a wavelength range from the configured database.

        Args:
            wavelength_center: Center of the wavelength window.
            tolerance_nm: Half-width of the window (± nm).
            elements_list: Optional list of element symbols to filter by (e.g., ["Fe", "Ca"]).
                           If None, queries for all available elements.
            ion_stages_dict: Optional dictionary specifying ion stages for particular elements.
                             e.g., {"Ca": ["II"], "Fe": ["I", "II"]}. If an element from
                             elements_list is not in this dict, all its stages are considered.
            min_aki: Minimum transition probability (A_ki) to include.
            min_rel_intensity: Minimum relative intensity (parsed from database string) to include.

        Returns:
            A list of ElementalLine objects matching the criteria.
        """
        logger.debug(f"Querying lines around {wavelength_center:.3f} ± {tolerance_nm:.3f} nm. "
                     f"Elements: {elements_list}, Stages: {ion_stages_dict}, "
                     f"Min Aki: {min_aki}, Min RelInt: {min_rel_intensity}")

        if self.db_type == "sqlite":
            return self._query_sqlite(wavelength_center, tolerance_nm, elements_list, ion_stages_dict, min_aki, min_rel_intensity)
        elif self.db_type == "csv":
            return self._query_csv(wavelength_center, tolerance_nm, elements_list, ion_stages_dict, min_aki, min_rel_intensity)
        else:
            logger.error(f"Unsupported database type: {self.db_type}")
            return []

    def get_available_elements_stages(self) -> Dict[str, List[str]]:
        """
        Returns a dictionary of available elements and their ion stages from the database.
        E.g., {"Fe": ["I", "II"], "Ca": ["I", "II"]}
        """
        available: Dict[str, List[str]] = {}
        if self.db_type == "sqlite":
            if not self.is_connected() or not self.cursor: self.connect()
            if not self.cursor: return {}
            
            self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            table_names = [row[0] for row in self.cursor.fetchall()]
            for table_name in table_names:
                parts = table_name.split('_') # Expect "Element_Stage" like "Fe_I"
                if len(parts) == 2:
                    el, stage = parts[0], parts[1]
                    if el not in available: available[el] = []
                    if stage not in available[el]: available[el].append(stage)

        elif self.db_type == "csv":
            if not self.csv_data_cache: self._preload_csv_data_if_path_valid()
            for cache_key in self.csv_data_cache.keys(): # e.g., "Fe_I", "Ca_II"
                parts = cache_key.split('_')
                if len(parts) == 2:
                    el, stage = parts[0], parts[1]
                    if el not in available: available[el] = []
                    if stage not in available[el]: available[el].append(stage)
        
        for el in available: available[el].sort() # Sort stages
        return dict(sorted(available.items())) # Sort elements


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
    
    # Create dummy data directory for testing
    test_db_dir = "test_nist_db_data"
    os.makedirs(test_db_dir, exist_ok=True)
    
    # --- Test with SQLite ---
    print("\n--- Testing SQLite Connector ---")
    sqlite_db_path = os.path.join(test_db_dir, "test_nist.db")
    if os.path.exists(sqlite_db_path): os.remove(sqlite_db_path) # Clean start

    conn_test = sqlite3.connect(sqlite_db_path)
    cur_test = conn_test.cursor()
    # Create Fe_I table
    cur_test.execute("""
    CREATE TABLE Fe_I (
        obs_wavelength_air_nm REAL, element TEXT, spectrum TEXT,
        Aki REAL, Ek_eV REAL, gk INTEGER, intensity_estimate TEXT
    )""")
    fe_i_data = [
        (248.327, "Fe", "I", 1.2e8, 5.00, 7, "1000"),
        (248.814, "Fe", "I", 8.0e7, 5.01, 5, "800 bl"),
        (300.001, "Fe", "I", 1.0e7, 3.00, 5, "50 sh") # For range test
    ]
    cur_test.executemany("INSERT INTO Fe_I VALUES (?,?,?,?,?,?,?)", fe_i_data)
    # Create Ca_II table
    cur_test.execute("""
    CREATE TABLE Ca_II (
        ritz_wavelength_vac_nm REAL, element TEXT, spectrum TEXT,
        Aki REAL, Ek_eV REAL, gk INTEGER, intensity_estimate TEXT
    )""")
    ca_ii_data = [
        (393.366, "Ca", "II", 1.4e8, 3.15, 4, "2000"),
        (396.847, "Ca", "II", 1.5e8, 3.12, 2, "1800")
    ]
    cur_test.executemany("INSERT INTO Ca_II VALUES (?,?,?,?,?,?,?)", ca_ii_data)
    conn_test.commit()
    conn_test.close()

    sqlite_connector = NISTDBConnector(db_type="sqlite", db_path=sqlite_db_path)
    assert sqlite_connector.is_connected()
    
    available_sqlite = sqlite_connector.get_available_elements_stages()
    print("Available elements/stages (SQLite):", available_sqlite)
    assert "Fe" in available_sqlite and "I" in available_sqlite["Fe"]
    assert "Ca" in available_sqlite and "II" in available_sqlite["Ca"]

    print("Querying Fe I lines around 248.5 nm (SQLite):")
    fe_lines_sql = sqlite_connector.query_lines_by_wavelength(248.5, 0.3, elements_list=["Fe"], ion_stages_dict={"Fe":["I"]})
    for line in fe_lines_sql: print(f"  Found: {line.element} {line.ion_stage} {line.wavelength_nm:.3f} nm, Aki={line.Aki:.1e}, Ek={line.Ek_ev}eV, RelInt={line.relative_intensity_db_str}({line.relative_intensity_db})")
    assert len(fe_lines_sql) == 2

    print("Querying Ca II lines around 393.4 nm (SQLite) with Aki filter:")
    ca_lines_sql = sqlite_connector.query_lines_by_wavelength(393.4, 0.1, elements_list=["Ca"], min_aki=1.0e8)
    for line in ca_lines_sql: print(f"  Found: {line.element} {line.ion_stage} {line.wavelength_nm:.3f} nm")
    assert len(ca_lines_sql) == 1 and ca_lines_sql[0].wavelength_nm == 393.366
    sqlite_connector.close()
    assert not sqlite_connector.is_connected()

    # --- Test with CSV ---
    print("\n--- Testing CSV Connector ---")
    csv_root_dir = os.path.join(test_db_dir, "csv_data")
    fe_dir = os.path.join(csv_root_dir, "Fe")
    ca_dir = os.path.join(csv_root_dir, "Ca")
    os.makedirs(fe_dir, exist_ok=True)
    os.makedirs(ca_dir, exist_ok=True)

    # Create Fe_I.csv
    with open(os.path.join(fe_dir, "I.csv"), 'w', newline='') as f: # Filename "I.csv" inside "Fe" folder
        writer = csv.writer(f)
        writer.writerow(["obs_wavelength_air_nm", "element", "spectrum", "Aki", "Ek_eV", "gk", "intensity_estimate"]) # Header
        writer.writerows(fe_i_data)
    # Create Ca_II.csv
    with open(os.path.join(ca_dir, "Ca_II.csv"), 'w', newline='') as f: # Filename "Ca_II.csv" inside "Ca" folder
        writer = csv.writer(f)
        writer.writerow(["ritz_wavelength_vac_nm", "element", "spectrum", "Aki", "Ek_eV", "gk", "intensity_estimate"])
        writer.writerows(ca_ii_data)

    csv_connector = NISTDBConnector(db_type="csv", db_path=csv_root_dir)
    assert len(csv_connector.csv_data_cache) > 0 # Should preload

    available_csv = csv_connector.get_available_elements_stages()
    print("Available elements/stages (CSV):", available_csv)
    assert "Fe" in available_csv and "I" in available_csv["Fe"]
    assert "Ca" in available_csv and "II" in available_csv["Ca"]


    print("Querying Fe I lines around 248.5 nm (CSV):")
    fe_lines_csv = csv_connector.query_lines_by_wavelength(248.5, 0.3, elements_list=["Fe"], ion_stages_dict={"Fe":["I"]})
    for line in fe_lines_csv: print(f"  Found: {line.element} {line.ion_stage} {line.wavelength_nm:.3f} nm, RelInt={line.relative_intensity_db}")
    assert len(fe_lines_csv) == 2

    print("Querying Ca II lines around 393.4 nm (CSV) with relative intensity filter:")
    ca_lines_csv = csv_connector.query_lines_by_wavelength(393.4, 0.1, elements_list=["Ca"], min_rel_intensity=1900)
    for line in ca_lines_csv: print(f"  Found: {line.element} {line.ion_stage} {line.wavelength_nm:.3f} nm, RelInt={line.relative_intensity_db}")
    assert len(ca_lines_csv) == 1 and ca_lines_csv[0].relative_intensity_db == 2000.0


    print("\nNIST DB Connector tests completed.")
    # Optional: Clean up test directory
    # import shutil
    # shutil.rmtree(test_db_dir)
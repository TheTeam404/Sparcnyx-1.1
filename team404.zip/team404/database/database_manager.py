# team404/database/database_manager.py

import logging
from typing import List, Dict, Optional, Any
from pathlib import Path

from .connectors.base_connector import BaseConnector
from .connectors.sqlite_connector import SQLiteConnector
from .connectors.csv_connector import CSVConnector

logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self):
        self.connections: Dict[str, BaseConnector] = {}
        logger.info("DatabaseManager initialized.")

    def add_database(self, path: str, file_type: str, mapping: Dict[str, str], **kwargs) -> bool:
        # ... (this method is unchanged) ...
        path_key = str(Path(path).resolve())
        if path_key in self.connections: self.remove_database(path_key)
        connector: Optional[BaseConnector] = None
        if file_type.lower() == 'sqlite': connector = SQLiteConnector(path=path_key, mapping=mapping)
        elif file_type.lower() in ['csv', 'txt', 'asc']: connector = CSVConnector(path=path_key, mapping=mapping, delimiter=kwargs.get('delimiter', ','))
        else: logger.error(f"Unsupported database file type: '{file_type}'"); return False
        if connector and connector.connect():
            self.connections[path_key] = connector
            logger.info(f"Successfully added and connected database: {path_key}")
            return True
        logger.error(f"Failed to connect to database at: {path_key}"); return False

    def remove_database(self, path: str) -> bool:
        # ... (this method is unchanged) ...
        path_key = str(Path(path).resolve())
        if path_key in self.connections:
            self.connections[path_key].close(); del self.connections[path_key]
            logger.info(f"Removed database connection: {path_key}"); return True
        return False

    def get_active_databases(self) -> List[Dict[str, str]]:
        # ... (this method is unchanged) ...
        return [{"path": path, "type": conn.__class__.__name__} for path, conn in self.connections.items()]

    def clear_all(self) -> None:
        # ... (this method is unchanged) ...
        for path_key in list(self.connections.keys()): self.remove_database(path_key)
        logger.info("Cleared all active database connections.")

    # ADDED: New method to get a combined list of elements from all active DBs.
    def get_all_available_elements_stages(self) -> Dict[str, List[str]]:
        """
        Collects available elements and stages from all active connectors and merges them.
        """
        combined_elements: Dict[str, List[str]] = {}
        for connector in self.connections.values():
            connector_elements = connector.get_available_elements_stages()
            for el, stages in connector_elements.items():
                if el not in combined_elements:
                    combined_elements[el] = []
                # Add new stages without creating duplicates
                combined_elements[el].extend([s for s in stages if s not in combined_elements[el]])
        
        # Sort the final lists for consistent display
        for el in combined_elements:
            combined_elements[el].sort()
        return dict(sorted(combined_elements.items()))

    def search_all_databases(self, wavelength_center: float, tolerance_nm: float,
                             elements_filter: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        # ... (this method is unchanged) ...
        all_results: List[Dict[str, Any]] = []
        if not self.connections: return []
        for path, connector in self.connections.items():
            try:
                results = connector.query_lines(wavelength_center, tolerance_nm, elements_filter)
                all_results.extend(results)
            except Exception as e:
                logger.error(f"Error querying database '{path}': {e}")
        all_results.sort(key=lambda d: abs(d.get('wavelength_nm', 0) - wavelength_center))
        return all_results
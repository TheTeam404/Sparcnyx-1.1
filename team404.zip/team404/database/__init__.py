# team404/database/__init__.py

"""
Database interaction modules for SpectraMapper Pro.

This package provides a manager for handling various database sources
and connectors for specific file types (SQLite, CSV, etc.).
"""

# Import the main manager that the rest of the application will use.
from .database_manager import DatabaseManager

# We also keep UserCustomDB accessible as it serves a distinct purpose.
from .user_custom_db import UserCustomDB

# The __all__ variable defines the public API of this package.
# When a user does `from team404.database import *`, only these names are imported.
__all__ = [
    "DatabaseManager",
    "UserCustomDB"
]
#!/usr/bin/env python3
"""
Peak NIST Lookup Tool with UI - v2.0
------------------------------------
Improved user experience, robust querying, and clearer output for matching
experimental peak wavelengths against the online NIST Atomic Spectra Database.
"""

import sys
import os
import csv
import logging
import time
from pathlib import Path
from typing import List, Dict, Optional, Any, Tuple
import re

from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QPushButton, QFileDialog, QLabel, QDoubleSpinBox,
    QComboBox, QTextEdit, QGroupBox, QMessageBox, QProgressDialog,
    QSizePolicy
)
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QObject

try:
    from astroquery.nist import Nist
    from astropy.table import Table
    from astropy import units as u
    import numpy as np
    import pandas as pd
    ASTRO_LIBS_AVAILABLE = True
except ImportError as e:
    ASTRO_LIBS_AVAILABLE = False
    # Dummy classes for UI to load if libs are missing
    class Table: pass
    class Nist: pass
    class u_dummy:
        AA = "Angstrom"; nm = "nanometer"
        def __getattr__(self, name): print(f"WARN: u.{name}"); return name
    u = u_dummy() # type: ignore
    class np_dummy:
        @staticmethod
        def floating(*args, **kwargs): return float
        @staticmethod
        def integer(*args, **kwargs): return int
        @staticmethod
        def isnan(val): return val is None or (isinstance(val, float) and val != val)
        @staticmethod
        def all(arr): return all(arr) if hasattr(arr, '__iter__') else bool(arr)
        @staticmethod
        def ma_is_masked(val): return False # type: ignore
        @staticmethod
        def array(val, dtype=None): return list(val) if hasattr(val,'__iter__') else [val]
    np = np_dummy # type: ignore
    class pd_dummy:
        @staticmethod
        def DataFrame(*args, **kwargs): return {"to_csv": lambda *a, **k: None} # Dummy DataFrame
        @staticmethod
        def to_numeric(series, errors='raise'): return series
        @staticmethod
        def notnull(val): return val is not None
    pd = pd_dummy # type: ignore

# --- Default Values ---
DEFAULT_WAVELENGTH_TOLERANCE_NM = 0.1
DEFAULT_QUERY_DELAY_S = 1.5 # Slightly increased default delay
DEFAULT_NIST_ENERGY_UNIT = "eV"
# Default to "vacuum" as it's more reliable with astroquery versions
DEFAULT_NIST_WL_TYPE_PARAM_FOR_WORKER = "vacuum"
DEFAULT_NIST_OUTPUT_ORDER = "wavelength"

# --- Logging Setup ---
logger = logging.getLogger("PeakNISTLookupUI_v2.0")
logger.setLevel(logging.INFO)
if not logger.hasHandlers():
    stream_handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

# --- Helper Functions ---
def robust_float_conversion(value: Any, default: Optional[float] = None) -> Optional[float]:
    if isinstance(value, (int, float)): return float(value)
    if ASTRO_LIBS_AVAILABLE and hasattr(np, 'floating') and isinstance(value, (np.floating, np.integer)): return float(value)
    if isinstance(value, str):
        try: return float(value.replace(',', '.'))
        except ValueError:
            match = re.match(r"^\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?).*", value)
            if match:
                try: return float(match.group(1))
                except ValueError: pass
    return default

def robust_int_conversion(value: Any, default: Optional[int] = None) -> Optional[int]:
    float_val = robust_float_conversion(value)
    if float_val is not None:
        try: return int(round(float_val))
        except (ValueError, TypeError): pass
    return default

def parse_nist_row_to_dict(row_data: Any, exp_wl_nm: float, wl_type_queried_for_note: str, energy_unit_requested: str) -> Optional[Dict[str, Any]]:
    if not ASTRO_LIBS_AVAILABLE: return None
    line_data: Dict[str, Any] = {}
    # Prioritize more specific column names that astroquery >= 0.4.7 might return
    col_map = {
        'wl_obs': ['Observed Wavelength Air', 'Observed Wavelength Vac', 'Observed Wavelength', 'Observed', 'obs_wl_vac(A)', 'obs_wl_air(A)'],
        'wl_ritz': ['Ritz Wavelength Air', 'Ritz Wavelength Vac', 'Ritz Wavelength', 'Ritz', 'ritz_wl_vac(A)'],
        'element': ['Element', 'Element Symbol'],
        'spectrum': ['Spectrum', 'Ion'],
        'aki': ['Aki', 'A_ki'], # Astroquery 0.4.7+ tends to use 'Aki' directly
        'ek': ['E_k', f'Ek_{energy_unit_requested.lower()}', f'E_k({energy_unit_requested})'],
        'gk': ['g_k', 'gk'],
        'rel_int': ['Rel. Int.', 'Rel Int', 'intens', 'Observed Rel. Int.']
    }

    def get_val(keys: List[str], default_val: Any = None) -> Any:
        for k_try in keys:
            if k_try in row_data.colnames:
                val_from_row = row_data[k_try]
                if hasattr(val_from_row, 'mask') and np.all(val_from_row.mask): continue
                if hasattr(val_from_row, 'mask') and not np.all(val_from_row.mask):
                    if not isinstance(val_from_row, (str, bytes)) and hasattr(np, 'ma') and np.ma.is_masked(val_from_row): continue # type: ignore
                    if hasattr(val_from_row, 'data'): val_from_row = val_from_row.data # Get underlying data from MaskedColumn
                if val_from_row is not None and str(val_from_row).strip() != "" and str(val_from_row).strip().lower() != 'nan':
                    return val_from_row
        return default_val

    # Wavelength selection and conversion
    db_wl_raw = None
    wl_col_name_found = ""
    if wl_type_queried_for_note.lower() in ["vacuum", "ritz"]:
        for k in col_map['wl_ritz']:
            if k in row_data.colnames: db_wl_raw = get_val([k]); wl_col_name_found = k; break
        if db_wl_raw is None: # Fallback to observed if Ritz not found
            for k in col_map['wl_obs']:
                if k in row_data.colnames: db_wl_raw = get_val([k]); wl_col_name_found = k; break
    else: # "obs"
        for k in col_map['wl_obs']:
            if k in row_data.colnames: db_wl_raw = get_val([k]); wl_col_name_found = k; break
        if db_wl_raw is None: # Fallback to ritz if Observed not found
            for k in col_map['wl_ritz']:
                if k in row_data.colnames: db_wl_raw = get_val([k]); wl_col_name_found = k; break
    
    if db_wl_raw is None: db_wl_raw = get_val(['Wavelength']); wl_col_name_found = 'Wavelength' # Generic fallback
    if db_wl_raw is None: logger.warning(f"NIST row parsing: Wavelength column not found. Cols: {row_data.colnames}"); return None

    db_wl_converted_nm = robust_float_conversion(db_wl_raw)
    if db_wl_converted_nm is None: logger.warning(f"NIST row parsing: Could not convert wavelength '{db_wl_raw}' to float."); return None

    # Astroquery >= 0.4.7 usually returns wavelengths in Angstrom without units in the column name itself
    # The unit might be in the column object's .unit attribute.
    # For simplicity, assume Angstrom if 'nm' is not in the found column name.
    if 'nm' not in wl_col_name_found.lower():
        line_data["Database_Wavelength_nm"] = db_wl_converted_nm / 10.0
    else:
        line_data["Database_Wavelength_nm"] = db_wl_converted_nm

    line_data["Experimental_Wavelength_nm"] = exp_wl_nm
    line_data["Delta_Wavelength_nm"] = exp_wl_nm - line_data["Database_Wavelength_nm"]
    line_data["Element"] = str(get_val(col_map['element'], "Unk")).strip()
    spectrum_raw = str(get_val(col_map['spectrum'], "?")).strip()
    parts = spectrum_raw.split(); line_data["Ion_Stage"] = parts[-1] if parts and (len(parts) > 1 or not parts[-1].isalpha() or parts[-1].upper() in ["I","II","III","IV","V","VI","VII","VIII","IX","X"]) else "?"
    aki_raw = get_val(col_map['aki']); line_data["Aki_s-1"] = robust_float_conversion(aki_raw)
    ek_raw = get_val(col_map['ek']); line_data[f"Ek_{energy_unit_requested}"] = robust_float_conversion(ek_raw)
    line_data["gk"] = robust_int_conversion(get_val(col_map['gk']))
    rel_int_raw = get_val(col_map['rel_int']); line_data["Relative_Intensity_DB"] = str(rel_int_raw).strip() if rel_int_raw is not None else None
    line_data["Notes"] = f"NIST Online ({wl_type_queried_for_note})"
    return line_data


# --- Worker Class ---
class NISTLookupWorker(QObject):
    finished = pyqtSignal(list, str); progress = pyqtSignal(int, int, str); error = pyqtSignal(str)
    def __init__(self, peak_wavelengths_nm: List[float], tolerance_nm: float,
                 element_filter: Optional[str], wl_type_param: str, query_delay: float):
        super().__init__(); self.peak_wavelengths_nm = peak_wavelengths_nm; self.tolerance_nm = tolerance_nm
        self.element_filter = element_filter; self.wl_type_param = wl_type_param # "vacuum" or "obs"
        self.query_delay = query_delay; self._is_cancelled = False
    def run(self):
        if not ASTRO_LIBS_AVAILABLE: self.error.emit("Astroquery/Astropy not installed."); self.finished.emit([], "Error: Missing libraries."); return
        all_matched_lines: List[Dict[str, Any]] = []; total_peaks = len(self.peak_wavelengths_nm)
        for i, exp_wl_nm in enumerate(self.peak_wavelengths_nm):
            if self._is_cancelled: logger.info(f"NISTLookupWorker: Cancelled at peak {i+1}/{total_peaks}."); self.finished.emit(all_matched_lines, f"Cancelled after {i} peaks."); return
            self.progress.emit(i + 1, total_peaks, f"Querying peak {exp_wl_nm:.4f} nm (Type: {self.wl_type_param})...")
            min_wl_nm_query = exp_wl_nm - self.tolerance_nm; max_wl_nm_query = exp_wl_nm + self.tolerance_nm
            min_wl_query_unit = min_wl_nm_query * u.nm; max_wl_query_unit = max_wl_nm_query * u.nm # type: ignore
            query_kwargs = {"linename": self.element_filter, "energy_level_unit": DEFAULT_NIST_ENERGY_UNIT,
                            "output_order": DEFAULT_NIST_OUTPUT_ORDER, "wavelength_type": self.wl_type_param}
            final_query_kwargs = {k:v for k,v in query_kwargs.items() if v is not None}
            try:
                time.sleep(self.query_delay)
                logger.debug(f"Nist.query args: ({min_wl_query_unit}, {max_wl_query_unit}), kwargs: {final_query_kwargs}")
                nist_table = Nist.query(min_wl_query_unit, max_wl_query_unit, **final_query_kwargs)
                if nist_table is None: logger.info(f"  NIST query None for {exp_wl_nm:.4f} nm."); all_matched_lines.append({"Experimental_Wavelength_nm": exp_wl_nm, "Notes": "NIST query returned no table object"}); continue
                elif len(nist_table) == 0: logger.info(f"  NIST query empty table for {exp_wl_nm:.4f} nm."); all_matched_lines.append({"Experimental_Wavelength_nm": exp_wl_nm, "Notes": "No lines found in NIST (empty table)"}); continue
                logger.info(f"  Found {len(nist_table)} lines for {exp_wl_nm:.4f} nm.")
                for row_idx, nist_row_data in enumerate(nist_table):
                    if self._is_cancelled: break
                    parsed_line = parse_nist_row_to_dict(nist_row_data, exp_wl_nm, self.wl_type_param, DEFAULT_NIST_ENERGY_UNIT)
                    if parsed_line: all_matched_lines.append(parsed_line)
                    else: logger.warning(f"    Could not parse NIST row {row_idx} for peak {exp_wl_nm:.4f} nm.")
                if self._is_cancelled: break
            except Exception as e:
                error_str = str(e); logger.error(f"  Error querying NIST for {exp_wl_nm:.4f} nm: {error_str}", exc_info=True)
                all_matched_lines.append({"Experimental_Wavelength_nm": exp_wl_nm, "Notes": f"NIST query error: {error_str[:100]}"})
        self.progress.emit(total_peaks, total_peaks, "Lookup complete."); self.finished.emit(all_matched_lines, f"Lookup complete. Processed {total_peaks} peaks.")
    def cancel(self): logger.info("NISTLookupWorker: Cancellation requested."); self._is_cancelled = True

# --- Main UI Window ---
class PeakNISTLookupUI(QWidget):
    def __init__(self):
        super().__init__(); self.worker_thread: Optional[QThread] = None; self.nist_worker: Optional[NISTLookupWorker] = None
        self.progress_dialog: Optional[QProgressDialog] = None; self._init_ui(); self._check_dependencies()
    def _check_dependencies(self):
        if not ASTRO_LIBS_AVAILABLE:
            QMessageBox.critical(self, "Dependency Error", "Required libraries (astroquery, astropy, numpy, pandas) are not installed.\nPlease install them: pip install PyQt5 astroquery astropy numpy pandas")
            if hasattr(self, 'start_button'): self.start_button.setEnabled(False)
    def _init_ui(self):
        self.setWindowTitle("Peak NIST Lookup Tool v2.0"); self.setGeometry(200, 200, 700, 600) # Wider
        layout = QVBoxLayout(self); params_group = QGroupBox("Input & Query Parameters")
        params_group.setStyleSheet("QGroupBox { font-weight: bold; } ")
        form_layout = QFormLayout(params_group); form_layout.setRowWrapPolicy(QFormLayout.WrapLongRows); form_layout.setLabelAlignment(Qt.AlignRight)

        self.input_file_edit = QLineEdit(); self.input_file_edit.setPlaceholderText("Click Browse to select your peak list TXT file")
        input_file_btn = QPushButton("Browse..."); input_file_btn.clicked.connect(self._browse_input_file); input_file_layout = QHBoxLayout()
        input_file_layout.addWidget(self.input_file_edit, 1); input_file_layout.addWidget(input_file_btn)
        form_layout.addRow(QLabel("Peak List File (TXT):"), input_file_layout)

        self.output_file_edit = QLineEdit(); self.output_file_edit.setPlaceholderText("Will be auto-suggested after selecting input file")
        output_file_btn = QPushButton("Browse..."); output_file_btn.clicked.connect(self._browse_output_file); output_file_layout = QHBoxLayout()
        output_file_layout.addWidget(self.output_file_edit, 1); output_file_layout.addWidget(output_file_btn)
        form_layout.addRow(QLabel("Output Results File (CSV):"), output_file_layout)

        self.tolerance_spinbox = QDoubleSpinBox(); self.tolerance_spinbox.setDecimals(3); self.tolerance_spinbox.setRange(0.001, 10.0) # Wider max
        self.tolerance_spinbox.setValue(DEFAULT_WAVELENGTH_TOLERANCE_NM); self.tolerance_spinbox.setSingleStep(0.005) # Finer step
        self.tolerance_spinbox.setSuffix(" nm"); self.tolerance_spinbox.setToolTip("Wavelength tolerance (±nm) for matching each peak against NIST data.\nSmaller values are stricter, larger values may yield more (possibly false) matches.")
        form_layout.addRow(QLabel("Wavelength Tolerance (±):"), self.tolerance_spinbox)

        self.element_filter_edit = QLineEdit(); self.element_filter_edit.setPlaceholderText("Optional (e.g., Fe, Ca II, Fe I-II)")
        self.element_filter_edit.setToolTip("Filter NIST results by element symbol and/or ion stage(s).\nExamples: 'Fe' (all Fe stages), 'Fe I' (neutral Fe), 'Ca II-V' (Ca+, Ca2+, Ca3+, Ca4+). Leave blank for all elements.")
        form_layout.addRow(QLabel("Element/Ion Filter:"), self.element_filter_edit)

        self.wl_type_combo = QComboBox(); self.wl_type_combo.addItem("Vacuum (Ritz/Calculated - Recommended)", "vacuum")
        self.wl_type_combo.addItem("Observed (Air/Vacuum Mix - Use if 'Vacuum' yields no results)", "obs")
        if DEFAULT_NIST_WL_TYPE_PARAM_FOR_WORKER == "vacuum": self.wl_type_combo.setCurrentIndex(0)
        else: self.wl_type_combo.setCurrentIndex(self.wl_type_combo.findData("obs"))
        self.wl_type_combo.setToolTip("Wavelength type for NIST query:\n'Vacuum (Ritz/Calculated)': Prioritizes calculated vacuum wavelengths. Often more consistent.\n'Observed (Air/Vacuum Mix)': Uses wavelengths as observed by NIST (can be air or vacuum).")
        form_layout.addRow(QLabel("NIST Wavelength Type:"), self.wl_type_combo)

        self.query_delay_spinbox = QDoubleSpinBox(); self.query_delay_spinbox.setDecimals(1); self.query_delay_spinbox.setRange(0.5, 10.0)
        self.query_delay_spinbox.setValue(DEFAULT_QUERY_DELAY_S); self.query_delay_spinbox.setSingleStep(0.1); self.query_delay_spinbox.setSuffix(" s")
        self.query_delay_spinbox.setToolTip("Delay in seconds between individual queries to the NIST server to avoid overloading it.")
        form_layout.addRow(QLabel("Query Delay:"), self.query_delay_spinbox)
        layout.addWidget(params_group)

        self.start_button = QPushButton("Start NIST Lookup"); self.start_button.setFixedHeight(40); font = self.start_button.font(); font.setPointSize(11); font.setBold(True); self.start_button.setFont(font)
        self.start_button.clicked.connect(self._start_lookup); layout.addWidget(self.start_button)

        log_group = QGroupBox("Log & Status"); log_group_layout = QVBoxLayout(log_group)
        self.log_area = QTextEdit(); self.log_area.setReadOnly(True); self.log_area.setMinimumHeight(150)
        self.log_area.setPlaceholderText("Detailed progress, warnings, and results summary will appear here..."); log_group_layout.addWidget(self.log_area)
        layout.addWidget(log_group); self.setLayout(layout)

    def _browse_input_file(self):
        filepath, _ = QFileDialog.getOpenFileName(self, "Select Peak List TXT File", str(Path.home()), "Text Files (*.txt);;All Files (*)")
        if filepath: self.input_file_edit.setText(filepath); p = Path(filepath); self.output_file_edit.setText(str(p.with_name(f"{p.stem}_nist_matches.csv")))
    def _browse_output_file(self):
        default_path = self.output_file_edit.text()
        if not default_path and self.input_file_edit.text(): p_in = Path(self.input_file_edit.text()); default_path = str(p_in.with_name(f"{p_in.stem}_nist_matches.csv"))
        elif not default_path: default_path = str(Path.home() / "nist_matches.csv")
        filepath, _ = QFileDialog.getSaveFileName(self, "Select Output CSV File", default_path, "CSV Files (*.csv);;All Files (*)")
        if filepath: self.output_file_edit.setText(filepath)
    def _append_log(self, message: str, level: str = "INFO"):
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S'); self.log_area.append(f"{timestamp} [{level}] {message}"); QApplication.processEvents()

    def _start_lookup(self):
        if not ASTRO_LIBS_AVAILABLE: self._check_dependencies(); return
        input_fpath_str = self.input_file_edit.text().strip(); output_fpath_str = self.output_file_edit.text().strip()
        if not input_fpath_str or not Path(input_fpath_str).is_file(): QMessageBox.warning(self, "Input Error", f"Input file not found or invalid: {input_fpath_str}"); return
        if not output_fpath_str: QMessageBox.warning(self, "Input Error", "Please specify an output CSV file path."); return
        peak_wavelengths: List[float] = []
        try:
            with open(input_fpath_str, 'r', encoding='utf-8') as f:
                for line_num, line_content in enumerate(f, 1):
                    line_content = line_content.strip()
                    if not line_content or line_content.startswith('#'): continue
                    parts = line_content.split('\t');
                    if not parts: continue
                    wavelength_str = parts[0].strip()
                    try: peak_wavelengths.append(float(wavelength_str))
                    except ValueError: self._append_log(f"Skipping invalid wavelength on line {line_num}: '{wavelength_str}' (from: '{line_content}')", "WARN")
            if not peak_wavelengths: QMessageBox.information(self, "No Peaks", "No valid peak wavelengths found to process in the input file."); return
        except Exception as e: QMessageBox.critical(self, "File Error", f"Error reading input file '{input_fpath_str}': {e}"); return
        tolerance = self.tolerance_spinbox.value(); element_filter = self.element_filter_edit.text().strip() or None
        wl_type_param = self.wl_type_combo.currentData() # "vacuum" or "obs"
        query_delay = self.query_delay_spinbox.value()

        self.log_area.clear(); self._append_log(f"Starting NIST lookup for {len(peak_wavelengths)} peaks...")
        self._append_log(f"  Input: {input_fpath_str}"); self._append_log(f"  Output: {output_fpath_str}")
        self._append_log(f"  Tolerance: ±{tolerance:.3f} nm");
        if element_filter: self._append_log(f"  Element Filter: {element_filter}")
        self._append_log(f"  Wavelength Type (to astroquery): {wl_type_param}")
        self._append_log(f"  Query Delay: {query_delay:.1f} s")

        self.start_button.setEnabled(False)
        self.progress_dialog = QProgressDialog("Querying NIST ASD...", "Cancel", 0, len(peak_wavelengths), self)
        self.progress_dialog.setWindowModality(Qt.WindowModal); self.progress_dialog.setAutoClose(True); self.progress_dialog.setAutoReset(True)
        self.progress_dialog.setMinimumDuration(0); self.progress_dialog.setValue(0)
        
        self.worker_thread = QThread(); self.nist_worker = NISTLookupWorker(peak_wavelengths, tolerance, element_filter, wl_type_param, query_delay)
        self.nist_worker.moveToThread(self.worker_thread); self.nist_worker.progress.connect(self._on_worker_progress)
        self.nist_worker.finished.connect(self._on_worker_finished); self.nist_worker.error.connect(self._on_worker_error)
        self.worker_thread.started.connect(self.nist_worker.run); self.nist_worker.finished.connect(self.worker_thread.quit)
        self.nist_worker.finished.connect(self.nist_worker.deleteLater); self.worker_thread.finished.connect(self.worker_thread.deleteLater)
        self.worker_thread.finished.connect(self._reset_worker_state);
        if self.progress_dialog: self.progress_dialog.canceled.connect(self.nist_worker.cancel)
        self.worker_thread.start()

    def _on_worker_progress(self, current_peak_idx: int, total_peaks: int, message: str):
        self._append_log(f"{message} ({current_peak_idx}/{total_peaks})", "DEBUG") # Changed level to DEBUG for less verbose UI log
        if self.progress_dialog: self.progress_dialog.setValue(current_peak_idx); self.progress_dialog.setLabelText(message)
    def _on_worker_finished(self, matched_lines: List[Dict[str, Any]], status_message: str):
        self._append_log(f"Worker finished: {status_message}")
        if self.progress_dialog: self.progress_dialog.setValue(self.progress_dialog.maximum())
        if matched_lines:
            output_fpath_str = self.output_file_edit.text().strip()
            # Ensure Ek column header matches DEFAULT_NIST_ENERGY_UNIT for consistency
            ek_col_name = f"Ek_{DEFAULT_NIST_ENERGY_UNIT}"
            output_headers = ["Experimental_Wavelength_nm", "Database_Wavelength_nm", "Delta_Wavelength_nm", "Element", "Ion_Stage", "Aki_s-1", ek_col_name, "gk", "Relative_Intensity_DB", "Notes"]
            try:
                df_results = pd.DataFrame(matched_lines) # type: ignore
                for header in output_headers: # Ensure all headers exist, fill with "N/A" if missing
                    if header not in df_results.columns: df_results[header] = "N/A"
                
                # Formatting for float columns, robust to "N/A" strings
                float_cols_format = {"Experimental_Wavelength_nm": "{:.4f}", "Database_Wavelength_nm": "{:.4f}", "Delta_Wavelength_nm": "{:.4f}", ek_col_name: "{:.3f}"}
                for col, fmt_str in float_cols_format.items():
                    if col in df_results.columns:
                        # Apply formatting only to valid numbers
                        def format_val(x):
                            val_num = robust_float_conversion(x)
                            return fmt_str.format(val_num) if val_num is not None else str(x) # Keep original if not number
                        df_results[col] = df_results[col].apply(format_val)
                
                if "Aki_s-1" in df_results.columns:
                    df_results["Aki_s-1"] = df_results["Aki_s-1"].apply(lambda x: f"{robust_float_conversion(x):.2e}" if robust_float_conversion(x) is not None else str(x))
                if "gk" in df_results.columns:
                     df_results["gk"] = df_results["gk"].apply(lambda x: f"{robust_int_conversion(x)}" if robust_int_conversion(x) is not None else str(x))

                df_results = df_results.fillna("N/A") # Replace any remaining actual NaN/None with "N/A" string
                df_results = df_results[output_headers] # Ensure correct column order
                df_results.to_csv(output_fpath_str, index=False, quoting=csv.QUOTE_MINIMAL)
                self._append_log(f"Successfully wrote {len(df_results)} rows to '{output_fpath_str}'.")
                QMessageBox.information(self, "Lookup Complete", f"Lookup complete. Results saved to:\n{output_fpath_str}")
            except Exception as e: self._append_log(f"Error writing output CSV: {e}", "ERROR"); QMessageBox.critical(self, "File Write Error", f"Failed to write results to CSV: {e}")
        else:
            self._append_log("No matching lines found or lookup was cancelled.")
            if "cancelled" not in status_message.lower(): QMessageBox.information(self, "No Results", "No matching lines found for the given peaks and parameters. Try increasing tolerance or checking filters.")
    def _on_worker_error(self, error_message: str):
        self._append_log(f"Worker Error: {error_message}", "ERROR");
        if self.progress_dialog: self.progress_dialog.cancel()
        QMessageBox.critical(self, "Processing Error", f"An error occurred during NIST lookup:\n{error_message}")
    def _reset_worker_state(self):
        self.start_button.setEnabled(True); self.worker_thread = None; self.nist_worker = None
        if self.progress_dialog: self.progress_dialog.deleteLater(); self.progress_dialog = None
        self._append_log("Ready for new lookup.", "INFO")
    def closeEvent(self, event):
        if self.nist_worker: self.nist_worker.cancel()
        if self.worker_thread and self.worker_thread.isRunning():
            logger.info("Waiting for NIST lookup thread to finish on close...")
            self.worker_thread.quit()
            if not self.worker_thread.wait(2000): logger.warning("NIST lookup thread did not finish gracefully, terminating."); self.worker_thread.terminate(); self.worker_thread.wait()
        super().closeEvent(event)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PeakNISTLookupUI()
    window.show()
    sys.exit(app.exec_())
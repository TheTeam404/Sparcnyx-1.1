# team404/core/spectrum_handler.py

"""
Handles processing of individual LIBSpectrum objects, including applying
preprocessing pipelines and other spectrum-specific manipulations.
"""

import logging
import copy
from typing import List, Dict, Any, Optional, Callable, Tuple

import numpy as np
from . import preprocessing_algorithms # Imports the module
from .data_models import LIBSpectrum, ProcessingStep

logger = logging.getLogger(__name__)

class SpectrumProcessor:
    """
    Manages and applies processing steps to LIBSpectrum objects.
    Provides methods to apply single steps or entire pipelines,
    and can return intermediate results for visualization.
    """
    def __init__(self):
        # Registry of available processing functions.
        # Maps function_name (as stored in ProcessingStep.name) to actual function.
        self.processing_functions: Dict[str, Callable] = {
            fn_name: getattr(preprocessing_algorithms, fn_name)
            for fn_name in preprocessing_algorithms.PROCESSING_FUNCTION_REGISTRY.keys()
            if hasattr(preprocessing_algorithms, fn_name)
        }
        # Log functions that are in registry but not found in the module
        for fn_name in preprocessing_algorithms.PROCESSING_FUNCTION_REGISTRY.keys():
            if fn_name not in self.processing_functions:
                logger.error(f"Processing function '{fn_name}' from REGISTRY not found in preprocessing_algorithms module!")
        
        logger.debug(f"SpectrumProcessor initialized with {len(self.processing_functions)} successfully mapped processing functions.")

    def apply_single_step(self,
                          spectrum: LIBSpectrum,
                          step: ProcessingStep,
                          current_wavelengths: np.ndarray,
                          current_intensities: np.ndarray
                          ) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], Dict[str, Any]]:
        """
        Applies a single ProcessingStep to the provided wavelength and intensity data.

        Args:
            spectrum: The original LIBSpectrum object (used for metadata like wavelengths if needed by specific algos).
            step: The ProcessingStep to apply.
            current_wavelengths: The wavelength array to process.
            current_intensities: The intensity array to process.

        Returns:
            A tuple: (
                new_wavelengths_or_None: Modified wavelengths if changed by step, else None.
                new_intensities_or_None: Modified intensities if step successful, else None.
                step_output_details: Dictionary with specific outputs from the step (e.g., 'estimated_baseline').
            )
        """
        if not step.enabled:
            logger.debug(f"Skipping disabled step: {step.name}")
            return None, None, {"status": "skipped_disabled"}

        func = self.processing_functions.get(step.name)
        if not func:
            logger.error(f"Processing function '{step.name}' not found in registry.")
            return None, None, {"error": f"Function '{step.name}' not found", "status": "error_function_not_found"}

        logger.debug(f"Applying step '{step.name}' with params {step.parameters} on data of shape {current_intensities.shape}")
        
        step_output_details: Dict[str, Any] = {"status": "applied"}
        new_wavelengths: Optional[np.ndarray] = None # By default, assume wavelengths don't change
        new_intensities: Optional[np.ndarray] = None

        try:
            params_for_algo = step.parameters.copy() # Use a copy

            if step.name.startswith("baseline_"):
                if step.name == "baseline_polynomial": # Needs original spectrum wavelengths for evaluation
                    # It processes current_intensities based on current_wavelengths
                    # but evaluates the baseline over the spectrum.raw_wavelengths
                    # For preview, we pass current_wavelengths for both fitting and evaluation.
                    # When applying permanently, it should evaluate on spectrum.raw_wavelengths if pipeline starts from raw.
                    # For now, assume it always works on the passed current_wavelengths.
                    processed_intensities, baseline = func(
                        current_wavelengths, current_intensities, **params_for_algo
                    )
                else: # e.g., ALS
                    processed_intensities, baseline = func(current_intensities, **params_for_algo)
                
                new_intensities = processed_intensities
                step_output_details['estimated_baseline'] = baseline
                # Wavelengths are assumed unchanged by these baseline methods for now

            elif step.name.startswith("normalize_"):
                if step.name == "normalize_to_area":
                     new_intensities = func(current_intensities, wavelengths=current_wavelengths, **params_for_algo)
                elif step.name == "normalize_msc":
                    if "reference_spectrum" not in params_for_algo: # MSC requires a reference
                        logger.warning(f"MSC step '{step.name}' missing 'reference_spectrum' in parameters. Skipping.")
                        return None, current_intensities, {"status": "skipped_missing_ref", "warning": "Missing reference spectrum for MSC"}
                    new_intensities = func(current_intensities, **params_for_algo)
                else:
                    new_intensities = func(current_intensities, **params_for_algo)
                # Wavelengths unchanged

            elif step.name.startswith("remove_cosmic_ray_"):
                new_intensities = func(current_intensities, wavelengths=current_wavelengths, **params_for_algo)
                # Wavelengths unchanged

            # Example for a hypothetical step that changes wavelengths (e.g., interpolation)
            # elif step.name == "interpolate_to_new_axis":
            #     target_wl_axis = params_for_algo.get("target_wavelength_axis")
            #     if target_wl_axis is None:
            #         raise ValueError("interpolate_to_new_axis requires 'target_wavelength_axis' parameter.")
            #     # func would be: interpolate(current_wavelengths, current_intensities, target_wl_axis)
            #     # It should return (interpolated_wavelengths, interpolated_intensities)
            #     new_wavelengths, new_intensities = func(current_wavelengths, current_intensities, target_wl_axis)

            else: # Default for smoothers, denoisers, or other intensity-only modifiers
                new_intensities = func(current_intensities, **params_for_algo)
                # Wavelengths unchanged
            
            step_output_details["status"] = "success"
            return new_wavelengths, new_intensities, step_output_details

        except Exception as e:
            logger.error(f"Error applying step '{step.name}': {e}", exc_info=True)
            return None, None, {"error": str(e), "status": "error_during_execution"}


    def apply_pipeline(self, spectrum: LIBSpectrum, pipeline: List[ProcessingStep]) -> bool:
        """
        Applies a sequence of ProcessingSteps to the LIBSpectrum.
        The spectrum's processed data is updated in-place after each successful step.
        The spectrum's `processing_pipeline` attribute is updated to the applied pipeline.
        This method always starts from the spectrum's raw data.
        """
        if not spectrum.is_valid():
            logger.error(f"Cannot apply pipeline: Spectrum {spectrum.spectrum_id} has no valid raw data.")
            return False

        # Always start processing from the spectrum's raw data for a full pipeline application
        current_wavelengths = spectrum.raw_wavelengths.copy()
        current_intensities = spectrum.raw_intensities.copy()
        
        applied_pipeline_successfully: List[ProcessingStep] = []
        all_steps_successful = True

        for step in pipeline:
            if not step.enabled:
                # Still add disabled steps to the spectrum's pipeline history if desired,
                # but mark them as not contributing to the current processed state for this run.
                # For simplicity, we only add successfully *executed* steps to the stored pipeline here.
                # If you want to store the *intended* pipeline including disabled steps, copy it first.
                logger.debug(f"Skipping disabled step in pipeline: {step.name}")
                # We can choose to add it to applied_pipeline_successfully or not.
                # If added, its 'enabled' flag shows its status.
                # Let's add it to reflect the full pipeline structure that was "applied".
                applied_pipeline_successfully.append(copy.deepcopy(step)) # Store a copy
                continue

            # Make a defensive copy of parameters, especially if step involves complex objects
            # like a reference spectrum for MSC that might be passed by reference.
            step_to_apply = ProcessingStep(step.name, copy.deepcopy(step.parameters), step.enabled)

            # Specific handling for MSC: if reference spectrum is expected to be 'mean'
            # it needs to be calculated from a dataset, which is outside single spectrum processing.
            # The GUI or batch processor should prepare the reference for MSC.
            # Here, we assume step_to_apply.parameters["reference_spectrum"] is ready if needed.

            temp_wl, temp_int, step_details = self.apply_single_step(
                spectrum, step_to_apply, current_wavelengths, current_intensities
            )

            if step_details.get("status") == "error_during_execution" or \
               step_details.get("status") == "error_function_not_found":
                all_steps_successful = False
                logger.error(f"Pipeline application stopped at step '{step.name}' for spectrum {spectrum.spectrum_id} due to error: {step_details.get('error')}")
                # Spectrum's processed data remains as it was before this failed step.
                # Update the spectrum's pipeline only with the steps that were successful *before* this one.
                break 
            
            # Update current data for the next step
            if temp_int is not None: # Step was applied and returned intensities
                current_intensities = temp_int
                if temp_wl is not None: # Step also returned new wavelengths
                    current_wavelengths = temp_wl
            # If temp_int is None but status was not error (e.g. skipped_missing_ref), intensities don't change.

            applied_pipeline_successfully.append(step_to_apply) # Store the successfully applied step

        # Update the spectrum's main processed data and its pipeline record
        spectrum.set_processed_data(current_intensities, current_wavelengths)
        spectrum.processing_pipeline = applied_pipeline_successfully 
        
        if all_steps_successful:
            logger.info(f"Successfully applied pipeline of {len(applied_pipeline_successfully)} effective steps to spectrum {spectrum.spectrum_id}.")
        else:
            logger.warning(f"Pipeline application for spectrum {spectrum.spectrum_id} had errors. "
                           f"{len(applied_pipeline_successfully)} steps were stored in its history before failure/stop.")
            
        return all_steps_successful


    def apply_pipeline_with_intermediates(
        self,
        spectrum_to_process: LIBSpectrum, # This spectrum object will be modified
        pipeline: List[ProcessingStep]
    ) -> Tuple[LIBSpectrum, List[Dict[str, Any]]]:
        """
        Applies a pipeline and returns the final spectrum AND intermediate results.
        The input spectrum_to_process is modified in-place for its processed data,
        but its .processing_pipeline attribute is NOT updated by this method.
        This is primarily for previews where the original spectrum object shouldn't
        have its history changed yet.

        Args:
            spectrum_to_process: LIBSpectrum to process (will be modified).
            pipeline: List of ProcessingStep objects.

        Returns:
            Tuple: (
                processed_spectrum: The input spectrum object, now with updated processed data.
                intermediate_results: List of dictionaries, each containing details from a step.
            )
        """
        if not spectrum_to_process.is_valid():
            raise ValueError(f"Cannot apply pipeline: Spectrum {spectrum_to_process.spectrum_id} has no valid raw data.")

        # Start from the spectrum's current state for this type of application
        # (which should be raw if it's a fresh copy for preview)
        current_wavelengths = spectrum_to_process.wavelengths.copy()
        current_intensities = spectrum_to_process.intensities.copy()
        
        intermediate_step_outputs: List[Dict[str, Any]] = []
        
        for step in pipeline:
            if not step.enabled:
                intermediate_step_outputs.append({"step_name": step.name, "status": "skipped_disabled"})
                continue

            step_to_apply = ProcessingStep(step.name, copy.deepcopy(step.parameters), step.enabled)
            
            temp_wl, temp_int, step_details = self.apply_single_step(
                spectrum_to_process, # Pass original for metadata if needed
                step_to_apply,
                current_wavelengths,
                current_intensities
            )
            
            step_details["step_name"] = step.name # Add step name for clarity
            intermediate_step_outputs.append(step_details)

            if step_details.get("status", "").startswith("error"):
                logger.error(f"Preview pipeline stopped at step '{step.name}' due to error: {step_details.get('error')}")
                # Update spectrum_to_process to state before error for consistency in preview
                spectrum_to_process.set_processed_data(current_intensities, current_wavelengths)
                # Don't raise, let caller handle based on intermediate_results
                break 
            
            if temp_int is not None:
                current_intensities = temp_int
                if temp_wl is not None:
                    current_wavelengths = temp_wl
            
            # Store the output wavelengths of this step if they changed, for plotting baselines correctly
            if temp_wl is not None:
                 step_details['wavelengths_at_step_output'] = temp_wl.copy()
            else: # Wavelengths didn't change
                 step_details['wavelengths_at_step_output'] = current_wavelengths.copy()


        # Set the final processed data on the input spectrum object
        spectrum_to_process.set_processed_data(current_intensities, current_wavelengths)
        
        return spectrum_to_process, intermediate_step_outputs


# Standalone utility function (can be deprecated if SpectrumProcessor is always used)
def apply_processing_pipeline(spectrum: LIBSpectrum, pipeline: List[ProcessingStep]) -> bool:
    """
    Applies a sequence of preprocessing steps to a LIBSpectrum object.
    Convenience wrapper around SpectrumProcessor.
    """
    processor = SpectrumProcessor()
    return processor.apply_pipeline(spectrum, pipeline)


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s-%(name)s[%(levelname)s]%(module)s:%(lineno)d-%(message)s')

    raw_wl = np.linspace(200, 800, 500) # Reduced points for faster testing
    raw_int_base = 50 + 0.1 * raw_wl + 30 * np.sin(raw_wl / 50) # Baseline
    raw_int_peaks = 200 * np.exp(-((raw_wl - 300)**2) / 10) + 150 * np.exp(-((raw_wl - 500)**2) / 20) # Peaks
    raw_int_noise = np.random.normal(0, 5, size=raw_wl.shape) # Noise
    raw_int = raw_int_base + raw_int_peaks + raw_int_noise
    
    spec = LIBSpectrum(raw_wl.copy(), raw_int.copy(), filename="test_proc.txt", spectrum_id="sp01")
    logger.info(f"Original spectrum: {spec.spectrum_id}, Sum Intens: {np.sum(spec.intensities):.2f}")

    pipeline_test = [
        ProcessingStep(name="baseline_als", parameters={"lam": 1e4, "p": 0.01, "niter": 5}),
        ProcessingStep(name="smooth_savgol", parameters={"window_length": 7, "polyorder": 3}),
        ProcessingStep(name="normalize_to_max")
    ]

    processor = SpectrumProcessor()
    
    logger.info("\n--- Testing apply_pipeline (modifies spectrum in-place) ---")
    # Create a copy for this test path
    spec_for_apply = LIBSpectrum(raw_wl.copy(), raw_int.copy(), spectrum_id="sp01_apply")
    success = processor.apply_pipeline(spec_for_apply, pipeline_test)
    if success:
        logger.info(f"Processed (apply_pipeline): {spec_for_apply.spectrum_id}, Sum Intens: {np.sum(spec_for_apply.intensities):.2f}")
        logger.info(f"Stored pipeline: {spec_for_apply.processing_pipeline}")
        assert len(spec_for_apply.processing_pipeline) == 3
        assert np.isclose(np.max(spec_for_apply.intensities), 1.0)
    else:
        logger.error("apply_pipeline failed.")

    logger.info("\n--- Testing apply_pipeline_with_intermediates (for preview) ---")
    # Create a fresh copy for this test path, ensure it starts from raw-like state
    spec_for_preview = LIBSpectrum(raw_wl.copy(), raw_int.copy(), spectrum_id="sp01_preview")
    
    processed_preview_spec, intermediates = processor.apply_pipeline_with_intermediates(spec_for_preview, pipeline_test)
    
    logger.info(f"Processed (preview): {processed_preview_spec.spectrum_id}, Sum Intens: {np.sum(processed_preview_spec.intensities):.2f}")
    assert np.isclose(np.max(processed_preview_spec.intensities), 1.0)
    logger.info(f"Number of intermediate results: {len(intermediates)}")
    for i, res in enumerate(intermediates):
        logger.info(f"Intermediate {i} ({res.get('step_name')}): Status - {res.get('status')}")
        if 'estimated_baseline' in res:
            logger.info(f"  ... estimated baseline available (sum: {np.sum(res['estimated_baseline']):.2f})")
            assert res['wavelengths_at_step_output'] is not None


    logger.info("\n--- Test error handling in pipeline ---")
    pipeline_with_error = [
        ProcessingStep(name="baseline_als", parameters={"lam": 1e4, "p": 0.01}),
        ProcessingStep(name="non_existent_step", parameters={}), # This will fail
        ProcessingStep(name="normalize_to_max")
    ]
    spec_for_error_test = LIBSpectrum(raw_wl.copy(), raw_int.copy(), spectrum_id="sp01_error")
    success_error = processor.apply_pipeline(spec_for_error_test, pipeline_with_error)
    assert not success_error
    logger.info(f"Pipeline with error: success={success_error}, number of steps in spectrum history: {len(spec_for_error_test.processing_pipeline)}")
    assert len(spec_for_error_test.processing_pipeline) == 1 # Only first step should be there
    # Check that processed data is from after the first step
    
    temp_spec_for_first_step_only = LIBSpectrum(raw_wl.copy(), raw_int.copy())
    processor.apply_single_step(temp_spec_for_first_step_only, pipeline_with_error[0], temp_spec_for_first_step_only.raw_wavelengths, temp_spec_for_first_step_only.raw_intensities)
    assert np.allclose(spec_for_error_test.intensities, temp_spec_for_first_step_only.intensities)
    
    logger.info("SpectrumHandler tests completed.")
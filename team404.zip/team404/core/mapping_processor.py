# team404/core/mapping_processor.py

"""
Handles the processing of LIBS spectral data for 2D elemental mapping.
This includes batch preprocessing, intensity extraction, and map generation.
"""

import logging
from typing import List, Dict, Tuple, Callable, Optional, Any
import numpy as np
import re
from scipy.interpolate import griddata # For potential map interpolation
from scipy.optimize import curve_fit
from scipy.signal import savgol_filter # For Savitzky-Golay filter
from scipy.special import voigt_profile # For Voigt fitting

# Import data models and other core components
from .data_models import LIBSpectrum, ElementalMapData, ProcessingStep

logger = logging.getLogger(__name__)

# --- Helper types ---
IntensityExtractionMethod = Callable[[LIBSpectrum, float, Dict[str, Any]], Optional[float]]


# --- "Real" (Simplified) Processing Functions ---
# In a final application, these would be imported from preprocessing_algorithms.py and peak_algorithms.py

def _apply_baseline_als(intensities: np.ndarray, **params) -> np.ndarray:
    """
    Applies Asymmetric Least Squares (ALS) baseline correction.
    Simplified version. A robust version would be in preprocessing_algorithms.py.
    """
    lam = params.get("lambda", 1e5)
    p = params.get("p", 0.01)
    niter = params.get("niter", 10)
    
    L = len(intensities)
    D = np.diff(np.eye(L), 2)
    # Pad D to have L columns if L is small (e.g., L < 3 for n=2 diff)
    if L < 3: # Simplified handling for very short arrays
        if L == 1: return intensities # No baseline for single point
        if L == 2: D_padded = np.zeros((1,2)) # Effectively no smoothing for 2 points
        else: D_padded = np.zeros((L-2,L)) # Should not happen if L < 3
    else:
        D_padded = lam * D.T @ D

    w = np.ones(L)
    baseline_corrected_intensities = intensities.copy() # Operate on a copy

    for _ in range(niter):
        W = np.diag(w)
        try:
            Z = W + D_padded
            z = np.linalg.solve(Z, w * baseline_corrected_intensities)
            w = p * (baseline_corrected_intensities > z) + (1 - p) * (baseline_corrected_intensities < z)
        except np.linalg.LinAlgError:
            logger.warning("Singular matrix in ALS, returning original intensities for this step.")
            return intensities # Return original if solver fails
            
    return baseline_corrected_intensities - z


def _apply_savgol_filter(intensities: np.ndarray, **params) -> np.ndarray:
    """
    Applies a Savitzky-Golay filter.
    Wrapper around scipy.signal.savgol_filter.
    """
    window_length = params.get("window_length", 5)
    polyorder = params.get("polyorder", 2)
    
    # Ensure window_length is odd and greater than polyorder
    if window_length % 2 == 0:
        window_length += 1
    if window_length <= polyorder:
        window_length = polyorder + 1 + (polyorder % 2) # Ensure odd and > polyorder

    if len(intensities) < window_length:
        logger.warning(f"Data length ({len(intensities)}) is less than SavGol window length ({window_length}). Skipping filter.")
        return intensities
        
    return savgol_filter(intensities, window_length, polyorder)


def _voigt_function_for_scipy(x, amplitude, center, sigma_g, gamma_l):
    """
    Voigt profile for use with scipy.optimize.curve_fit.
    sigma_g: Gaussian sigma
    gamma_l: Lorentzian HWHM (gamma)
    """
    # voigt_profile expects sigma (Gaussian std dev) and gamma (Lorentzian HWHM)
    return amplitude * voigt_profile(x - center, sigma_g, gamma_l)


def _fit_voigt_for_map(
    wavelengths: np.ndarray, intensities: np.ndarray, center_wl_guess: float, fit_window_nm: float = 1.0
) -> Optional[Dict[str, float]]:
    """
    Fits a Voigt profile to a region of the spectrum using scipy.
    Returns a dictionary with 'amplitude' and 'area' if successful.
    """
    roi_mask = (wavelengths >= center_wl_guess - fit_window_nm / 2) & \
               (wavelengths <= center_wl_guess + fit_window_nm / 2)
    
    wl_roi = wavelengths[roi_mask]
    int_roi = intensities[roi_mask]

    if len(wl_roi) < 3: # Need at least 3 points for a meaningful fit (ideally more)
        logger.debug(f"Not enough points in ROI for Voigt fit around {center_wl_guess:.2f} nm.")
        return None

    try:
        # Initial guesses
        amplitude_guess = np.max(int_roi) - np.min(int_roi)
        if amplitude_guess <= 0: amplitude_guess = np.finfo(float).eps # Ensure positive
        
        # Rough FWHM estimate for initial width guesses (can be improved)
        # These are just starting points; bounds are more critical.
        # Sigma and Gamma are related to FWHM but not directly FWHM.
        # For voigt_profile, sigma is Gaussian std dev, gamma is Lorentzian HWHM.
        # A very rough starting point for widths could be a fraction of the ROI.
        initial_sigma_g = fit_window_nm / 10.0 
        initial_gamma_l = fit_window_nm / 10.0


        p0 = [amplitude_guess, center_wl_guess, initial_sigma_g, initial_gamma_l]
        
        # Bounds: [amplitude, center, sigma_g, gamma_l]
        # Center can vary slightly around the guess.
        # Widths must be positive and not excessively large.
        bounds_lower = [0, center_wl_guess - fit_window_nm/4, 1e-4, 1e-4]
        bounds_upper = [amplitude_guess * 2 + np.finfo(float).eps, # Max amplitude can be larger
                        center_wl_guess + fit_window_nm/4, 
                        fit_window_nm, # Sigma_G max
                        fit_window_nm]  # Gamma_L max


        popt, pcov = curve_fit(_voigt_function_for_scipy, wl_roi, int_roi, p0=p0, bounds=(bounds_lower, bounds_upper), maxfev=5000)
        
        amplitude, center, sigma_g, gamma_l = popt
        
        # Calculate area (approximate for Voigt, or use numerical integration of fitted curve)
        # For simplicity, A * (sqrt(2*pi)*sigma_G + pi*gamma_L) is a rough approximation sometimes used
        # A more accurate way is to integrate the fitted function.
        # Here, let's just use amplitude for simplicity or a very rough area.
        # A common approximation for Voigt FWHM: f_V ≈ 0.5346*f_L + sqrt(0.2166*f_L^2 + f_G^2)
        # f_G = 2*sigma_g*sqrt(2*ln2), f_L = 2*gamma_l
        
        # For area, integrate the fitted function numerically
        fitted_curve_roi = _voigt_function_for_scipy(wl_roi, *popt)
        area = np.trapz(fitted_curve_roi, wl_roi) if len(wl_roi) > 1 else amplitude # Fallback

        return {"amplitude": amplitude, "area": area, "center": center, "sigma_g": sigma_g, "gamma_l": gamma_l}

    except RuntimeError:
        logger.debug(f"Voigt fit did not converge for ROI around {center_wl_guess:.2f} nm.")
    except ValueError as e:
        logger.debug(f"ValueError during Voigt fit for ROI around {center_wl_guess:.2f} nm: {e}")
    except Exception as e:
        logger.error(f"Unexpected error during Voigt fit for {center_wl_guess:.2f} nm: {e}")
    return None


# --- Intensity Extraction Methods (Modified to use the more real Voigt fit) ---

def get_intensity_at_peak_height(
    spectrum: LIBSpectrum, target_wavelength: float, params: Dict[str, Any]
) -> Optional[float]:
    """Extracts intensity at the exact target_wavelength (interpolated)."""
    try:
        interp_val = np.interp(target_wavelength, spectrum.wavelengths, spectrum.intensities)
        return float(interp_val)
    except Exception as e:
        logger.warning(f"Could not get peak height for {spectrum.spectrum_id} at {target_wavelength:.2f} nm: {e}")
        return None

def get_intensity_by_peak_area(
    spectrum: LIBSpectrum, target_wavelength: float, params: Dict[str, Any]
) -> Optional[float]:
    """Calculates integrated intensity (area) around the target_wavelength."""
    integration_window_nm = params.get("integration_window_nm", 0.2)
    wl_min = target_wavelength - integration_window_nm / 2
    wl_max = target_wavelength + integration_window_nm / 2

    wavelengths, intensities = spectrum.wavelengths, spectrum.intensities
    roi_indices = np.where((wavelengths >= wl_min) & (wavelengths <= wl_max))[0]

    if len(roi_indices) < 2:
        logger.warning(f"Not enough points for area integration for {spectrum.spectrum_id} at {target_wavelength:.2f} nm with window {integration_window_nm} nm.")
        return None
    try:
        area = np.trapz(intensities[roi_indices], wavelengths[roi_indices])
        return float(area)
    except Exception as e:
        logger.warning(f"Could not get peak area for {spectrum.spectrum_id} at {target_wavelength:.2f} nm: {e}")
        return None

def get_intensity_by_voigt_fit(
    spectrum: LIBSpectrum, target_wavelength: float, params: Dict[str, Any]
) -> Optional[float]:
    """Extracts intensity (amplitude or area) from a Voigt fit."""
    fit_metric = params.get("fit_metric", "amplitude") # "amplitude" or "area"
    fit_window_nm_map = params.get("fit_window_nm_map", 1.0)

    fit_results = _fit_voigt_for_map(spectrum.wavelengths, spectrum.intensities, target_wavelength, fit_window_nm_map)

    if fit_results:
        if fit_metric == "amplitude" and "amplitude" in fit_results:
            return float(fit_results["amplitude"])
        elif fit_metric == "area" and "area" in fit_results:
            return float(fit_results["area"])
        else:
            logger.warning(f"Voigt fit metric '{fit_metric}' not found in results for {spectrum.spectrum_id} at {target_wavelength:.2f} nm.")
    else:
        logger.debug(f"Voigt fit failed for {spectrum.spectrum_id} at {target_wavelength:.2f} nm.")
    return None


INTENSITY_EXTRACTION_METHODS: Dict[str, IntensityExtractionMethod] = {
    "peak_height": get_intensity_at_peak_height,
    "peak_area": get_intensity_by_peak_area,
    "voigt_fit": get_intensity_by_voigt_fit,
}


class MappingProcessor:
    def __init__(self,
                 spectra_collection: List[LIBSpectrum],
                 map_dimensions: Tuple[int, int],
                 filename_coord_pattern: Optional[str] = None, # Added for regex parsing
                 preprocessing_pipeline: Optional[List[ProcessingStep]] = None):
        self.spectra_collection = spectra_collection
        self.num_x_points, self.num_y_points = map_dimensions
        self.filename_coord_pattern = filename_coord_pattern
        self.preprocessing_pipeline = preprocessing_pipeline if preprocessing_pipeline else []

        self._prepare_coordinates()
        # Batch preprocessing is now done once upon initialization,
        # modifying the LIBSpectrum objects in the collection for the mapping context.
        self._batch_preprocess_spectra()

    def _prepare_coordinates(self):
        all_x = set()
        all_y = set()
        has_coords = all(s.x_coord is not None and s.y_coord is not None for s in self.spectra_collection)

        if has_coords:
            logger.info("Using pre-assigned coordinates from LIBSpectrum objects.")
            for s in self.spectra_collection:
                all_x.add(s.x_coord)
                all_y.add(s.y_coord)
        elif self.filename_coord_pattern:
            logger.info(f"Attempting to parse coordinates from filenames using pattern: {self.filename_coord_pattern}")
            try:
                coord_regex = re.compile(self.filename_coord_pattern)
                for s in self.spectra_collection:
                    if s.filename:
                        match = coord_regex.search(s.filename)
                        if match and len(match.groups()) >= 2:
                            s.x_coord = float(match.group(1))
                            s.y_coord = float(match.group(2))
                            all_x.add(s.x_coord)
                            all_y.add(s.y_coord)
                        else:
                            logger.warning(f"Could not parse coordinates from filename: {s.filename}")
            except re.error as e:
                raise ValueError(f"Invalid regex for coordinate parsing: {e}") from e
        else:
            logger.info("Assigning grid coordinates based on order and map dimensions.")
            if len(self.spectra_collection) != self.num_x_points * self.num_y_points:
                msg = (f"Number of spectra ({len(self.spectra_collection)}) does not match "
                       f"map dimensions ({self.num_x_points}x{self.num_y_points}). Cannot assign grid coordinates.")
                raise ValueError(msg)
            idx = 0
            for y_idx in range(self.num_y_points):
                for x_idx in range(self.num_x_points):
                    self.spectra_collection[idx].x_coord = float(x_idx)
                    self.spectra_collection[idx].y_coord = float(y_idx)
                    all_x.add(float(x_idx))
                    all_y.add(float(y_idx))
                    idx += 1
        
        self.unique_x_coords = np.array(sorted(list(all_x)))
        self.unique_y_coords = np.array(sorted(list(all_y)))

        if len(self.unique_x_coords) != self.num_x_points or len(self.unique_y_coords) != self.num_y_points:
             logger.warning(f"Effective grid dimensions ({len(self.unique_x_coords)}x{len(self.unique_y_coords)}) "
                           f"differ from specified map dimensions ({self.num_x_points}x{self.num_y_points}). "
                           f"Using effective dimensions for map grid.")
             self.num_x_points = len(self.unique_x_coords)
             self.num_y_points = len(self.unique_y_coords)

    def _batch_preprocess_spectra(self, progress_callback: Optional[Callable[[int, int], None]] = None,
                                  interruption_check_callback: Optional[Callable[[], bool]] = None):
        if not self.preprocessing_pipeline:
            logger.info("No preprocessing pipeline defined for mapping.")
            for spectrum in self.spectra_collection: # Ensure processed state is same as raw if no pipeline
                 spectrum.set_processed_data(spectrum.raw_intensities.copy(), spectrum.raw_wavelengths.copy())
            return

        total_spectra = len(self.spectra_collection)
        logger.info(f"Starting batch preprocessing for {total_spectra} spectra for mapping context.")
        for i, spectrum in enumerate(self.spectra_collection):
            if interruption_check_callback and interruption_check_callback():
                logger.info("Batch preprocessing interrupted by user request.")
                break
            
            current_intensities = spectrum.raw_intensities.copy()
            
            for step in self.preprocessing_pipeline:
                if not step.enabled:
                    continue
                try:
                    if step.name == "baseline_als":
                        current_intensities = _apply_baseline_als(current_intensities, **step.parameters)
                    elif step.name == "savgol_filter":
                        current_intensities = _apply_savgol_filter(current_intensities, **step.parameters)
                    else:
                        logger.warning(f"Unknown or unsupported preprocessing step for mapping: '{step.name}'. Skipping.")
                except Exception as e:
                    logger.error(f"Error applying step '{step.name}' to spectrum {spectrum.spectrum_id} during batch map processing: {e}")
            
            spectrum.set_processed_data(current_intensities, spectrum.raw_wavelengths)
            spectrum.processing_pipeline = self.preprocessing_pipeline
            
            if progress_callback:
                progress_callback(i + 1, total_spectra)
        logger.info("Batch preprocessing for mapping context completed.")

    # --- ADDED: New helper method ---
    def get_map_grid_shape(self) -> Tuple[int, int]:
        """Returns the effective grid dimensions (num_x_points, num_y_points)."""
        return self.num_x_points, self.num_y_points

    # --- ADDED: New helper method ---
    def get_spectrum_at_coords(self, x_coord: float, y_coord: float) -> Optional[LIBSpectrum]:
        """
        Finds the spectrum in the collection closest to the given coordinates.

        Args:
            x_coord: The target X coordinate.
            y_coord: The target Y coordinate.

        Returns:
            The LIBSpectrum object closest to the target coordinates, or None if no spectra are loaded.
        """
        if not self.spectra_collection:
            return None

        # Calculate squared Euclidean distance for all spectra
        distances = [
            (s.x_coord - x_coord)**2 + (s.y_coord - y_coord)**2
            for s in self.spectra_collection if s.x_coord is not None and s.y_coord is not None
        ]

        if not distances:
            return None # No spectra with valid coordinates

        # Find the index of the minimum distance
        min_distance_index = np.argmin(distances)
        return self.spectra_collection[min_distance_index]

    def generate_elemental_map(
        self,
        element_label: str,
        target_wavelength: float,
        quantification_method: str,
        quant_params: Optional[Dict[str, Any]] = None,
        progress_callback: Optional[Callable[[int, int], None]] = None,
        interruption_check_callback: Optional[Callable[[], bool]] = None # --- MODIFIED ---
    ) -> Optional[ElementalMapData]:
        if quantification_method not in INTENSITY_EXTRACTION_METHODS:
            logger.error(f"Unsupported quantification method: {quantification_method}")
            return None
        
        intensity_extraction_func = INTENSITY_EXTRACTION_METHODS[quantification_method]
        params = quant_params if quant_params else {}

        logger.info(f"Generating map for '{element_label}' at {target_wavelength:.2f} nm "
                    f"using method '{quantification_method}'.")

        intensity_matrix = np.full((self.num_y_points, self.num_x_points), np.nan, dtype=float)
        total_spectra = len(self.spectra_collection)

        for i, spectrum in enumerate(self.spectra_collection):
            # --- MODIFIED: Added interruption check ---
            if interruption_check_callback and interruption_check_callback():
                logger.info("Map generation interrupted by user request.")
                return None
            # --- END MODIFICATION ---

            if spectrum.x_coord is None or spectrum.y_coord is None:
                logger.warning(f"Spectrum {spectrum.spectrum_id} missing coordinates. Skipping for map.")
                if progress_callback: progress_callback(i + 1, total_spectra)
                continue
            try:
                # Find the index in the unique coordinate arrays to place the value in the matrix
                x_idx = np.where(self.unique_x_coords == spectrum.x_coord)[0][0]
                y_idx = np.where(self.unique_y_coords == spectrum.y_coord)[0][0]
            except IndexError:
                logger.warning(f"Could not map coordinates ({spectrum.x_coord}, {spectrum.y_coord}) "
                               f"for spectrum {spectrum.spectrum_id} to map grid. Skipping.")
                if progress_callback: progress_callback(i + 1, total_spectra)
                continue

            intensity_value = intensity_extraction_func(spectrum, target_wavelength, params)

            if intensity_value is not None:
                intensity_matrix[y_idx, x_idx] = intensity_value
            else:
                logger.debug(f"No intensity value for spectrum {spectrum.spectrum_id} at map point ({x_idx}, {y_idx}).")

            if progress_callback:
                progress_callback(i + 1, total_spectra)
        
        # --- MODIFIED: Changed what is stored in ElementalMapData ---
        map_data = ElementalMapData(
            element_label=element_label,
            intensity_matrix=intensity_matrix,
            x_coordinates_map=self.unique_x_coords, # Store the grid axes
            y_coordinates_map=self.unique_y_coords, # Store the grid axes
            target_wavelength_nm=target_wavelength,
            quantification_method=quantification_method,
            quant_params=params
        )
        # --- END MODIFICATION ---
        
        logger.info(f"Map generation for '{element_label}' completed.")
        return map_data

    def interpolate_map(self, map_data: ElementalMapData, method='linear', fill_value=np.nan) -> np.ndarray:
        logger.info(f"Interpolating map '{map_data.element_label}' using method '{method}'.")
        x = map_data.x_coordinates_map
        y = map_data.y_coordinates_map
        z = map_data.intensity_matrix

        points_with_data = []
        values_at_points = []
        for iy, y_val in enumerate(y):
            for ix, x_val in enumerate(x):
                if not np.isnan(z[iy, ix]):
                    points_with_data.append([x_val, y_val])
                    values_at_points.append(z[iy, ix])
        
        if not points_with_data:
            logger.warning("No data points available for interpolation.")
            return z

        points_with_data = np.array(points_with_data)
        values_at_points = np.array(values_at_points)

        xi = np.linspace(x.min(), x.max(), len(x) * 2)
        yi = np.linspace(y.min(), y.max(), len(y) * 2)
        grid_x, grid_y = np.meshgrid(xi, yi)

        try:
            interpolated_z = griddata(points_with_data, values_at_points, (grid_x, grid_y),
                                      method=method, fill_value=fill_value)
            logger.info("Interpolation successful.")
            return interpolated_z
        except Exception as e:
            logger.error(f"Interpolation failed: {e}")
            return z


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    logger.info("Mapping Processor Module - Example Usage with 'Real' Functions")

    num_x, num_y = 5, 4
    spectra = []
    base_wl = np.linspace(200, 800, 1024) # More points for better fitting
    for yi in range(num_y):
        for xi in range(num_x):
            peak1_intensity = 10 + xi * 5 + yi * 3
            peak2_intensity = 50 - xi * 2 - yi * 5
            # Add a simple baseline and noise
            baseline = 5 + 0.01 * base_wl + np.sin(base_wl / 50) * 2
            noise = np.random.normal(0, 0.5, len(base_wl))
            intensities = (
                peak1_intensity * voigt_profile(base_wl - 300.0, 0.05, 0.03) + # Simulating Voigt peaks
                peak2_intensity * voigt_profile(base_wl - 500.0, 0.08, 0.05) +
                baseline + noise
            )
            spectrum = LIBSpectrum(base_wl, intensities, filename=f"map_x{xi}_y{yi}.txt", x_coord=float(xi), y_coord=float(yi))
            spectra.append(spectrum)

    pipeline = [
        ProcessingStep(name="baseline_als", parameters={"lambda": 1e4, "p": 0.005, "niter":15}),
        ProcessingStep(name="savgol_filter", parameters={"window_length": 11, "polyorder": 3})
    ]

    try:
        processor = MappingProcessor(spectra, map_dimensions=(num_x, num_y), preprocessing_pipeline=pipeline)
        
        # Check if preprocessing changed one of the spectra (it should have)
        original_first_spec_intensity_sum = np.sum(spectra[0].raw_intensities)
        processed_first_spec_intensity_sum = np.sum(spectra[0].intensities) # Accesses processed data
        print(f"Original first spectrum sum: {original_first_spec_intensity_sum:.2f}")
        print(f"Processed first spectrum sum (after batch): {processed_first_spec_intensity_sum:.2f}")
        assert not np.isclose(original_first_spec_intensity_sum, processed_first_spec_intensity_sum), "Preprocessing did not change data"


        def progress_update(current, total):
            print(f"Map generation progress: {current}/{total}", end='\r')

        map1_data = processor.generate_elemental_map(
            element_label="Fit Amplitude at 300nm",
            target_wavelength=300.0,
            quantification_method="voigt_fit",
            quant_params={"fit_metric": "amplitude", "fit_window_nm_map": 2.0}, # Wider window for Voigt
            progress_callback=progress_update
        )
        print("\n") # Newline after progress

        if map1_data:
            print(f"Generated map: {map1_data.element_label}")
            print(f"Matrix shape: {map1_data.intensity_matrix.shape}")
            print("Intensity Matrix (first 3x3 or all):")
            print(map1_data.intensity_matrix[:min(3,num_y), :min(3,num_x)])
            assert map1_data.intensity_matrix.shape == (num_y, num_x)

    except ValueError as e:
        print(f"Error initializing MappingProcessor: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
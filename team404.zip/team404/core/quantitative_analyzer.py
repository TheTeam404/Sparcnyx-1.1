# team404/core/quantitative_analyzer.py

"""
Provides tools for quantitative analysis of LIBS spectra,
such as Boltzmann plots for plasma temperature estimation.
"""

import logging
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass, field # Import field for default_factory

import numpy as np
from scipy.stats import linregress
# For RANSAC, scikit-learn is a common choice
try:
    from sklearn.linear_model import RANSACRegressor
    from sklearn.metrics import r2_score, mean_squared_error
    _SKLEARN_AVAILABLE = True
except ImportError:
    _SKLEARN_AVAILABLE = False
    RANSACRegressor = None # Placeholder
    logger = logging.getLogger(__name__) # Logger needed here if sklearn fails
    logger.warning("Scikit-learn not found. RANSACRegressor for Boltzmann plot will not be available.")


logger = logging.getLogger(__name__)

# Constants for Boltzmann plot
K_B_EV = 8.617333262145e-5  # Boltzmann constant in eV/K
K_B_CM = 0.69503476        # Boltzmann constant in cm^-1/K
H_C_EV_NM = 1239.84193     # hc product in eV*nm (for E = hc/lambda)

@dataclass
class BoltzmannLinePoint:
    """
    Represents a single data point for a Boltzmann plot.
    Fields without defaults must come before fields with defaults.
    """
    # Fields without default values
    intensity: float
    wavelength_nm: float  # Experimental wavelength of the line peak
    Aki: float            # Transition probability (s^-1)
    gk: float             # Statistical weight of the upper energy level
    Ek: float             # Upper energy level (in specified units, e.g., eV or cm^-1)

    # Fields with default values (must come after non-default fields)
    element: Optional[str] = None
    ion_stage: Optional[str] = None
    intensity_uncertainty: Optional[float] = None # For weighted fits, if available
    # Optional: Store original database line info if needed for reference
    db_wavelength_nm: Optional[float] = None
    notes: Optional[str] = None

    def __post_init__(self):
        # Validation after initialization
        if self.intensity <= 0:
            # logger.warning(f"BoltzmannLinePoint created with non-positive intensity: {self.intensity}")
            # Allow zero/negative for plotting, but it will likely be filtered or cause math errors.
            pass # Or raise ValueError("Intensity must be positive for Boltzmann plot calculations.")
        if self.Aki <= 0:
            raise ValueError("Aki (transition probability) must be positive.")
        if self.gk <= 0:
            raise ValueError("gk (statistical weight) must be positive.")
        # Ek can be zero (ground state of upper level relative to some zero)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "intensity": self.intensity,
            "wavelength_nm": self.wavelength_nm,
            "Aki": self.Aki,
            "gk": self.gk,
            "Ek": self.Ek,
            "element": self.element,
            "ion_stage": self.ion_stage,
            "intensity_uncertainty": self.intensity_uncertainty,
            "db_wavelength_nm": self.db_wavelength_nm,
            "notes": self.notes,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BoltzmannLinePoint':
        return cls(**data)


class QuantitativeAnalyzer:
    """
    Performs quantitative analysis tasks on spectral data.
    """

    def __init__(self):
        logger.info("QuantitativeAnalyzer initialized.")

    def calculate_boltzmann_plot(self,
                                 line_points: List[BoltzmannLinePoint],
                                 energy_unit: str = "ev", # "ev" or "cm-1"
                                 use_ransac: bool = False,
                                 ransac_params: Optional[Dict[str, Any]] = None
                                 ) -> Optional[Dict[str, Any]]:
        """
        Calculates data for a Boltzmann plot and estimates plasma temperature.

        Args:
            line_points: A list of BoltzmannLinePoint objects, all for the
                         same element and ionization stage.
            energy_unit: The unit of 'Ek' in the line_points ("ev" or "cm-1").
            use_ransac: Whether to use RANSAC for robust linear regression.
            ransac_params: Dictionary of parameters for RANSACRegressor if use_ransac is True.
                           E.g., {'min_samples': 2, 'residual_threshold': 0.5}

        Returns:
            A dictionary containing plot data and results, or None if calculation fails.
            Keys: 'x_values_all', 'y_values_all', 'slope', 'intercept', 'r_squared',
                  'temperature_k', 'temperature_uncertainty_k' (optional),
                  'n_points_valid_input', 'n_points_used_in_fit', 'fit_method',
                  'inlier_mask' (if RANSAC used).
        """
        if not line_points or len(line_points) < 2:
            logger.warning("Boltzmann plot calculation requires at least two valid line points.")
            return {"error": "Insufficient valid line points for Boltzmann plot (minimum 2 required)."}

        if energy_unit.lower() not in ["ev", "cm-1", "cm^-1"]:
            logger.error(f"Invalid energy unit for Boltzmann plot: {energy_unit}")
            return {"error": f"Invalid energy unit '{energy_unit}'. Must be 'ev' or 'cm-1'."}
        
        # Prepare x and y values for the plot
        # y = ln(I * lambda / (Aki * gk))  (lambda in nm)
        # x = Ek
        x_values = []
        y_values = []
        valid_points_for_fit = [] # Store original BoltzmannLinePoint objects used in fit

        for point in line_points:
            if point.intensity <= 0 or point.Aki <= 0 or point.gk <= 0:
                logger.warning(f"Skipping invalid Boltzmann point (I, Aki, or gk <= 0): {point}")
                continue
            
            # Ensure Ek is positive or zero for typical Boltzmann plots
            # (negative Ek relative to ionization limit might occur but is unusual for typical Te calcs)
            if point.Ek < 0:
                logger.warning(f"Skipping Boltzmann point with negative Ek: {point.Ek} for {point}")
                continue

            # y_val = np.log((point.intensity * point.wavelength_nm) / (point.Aki * point.gk))
            # Alternative form often seen: y = ln(I / (A_ki * g_k * nu)) where nu = c/lambda.
            # Or y = ln(I * lambda^3 / (A_ki * g_k * C)) where C is a constant factor (2*pi*h*c^2 etc.)
            # The common form for Te from slope is y = ln(I*lambda / (Aki*gk)) vs Ek,
            # where slope = -1 / (k_B * T_e). Ensure Ek units match k_B units.
            
            # Using the form: ln( I * lambda_nm / (A_ki * g_k) )
            # This form makes the y-axis unitless effectively (after log).
            # Some sources use ln(I / (A_ki * g_k)), but including lambda is common when intensity is energy/area/time.
            # The choice affects the intercept but not the slope (and thus not Te).
            # Let's stick to ln(I * lambda / (A_ki * g_k)) for consistency if intensity I is per unit wavelength interval.
            # If I is total photon count, then ln(I / (A_ki * g_k)) might be used.
            # Assuming Intensity (I) here is as measured from spectrum (counts, arbitrary units related to irradiance).
            
            try:
                y_val = np.log((point.intensity * point.wavelength_nm) / (point.Aki * point.gk))
                x_values.append(point.Ek)
                y_values.append(y_val)
                valid_points_for_fit.append(point)
            except (ValueError, TypeError, ZeroDivisionError) as e:
                logger.warning(f"Error calculating x/y for Boltzmann point {point}: {e}. Skipping.")
                continue
        
        if len(x_values) < 2:
            logger.warning("Not enough valid points remaining after filtering for Boltzmann plot calculation.")
            return {"error": "Fewer than two valid data points remain after filtering for Boltzmann plot."}

        x_fit_array = np.array(x_values).reshape(-1, 1) # For scikit-learn compatibility (needs 2D X)
        y_fit_array = np.array(y_values)

        slope, intercept, r_value, p_value, std_err_slope = -1.0, 0.0, 0.0, 1.0, np.nan # Initialize
        temperature_k: Optional[float] = None
        temp_uncertainty_k: Optional[float] = None
        inlier_mask: Optional[np.ndarray] = None
        fit_method = "Linear Regression"
        n_points_used = len(x_fit_array)

        if use_ransac and _SKLEARN_AVAILABLE and RANSACRegressor is not None:
            fit_method = "RANSAC Regression"
            ransac_defaults = {'min_samples': max(2, int(0.3 * len(x_fit_array))), # At least 30% of points
                               'residual_threshold': None, # Auto-estimate from MAD
                               'max_trials': 100, 'stop_probability': 0.99}
            if ransac_params:
                ransac_defaults.update(ransac_params)
            
            try:
                # Ensure min_samples is not greater than number of samples
                if ransac_defaults['min_samples'] is not None and ransac_defaults['min_samples'] > len(x_fit_array):
                    ransac_defaults['min_samples'] = len(x_fit_array)
                
                ransac = RANSACRegressor(**ransac_defaults, random_state=42)
                ransac.fit(x_fit_array, y_fit_array)
                inlier_mask = ransac.inlier_mask_
                n_points_used = np.sum(inlier_mask)

                if n_points_used < 2 : # RANSAC failed to find enough inliers for a fit
                    logger.warning("RANSAC found fewer than 2 inliers. Falling back to standard linregress on all points.")
                    # Fallback to standard linear regression on all points
                    slope, intercept, r_value, p_value, std_err_slope = linregress(x_fit_array.flatten(), y_fit_array)
                    inlier_mask = np.ones(len(x_fit_array), dtype=bool) # All points are "inliers"
                    n_points_used = len(x_fit_array)
                    fit_method = "Linear Regression (RANSAC fallback)"
                else:
                    # Refit OLS on inliers for final parameters (RANSAC itself might use a robust estimator)
                    # For consistency, we can use linregress on the inliers found by RANSAC
                    x_inliers = x_fit_array[inlier_mask].flatten()
                    y_inliers = y_fit_array[inlier_mask]
                    if len(x_inliers) >=2:
                         slope, intercept, r_value, p_value, std_err_slope = linregress(x_inliers, y_inliers)
                    else: # Should not happen if n_points_used >= 2 from RANSAC
                         slope, intercept, r_value, p_value, std_err_slope = linregress(x_fit_array.flatten(), y_fit_array) # Fallback again
                         inlier_mask = np.ones(len(x_fit_array), dtype=bool)
                         n_points_used = len(x_fit_array)
                         fit_method = "Linear Regression (RANSAC inlier selection failed)"


            except Exception as e_ransac:
                logger.error(f"RANSAC regression failed: {e_ransac}. Falling back to standard linregress.")
                slope, intercept, r_value, p_value, std_err_slope = linregress(x_fit_array.flatten(), y_fit_array)
                fit_method = "Linear Regression (RANSAC error)"
                inlier_mask = np.ones(len(x_fit_array), dtype=bool) # Mark all as inliers for plotting consistency
        else:
            if use_ransac and not _SKLEARN_AVAILABLE:
                logger.warning("RANSAC requested but scikit-learn is not available. Using standard linregress.")
                fit_method = "Linear Regression (sklearn unavailable)"
            slope, intercept, r_value, p_value, std_err_slope = linregress(x_fit_array.flatten(), y_fit_array)
            inlier_mask = np.ones(len(x_fit_array), dtype=bool) # All points are inliers for standard fit

        r_squared = r_value**2

        # Calculate temperature
        # Slope = -1 / (k_B * T_e)  => T_e = -1 / (slope * k_B)
        k_b_selected = K_B_EV if energy_unit.lower() == "ev" else K_B_CM
        if slope == 0: # Avoid division by zero if slope is flat
            logger.warning("Boltzmann plot slope is zero, temperature calculation is undefined (infinite).")
            temperature_k = np.inf
            temp_uncertainty_k = np.inf
        elif slope > 0: # Positive slope is physically incorrect for LTE plasma emission
            logger.warning(f"Boltzmann plot slope is positive ({slope:.2e}), which is non-physical for LTE. Temperature will be negative.")
            # Still calculate, but it's an indicator of issues (non-LTE, wrong lines, self-absorption, etc.)
            temperature_k = -1.0 / (slope * k_b_selected)
            temp_uncertainty_k = np.abs(std_err_slope / (slope**2 * k_b_selected)) if not np.isnan(std_err_slope) else np.nan
        else: # Negative slope, expected case
            temperature_k = -1.0 / (slope * k_b_selected)
            # Propagate uncertainty: delta_T / T = delta_slope / slope
            temp_uncertainty_k = np.abs(temperature_k * (std_err_slope / slope)) if not np.isnan(std_err_slope) and slope != 0 else np.nan


        return {
            "x_values_all": np.array(x_values), # All valid input Ek values
            "y_values_all": np.array(y_values), # All valid input ln(I*lambda/Ag) values
            "slope": slope,
            "intercept": intercept,
            "r_squared": r_squared,
            "std_err_slope": std_err_slope,
            "temperature_k": temperature_k,
            "temperature_uncertainty_k": temp_uncertainty_k,
            "n_points_valid_input": len(x_values),
            "n_points_used_in_fit": n_points_used,
            "fit_method": fit_method,
            "inlier_mask": inlier_mask, # Mask relative to x_values_all/y_values_all
            "selected_line_points_for_fit": valid_points_for_fit # Original objects used
        }

    # Placeholder for calibration curve functionality
    def calculate_calibration_curve(self, concentrations: np.ndarray, intensities: np.ndarray) -> Optional[Dict[str, Any]]:
        """
        (Placeholder) Calculates a linear calibration curve.
        """
        if len(concentrations) != len(intensities) or len(concentrations) < 2:
            logger.warning("Insufficient data for calibration curve.")
            return None
        
        slope, intercept, r_value, _, _ = linregress(concentrations, intensities)
        return {
            "slope": slope,
            "intercept": intercept,
            "r_squared": r_value**2
        }


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)

    # Test BoltzmannLinePoint dataclass ordering
    try:
        # Valid order
        bp_valid = BoltzmannLinePoint(intensity=100.0, wavelength_nm=300.0, Aki=1e7, gk=3.0, Ek=2.5, element="Fe", ion_stage="I")
        logger.info(f"Valid BoltzmannLinePoint: {bp_valid}")

        # If you were to test an invalid order (e.g., default arg before non-default),
        # Python would raise TypeError at class definition time for the dataclass itself.
        # The error in the prompt was likely that one of the *non-default* fields was accidentally
        # given a default value in a previous version, or a default field was placed before a non-default one.
        # Example of what would cause the error if `element` was non-default and after `Ek`:
        # @dataclass
        # class BoltzmannLinePointTest:
        #     intensity: float
        #     wavelength_nm: float
        #     Aki: float
        #     gk: float
        #     element: str # Non-default
        #     Ek: float = 0.0 # Default -- THIS WOULD CAUSE ERROR if element was after Ek in definition.
        # This is not how the error happens with dataclasses, it's about order in definition:
        # @dataclass
        # class BoltzmannLinePointTestError:
        #     Ek: float = 0.0 # Default
        #     intensity: float # NON-DEFAULT AFTER DEFAULT --> ERROR
        # Correct order for above:
        # @dataclass
        # class BoltzmannLinePointTestCorrect:
        #     intensity: float # Non-default
        #     Ek: float = 0.0 # Default
            
    except Exception as e:
        logger.error(f"Error testing BoltzmannLinePoint: {e}")


    # Test QuantitativeAnalyzer
    analyzer = QuantitativeAnalyzer()

    # Dummy data for Boltzmann plot
    # Fe I lines (example values, not necessarily accurate or consistent for a real plasma)
    points = [
        BoltzmannLinePoint(intensity=1000, wavelength_nm=373.486, Aki=1.76e7, gk=9, Ek=3.368, element="Fe", ion_stage="I"), # Ek in eV
        BoltzmannLinePoint(intensity=800,  wavelength_nm=373.713, Aki=6.06e7, gk=7, Ek=3.332, element="Fe", ion_stage="I"),
        BoltzmannLinePoint(intensity=1200, wavelength_nm=374.556, Aki=2.68e7, gk=9, Ek=4.256, element="Fe", ion_stage="I"),
        BoltzmannLinePoint(intensity=600,  wavelength_nm=374.826, Aki=4.06e7, gk=5, Ek=3.404, element="Fe", ion_stage="I"),
        BoltzmannLinePoint(intensity=1500, wavelength_nm=375.823, Aki=5.06e7, gk=7, Ek=4.220, element="Fe", ion_stage="I"),
        BoltzmannLinePoint(intensity=20,   wavelength_nm=376.379, Aki=3.06e7, gk=5, Ek=4.186, element="Fe", ion_stage="I"), # Potential outlier
    ]

    logger.info("\n--- Testing Boltzmann Plot (eV, no RANSAC) ---")
    results_ev = analyzer.calculate_boltzmann_plot(points, energy_unit="ev", use_ransac=False)
    if results_ev and "error" not in results_ev:
        logger.info(f"Temp (eV, no RANSAC): {results_ev['temperature_k']:.0f} K, R²: {results_ev['r_squared']:.4f}")
        logger.info(f"Points used: {results_ev['n_points_used_in_fit']}/{results_ev['n_points_valid_input']}")
    else:
        logger.error(f"Boltzmann (eV, no RANSAC) failed: {results_ev.get('error', 'Unknown error')}")

    if _SKLEARN_AVAILABLE:
        logger.info("\n--- Testing Boltzmann Plot (eV, with RANSAC) ---")
        results_ev_ransac = analyzer.calculate_boltzmann_plot(points, energy_unit="ev", use_ransac=True)
        if results_ev_ransac and "error" not in results_ev_ransac:
            logger.info(f"Temp (eV, RANSAC): {results_ev_ransac['temperature_k']:.0f} K, R²: {results_ev_ransac['r_squared']:.4f}")
            logger.info(f"Points used: {results_ev_ransac['n_points_used_in_fit']}/{results_ev_ransac['n_points_valid_input']} by {results_ev_ransac['fit_method']}")
            logger.info(f"Inlier mask: {results_ev_ransac['inlier_mask']}")
        else:
            logger.error(f"Boltzmann (eV, RANSAC) failed: {results_ev_ransac.get('error', 'Unknown error')}")
    else:
        logger.info("\nSkipping RANSAC test as scikit-learn is not available.")

    # Example with cm-1 (convert Ek from eV to cm-1: 1 eV = 8065.54 cm-1)
    points_cm = [
        BoltzmannLinePoint(p.intensity, p.wavelength_nm, p.Aki, p.gk, p.Ek * 8065.54, p.element, p.ion_stage)
        for p in points
    ]
    logger.info("\n--- Testing Boltzmann Plot (cm-1, no RANSAC) ---")
    results_cm = analyzer.calculate_boltzmann_plot(points_cm, energy_unit="cm-1", use_ransac=False)
    if results_cm and "error" not in results_cm:
        logger.info(f"Temp (cm-1, no RANSAC): {results_cm['temperature_k']:.0f} K, R²: {results_cm['r_squared']:.4f}")
    else:
        logger.error(f"Boltzmann (cm-1, no RANSAC) failed: {results_cm.get('error', 'Unknown error')}")

    logger.info("\n--- Test with insufficient points ---")
    results_few = analyzer.calculate_boltzmann_plot(points[:1], energy_unit="ev")
    if results_few and "error" in results_few:
        logger.info(f"Correctly failed with few points: {results_few['error']}")
    else:
        logger.error(f"Test with few points did not fail as expected: {results_few}")

    logger.info("\n--- Test with invalid point data (e.g., negative intensity) ---")
    invalid_points = [
        BoltzmannLinePoint(intensity=-100, wavelength_nm=300.0, Aki=1e7, gk=1, Ek=1.0)
    ] + points[1:]
    results_invalid = analyzer.calculate_boltzmann_plot(invalid_points, energy_unit="ev")
    # It should filter out the invalid point and potentially proceed or fail if not enough valid points remain.
    if results_invalid and "error" not in results_invalid:
         logger.info(f"Boltzmann with invalid point: Temp: {results_invalid['temperature_k']:.0f} K, Points Used: {results_invalid['n_points_used_in_fit']}/{results_invalid['n_points_valid_input']}")
    elif results_invalid and "error" in results_invalid:
         logger.info(f"Boltzmann with invalid point correctly handled: {results_invalid['error']}")
    else:
        logger.error(f"Boltzmann with invalid point failed unexpectedly: {results_invalid}")
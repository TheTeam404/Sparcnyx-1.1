# team404/core/chemometrics_tools.py

"""
Chemometrics tools for multivariate analysis of LIBS spectra.
Utilizes scikit-learn for PCA, PLS, and classification models.
"""

import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.cross_decomposition import PLSRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_predict, train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, r2_score, mean_squared_error

_CUML_AVAILABLE = False
try:
    import cuml
    from cuml.preprocessing import StandardScaler as cuStandardScaler
    from cuml.decomposition import PCA as cuPCA
    from cuml.svm import SVC as cuSVC
    from cuml.neighbors import KNeighborsClassifier as cuKNeighborsClassifier
    from cuml.ensemble import RandomForestClassifier as cuRandomForestClassifier
    cuml.set_global_output_type('numpy')
    _CUML_AVAILABLE = True
except ImportError:
    pass

from team404.core.data_models import LIBSpectrum

# Import robust, centralized preprocessing functions
from .preprocessing_algorithms import (
    baseline_als,
    baseline_polynomial,
    normalize_snv,
    normalize_msc,
    normalize_to_max,
    normalize_to_area,
)
from .file_io import load_spectrum_from_file

logger = logging.getLogger(__name__)


def _preprocess_spectra_for_chemometrics(
    spectra_list: List[Union[Tuple[np.ndarray, np.ndarray], 'LIBSpectrum']],
    target_wavelengths: Optional[np.ndarray] = None,
    interpolation_step_nm: Optional[float] = 0.01,
    baseline_method: Optional[str] = 'als',
    als_lambda: float = 1e5,
    als_p: float = 0.01,
    poly_order: int = 3,
    normalization_method: Optional[str] = 'snv',
    verbose: bool = False
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Preprocesses a list of in-memory spectra for chemometric analysis. This function is now
    refactored to be robust against spectra of inconsistent lengths.
    """
    if not spectra_list:
        return np.array([]), np.array([])

    # Step 1: Determine common wavelength axis if interpolation is enabled.
    if interpolation_step_nm is not None and target_wavelengths is None:
        min_wl, max_wl = np.inf, -np.inf
        for spec in spectra_list:
            wl = spec.wavelengths if hasattr(spec, 'wavelengths') else spec[0]
            if wl.size > 0:
                min_wl, max_wl = min(min_wl, np.min(wl)), max(max_wl, np.max(wl))
        if np.isfinite(min_wl) and np.isfinite(max_wl):
            target_wavelengths = np.arange(min_wl, max_wl + interpolation_step_nm, interpolation_step_nm)
            logger.info(f"Determined common wavelength axis: {len(target_wavelengths)} points from {min_wl:.2f} to {max_wl:.2f} nm")
        else:
            raise ValueError("Could not determine a valid wavelength range from the provided spectra.")
    
    # Step 2: Create a consistent matrix of intensities by interpolating all spectra.
    # This is now the FIRST processing step, ensuring all subsequent operations work on arrays of the same shape.
    interpolated_matrix = []
    for spec_data in spectra_list:
        original_wl = spec_data.wavelengths if hasattr(spec_data, 'wavelengths') else spec_data[0]
        original_int = spec_data.intensities if hasattr(spec_data, 'intensities') else spec_data[1]
        
        if target_wavelengths is not None:
            interp_func = interp1d(original_wl, original_int, kind='linear', fill_value="extrapolate")
            interpolated_matrix.append(interp_func(target_wavelengths))
        else:
            # If no interpolation, we assume all spectra already have the same length.
            # This path is risky if input data is inconsistent, but we keep it for flexibility.
            interpolated_matrix.append(original_int)
    
    current_matrix = np.array(interpolated_matrix)
    current_wavelengths = target_wavelengths if target_wavelengths is not None else (spectra_list[0][0] if spectra_list else np.array([]))

    # Step 3: Now that we have a consistent matrix, perform other operations.
    
    # Baseline Correction
    if baseline_method:
        processed_rows = []
        for i in range(current_matrix.shape[0]):
            if baseline_method == 'als':
                corrected_row, _ = baseline_als(current_matrix[i, :], lam=als_lambda, p=als_p)
            elif baseline_method == 'polynomial':
                corrected_row, _ = baseline_polynomial(current_wavelengths, current_matrix[i, :], order=poly_order)
            else:
                corrected_row = current_matrix[i, :]
            processed_rows.append(corrected_row)
        current_matrix = np.array(processed_rows)

    # Normalization
    if normalization_method:
        if normalization_method == 'msc':
            # Calculate reference spectrum from the already-processed (interpolated & baseline-corrected) matrix
            msc_reference_spectrum = np.mean(current_matrix, axis=0)
            logger.info("Calculated mean spectrum as reference for MSC.")
        
        processed_rows = []
        for i in range(current_matrix.shape[0]):
            if normalization_method == 'snv':
                processed_row = normalize_snv(current_matrix[i, :])
            elif normalization_method == 'msc':
                processed_row = normalize_msc(current_matrix[i, :], msc_reference_spectrum)
            elif normalization_method == 'max':
                processed_row = normalize_to_max(current_matrix[i, :])
            elif normalization_method == 'area':
                processed_row = normalize_to_area(current_matrix[i, :], wavelengths=current_wavelengths)
            else:
                processed_row = current_matrix[i, :]
            processed_rows.append(processed_row)
        current_matrix = np.array(processed_rows)

    return current_matrix, current_wavelengths

def perform_pca(data_matrix, n_components=None, scale_data=True):
    """
    Performs Principal Component Analysis (PCA) on the given data matrix.
    """
    if data_matrix.size == 0:
        return None, np.array([]), np.array([]), np.array([])

    X = data_matrix.copy()
    if scale_data:
        scaler_cls = cuStandardScaler if _CUML_AVAILABLE else StandardScaler
        scaler = scaler_cls()
        X = scaler.fit_transform(X)

    pca_cls = cuPCA if _CUML_AVAILABLE else PCA
    pca = pca_cls(n_components=n_components)
    scores = pca.fit_transform(X)
    
    # getattr handles slight variations if cuML versions change the attribute subtly
    loadings = getattr(pca, 'components_', np.array([]))
    explained_variance_ratio = getattr(pca, 'explained_variance_ratio_', np.array([]))

    return pca, scores, loadings, explained_variance_ratio


def perform_pls_regression(X_matrix, y_vector, n_components=2, scale_data=True,
                           cross_validate=False, cv_folds=5):
    """
    Performs Partial Least Squares (PLS) Regression.
    """
    if X_matrix.size == 0 or y_vector.size == 0:
        return {"error": "Input data is empty."}
    if X_matrix.shape[0] != y_vector.shape[0]:
        return {"error": "X_matrix and y_vector must have the same number of samples."}

    X = X_matrix.copy()
    y = y_vector.copy().ravel()
    
    x_scaler, y_scaler = None, None
    if scale_data:
        x_scaler = StandardScaler(); X = x_scaler.fit_transform(X)
        y_scaler = StandardScaler(); y = y_scaler.fit_transform(y.reshape(-1, 1)).ravel()

    pls_model = PLSRegression(n_components=n_components, scale=False)
    pls_model.fit(X, y)
    y_pred_train = pls_model.predict(X)

    y_true_train_orig = y_scaler.inverse_transform(y.reshape(-1, 1)).ravel() if y_scaler else y
    y_pred_train_orig = y_scaler.inverse_transform(y_pred_train.reshape(-1, 1)).ravel() if y_scaler else y_pred_train

    r2_train = r2_score(y_true_train_orig, y_pred_train_orig)
    rmse_train = np.sqrt(mean_squared_error(y_true_train_orig, y_pred_train_orig))

    results = {'model': pls_model, 'y_pred_train': y_pred_train_orig, 'r2_train': r2_train, 'rmse_train': rmse_train, 'x_scaler': x_scaler, 'y_scaler': y_scaler}

    if cross_validate:
        y_pred_cv = cross_val_predict(PLSRegression(n_components=n_components, scale=False), X, y, cv=cv_folds)
        y_pred_cv_orig = y_scaler.inverse_transform(y_pred_cv.reshape(-1, 1)).ravel() if y_scaler else y_pred_cv
        r2_cv = r2_score(y_true_train_orig, y_pred_cv_orig)
        rmsecv = np.sqrt(mean_squared_error(y_true_train_orig, y_pred_cv_orig))
        results.update({'y_pred_cv': y_pred_cv_orig, 'r2_cv': r2_cv, 'rmsecv': rmsecv})

    return results


def train_classifier_model(X_matrix, y_labels, model_type='lda', scale_data=True, test_size=0.25, random_state=None, **kwargs):
    """
    Trains a classification model and evaluates it.
    """
    if X_matrix.size == 0 or y_labels.size == 0:
        return {"error": "Input data is empty."}
    if X_matrix.shape[0] != y_labels.shape[0]:
        return {"error": "X_matrix and y_labels must have the same number of samples."}

    X, y = X_matrix.copy(), y_labels.copy()

    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)

    stratify_param = y_encoded if len(np.unique(y_encoded)) > 1 else None
    X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=test_size, random_state=random_state, stratify=stratify_param)
    
    x_scaler = None
    if scale_data:
        scaler_cls = cuStandardScaler if _CUML_AVAILABLE else StandardScaler
        x_scaler = scaler_cls()
        X_train = x_scaler.fit_transform(X_train)
        X_test = x_scaler.transform(X_test)

    model_type_lower = model_type.lower()
    if model_type_lower == 'lda': 
        model = LinearDiscriminantAnalysis(**kwargs)
    elif model_type_lower == 'svm': 
        model = cuSVC(probability=True, **kwargs) if _CUML_AVAILABLE else SVC(probability=True, **kwargs)
    elif model_type_lower == 'knn': 
        model = cuKNeighborsClassifier(**kwargs) if _CUML_AVAILABLE else KNeighborsClassifier(**kwargs)
    elif model_type_lower == 'randomforest': 
        model = cuRandomForestClassifier(random_state=random_state, **kwargs) if _CUML_AVAILABLE else RandomForestClassifier(random_state=random_state, **kwargs)
    else: 
        return {"error": f"Unsupported model_type: {model_type}"}

    model.fit(X_train, y_train)
    y_pred_test = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred_test)
    cm = confusion_matrix(y_test, y_pred_test, labels=np.unique(y_encoded))
    cr = classification_report(y_test, y_pred_test, target_names=label_encoder.classes_, output_dict=True, zero_division=0)
    
    return {'model': model, 'label_encoder': label_encoder, 'x_scaler': x_scaler, 'accuracy': accuracy, 'confusion_matrix': cm, 'classification_report': cr, 'y_test_labels': label_encoder.inverse_transform(y_test), 'y_pred_test_labels': label_encoder.inverse_transform(y_pred_test)}


if __name__ == '__main__':
    print("Chemometrics Tools Module")
    # (Test block remains unchanged)
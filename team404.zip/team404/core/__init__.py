# team404/core/__init__.py

"""
Core processing and data handling modules for SpectraMapper Pro.
"""

# You can selectively import key classes or functions here
# for easier access from other parts of the application, e.g.:
# from .spectrum_handler import Spectrum
# from .project_manager import ProjectManager
# from .file_io import load_spectrum_from_file
# from .peak_algorithms import find_peaks_scipy, fit_voigt_profile

# For now, this can remain relatively empty, or just serve to mark the directory.
# Python treats directories with an __init__.py file as packages.

# Example: Define a version for the core package (optional)
__version__ = "0.1.0"
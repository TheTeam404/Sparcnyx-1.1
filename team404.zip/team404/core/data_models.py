# team404/core/data_models.py

"""
Core data models for SpectraMapper Pro.
These classes represent the main data structures used throughout the application,
such as spectra, processing steps, peaks, elemental lines, map data, and projects.
"""

import logging
import uuid
import datetime
from typing import List, Dict, Any, Optional, Union, Tuple
import numpy as np
import copy # For deepcopying

logger = logging.getLogger(__name__)

# --- Constants ---
DEFAULT_PROCESSING_PIPELINE_NAME = "Default"

# --- Processing Step Model ---
class ProcessingStep:
    """Represents a single step in a preprocessing pipeline."""
    def __init__(self, name: str, parameters: Optional[Dict[str, Any]] = None, enabled: bool = True):
        if not name:
            raise ValueError("Processing step name cannot be empty.")
        self.step_id: str = str(uuid.uuid4())
        self.name: str = name
        self.parameters: Dict[str, Any] = parameters if parameters is not None else {}
        self.enabled: bool = enabled

    def __repr__(self) -> str:
        return f"ProcessingStep(id={self.step_id[:8]}, name='{self.name}', enabled={self.enabled}, params={self.parameters})"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_id": self.step_id,
            "name": self.name,
            "parameters": copy.deepcopy(self.parameters),
            "enabled": self.enabled
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ProcessingStep':
        step = cls(name=data['name'], parameters=data.get('parameters', {}), enabled=data.get('enabled', True))
        step.step_id = data.get('step_id', str(uuid.uuid4()))
        return step

# --- Elemental Line Model (for database results) ---
class ElementalLine:
    """Represents a spectral line from a database (e.g., NIST)."""
    def __init__(self,
                 wavelength_nm: float,
                 element: str,
                 ion_stage: str,
                 intensity_db: Optional[Union[float, str]] = None,
                 intensity_db_str: Optional[str] = None,
                 Aki: Optional[float] = None,
                 Ek_ev: Optional[float] = None,
                 Ek_cm_inv: Optional[float] = None,
                 Ei_ev: Optional[float] = None,
                 Ei_cm_inv: Optional[float] = None,
                 gk: Optional[Union[int, float]] = None,
                 gi: Optional[Union[int, float]] = None,
                 source_db: Optional[str] = "N/A",
                 user_db_line_id: Optional[str] = None,
                 user_db_notes: Optional[str] = None):
        self.wavelength_nm = wavelength_nm
        self.element = element
        self.ion_stage = ion_stage
        self.intensity_db = intensity_db
        self.intensity_db_str = intensity_db_str if intensity_db_str is not None else str(intensity_db)
        self.Aki = Aki
        self.Ek_ev = Ek_ev
        self.Ek_cm_inv = Ek_cm_inv
        self.Ei_ev = Ei_ev
        self.Ei_cm_inv = Ei_cm_inv
        self.gk = gk
        self.gi = gi
        self.source_db = source_db
        self.user_db_line_id = user_db_line_id
        self.user_db_notes = user_db_notes

    def __repr__(self) -> str:
        return (f"ElementalLine({self.element} {self.ion_stage} @ {self.wavelength_nm:.3f} nm, "
                f"Aki={self.Aki:.2e if self.Aki else 'N/A'}, Ek_ev={self.Ek_ev:.2f if self.Ek_ev else 'N/A'})")

    def to_dict(self) -> Dict[str, Any]:
        return self.__dict__

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ElementalLine':
        return cls(**data)

# --- Peak Model ---
class Peak:
    """Represents a detected or fitted peak in a spectrum."""
    def __init__(self,
                 detected_wavelength_nm: Optional[float] = None,
                 detected_intensity: Optional[float] = None,
                 peak_id: Optional[str] = None,
                 width_points: Optional[float] = None,
                 prominence: Optional[float] = None,
                 is_fitted: bool = False,
                 fitted_wavelength_nm: Optional[float] = None,
                 fitted_amplitude: Optional[float] = None,
                 gaussian_sigma_nm: Optional[float] = None,
                 lorentzian_gamma_nm: Optional[float] = None,
                 voigt_fwhm_nm: Optional[float] = None,
                 peak_area: Optional[float] = None,
                 fit_r_squared: Optional[float] = None,
                 fit_params_covariance: Optional[np.ndarray] = None,
                 fit_model_type: Optional[str] = None,
                 is_identified: bool = False,
                 identified_elements: Optional[List[Dict[str, Any]]] = None):
        
        self.peak_id: str = peak_id or str(uuid.uuid4())
        self.detected_wavelength_nm = detected_wavelength_nm
        self.detected_intensity = detected_intensity
        self.width_points = width_points
        self.prominence = prominence

        self.is_fitted = is_fitted
        self.fitted_wavelength_nm = fitted_wavelength_nm
        self.fitted_amplitude = fitted_amplitude
        self.gaussian_sigma_nm = gaussian_sigma_nm
        self.lorentzian_gamma_nm = lorentzian_gamma_nm
        self.voigt_fwhm_nm = voigt_fwhm_nm
        self.peak_area = peak_area
        self.fit_r_squared = fit_r_squared
        self.fit_params_covariance = fit_params_covariance
        self.fit_model_type = fit_model_type

        self.is_identified = is_identified
        self.identified_elements: List[Dict[str, Any]] = identified_elements if identified_elements is not None else []

    def get_effective_wavelength(self) -> Optional[float]:
        return self.fitted_wavelength_nm if self.is_fitted and self.fitted_wavelength_nm is not None else self.detected_wavelength_nm

    def get_effective_intensity(self) -> Optional[float]:
        return self.fitted_amplitude if self.is_fitted and self.fitted_amplitude is not None else self.detected_intensity

    def __repr__(self) -> str:
        wl = self.get_effective_wavelength()
        status = "Fitted" if self.is_fitted else "Detected"
        iden_status = f", ID'd ({len(self.identified_elements)} matches)" if self.is_identified and self.identified_elements else ""
        return f"Peak({self.peak_id[:8]}, {status} @ {wl:.3f} nm{iden_status})"

    def to_dict(self) -> Dict[str, Any]:
        data = self.__dict__.copy()
        if isinstance(data.get('fit_params_covariance'), np.ndarray):
            data['fit_params_covariance'] = data['fit_params_covariance'].tolist()
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Peak':
        if 'fit_params_covariance' in data and isinstance(data['fit_params_covariance'], list):
            data['fit_params_covariance'] = np.array(data['fit_params_covariance'])
        return cls(**data)
    
    def update_from_dict(self, data: Dict[str, Any]):
        if 'fit_params_covariance' in data and isinstance(data['fit_params_covariance'], list):
            data['fit_params_covariance'] = np.array(data['fit_params_covariance'])
        for key, value in data.items():
            if hasattr(self, key):
                setattr(self, key, value)
            else:
                logger.warning(f"Peak.update_from_dict: Attribute '{key}' not found in Peak model.")

# --- LIBS Spectrum Model ---
class LIBSpectrum:
    """Represents a single LIBS spectrum, including raw and processed data."""
    def __init__(self,
                 raw_wavelengths: np.ndarray,
                 raw_intensities: np.ndarray,
                 spectrum_id: Optional[str] = None,
                 filename: Optional[str] = None,
                 filepath: Optional[str] = None,
                 metadata: Optional[Dict[str, Any]] = None,
                 x_coord: Optional[float] = None,
                 y_coord: Optional[float] = None,
                 z_coord: Optional[float] = None):

        if not isinstance(raw_wavelengths, np.ndarray) or raw_wavelengths.ndim != 1 or \
           not isinstance(raw_intensities, np.ndarray) or raw_intensities.ndim != 1:
            raise ValueError("Wavelengths and intensities must be 1D NumPy arrays.")
        if raw_wavelengths.shape != raw_intensities.shape:
            raise ValueError("Wavelengths and intensities must have the same shape.")

        self.spectrum_id: str = spectrum_id or str(uuid.uuid4())
        self.filename: Optional[str] = filename
        self.filepath: Optional[str] = filepath
        self.timestamp: datetime.datetime = datetime.datetime.now(datetime.timezone.utc)
        self.metadata: Dict[str, Any] = metadata if metadata is not None else {}

        self._raw_wavelengths: np.ndarray = raw_wavelengths.copy()
        self._raw_intensities: np.ndarray = raw_intensities.copy()

        self._processed_wavelengths: np.ndarray = self._raw_wavelengths.copy()
        self._processed_intensities: np.ndarray = self._raw_intensities.copy()

        self.processing_pipeline: List[ProcessingStep] = []
        self.peaks: List[Peak] = []
        
        self.x_coord: Optional[float] = x_coord
        self.y_coord: Optional[float] = y_coord
        self.z_coord: Optional[float] = z_coord

    @property
    def raw_wavelengths(self) -> np.ndarray: return self._raw_wavelengths
    @property
    def raw_intensities(self) -> np.ndarray: return self._raw_intensities
    @property
    def wavelengths(self) -> np.ndarray: return self._processed_wavelengths
    @property
    def intensities(self) -> np.ndarray: return self._processed_intensities
    
    def get_processed_wavelengths(self) -> np.ndarray: return self._processed_wavelengths
    def get_processed_intensities(self) -> np.ndarray: return self._processed_intensities

    def set_processed_data(self, new_intensities: np.ndarray, new_wavelengths: Optional[np.ndarray] = None):
        if new_wavelengths is not None:
            if new_wavelengths.shape != new_intensities.shape:
                raise ValueError("New processed wavelengths and intensities must have the same shape.")
            self._processed_wavelengths = new_wavelengths.copy()
        elif self._processed_wavelengths.shape != new_intensities.shape:
             raise ValueError("New processed intensities shape must match existing processed wavelengths shape if wavelengths are not updated.")
        self._processed_intensities = new_intensities.copy()

    def clear_processing_pipeline(self):
        self._processed_wavelengths = self._raw_wavelengths.copy()
        self._processed_intensities = self._raw_intensities.copy()
        self.processing_pipeline = []
        logger.debug(f"Processing pipeline cleared for spectrum {self.spectrum_id}. Processed data reset to raw.")

    def is_valid(self) -> bool:
        return (self._raw_wavelengths is not None and self._raw_intensities is not None and
                self._raw_wavelengths.size > 0 and self._raw_intensities.size > 0 and
                self._raw_wavelengths.size == self._raw_intensities.size)

    def is_valid_for_processing(self) -> bool:
        return (self._processed_wavelengths is not None and self._processed_intensities is not None and
                self._processed_wavelengths.size > 0 and self._processed_intensities.size > 0 and
                self._processed_wavelengths.size == self._processed_intensities.size)

    def __repr__(self) -> str:
        return (f"LIBSpectrum(id={self.spectrum_id[:8]}, filename='{self.filename}', "
                f"points={len(self.raw_wavelengths)}, peaks={len(self.peaks)}, "
                f"steps={len(self.processing_pipeline)})")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "spectrum_id": self.spectrum_id, "filename": self.filename, "filepath": self.filepath,
            "timestamp": self.timestamp.isoformat(), "metadata": copy.deepcopy(self.metadata),
            "raw_wavelengths": self._raw_wavelengths.tolist(), "raw_intensities": self._raw_intensities.tolist(),
            "processed_wavelengths": self._processed_wavelengths.tolist(),
            "processed_intensities": self._processed_intensities.tolist(),
            "processing_pipeline": [step.to_dict() for step in self.processing_pipeline],
            "peaks": [peak.to_dict() for peak in self.peaks],
            "x_coord": self.x_coord, "y_coord": self.y_coord, "z_coord": self.z_coord,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LIBSpectrum':
        spectrum = cls(
            raw_wavelengths=np.array(data['raw_wavelengths'], dtype=float),
            raw_intensities=np.array(data['raw_intensities'], dtype=float),
            spectrum_id=data.get('spectrum_id'), filename=data.get('filename'),
            filepath=data.get('filepath'), metadata=data.get('metadata', {}),
            x_coord=data.get('x_coord'), y_coord=data.get('y_coord'), z_coord=data.get('z_coord')
        )
        spectrum.timestamp = datetime.datetime.fromisoformat(data['timestamp'])
        spectrum._processed_wavelengths = np.array(data.get('processed_wavelengths', data['raw_wavelengths']), dtype=float)
        spectrum._processed_intensities = np.array(data.get('processed_intensities', data['raw_intensities']), dtype=float)
        spectrum.processing_pipeline = [ProcessingStep.from_dict(step_data) for step_data in data.get('processing_pipeline', [])]
        spectrum.peaks = [Peak.from_dict(peak_data) for peak_data in data.get('peaks', [])]
        return spectrum

# --- Elemental Map Data Model ---
class ElementalMapData:
    """Represents a generated 2D elemental map."""
    def __init__(self,
                 element_label: str, intensity_matrix: np.ndarray,
                 x_coordinates_map: Optional[np.ndarray] = None,
                 y_coordinates_map: Optional[np.ndarray] = None,
                 target_wavelength_nm: Optional[float] = None,
                 quantification_method: Optional[str] = None,
                 quant_params: Optional[Dict[str, Any]] = None,
                 source_spectrum_ids: Optional[List[List[Optional[str]]]] = None):
        self.map_id: str = str(uuid.uuid4())
        self.element_label = element_label
        self.intensity_matrix = intensity_matrix
        self.x_coordinates_map = x_coordinates_map
        self.y_coordinates_map = y_coordinates_map
        self.target_wavelength_nm = target_wavelength_nm
        self.quantification_method = quantification_method
        self.quant_params = quant_params if quant_params is not None else {}
        self.source_spectrum_ids = source_spectrum_ids

    def to_dict(self) -> Dict[str, Any]:
        return {
            "map_id": self.map_id, "element_label": self.element_label,
            "intensity_matrix": self.intensity_matrix.tolist(),
            "x_coordinates_map": self.x_coordinates_map.tolist() if self.x_coordinates_map is not None else None,
            "y_coordinates_map": self.y_coordinates_map.tolist() if self.y_coordinates_map is not None else None,
            "target_wavelength_nm": self.target_wavelength_nm,
            "quantification_method": self.quantification_method,
            "quant_params": copy.deepcopy(self.quant_params),
            "source_spectrum_ids": self.source_spectrum_ids
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ElementalMapData':
        map_data = cls(
            element_label=data['element_label'], intensity_matrix=np.array(data['intensity_matrix'], dtype=float),
            x_coordinates_map=np.array(data['x_coordinates_map'], dtype=float) if data.get('x_coordinates_map') is not None else None,
            y_coordinates_map=np.array(data['y_coordinates_map'], dtype=float) if data.get('y_coordinates_map') is not None else None,
            target_wavelength_nm=data.get('target_wavelength_nm'),
            quantification_method=data.get('quantification_method'),
            quant_params=data.get('quant_params', {}),
            source_spectrum_ids=data.get('source_spectrum_ids')
        )
        map_data.map_id = data.get('map_id', str(uuid.uuid4()))
        return map_data

# --- Project Data Model ---
class LIBSProject:
    """Encapsulates all data related to a single LIBS analysis project."""
    def __init__(self, project_name: str, project_filepath: Optional[str] = None):
        if not project_name or not project_name.strip():
            raise ValueError("Project name cannot be empty.")
        self.project_id: str = str(uuid.uuid4())
        self.project_name: str = project_name
        self.project_filepath: Optional[str] = project_filepath
        self.creation_date: datetime.datetime = datetime.datetime.now(datetime.timezone.utc)
        self.last_modified_date: datetime.datetime = datetime.datetime.now(datetime.timezone.utc)
        self._is_dirty: bool = False # Flag to track unsaved changes

        self.spectra: Dict[str, LIBSpectrum] = {}
        self.active_spectrum_id: Optional[str] = None
        
        self.elemental_maps: Dict[str, ElementalMapData] = {}
        self.settings: Dict[str, Any] = {}
        self.user_notes: str = ""

    def add_spectrum(self, spectrum: LIBSpectrum):
        if not isinstance(spectrum, LIBSpectrum):
            raise TypeError("Can only add LIBSpectrum objects to project.")
        if spectrum.spectrum_id in self.spectra:
            logger.warning(f"Spectrum with ID {spectrum.spectrum_id} already exists. Overwriting.")
        self.spectra[spectrum.spectrum_id] = spectrum
        self.mark_dirty() # Adding a spectrum makes the project dirty
        if self.active_spectrum_id is None and self.spectra:
            self.set_active_spectrum(spectrum.spectrum_id)

    def remove_spectrum(self, spectrum_id: str) -> bool:
        if spectrum_id in self.spectra:
            del self.spectra[spectrum_id]
            if self.active_spectrum_id == spectrum_id:
                self.active_spectrum_id = next(iter(self.spectra), None) if self.spectra else None
            self.mark_dirty()
            logger.info(f"Removed spectrum {spectrum_id} from project {self.project_name}.")
            return True
        logger.warning(f"Spectrum {spectrum_id} not found for removal in project {self.project_name}.")
        return False

    def get_spectrum(self, spectrum_id: str) -> Optional[LIBSpectrum]:
        return self.spectra.get(spectrum_id)

    def get_active_spectrum(self) -> Optional[LIBSpectrum]:
        return self.spectra.get(self.active_spectrum_id) if self.active_spectrum_id else None

    def set_active_spectrum(self, spectrum_id: Optional[str]):
        if self.active_spectrum_id == spectrum_id: return # No change

        if spectrum_id is None:
            self.active_spectrum_id = None
            logger.debug(f"Active spectrum cleared for project {self.project_name}.")
        elif spectrum_id in self.spectra:
            self.active_spectrum_id = spectrum_id
            logger.debug(f"Active spectrum set to {spectrum_id} for project {self.project_name}.")
        else:
            logger.warning(f"Cannot set active spectrum: ID {spectrum_id} not found in project {self.project_name}.")
            return
        # Changing active spectrum itself usually doesn't make project "dirty" in terms of needing to save
        # unless other actions depend on it. For now, let's not mark dirty here.
        # self.update_last_modified() # Only update if actual data changed.

    def update_last_modified(self):
        self.last_modified_date = datetime.datetime.now(datetime.timezone.utc)

    def mark_dirty(self, dirty_status: bool = True):
        """Marks the project as having unsaved changes."""
        if self._is_dirty != dirty_status:
            self._is_dirty = dirty_status
            if dirty_status:
                logger.debug(f"Project '{self.project_name}' marked as dirty.")
                self.update_last_modified() # Also update modified time when it becomes dirty
            else:
                logger.debug(f"Project '{self.project_name}' marked as clean (saved).")

    def is_dirty(self) -> bool:
        """Checks if the project has unsaved changes."""
        return self._is_dirty

    def to_dict(self) -> Dict[str, Any]:
        return {
            "project_id": self.project_id, "project_name": self.project_name,
            "project_filepath": self.project_filepath,
            "creation_date": self.creation_date.isoformat(),
            "last_modified_date": self.last_modified_date.isoformat(),
            "_is_dirty": self._is_dirty, # Save dirty status (though typically reset on load)
            "spectra": {sid: spec.to_dict() for sid, spec in self.spectra.items()},
            "active_spectrum_id": self.active_spectrum_id,
            "elemental_maps": {mid: map_data.to_dict() for mid, map_data in self.elemental_maps.items()},
            "settings": copy.deepcopy(self.settings), "user_notes": self.user_notes,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LIBSProject':
        project = cls(project_name=data['project_name'], project_filepath=data.get('project_filepath'))
        project.project_id = data.get('project_id', str(uuid.uuid4()))
        project.creation_date = datetime.datetime.fromisoformat(data['creation_date'])
        project.last_modified_date = datetime.datetime.fromisoformat(data['last_modified_date'])
        project._is_dirty = data.get('_is_dirty', False) # Load dirty status, typically false after load
        
        project.spectra = {sid: LIBSpectrum.from_dict(spec_data) for sid, spec_data in data.get('spectra', {}).items()}
        project.active_spectrum_id = data.get('active_spectrum_id')
        if project.active_spectrum_id not in project.spectra:
            project.active_spectrum_id = next(iter(project.spectra), None) if project.spectra else None

        project.elemental_maps = {mid: ElementalMapData.from_dict(map_data) for mid, map_data in data.get('elemental_maps', {}).items()}
        
        project.settings = data.get('settings', {})
        project.user_notes = data.get('user_notes', "")
        project.mark_dirty(False) # A freshly loaded project is considered not dirty
        return project

    def __repr__(self) -> str:
        active_id_short = self.active_spectrum_id[:8] if self.active_spectrum_id else 'None'
        dirty_str = "*" if self._is_dirty else ""
        return (f"LIBSProject(name='{self.project_name}{dirty_str}', spectra={len(self.spectra)}, "
                f"active_id='{active_id_short}')")
# team404/core/peak_algorithms.py

"""
Provides algorithms for peak detection and fitting in LIBS spectra.
Focuses on robust Voigt profile fitting.
"""

import logging
import numpy as np
from scipy.signal import find_peaks
from scipy.optimize import curve_fit
from scipy.special import voigt_profile

try:
    from lmfit.models import VoigtModel
    from lmfit import Parameters as LMFitParameters
    LMFIT_AVAILABLE = True
except ImportError:
    LMFIT_AVAILABLE = False

from typing import List, Dict, Any, Optional, Tuple

from .data_models import Peak

logger = logging.getLogger(__name__)

if not LMFIT_AVAILABLE:
    logger.warning(
        "lmfit library not found. Voigt fitting will use a numerical approximation "
        "via scipy.optimize.curve_fit, which might be less robust for complex or noisy peaks. "
        "Consider installing lmfit (`pip install lmfit`) for improved fitting."
    )

DEFAULT_FIND_PEAKS_PARAMS = {
    "height": None, "threshold": None, "distance": 5,
    "prominence": 0.1, "width": None, "wlen": None,
    "rel_height": 0.5, "plateau_size": None
}

def detect_peaks_scipy(
    wavelengths: np.ndarray,
    intensities: np.ndarray,
    params: Optional[Dict[str, Any]] = None
) -> List[Peak]:
    if not isinstance(wavelengths, np.ndarray) or not isinstance(intensities, np.ndarray) or \
       wavelengths.ndim != 1 or intensities.ndim != 1 or \
       wavelengths.size == 0 or intensities.size == 0 or \
       wavelengths.size != intensities.size:
        logger.warning("Invalid input for peak detection: Wavelengths or intensities are empty, not 1D, or mismatched.")
        return []

    current_params = DEFAULT_FIND_PEAKS_PARAMS.copy()
    if params: current_params.update(params)

    if current_params.get("prominence") is not None:
        try:
            prominence_val = float(current_params["prominence"])
            if 0 < prominence_val < 1.0:
                data_min, data_max = np.min(intensities), np.max(intensities)
                data_range = data_max - data_min
                if data_range > 1e-9: current_params["prominence"] = prominence_val * data_range
                else: current_params["prominence"] = None; logger.debug("Data range near zero, relative prominence set to None.")
            elif prominence_val <= 0: current_params["prominence"] = None
        except ValueError: logger.warning(f"Could not parse prominence '{current_params['prominence']}'. Ignoring."); current_params["prominence"] = None
            
    if current_params.get("height") is not None:
        try:
            height_val = float(current_params["height"])
            if height_val <= 0: current_params["height"] = None
        except ValueError: logger.warning(f"Could not parse height '{current_params['height']}'. Ignoring."); current_params["height"] = None

    scipy_params = {k: v for k, v in current_params.items() if v is not None and k in DEFAULT_FIND_PEAKS_PARAMS}
    if "width" in scipy_params and isinstance(scipy_params["width"], str):
        try:
            width_str = scipy_params["width"].strip()
            if not width_str: del scipy_params["width"]
            else:
                parts = [p.strip() for p in width_str.split(',')]
                if len(parts) == 1 and parts[0]: scipy_params["width"] = float(parts[0]); assert scipy_params["width"] > 0
                elif len(parts) == 2 and parts[0] and parts[1]:
                    min_w, max_w = float(parts[0]), float(parts[1]); assert min_w > 0 and max_w > 0
                    scipy_params["width"] = tuple(sorted((min_w, max_w)))
                else: raise ValueError("Width format incorrect.")
        except (ValueError, AssertionError) as e_width:
            logger.warning(f"Invalid width parameter '{scipy_params.get('width')}': {e_width}. Ignoring."); 
            if "width" in scipy_params: del scipy_params["width"]
    elif "width" in scipy_params and isinstance(scipy_params["width"], (int, float)) and scipy_params["width"] <=0:
         logger.warning(f"Numeric width {scipy_params['width']} must be positive. Ignoring."); del scipy_params["width"]
    elif "width" in scipy_params and isinstance(scipy_params["width"], (list, tuple)):
        if not (len(scipy_params["width"]) == 2 and scipy_params["width"][0] <= scipy_params["width"][1] and scipy_params["width"][0] > 0):
            logger.warning(f"Invalid width range {scipy_params['width']}. Ignoring."); del scipy_params["width"]

    logger.debug(f"Calling scipy.find_peaks with processed params: {scipy_params}")
    try: peak_indices, properties = find_peaks(intensities, **scipy_params)
    except Exception as e: logger.error(f"Error in scipy.signal.find_peaks: {e}", exc_info=True); return []

    detected_peaks_list: List[Peak] = []
    if peak_indices.size > 0:
        prominences_data = properties.get("prominences"); width_points_data = properties.get("widths")
        for i, idx in enumerate(peak_indices):
            peak_obj = Peak(
                detected_wavelength_nm=wavelengths[idx], detected_intensity=intensities[idx],
                prominence=prominences_data[i] if prominences_data is not None and i < len(prominences_data) else np.nan,
                width_points=width_points_data[i] if width_points_data is not None and i < len(width_points_data) else np.nan
            )
            detected_peaks_list.append(peak_obj)
        logger.info(f"Detected {len(detected_peaks_list)} peaks.")
    else: logger.info("No peaks detected with current parameters.")
    return detected_peaks_list

def _voigt_scipy_numerical(x: np.ndarray, center: float, amplitude_scaler: float, sigma_g: float, gamma_l: float) -> np.ndarray:
    sigma_g_safe = max(abs(sigma_g), 1e-7); gamma_l_safe = max(abs(gamma_l), 1e-9)
    return amplitude_scaler * voigt_profile(x - center, sigma_g_safe, gamma_l_safe)

def _voigt_scipy_numerical_with_offset(x: np.ndarray, center: float, amplitude_scaler: float, sigma_g: float, gamma_l: float, offset: float) -> np.ndarray:
    return _voigt_scipy_numerical(x, center, amplitude_scaler, sigma_g, gamma_l) + offset

def _fwhm_voigt_approx(sigma_g: float, gamma_l: float) -> float:
    if sigma_g <= 1e-9 and gamma_l <= 1e-9: return 0.0
    fwhm_l = 2.0 * gamma_l; fwhm_g = 2.0 * np.sqrt(2.0 * np.log(2.0)) * sigma_g
    return 0.5346 * fwhm_l + np.sqrt(0.2166 * fwhm_l**2 + fwhm_g**2)

def fit_peak_voigt(
    peak: Peak, wavelengths: np.ndarray, intensities: np.ndarray,
    fit_window_nm: float = 1.0,
    initial_guesses_override: Optional[Dict[str, float]] = None
) -> bool:
    if peak.detected_wavelength_nm is None or peak.detected_intensity is None:
        logger.debug(f"Peak {peak.peak_id[:8]} missing data. Cannot fit."); peak.is_fitted = False; return False

    center_wl_detected = peak.detected_wavelength_nm; half_window = abs(fit_window_nm) / 2.0
    min_wl_spectrum, max_wl_spectrum = np.min(wavelengths), np.max(wavelengths)
    fit_wl_min = max(min_wl_spectrum, center_wl_detected - half_window)
    fit_wl_max = min(max_wl_spectrum, center_wl_detected + half_window)
    fit_indices = np.where((wavelengths >= fit_wl_min) & (wavelengths <= fit_wl_max))[0]

    if len(fit_indices) < 5:
        logger.debug(f"Peak {peak.peak_id[:8]}: Not enough points ({len(fit_indices)}) in window for Voigt fit."); peak.is_fitted = False; return False

    x_fit = wavelengths[fit_indices]; y_fit = intensities[fit_indices]
    local_baseline_estimate = np.min(y_fit)
    amp_guess_rel_to_baseline = max(peak.detected_intensity - local_baseline_estimate, peak.detected_intensity * 0.05 if peak.detected_intensity > 0 else 1e-3, 1e-3)
    center_guess = center_wl_detected
    min_possible_width_nm = np.mean(np.diff(x_fit)) if len(x_fit) > 1 else 0.001; min_possible_width_nm = max(min_possible_width_nm, 1e-4)
    fwhm_guess_nm = fit_window_nm / 3.0
    try:
        half_max_val = local_baseline_estimate + amp_guess_rel_to_baseline / 2.0
        indices_above_half_max = np.where(y_fit > half_max_val)[0]
        if len(indices_above_half_max) >= 2: fwhm_guess_nm = max(x_fit[indices_above_half_max[-1]] - x_fit[indices_above_half_max[0]], min_possible_width_nm)
    except: pass
    sigma_g_guess = max(fwhm_guess_nm / (2.0 * 2.3548), min_possible_width_nm); gamma_l_guess = max(fwhm_guess_nm / 2.0, min_possible_width_nm)

    if initial_guesses_override:
        center_guess = initial_guesses_override.get('center', center_guess); amp_guess_rel_to_baseline = initial_guesses_override.get('amplitude', amp_guess_rel_to_baseline)
        sigma_g_guess = initial_guesses_override.get('sigma_g', sigma_g_guess); gamma_l_guess = initial_guesses_override.get('gamma_l', gamma_l_guess)
        local_baseline_estimate = initial_guesses_override.get('offset', local_baseline_estimate)

    center_bound_abs_limit = fit_window_nm * 0.5 # Peak center shouldn't move too far
    amp_bound_min_abs = amp_guess_rel_to_baseline * 0.01
    amp_bound_max_abs = amp_guess_rel_to_baseline * 20 + (np.max(y_fit) - np.min(y_fit)) # Allow larger for overlapping cases
    width_bound_min_abs = min_possible_width_nm * 0.1 # Allow very narrow
    width_bound_max_abs = fit_window_nm * 2.0

    try:
        if LMFIT_AVAILABLE:
            model = VoigtModel()
            params = model.make_params(
                amplitude=amp_guess_rel_to_baseline * fwhm_guess_nm, # lmfit amplitude is area-like
                center=center_guess,
                sigma=sigma_g_guess,
                gamma=gamma_l_guess # lmfit gamma is HWHM, can be constrained if needed
            )
            params['center'].set(min=center_wl_detected - center_bound_abs_limit, max=center_wl_detected + center_bound_abs_limit)
            params['amplitude'].set(min=amp_bound_min_abs * width_bound_min_abs, max=amp_bound_max_abs * width_bound_max_abs)
            params['sigma'].set(min=width_bound_min_abs, max=width_bound_max_abs)
            params['gamma'].set(min=width_bound_min_abs, max=width_bound_max_abs, vary=True)
            
            result = model.fit(y_fit - local_baseline_estimate, params, x=x_fit, nan_policy='omit')

            if result and result.success:
                peak.is_fitted = True
                peak.fitted_amplitude = result.params['height'].value # Actual height above fitted baseline
                peak.fitted_wavelength_nm = result.params['center'].value
                peak.gaussian_sigma_nm = result.params['sigma'].value
                peak.lorentzian_gamma_nm = result.params['gamma'].value
                peak.voigt_fwhm_nm = result.params['fwhm'].value
                y_model_peak_only = result.eval(x=x_fit)
                peak.peak_area = np.trapz(y_model_peak_only, x_fit)
                y_fit_sub = y_fit - local_baseline_estimate; var_yfs = np.var(y_fit_sub) if len(y_fit_sub)>1 else 1.0
                peak.fit_r_squared = 1 - result.redchi / var_yfs if var_yfs > 1e-12 else (0.0 if result.redchi > 1e-9 else 1.0)
                peak.fit_model_type = "Voigt (lmfit)"
                logger.debug(f"LMFIT Success: Peak {peak.peak_id[:8]} @ {peak.fitted_wavelength_nm:.3f}, H={peak.fitted_amplitude:.2f}, FWHM={peak.voigt_fwhm_nm:.3f}, R2={peak.fit_r_squared:.3f}")
                return True
            else: logger.warning(f"LMFIT fit failed: Peak {peak.peak_id[:8]} @ {center_wl_detected:.2f}nm. Msg: {result.message if result else 'None'}"); peak.is_fitted=False; return False
        else: # Scipy fallback
            p0_scipy = [center_guess, amp_guess_rel_to_baseline, sigma_g_guess, gamma_l_guess, local_baseline_estimate]
            bounds_l_scipy = [center_wl_detected-center_bound_abs_limit, amp_bound_min_abs, width_bound_min_abs, width_bound_min_abs, y_fit.min() - 0.5*amp_guess_rel_to_baseline]
            bounds_u_scipy = [center_wl_detected+center_bound_abs_limit, amp_bound_max_abs, width_bound_max_abs, width_bound_max_abs, y_fit.max() + 0.5*amp_guess_rel_to_baseline]
            for i in range(len(p0_scipy)): # Ensure p0 is within bounds
                p0_scipy[i] = np.clip(p0_scipy[i], bounds_l_scipy[i], bounds_u_scipy[i])
                if bounds_l_scipy[i] >= bounds_u_scipy[i]: # Correct invalid bound pair
                    mid_val = p0_scipy[i]; delta = abs(mid_val*0.1) if mid_val!=0 else 0.1
                    bounds_l_scipy[i] = mid_val - delta; bounds_u_scipy[i] = mid_val + delta
            
            try:
                popt, pcov = curve_fit(_voigt_scipy_numerical_with_offset, x_fit, y_fit, p0=p0_scipy, bounds=(bounds_l_scipy, bounds_u_scipy), 
                                       maxfev=10000, ftol=1e-7, xtol=1e-7, method='trf')
            except RuntimeError as e: logger.warning(f"Scipy RuntimeError: Peak {peak.peak_id[:8]} @ {center_wl_detected:.2f}nm: {e}"); peak.is_fitted=False; return False
            except ValueError as e: logger.warning(f"Scipy ValueError: Peak {peak.peak_id[:8]} @ {center_wl_detected:.2f}nm: {e}"); peak.is_fitted=False; return False

            peak.is_fitted = True; peak.fitted_wavelength_nm = popt[0]
            # For _voigt_scipy_numerical, popt[1] is amplitude_scaler. Actual height is derived.
            # Height = amplitude_scaler * voigt_profile(0, sigma_g, gamma_l)
            fitted_sigma_g = abs(popt[2]); fitted_gamma_l = abs(popt[3])
            norm_factor_at_peak = voigt_profile(0, fitted_sigma_g, fitted_gamma_l)
            peak.fitted_amplitude = popt[1] * norm_factor_at_peak if norm_factor_at_peak > 1e-9 else popt[1]
            peak.gaussian_sigma_nm = fitted_sigma_g; peak.lorentzian_gamma_nm = fitted_gamma_l
            peak.voigt_fwhm_nm = _fwhm_voigt_approx(peak.gaussian_sigma_nm, peak.lorentzian_gamma_nm)
            y_model_peak_only = _voigt_scipy_numerical(x_fit, popt[0], popt[1], popt[2], popt[3])
            peak.peak_area = np.trapz(y_model_peak_only, x_fit)
            y_model_total = _voigt_scipy_numerical_with_offset(x_fit, *popt)
            residuals = y_fit - y_model_total; ss_res = np.sum(residuals**2); ss_tot = np.sum((y_fit - np.mean(y_fit))**2)
            peak.fit_r_squared = 1-(ss_res/ss_tot) if ss_tot>1e-12 else (0.0 if ss_res>1e-9 else 1.0)
            peak.fit_model_type = "Voigt+Offset (scipy)"
            logger.debug(f"Scipy Fit: Peak {peak.peak_id[:8]} @ {peak.fitted_wavelength_nm:.3f}, H={peak.fitted_amplitude:.2f}, R2={peak.fit_r_squared:.3f}")
            return peak.fit_r_squared > -0.5 # Success if converged and R2 is not extremely bad
            
    except Exception as e:
        logger.error(f"Unexpected error fitting peak {peak.peak_id[:8]} @ {center_wl_detected:.2f}nm: {e}", exc_info=True)
        peak.is_fitted = False
    return False
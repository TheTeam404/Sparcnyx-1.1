# team404/core/elemental_identifier.py

"""
Provides the ElementalIdentifier class for matching spectral features
against a local spectral line database.
"""

import logging
from typing import List, Dict, Optional, Any

import numpy as np

from .data_models import Peak, ElementalLine, LIBSpectrum
# MODIFIED: Import the generic BaseConnector instead of the specific, old connector.
from ..database.connectors.base_connector import BaseConnector

logger = logging.getLogger(__name__)

class ElementalIdentifier:
    """
    Identifies elements by matching spectral features (peaks) against a
    local spectral line database using a provided database connector.
    """

    # MODIFIED: The type hint is now the generic BaseConnector.
    def __init__(self, db_connector: Optional[BaseConnector] = None):
        """
        Initializes the ElementalIdentifier.

        Args:
            db_connector: An initialized instance of a class that inherits from BaseConnector
                          (e.g., SQLiteConnector, CSVConnector).
        """
        self.db_connector = db_connector
        if self.db_connector is None:
            logger.info(
                "ElementalIdentifier initialized without a DB connector. "
                "Local identification will be unavailable until a connector is provided."
            )
        elif not self.db_connector.is_connected():
             logger.warning(
                "ElementalIdentifier initialized with a DB connector that is not connected. "
                "Local identification may fail."
            )
        else:
            logger.info("ElementalIdentifier initialized with a database connector.")

    def set_connector(self, db_connector: BaseConnector):
        """Allows setting or changing the database connector after initialization."""
        self.db_connector = db_connector
        logger.info(f"Database connector set to {db_connector.__class__.__name__} for ElementalIdentifier.")

    def identify_single_peak(self,
                             experimental_wavelength_nm: float,
                             wavelength_tolerance_nm: float = 0.1,
                             selected_elements: Optional[List[str]] = None
                            ) -> List[Dict[str, Any]]:
        """
        Identifies a single experimental peak wavelength using the configured database connector.
        (Note: This is a simplified version; identify_peaks_in_list is generally preferred)

        Returns:
            A list of match dictionaries compatible with the ElementalLine data model.
        """
        if not self.db_connector or not self.db_connector.is_connected():
            logger.warning("No database connected. Cannot identify single peak.")
            return []

        try:
            # MODIFIED: Changed method call from find_lines_for_peak to the new generic query_lines.
            matches = self.db_connector.query_lines(
                wavelength_center=experimental_wavelength_nm,
                tolerance_nm=wavelength_tolerance_nm,
                elements_filter=selected_elements
            )
            # Add context for the UI/downstream processing
            for match in matches:
                match['experimental_wavelength_nm'] = experimental_wavelength_nm
                match['delta_wavelength_nm'] = experimental_wavelength_nm - match.get('wavelength_nm', experimental_wavelength_nm)
            return matches
        except Exception as e:
            logger.error(f"Error during single peak identification: {e}", exc_info=True)
            return []

    def identify_peaks_in_list(self,
                               peaks: List[Peak],
                               wavelength_tolerance_nm: float = 0.1,
                               selected_elements: Optional[List[str]] = None
                              ) -> List[Peak]:
        """
        Identifies elements for a list of Peak objects using the current database connector.
        Updates Peak objects in-place with identification results.
        """
        if not self.db_connector or not self.db_connector.is_connected():
            logger.warning("No database connected. Cannot identify peaks.")
            for peak_obj in peaks:
                peak_obj.is_identified = False
                peak_obj.identified_elements = []
            return peaks

        num_peaks_identified_total = 0
        total_matches_found = 0

        for peak_obj in peaks:
            effective_wl = peak_obj.get_effective_wavelength()
            if effective_wl is None:
                peak_obj.is_identified = False
                peak_obj.identified_elements = []
                continue

            try:
                # MODIFIED: Changed method call to the new generic query_lines.
                matches = self.db_connector.query_lines(
                    wavelength_center=effective_wl,
                    tolerance_nm=wavelength_tolerance_nm,
                    elements_filter=selected_elements
                )
                
                if matches:
                    # Add context required by the data model/UI
                    for match in matches:
                        match['experimental_wavelength_nm'] = effective_wl
                        match['delta_wavelength_nm'] = effective_wl - match.get('wavelength_nm', effective_wl)

                    peak_obj.is_identified = True
                    peak_obj.identified_elements = matches
                    num_peaks_identified_total += 1
                    total_matches_found += len(matches)
                else:
                    peak_obj.is_identified = False
                    peak_obj.identified_elements = []
            except Exception as e:
                logger.error(f"Error identifying peak {peak_obj.peak_id[:8]} at {effective_wl:.3f} nm: {e}", exc_info=True)
                peak_obj.is_identified = False
                peak_obj.identified_elements = []
        
        logger.info(f"Peak list identification complete. {num_peaks_identified_total} of {len(peaks)} peaks had at least one match. Total matches: {total_matches_found}.")
        return peaks

    def identify_peaks_in_spectrum(self, spectrum: LIBSpectrum, **kwargs):
        """Convenience method to identify peaks for an entire LIBSpectrum object."""
        if not spectrum or not spectrum.peaks:
            logger.info(f"No peaks to identify in spectrum {spectrum.spectrum_id if spectrum else 'N/A'}")
            return
        
        # Pass through arguments like tolerance and element filters
        self.identify_peaks_in_list(
            spectrum.peaks,
            wavelength_tolerance_nm=kwargs.get('wavelength_tolerance_nm', 0.1),
            selected_elements=kwargs.get('selected_elements')
        )
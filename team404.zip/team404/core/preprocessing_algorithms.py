# team404/core/preprocessing_algorithms.py

"""
Provides algorithms for various spectral preprocessing steps.
Also defines the registry and schema for these algorithms for UI integration.
"""

import logging
import numpy as np
from scipy.signal import savgol_filter, medfilt
from scipy.ndimage import gaussian_filter1d
from scipy.interpolate import interp1d
from scipy import sparse
from scipy.sparse.linalg import spsolve
from typing import Tuple, Optional, List, Union, Dict, Any

_PYWT_AVAILABLE = False
try:
    import pywt
    _PYWT_AVAILABLE = True
except ImportError:
    pass # Handled in the wavelet function

_CUPY_AVAILABLE = False
try:
    import cupy as cp
    import cupyx.scipy.sparse as cp_sparse
    from cupyx.scipy.sparse.linalg import spsolve as cp_spsolve
    _CUPY_AVAILABLE = True
except ImportError:
    pass

logger = logging.getLogger(__name__)

# --- Helper for Input Validation ---
def _validate_intensity_array(
    intensities: Union[np.ndarray, List, Tuple],
    array_name: str = "intensities",
    ensure_non_empty: bool = True,
    min_length: Optional[int] = None
) -> np.ndarray:
    """
    Validate and convert input to a 1D numpy array of floats.
    Optionally ensures it's not empty and meets a minimum length.
    """
    if not isinstance(intensities, np.ndarray):
        try:
            intensities_arr = np.asarray(intensities, dtype=float)
        except Exception as e:
            logger.error(f"Could not convert {array_name} to a NumPy array: {e}")
            raise TypeError(f"{array_name} must be a NumPy array or convertible to one.") from e
    else:
        if not np.issubdtype(intensities.dtype, np.floating):
            intensities_arr = intensities.astype(float)
        else:
            intensities_arr = intensities.copy() # Work on a copy

    if intensities_arr.ndim == 0: # Scalar input
        intensities_arr = np.array([intensities_arr.item()], dtype=float)
    elif intensities_arr.ndim > 1:
        logger.error(f"{array_name} must be a 1D array, but got {intensities_arr.ndim} dimensions.")
        raise ValueError(f"{array_name} must be a 1D array.")

    if ensure_non_empty and intensities_arr.size == 0:
        logger.error(f"{array_name} array cannot be empty for this operation.")
        raise ValueError(f"{array_name} array cannot be empty.")
    
    if min_length is not None and intensities_arr.size < min_length:
        logger.error(f"{array_name} array must have at least {min_length} elements; got {intensities_arr.size}.")
        raise ValueError(f"{array_name} array length {intensities_arr.size} is less than minimum required {min_length}.")
        
    return intensities_arr

# --- Baseline Correction Algorithms ---

def baseline_als(
    intensities: np.ndarray,
    lam: float = 1e5,  # Smoothness parameter
    p: float = 0.01,   # Asymmetry parameter
    niter: int = 10,   # Max iterations
    tol: float = 1e-3  # Convergence tolerance
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Adaptive Smoothness Asymmetric Least Squares (ALS) baseline fitting.
    (Eilers & Boelens, 2005; similar to AsLS described in Wei et al., 2022 review)

    Args:
        intensities: NumPy array of intensity values (1D).
        lam: Smoothness parameter (larger values make baseline smoother).
        p: Asymmetry parameter (0 < p < 1). For positive peaks, p is small (e.g., 0.001-0.1)
           to give less weight to points above the baseline, pushing it down.
        niter: Maximum number of iterations.
        tol: Tolerance for convergence.

    Returns:
        Tuple: (baseline_corrected_intensities, estimated_baseline)
    """
    y = _validate_intensity_array(intensities, "ALS intensities", min_length=3)
    L = len(y)

    # Validate parameters
    if not (0 < p < 1):
        logger.warning(f"ALS: p value {p} is outside (0,1). Clamping to [eps, 1-eps].")
        p = np.clip(p, np.finfo(float).eps, 1.0 - np.finfo(float).eps)
    if lam <= 0:
        logger.warning(f"ALS: lambda value {lam} must be positive. Using abs(lam) or fallback to 1e2.")
        lam = abs(lam) if lam !=0 else 1e2
    if niter <= 0: niter = 1
    if tol <= 0: tol = 1e-3
        
    # Sparse difference matrix construction (O(N) operation instead of O(N^3))
    D = sparse.diags([1, -2, 1], [0, 1, 2], shape=(L - 2, L))
    DTD = lam * D.transpose().dot(D) # pre-multiply lambda

    # Try GPU accelerated ALS first if available
    if _CUPY_AVAILABLE:
        try:
            w_cp = cp.ones(L)
            y_cp = cp.asarray(y)
            DTD_cp = cp_sparse.csr_matrix(DTD)
            z_cp = cp.zeros(L)
            
            for i in range(niter):
                z_old_cp = z_cp.copy()
                W_cp = cp_sparse.diags(w_cp, 0, shape=(L, L), format='csr')
                C_cp = W_cp + DTD_cp
                z_cp = cp_spsolve(C_cp, w_cp * y_cp)
                
                w_cp = p * (y_cp > z_cp) + (1 - p) * (y_cp <= z_cp)
                
                norm_z_old = cp.linalg.norm(z_old_cp)
                if norm_z_old > cp.finfo(float).eps:
                    if cp.linalg.norm(z_cp - z_old_cp) / norm_z_old < tol:
                        logger.debug(f"ALS (GPU) converged at iteration {i+1}.")
                        break
                elif cp.linalg.norm(z_cp - z_old_cp) < tol * cp.sqrt(L):
                    logger.debug(f"ALS (GPU, from zero) converged at iteration {i+1}.")
                    break
            else:
                logger.debug(f"ALS (GPU) reached maximum iterations ({niter}).")
            
            z = cp.asnumpy(z_cp)
            baseline_corrected = y - z
            return baseline_corrected, z
        except Exception as e:
            logger.warning(f"GPU ALS failed: {e}. Falling back to CPU sparse ALS.")

    # CPU Sparse ALS Fallback
    w = np.ones(L)
    z = np.zeros(L)

    for i in range(niter):
        z_old = z.copy()
        W = sparse.diags(w, 0, shape=(L, L), format='csr')
        
        C = W + DTD
        try:
            z = spsolve(C, w * y)
        except Exception:
            logger.warning("ALS: Sparse matrix solve failed. Using pseudo-inverse (lstsq) as fallback.")
            z = np.linalg.lstsq(C.toarray(), w * y, rcond=None)[0]

        # Update weights asymmetrically
        w = p * (y > z) + (1 - p) * (y <= z) 
        
        # Check for convergence
        norm_z_old = np.linalg.norm(z_old)
        if norm_z_old > np.finfo(float).eps:
            if np.linalg.norm(z - z_old) / norm_z_old < tol:
                logger.debug(f"ALS converged at iteration {i+1}.")
                break
        elif np.linalg.norm(z - z_old) < tol * np.sqrt(L):
            logger.debug(f"ALS (from zero baseline) converged at iteration {i+1}.")
            break
    else:
        logger.debug(f"ALS reached maximum iterations ({niter}).")
        
    baseline_corrected = y - z
    return baseline_corrected, z


def baseline_polynomial(
    wavelengths: np.ndarray,
    intensities: np.ndarray,
    order: int = 2,
    roi_indices: Optional[List[int]] = None, # List of indices for baseline points
    exclude_indices_ranges: Optional[List[Tuple[int, int]]] = None # List of (start, end) tuples to exclude
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Fits a polynomial to selected baseline regions or all points excluding peak regions.
    If neither roi_indices nor exclude_indices_ranges are provided, fits to all points.

    Args:
        wavelengths: Full wavelength array (1D).
        intensities: Full intensity array (1D).
        order: Order of the polynomial.
        roi_indices: Optional list of indices known to be baseline.
        exclude_indices_ranges: Optional list of (start_idx, end_idx) tuples (inclusive) to exclude.
                                Ignored if roi_indices is provided.
    Returns:
        Tuple: (baseline_corrected_intensities, estimated_baseline)
    """
    wl_val = _validate_intensity_array(wavelengths, "Polynomial baseline wavelengths")
    int_val = _validate_intensity_array(intensities, "Polynomial baseline intensities")

    if wl_val.size != int_val.size:
        raise ValueError("Wavelengths and intensities must have the same length for polynomial baseline.")
    if wl_val.size == 0 : return np.array([]), np.array([])

    if not isinstance(order, int) or order < 0:
        logger.warning(f"Polynomial order {order} invalid. Setting to 0.")
        order = 0
    
    num_points_total = len(wl_val)
    min_points_for_fit = order + 1

    if num_points_total < min_points_for_fit:
        logger.warning(f"Not enough data points ({num_points_total}) for polynomial of order {order}. Returning original data.")
        return int_val.copy(), np.zeros_like(int_val)

    wl_to_fit: np.ndarray
    int_to_fit: np.ndarray

    if roi_indices is not None and len(roi_indices) > 0:
        try:
            roi_idx_arr = np.unique(np.asarray(roi_indices, dtype=int)) # Unique, sorted
            if np.any(roi_idx_arr < 0) or np.any(roi_idx_arr >= num_points_total):
                logger.error("roi_indices contains out-of-bounds values. Using all points.")
                wl_to_fit, int_to_fit = wl_val, int_val
            elif len(roi_idx_arr) < min_points_for_fit:
                logger.warning(f"Not enough unique points in ROI ({len(roi_idx_arr)}) for order {order}. Using all points.")
                wl_to_fit, int_to_fit = wl_val, int_val
            else:
                wl_to_fit, int_to_fit = wl_val[roi_idx_arr], int_val[roi_idx_arr]
        except Exception as e:
            logger.error(f"Error processing roi_indices: {e}. Using all points.")
            wl_to_fit, int_to_fit = wl_val, int_val
    elif exclude_indices_ranges is not None and len(exclude_indices_ranges) > 0:
        mask = np.ones(num_points_total, dtype=bool)
        for r_start, r_end in exclude_indices_ranges:
            if 0 <= r_start <= r_end < num_points_total:
                mask[r_start : r_end + 1] = False
            else: logger.warning(f"Invalid range in exclude_indices_ranges: ({r_start},{r_end}). Ignored.")
        
        if np.sum(mask) < min_points_for_fit:
            logger.warning(f"Not enough points ({np.sum(mask)}) after exclusions for order {order}. Using all points.")
            wl_to_fit, int_to_fit = wl_val, int_val
        else:
            wl_to_fit, int_to_fit = wl_val[mask], int_val[mask]
    else: # No ROI or exclusions, fit to all data
        wl_to_fit, int_to_fit = wl_val, int_val
    
    if len(wl_to_fit) < min_points_for_fit: # Final check
        logger.warning(f"After selection, not enough points ({len(wl_to_fit)}) for polynomial of order {order}. Returning original data.")
        return int_val.copy(), np.zeros_like(int_val)

    try:
        coeffs = np.polyfit(wl_to_fit, int_to_fit, order)
        baseline = np.polyval(coeffs, wl_val) # Evaluate baseline over the full original wavelength range
        return int_val - baseline, baseline
    except (np.linalg.LinAlgError, ValueError) as e: # Catches rank deficiency, etc.
        logger.error(f"Error during polynomial fitting (np.polyfit/polyval): {e}. Returning original data.")
        return int_val.copy(), np.zeros_like(int_val)


# --- Smoothing / Noise Reduction ---
def smooth_savgol(intensities: np.ndarray, window_length: int = 5, polyorder: int = 2, deriv: int = 0, delta: float = 1.0, mode: str = 'interp') -> np.ndarray:
    y = _validate_intensity_array(intensities, "Savgol input", ensure_non_empty=False) # Allow empty for graceful return
    if y.size == 0: return np.array([])

    if not isinstance(window_length, int) or window_length <= 0:
        logger.warning(f"SavGol window_length ({window_length}) invalid. Using 3."); window_length = 3
    if window_length % 2 == 0: window_length += 1 # Must be odd
    
    if len(y) < window_length:
        logger.warning(f"Data length ({len(y)}) < SavGol window ({window_length}). Returning original."); return y.copy()

    if not isinstance(polyorder, int) or polyorder < 0:
        logger.warning(f"SavGol polyorder ({polyorder}) invalid. Using 0."); polyorder = 0
    if polyorder >= window_length:
        polyorder = max(0, window_length - 1) # polyorder must be less than window_length
        logger.warning(f"SavGol polyorder adjusted to {polyorder} for window {window_length}.")
    
    # Other params (deriv, delta, mode) are assumed valid per schema or scipy defaults
    try:
        return savgol_filter(y, window_length, polyorder, deriv=deriv, delta=delta, mode=mode)
    except ValueError as ve:
        logger.error(f"Error in Savitzky-Golay smoothing: {ve}. Returning original data."); return y.copy()


def smooth_median(intensities: np.ndarray, kernel_size: int = 5) -> np.ndarray:
    y = _validate_intensity_array(intensities, "Median filter input", ensure_non_empty=False)
    if y.size == 0: return np.array([])
    if not isinstance(kernel_size, int) or kernel_size <= 0:
        logger.warning(f"Median kernel_size ({kernel_size}) invalid. Using 3."); kernel_size = 3
    if kernel_size % 2 == 0: kernel_size += 1 # Must be odd
    if len(y) < kernel_size : # medfilt handles this gracefully by returning original if kernel is too large
        logger.debug(f"Data length ({len(y)}) < Median kernel ({kernel_size}). Medfilt may return original.")
    if kernel_size == 1: return y.copy()
    return medfilt(y, kernel_size=kernel_size)

def smooth_moving_average(intensities: np.ndarray, window_length: int = 5) -> np.ndarray:
    y = _validate_intensity_array(intensities, "Moving average input", ensure_non_empty=False)
    if y.size == 0: return np.array([])
    if not isinstance(window_length, int) or window_length < 1:
        logger.warning(f"Moving average window_length ({window_length}) invalid. Using 1."); window_length = 1
    if window_length == 1 or len(y) < window_length: return y.copy() # No change or not enough data for full window
    return np.convolve(y, np.ones(window_length)/window_length, mode='same')

def smooth_gaussian(intensities: np.ndarray, sigma: float = 1.0) -> np.ndarray:
    y = _validate_intensity_array(intensities, "Gaussian filter input", ensure_non_empty=False)
    if y.size == 0: return np.array([])
    if not isinstance(sigma, (int, float)) or sigma <= 0:
        logger.warning(f"Gaussian sigma ({sigma}) must be positive. Using 1.0."); sigma = 1.0
    return gaussian_filter1d(y, sigma=sigma)

# --- Normalization ---
def normalize_to_max(intensities: np.ndarray) -> np.ndarray:
    y = _validate_intensity_array(intensities, "Normalize to max input", ensure_non_empty=False)
    if y.size == 0: return np.array([])
    max_val = np.max(y)
    if np.abs(max_val) > np.finfo(float).eps: return y / max_val
    logger.warning("Max intensity is near zero for normalize_to_max. Returning original data.")
    return y.copy()

def normalize_to_area(intensities: np.ndarray, wavelengths: Optional[np.ndarray] = None) -> np.ndarray:
    y = _validate_intensity_array(intensities, "Normalize to area input", ensure_non_empty=False)
    if y.size == 0: return np.array([])
    
    area: float
    if wavelengths is not None:
        wl = _validate_intensity_array(wavelengths, "Wavelengths for normalize_to_area", ensure_non_empty=False)
        if wl.size == y.size and y.size > 1: area = np.trapz(y, wl)
        elif y.size == 1: area = y[0] # Area of single point is its value
        else: 
            logger.warning("Mismatched/invalid wavelengths for area norm; using sum of intensities.")
            area = np.sum(y)
    elif y.size == 1: area = y[0]
    else: area = np.sum(y) # Default to sum if no wavelengths or not suitable
    
    if abs(area) > np.finfo(float).eps: return y / area
    logger.warning("Total area/sum is near zero for normalize_to_area. Returning original data.")
    return y.copy()

def normalize_snv(intensities: np.ndarray) -> np.ndarray:
    y = _validate_intensity_array(intensities, "SNV input", ensure_non_empty=False)
    if y.size == 0: return np.array([])
    if y.size == 1: return np.array([0.0], dtype=float) # SNV of a single point is 0
    
    mean_val = np.mean(y)
    std_val = np.std(y)
    if std_val > np.finfo(float).eps: return (y - mean_val) / std_val
    logger.debug("Standard deviation is near zero for SNV. Returning mean-centered data.")
    return y - mean_val # Avoid division by zero, just mean-center

def normalize_msc(intensities: np.ndarray, reference_spectrum: np.ndarray) -> np.ndarray:
    """
    Applies Multiplicative Scatter Correction (MSC).
    Requires a reference spectrum (e.g., mean of dataset).
    Formula: X_corrected = (X_original - intercept) / slope
             where X_original = slope * X_reference + intercept + error
    """
    spec_to_correct = _validate_intensity_array(intensities, "MSC input spectrum", min_length=2)
    ref_spec = _validate_intensity_array(reference_spectrum, "MSC reference spectrum", min_length=2)

    if spec_to_correct.shape != ref_spec.shape:
        raise ValueError("MSC: Input spectrum and reference spectrum must have the same shape.")

    # Fit linear model: spec_to_correct = slope * ref_spec + intercept
    # Using np.vstack to create design matrix for lstsq (or polyfit)
    X_fit = np.vstack([ref_spec, np.ones(len(ref_spec))]).T
    try:
        slope, intercept = np.linalg.lstsq(X_fit, spec_to_correct, rcond=None)[0]
    except np.linalg.LinAlgError as e:
        logger.error(f"MSC: Linear algebra error during fitting: {e}. Returning original spectrum.")
        return spec_to_correct.copy()

    if np.abs(slope) < np.finfo(float).eps:
        logger.warning("MSC: Calculated slope is near zero. Correction might be unstable. Returning original spectrum.")
        return spec_to_correct.copy()
            
    return (spec_to_correct - intercept) / slope

# --- Cosmic Ray / Spike Removal ---
def remove_cosmic_ray_median_filter_based(
    intensities: np.ndarray,
    wavelengths: Optional[np.ndarray] = None, # For interpolation
    kernel_size: int = 7,      # For median filter
    threshold_factor: float = 3.0 # For MAD-based threshold
) -> np.ndarray:
    y_orig = _validate_intensity_array(intensities, "Cosmic ray removal input", ensure_non_empty=False)
    if y_orig.size == 0: return np.array([])
    y = y_orig.copy()

    if not isinstance(kernel_size, int) or kernel_size <= 0: kernel_size = 3
    if kernel_size % 2 == 0: kernel_size += 1
    if len(y) < kernel_size or kernel_size == 1: return y # Not enough points or no filtering

    wl_validated: Optional[np.ndarray] = None
    if wavelengths is not None:
        wl_validated = _validate_intensity_array(wavelengths, "Wavelengths for cosmic ray removal", ensure_non_empty=False)
        if wl_validated.size != y.size: 
            logger.warning("Cosmic ray: Wavelengths/intensities mismatch. Interpolation disabled.")
            wl_validated = None
        elif wl_validated.size > 1 and np.any(np.diff(wl_validated) <= 0): 
            logger.warning("Cosmic ray: Wavelengths not strictly increasing. Interpolation might be unreliable.")
    
    median_filtered = medfilt(y, kernel_size=kernel_size)
    difference = np.abs(y - median_filtered)
    
    # Robust threshold using MAD of differences
    median_of_differences = np.median(difference)
    mad_of_differences = np.median(np.abs(difference - median_of_differences))
    
    # Scaled MAD for threshold (1.4826 is 1 / ppf(0.75) for Gaussian)
    if mad_of_differences > np.finfo(float).eps:
        threshold_val = median_of_differences + threshold_factor * 1.4826 * mad_of_differences
    else: # MAD is zero, fallback to std if significant, else no spikes if differences are all tiny
        std_of_differences = np.std(difference)
        if std_of_differences > np.finfo(float).eps * len(y): # Check if std is meaningfully non-zero
            threshold_val = median_of_differences + threshold_factor * 1.4826 * std_of_differences
        elif median_of_differences < np.finfo(float).eps : # All differences are tiny/zero
             return y # No spikes to find
        else: # MAD is zero, but median_of_differences is not. Use a small factor of median_of_differences.
             threshold_val = median_of_differences * (1 + threshold_factor * 0.1) # Arbitrary small uplift

    spikes_indices = np.where(difference > threshold_val)[0]

    if len(spikes_indices) > 0:
        logger.debug(f"Cosmic ray: Detected {len(spikes_indices)} potential spikes using threshold {threshold_val:.3g}.")
        is_spike_mask = np.zeros(len(y), dtype=bool); is_spike_mask[spikes_indices] = True

        for idx in spikes_indices:
            replaced_by_interp = False
            if wl_validated is not None and 0 < idx < len(y) - 1: # Can interpolate if not at edges
                # Find nearest non-spike neighbors for interpolation
                prev_non_spike = idx - 1
                while prev_non_spike >= 0 and is_spike_mask[prev_non_spike]: prev_non_spike -= 1
                
                next_non_spike = idx + 1
                while next_non_spike < len(y) and is_spike_mask[next_non_spike]: next_non_spike += 1

                if prev_non_spike >= 0 and next_non_spike < len(y) and prev_non_spike != next_non_spike:
                    # Ensure wavelengths at candidates are distinct
                    if not np.isclose(wl_validated[prev_non_spike], wl_validated[next_non_spike]):
                        x_pts = [wl_validated[prev_non_spike], wl_validated[next_non_spike]]
                        y_pts_interp = [y[prev_non_spike], y[next_non_spike]] # Use original y of non-spike neighbors
                        
                        # Ensure x_pts are sorted for interp1d robustness
                        if x_pts[0] > x_pts[1]: x_pts.reverse(); y_pts_interp.reverse()
                        try:
                            interp_func = interp1d(x_pts, y_pts_interp, kind='linear', bounds_error=False, 
                                                   fill_value=median_filtered[idx]) 
                            y[idx] = interp_func(wl_validated[idx])
                            replaced_by_interp = True
                        except ValueError as e_interp:
                            logger.warning(f"Cosmic ray: Interpolation failed for spike at index {idx} (wl {wl_validated[idx]:.2f}): {e_interp}. Using median fallback.")
            
            if not replaced_by_interp: # Fallback to median value from initial median filter
                y[idx] = median_filtered[idx]
    return y

# --- Wavelet Denoising (Conceptual) ---
def conceptual_wavelet_denoise(
    intensities: np.ndarray, wavelet: str = 'db4',
    level: Optional[int] = None, threshold_method: str = 'soft'
) -> np.ndarray:
    """
    Performs wavelet denoising on the intensity data.

    Args:
        intensities: The 1D NumPy array of spectral intensities.
        wavelet: The name of the wavelet to use (e.g., 'db4', 'sym8').
        level: The level of decomposition. If None, the maximum possible level is used.
        threshold_method: Type of thresholding ('soft' or 'hard').

    Returns:
        The denoised 1D NumPy array of intensities.
    """
    y = _validate_intensity_array(intensities, "Wavelet input", ensure_non_empty=False)
    original_len = len(y)
    if original_len < 2:
        return y.copy()

    if not _PYWT_AVAILABLE:
        logger.warning("PyWavelets library not installed (`pip install pywavelets`). Wavelet denoising is unavailable.")
        return y.copy()

    try:
        w = pywt.Wavelet(wavelet)
    except ValueError:
        logger.error(f"Invalid wavelet name: '{wavelet}'. Using 'db4' as fallback.")
        w = pywt.Wavelet('db4')

    # Determine optimal decomposition level
    max_level = pywt.dwt_max_level(original_len, w.dec_len)
    if level is None or level > max_level:
        level_to_use = max_level
        logger.debug(f"Adjusting wavelet decomposition level to maximum possible: {max_level}")
    else:
        level_to_use = level

    if level_to_use < 1:
        logger.warning(f"Data length {original_len} is too short for wavelet '{w.name}'. Returning original data.")
        return y.copy()
    
    # 1. Decompose
    coeffs = pywt.wavedec(y, w, level=level_to_use)

    # 2. Estimate noise and calculate threshold
    # Use Median Absolute Deviation on the finest detail coefficients (robust to outliers)
    detail_coeffs_cd1 = coeffs[-1]
    sigma_mad = np.median(np.abs(detail_coeffs_cd1 - np.median(detail_coeffs_cd1))) / 0.6745
    
    # Universal Threshold
    threshold_val = sigma_mad * np.sqrt(2 * np.log(original_len))
    logger.debug(f"Wavelet denoising: Estimated noise (sigma) = {sigma_mad:.3f}, Universal Threshold = {threshold_val:.3f}")

    # 3. Threshold detail coefficients
    new_coeffs = [coeffs[0]] # Keep approximation coefficients
    for c in coeffs[1:]:
        new_coeffs.append(pywt.threshold(c, value=threshold_val, mode=threshold_method))

    # 4. Reconstruct
    denoised_y = pywt.waverec(new_coeffs, w)

    # Ensure output length matches input length
    if len(denoised_y) > original_len:
        return denoised_y[:original_len]
    elif len(denoised_y) < original_len:
        # Pad if necessary (less common with waverec)
        return np.pad(denoised_y, (0, original_len - len(denoised_y)), 'edge')
    
    return denoised_y

    

# --- Registry and Schema Definitions ---

PROCESSING_FUNCTION_REGISTRY: Dict[str, str] = {
    # internal_func_name: UserFriendlyDisplayName
    "baseline_als": "Baseline: Asymmetric Least Squares (ALS)",
    "baseline_polynomial": "Baseline: Polynomial Fit (ROI/Exclusion)",
    "smooth_savgol": "Smooth: Savitzky-Golay Filter",
    "smooth_median": "Smooth: Median Filter",
    "smooth_moving_average": "Smooth: Moving Average",
    "smooth_gaussian": "Smooth: Gaussian Filter",
    "normalize_to_max": "Normalize: To Max Intensity (0-1)",
    "normalize_to_area": "Normalize: To Area/Sum",
    "normalize_snv": "Normalize: Standard Normal Variate (SNV)",
    "normalize_msc": "Normalize: Multiplicative Scatter Correction (MSC)",
    "remove_cosmic_ray_median_filter_based": "Remove Spikes: Median-Filter Based",
    "conceptual_wavelet_denoise": "Denoise: Wavelet Transform",
}

DEFAULT_PARAMS_SCHEMA: Dict[str, Dict[str, Any]] = {
    "baseline_als": {
        "lam": {"type": "float", "default": 1e5, "min": 1e1, "max": 1e9, "step": 1e4, "decimals": 0, "label": "Lambda (Smoothness)", "tooltip": "Smoothness (1e2-1e9). Larger = smoother."},
        "p": {"type": "float", "default": 0.01, "min": 0.0001, "max": 0.9999, "step": 0.001, "decimals": 4, "label": "p (Asymmetry)", "tooltip": "Asymmetry (0-1). Small for positive peaks (e.g. 0.001-0.1)."},
        "niter": {"type": "int", "default": 10, "min": 1, "max": 100, "label": "Max Iterations", "tooltip": "Maximum fitting iterations."},
        "tol": {"type": "float", "default": 1e-3, "min":1e-7, "max":1e-1, "decimals":7, "label":"Tolerance", "tooltip":"Convergence tolerance."}
    },
    "baseline_polynomial": {
        "order": {"type": "int", "default": 2, "min": 0, "max": 15, "label": "Polynomial Order", "tooltip": "Order of polynomial. Requires order+1 points."},
    },
    "smooth_savgol": {
        "window_length": {"type": "int", "default": 5, "min": 3, "max": 201, "step": 2, "label": "Window Length (odd)", "tooltip": "Filter window (odd, positive)."},
        "polyorder": {"type": "int", "default": 2, "min": 0, "max": 20, "label": "Polynomial Order", "tooltip": "Polynomial order (must be < window_length)."},
        "deriv": {"type": "int", "default": 0, "min":0, "max":5, "label": "Derivative Order", "tooltip":"Order of derivative (0 for smoothing)."},
        "mode": {"type": "str", "default":"interp", "options":["interp", "mirror", "constant", "nearest", "wrap"], "label":"Border Mode", "tooltip":"Mode for handling signal borders."}
    },
    "smooth_median": {
        "kernel_size": {"type": "int", "default": 5, "min": 3, "max": 201, "step": 2, "label": "Kernel Size (odd)", "tooltip": "Size of median filter kernel (odd, positive)."}
    },
    "smooth_moving_average": {
        "window_length": {"type": "int", "default": 5, "min": 1, "max": 201, "label": "Window Length", "tooltip": "Length of moving average window (positive)."}
    },
    "smooth_gaussian": {
        "sigma": {"type": "float", "default": 1.0, "min": 0.1, "max": 50.0, "step": 0.1, "decimals": 2, "label": "Sigma (Std. Dev.)", "tooltip": "Standard deviation for Gaussian kernel (positive)."}
    },
    "normalize_to_max": {},
    "normalize_to_area": {},
    "normalize_snv": {},
    "normalize_msc": {
        "info_msc": {"type": "label", "text": "Note: Reference spectrum for MSC must be provided by calling context (e.g., mean of dataset or a specific spectrum object)."}
    },
    "remove_cosmic_ray_median_filter_based": {
        "kernel_size": {"type": "int", "default": 7, "min": 3, "max": 51, "step": 2, "label": "Median Kernel (odd)", "tooltip": "Kernel for local median (odd, positive)."},
        "threshold_factor": {"type": "float", "default": 3.0, "min": 0.1, "max": 20.0, "decimals":1, "label": "Threshold Factor (MAD)", "tooltip": "Multiplier for MAD of residuals to set spike threshold."}
    },
    "conceptual_wavelet_denoise": {
        "wavelet": {"type": "str", "default": "db4", "options": pywt.wavelist(kind='discrete') if _PYWT_AVAILABLE else ['db4', 'sym8'], "label": "Wavelet Family", "tooltip": "Name of the wavelet (e.g., 'db4', 'sym8')."},
        "level": {"type": "int", "default": 4, "min": 0, "max": 15, "label": "Decomposition Level", "tooltip": "Set decomposition level. If 0 or too high, max possible will be used."},
        "threshold_method": {"type": "str", "default": "soft", "options": ["soft", "hard"], "label": "Thresholding Method", "tooltip": "Soft or hard thresholding."}
    }
}

for func_name_in_registry in PROCESSING_FUNCTION_REGISTRY:
    if func_name_in_registry not in DEFAULT_PARAMS_SCHEMA:
        DEFAULT_PARAMS_SCHEMA[func_name_in_registry] = {}
        logger.debug(f"Auto-added empty schema for '{func_name_in_registry}' as it was missing from DEFAULT_PARAMS_SCHEMA.")
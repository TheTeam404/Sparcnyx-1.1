# team404/core/project_manager.py

import logging
import os
import json
from pathlib import Path
from typing import Optional, Dict, Any, List
import copy

import numpy as np # For deepcopy

from . import data_models as dm_runtime 
from . import file_io as fio_runtime

from ..app_config import APP_VERSION, DEFAULT_PROJECT_SETTINGS_FILENAME


logger = logging.getLogger(__name__)


class ProjectManager:
    """
    Manages LIBS projects: creation, loading, saving, and access to current project data.
    """
    def __init__(self, app_settings_manager=None):
        self.current_project: Optional[dm_runtime.LIBSProject] = None
        self.app_settings_manager = app_settings_manager
        self.default_project_settings: Dict[str, Any] = self._load_default_project_settings()

    def _get_default_project_settings_filepath(self) -> Path:
        try:
            base_path = Path(__file__).resolve().parent.parent
            return base_path / "assets" / "config_templates" / DEFAULT_PROJECT_SETTINGS_FILENAME
        except NameError: 
            logger.warning("__file__ not defined, attempting fallback for default_project_params.json path.")
            return Path("team404") / "assets" / "config_templates" / DEFAULT_PROJECT_SETTINGS_FILENAME

    def _load_default_project_settings(self) -> Dict[str, Any]:
        filepath = self._get_default_project_settings_filepath()
        try:
            if filepath.exists() and filepath.is_file():
                with filepath.open('r', encoding='utf-8') as f:
                    settings = json.load(f)
                logger.info(f"Successfully loaded default project settings from {filepath}")
                return settings
            else:
                logger.warning(f"Default project settings file not found at {filepath}. Using empty defaults.")
        except json.JSONDecodeError as e:
            logger.error(f"Error decoding default project settings file {filepath}: {e}. Using empty defaults.")
        except Exception as e:
            logger.error(f"Error loading default project settings from {filepath}: {e}. Using empty defaults.")
        
        return {
            "version": APP_VERSION,
            "preprocessing_params": {}, "peak_detection_params": {}, "elemental_id_params": {},
            "quantitative_params": {}, "mapping_params": {}, "chemometrics_params": {}
        }

    def is_project_open(self) -> bool:
        return self.current_project is not None

    # ADD THIS METHOD
    def get_current_project(self) -> Optional[dm_runtime.LIBSProject]:
        """Returns the currently active LIBSProject instance, or None."""
        return self.current_project

    def get_current_project_name(self) -> Optional[str]:
        return self.current_project.project_name if self.current_project else None

    def get_current_project_filepath(self) -> Optional[str]:
        return self.current_project.project_filepath if self.current_project else None
    
    def get_project_settings(self) -> Dict[str, Any]:
        if self.current_project and self.current_project.settings:
            merged_settings = copy.deepcopy(self.default_project_settings)
            self._deep_merge_settings(merged_settings, self.current_project.settings)
            return merged_settings
        return copy.deepcopy(self.default_project_settings)

    def _deep_merge_settings(self, target: Dict, source: Dict):
        for key, value in source.items():
            if isinstance(value, dict) and isinstance(target.get(key), dict):
                self._deep_merge_settings(target[key], value)
            else:
                target[key] = value

    def new_project(self, project_name: str = "Untitled Project", project_dir: Optional[str] = None) -> bool:
        if self.is_project_open() and self.current_project is not None:
            logger.info(f"Creating new project '{project_name}' while '{self.current_project.project_name}' is open.")
            self.close_project(save_if_dirty=False)

        self.current_project = dm_runtime.LIBSProject(project_name=project_name)
        self.current_project.settings = copy.deepcopy(self.default_project_settings)
        self.mark_project_dirty(False) 

        if project_dir:
            proj_path = Path(project_dir)
            proj_path.mkdir(parents=True, exist_ok=True)
            safe_name = "".join(c if c.isalnum() or c in (' ', '_', '-') else '_' for c in project_name).rstrip().replace(" ", "_")
            if not safe_name: safe_name = "Untitled_Project"
            filename = f"{safe_name}.libs_proj"
            self.current_project.project_filepath = str(proj_path / filename)
        else:
            self.current_project.project_filepath = None
            self.mark_project_dirty(True)

        logger.info(f"New project '{project_name}' created. Filepath (if set): {self.current_project.project_filepath}")
        return True

    def load_project(self, filepath: str) -> bool:
        path_obj = Path(filepath)
        if not path_obj.is_file():
            logger.error(f"Project file not found: {filepath}")
            return False
        try:
            loaded_proj = fio_runtime.load_project_from_file(str(path_obj))
            if loaded_proj:
                self.close_project(save_if_dirty=False)
                self.current_project = loaded_proj
                if self.current_project:
                    default_copy = copy.deepcopy(self.default_project_settings)
                    self._deep_merge_settings(default_copy, self.current_project.settings)
                    self.current_project.settings = default_copy
                    self.current_project.mark_dirty(False)
                logger.info(f"Project '{loaded_proj.project_name}' loaded from {filepath}")
                return True
            return False
        except Exception as e:
            logger.error(f"Failed to load project from {filepath}: {e}", exc_info=True)
            return False

    def save_project(self, filepath: Optional[str] = None) -> bool:
        if not self.current_project:
            logger.warning("No current project to save."); return False
        
        target_path_str = filepath if filepath else self.current_project.project_filepath
        if not target_path_str:
            logger.error("No filepath specified for saving project."); return False
        
        target_path = Path(target_path_str)
        try:
            target_path.parent.mkdir(parents=True, exist_ok=True)
            success = fio_runtime.save_project_to_file(self.current_project, str(target_path))
            if success and self.current_project :
                self.current_project.project_filepath = str(target_path)
                self.current_project.mark_dirty(False)
                self.current_project.update_last_modified()
                logger.info(f"Project '{self.current_project.project_name}' saved to {target_path}")
            return success
        except Exception as e:
            logger.error(f"Error saving project to {target_path}: {e}", exc_info=True)
            return False

    def save_project_as(self, filepath: str) -> bool:
        if not self.current_project:
            logger.warning("No current project to save as."); return False
        return self.save_project(filepath)

    def close_project(self, save_if_dirty: bool = True) -> bool:
        if self.current_project:
            project_name = self.current_project.project_name
            self.current_project = None
            logger.info(f"Project '{project_name}' closed.")
        else: logger.info("No project was open to close.")
        return True

    def get_active_spectrum(self) -> Optional[dm_runtime.LIBSpectrum]:
        # Use the new get_current_project method
        project = self.get_current_project()
        return project.get_active_spectrum() if project else None


    def add_spectrum_to_project(self, spectrum: dm_runtime.LIBSpectrum):
        project = self.get_current_project() # Use the new getter
        if project: project.add_spectrum(spectrum)
        else: logger.warning("Cannot add spectrum: No project is open.")

    def remove_spectrum_from_project(self, spectrum_id: str) -> bool:
        project = self.get_current_project() # Use the new getter
        if project: return project.remove_spectrum(spectrum_id)
        else: logger.warning("Cannot remove spectrum: No project is open.")
        return False

    def set_active_spectrum(self, spectrum_id: Optional[str]):
        project = self.get_current_project() # Use the new getter
        if project: project.set_active_spectrum(spectrum_id)
        elif spectrum_id is not None: logger.warning("Cannot set active spectrum: No project open.")

    def mark_project_dirty(self, dirty: bool = True):
        project = self.get_current_project() # Use the new getter
        if project:
            project.mark_dirty(dirty)
        elif dirty:
             logger.warning("Attempted to mark project dirty, but no project is open.")

    def is_project_dirty(self) -> bool:
        project = self.get_current_project() # Use the new getter
        if project:
            return project.is_dirty()
        return False


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    from PyQt5.QtWidgets import QApplication
    from ..app_config import ORGANIZATION_NAME, APP_CONFIGURATION_NAME
    
    app = QApplication.instance() or QApplication([])
    QApplication.setOrganizationName(ORGANIZATION_NAME)
    QApplication.setApplicationName(APP_CONFIGURATION_NAME)

    from ..gui.dialogs.preferences_dialog import app_settings_manager

    pm = ProjectManager(app_settings_manager=app_settings_manager)
    logger.info(f"Default project settings version: {pm.default_project_settings.get('version')}")
    pm.new_project("My Test Project 1")
    assert pm.is_project_open()
    assert pm.is_project_dirty() 

    current_proj = pm.get_current_project() # Test the new getter
    if current_proj:
        current_proj.project_filepath = "./temp_test_projects/new_proj.libs_proj"
        pm.mark_project_dirty(False) 
        assert not pm.is_project_dirty()

        wl = np.array([200, 201, 202], dtype=float); intens = np.array([10, 20, 15], dtype=float)
        spec1 = dm_runtime.LIBSpectrum(wl, intens, filename="s1.txt")
        pm.add_spectrum_to_project(spec1)
        assert pm.is_project_dirty(), "Project should be dirty after adding a spectrum"
        assert len(current_proj.spectra) == 1
        
        temp_dir = Path("./temp_test_projects"); temp_dir.mkdir(exist_ok=True)
        # test_proj_path = temp_dir / "my_test_project_1.libs_proj" # Path will be from current_proj.project_filepath
        
        if pm.save_project(): 
            logger.info(f"Project saved to {current_proj.project_filepath}")
            assert not pm.is_project_dirty(), "Project should be clean after saving"
            
            pm.close_project(save_if_dirty=False)
            if current_proj.project_filepath and pm.load_project(str(current_proj.project_filepath)):
                logger.info("Project loaded successfully.")
                assert not pm.is_project_dirty(), "Loaded project should be clean"
                loaded_project = pm.get_current_project()
                if loaded_project: assert len(loaded_project.spectra) == 1
    logger.info("ProjectManager tests completed.")
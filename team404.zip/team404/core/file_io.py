# team404/core/file_io.py

"""
Handles file input/output operations for SpectraMapper Pro, including:
- Loading raw spectral data from various text formats and HDF5.
- Saving processed spectral data.
- Loading and saving LIBSProject files (JSON format).
"""

import csv
import json
import logging
import os
import re
from pathlib import Path
from typing import Tuple, List, Dict, Any, Optional, Union
import collections
from typing_extensions import runtime

import numpy as np

# Import for HDF5 support. This is a new dependency.
# Ensure 'h5py' is added to requirements.txt
try:
    import h5py
    H5PY_AVAILABLE = True
except ImportError:
    H5PY_AVAILABLE = False


# Import data models using TYPE_CHECKING to avoid circular imports at runtime
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .data_models import LIBSpectrum, LIBSProject

# Delayed import of data_models for runtime
if not TYPE_CHECKING:
    # Attempt to import, but allow it to fail gracefully if not essential for all functions
    # or if this module is used in a context where data_models might not be fully set up.
    try:
        from . import data_models as runtime
    except ImportError:
        runtime = None # Allows basic file I/O to work even if data_models is problematic

logger = logging.getLogger(__name__)

# Constants
DELIMITER_CHECK_LINES = 20 # Number of lines to check for auto-delimiter detection

# --- Spectral Data File Loading ---

def _attempt_auto_delimiter_for_line(line: str, common_delimiters=(',', '\t', ';', ' ')) -> Optional[str]:
    """Tries to guess the delimiter from a single line of text."""
    counts = {delim: line.count(delim) for delim in common_delimiters if delim != ' '}
    
    # Special handling for space: count segments after splitting by space
    if ' ' in common_delimiters:
        space_parts = [p for p in line.strip().split(' ') if p]
        if len(space_parts) > 1:
            counts[' '] = len(space_parts) - 1 # Number of "separations"
        else:
            counts[' '] = 0


    # Find delimiter that results in a reasonable number of parts (e.g., >= 1 split)
    # and is present. Prioritize by common_delimiters order if counts are similar.
    for delim in common_delimiters:
        if counts.get(delim, 0) > 0:
             # Basic check: if delim creates more than one piece after split.
            if delim == ' ':
                if [p for p in line.strip().split() if p]: # Ensure non-empty parts
                    return ' ' # Tentatively accept space
            elif len(line.split(delim)) > 1:
                return delim
    return None


def _parse_spectral_data_lines(
    lines: List[str],
    filepath_str: str, # For logging context
    delimiter: Optional[str] = None,
    skip_header: int = 0,
    comment_char: Optional[str] = '#',
    wl_col_idx: int = 0,
    int_col_idx: int = 1
) -> Tuple[List[float], List[float], Dict[str, Any], int, Optional[str]]:
    """
    Parses lines of text to extract wavelength and intensity data.

    Returns:
        Tuple containing (wavelengths, intensities, extracted_metadata, data_start_line_idx, detected_delimiter_or_None)
    """
    wavelengths: List[float] = []
    intensities: List[float] = []
    raw_header_content: List[str] = []
    data_start_line_idx = -1  # 0-based index of the first actual data line read
    
    detected_delimiter = delimiter # Will be updated if auto-detected

    if wl_col_idx == int_col_idx:
        logger.error(f"Wavelength column index ({wl_col_idx}) and intensity column index ({int_col_idx}) cannot be the same.")
        # No data can be parsed, return empty lists and indicate failure via empty data
        return [], [], {"error": "Column indices are identical"}, -1, detected_delimiter


    # Auto-detect delimiter from potential data lines if not provided
    if detected_delimiter is None:
        delimiter_candidates = []
        lines_checked_for_delim = 0
        for i, line_to_check in enumerate(lines):
            if i < skip_header:
                continue
            if comment_char and line_to_check.strip().startswith(comment_char):
                continue
            if not line_to_check.strip(): # Skip empty lines
                continue
            
            guessed_delim = _attempt_auto_delimiter_for_line(line_to_check)
            if guessed_delim:
                delimiter_candidates.append(guessed_delim)
            
            lines_checked_for_delim += 1
            if lines_checked_for_delim >= DELIMITER_CHECK_LINES:
                break
        
        if delimiter_candidates:
            most_common_delim = collections.Counter(delimiter_candidates).most_common(1)[0][0]
            detected_delimiter = most_common_delim
            logger.debug(f"Auto-detected delimiter: '{detected_delimiter}' for {filepath_str}")
        else:
            detected_delimiter = ' ' # Default if still not found
            logger.warning(f"Could not auto-detect delimiter for {filepath_str}, defaulting to space. Parsing may be incorrect.")

    parsing_data = False
    for line_idx, line in enumerate(lines):
        line_strip = line.strip()

        if line_idx < skip_header:
            raw_header_content.append(line_strip)
            continue

        if not line_strip or (comment_char and line_strip.startswith(comment_char)):
            if not parsing_data: # If comments/blanks are before any data line
                 raw_header_content.append(line_strip) # Consider these part of extended header
            continue
        
        if not parsing_data:
            parsing_data = True
            data_start_line_idx = line_idx 

        try:
            if detected_delimiter == ' ': # Handle multiple spaces as a single delimiter
                parts = [p for p in line_strip.split() if p] # Default split() handles multiple spaces
            else:
                parts = [p.strip() for p in line_strip.split(detected_delimiter)]

            if len(parts) > max(wl_col_idx, int_col_idx):
                wl_str = parts[wl_col_idx]
                int_str = parts[int_col_idx]
                
                # Attempt to convert, allowing for scientific notation. Replace comma with dot for European decimals.
                wl_str_cleaned = wl_str.replace(',', '.')
                int_str_cleaned = int_str.replace(',', '.')

                wavelength = float(wl_str_cleaned)
                intensity = float(int_str_cleaned)

                wavelengths.append(wavelength)
                intensities.append(intensity)
            else:
                logger.warning(
                    f"Line {line_idx+1} in '{filepath_str}' ('{line_strip[:50]}...') "
                    f"has too few columns ({len(parts)}) using delimiter '{detected_delimiter}'. Skipping."
                )
        except ValueError as e:
            logger.warning(
                f"Could not parse numeric data from line {line_idx+1} in '{filepath_str}' ('{line_strip[:50]}...'): {e}. Skipping."
            )
        except IndexError as e: # Should be caught by len(parts) check, but as safeguard
            logger.warning(
                f"Column index out of bounds for line {line_idx+1} in '{filepath_str}' ('{line_strip[:50]}...'): {e}. Skipping."
            )
    
    metadata = {
        "raw_header_lines": raw_header_content,
        "data_start_line_number": data_start_line_idx + 1 if data_start_line_idx != -1 else -1, # 1-based for users
        "comment_char_used": comment_char,
        "detected_delimiter": detected_delimiter if delimiter is None else None # Only store if auto-detected
    }
    return wavelengths, intensities, metadata, data_start_line_idx, detected_delimiter


def load_spectrum_from_file(
    filepath: Union[str, os.PathLike],
    delimiter: Optional[str] = None,
    skip_header: int = 0,
    comment_char: Optional[str] = '#',
    wl_col_idx: int = 0,
    int_col_idx: int = 1,
    encoding: str = 'utf-8'
) -> Optional[Tuple[np.ndarray, np.ndarray, Dict[str, Any]]]:
    """
    Loads a single spectrum from a text file.

    Args:
        filepath: Path to the spectral data file.
        delimiter: Column delimiter. If None, attempts to auto-detect.
        skip_header: Number of initial lines to treat strictly as header.
        comment_char: Character indicating a comment line.
        wl_col_idx: Index of the wavelength column (0-based).
        int_col_idx: Index of the intensity column (0-based).
        encoding: File encoding.

    Returns:
        A tuple (wavelengths_array, intensities_array, metadata_dict) or None if loading fails.
    """
    path_obj = Path(filepath)
    logger.info(f"Attempting to load spectrum from: {path_obj}")

    if not path_obj.exists():
        logger.error(f"File not found: {path_obj}")
        return None
    if not path_obj.is_file():
        logger.error(f"Path is not a file: {path_obj}")
        return None

    if skip_header < 0:
        logger.warning(f"skip_header ({skip_header}) is negative, using 0.")
        skip_header = 0
    if wl_col_idx < 0:
        logger.error(f"wl_col_idx ({wl_col_idx}) cannot be negative.")
        return None
    if int_col_idx < 0:
        logger.error(f"int_col_idx ({int_col_idx}) cannot be negative.")
        return None


    try:
        with path_obj.open('r', encoding=encoding) as f:
            lines = f.readlines()
    except FileNotFoundError: # Should be caught by path_obj.exists() but good practice
        logger.error(f"File not found during open: {path_obj}")
        return None
    except IOError as e:
        logger.error(f"IOError reading file {path_obj}: {e}")
        return None
    except UnicodeDecodeError as e:
        logger.error(f"UnicodeDecodeError for {path_obj} with encoding {encoding}. Try a different encoding (e.g. 'latin-1', 'utf-16'): {e}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error reading file {path_obj}: {e}")
        return None

    if not lines:
        logger.warning(f"File {path_obj} is empty.")
        return (np.array([]), np.array([]), {"message": "File is empty"})


    wavelengths_list, intensities_list, metadata, _, _ = _parse_spectral_data_lines(
        lines, str(path_obj), delimiter, skip_header, comment_char, wl_col_idx, int_col_idx
    )
    
    if "error" in metadata: # Error from _parse_spectral_data_lines like identical columns
        logger.error(f"Failed to parse spectral data from {path_obj}: {metadata['error']}")
        return None

    if not wavelengths_list or not intensities_list:
        logger.error(f"No valid spectral data found in {path_obj} with given parameters.")
        return None # Metadata might contain info about why it failed implicitly

    # Sort by wavelength if not already sorted
    try:
        sorted_indices = np.argsort(wavelengths_list)
        wl_array = np.array(wavelengths_list, dtype=float)[sorted_indices]
        int_array = np.array(intensities_list, dtype=float)[sorted_indices]
    except Exception as e:
        logger.error(f"Error converting parsed data to NumPy arrays or sorting for {path_obj}: {e}")
        return None

    logger.info(f"Successfully loaded {len(wl_array)} data points from {path_obj}.")
    return wl_array, int_array, metadata


def save_spectrum_to_file(
    filepath: Union[str, os.PathLike],
    wavelengths: np.ndarray,
    intensities: np.ndarray,
    header_lines: Optional[List[str]] = None,
    delimiter: str = '\t',
    fmt: Union[str, List[str]] = '%.6f',
    encoding: str = 'utf-8'
) -> bool:
    """
    Saves spectral data to a text file.

    Args:
        filepath: Path to save the file.
        wavelengths: NumPy array of wavelengths.
        intensities: NumPy array of intensities.
        header_lines: Optional list of strings to write as a header (each string is a line).
        delimiter: Column delimiter.
        fmt: Format string(s) for numbers (e.g., '%.6f' or ['%.3f', '%.2e']).
        encoding: File encoding.

    Returns:
        True if saving was successful, False otherwise.
    """
    path_obj = Path(filepath)

    if not isinstance(wavelengths, np.ndarray) or wavelengths.ndim != 1:
        logger.error("Wavelengths must be a 1D NumPy array.")
        return False
    if not isinstance(intensities, np.ndarray) or intensities.ndim != 1:
        logger.error("Intensities must be a 1D NumPy array.")
        return False

    if wavelengths.size != intensities.size:
        logger.error("Wavelengths and intensities arrays must have the same length.")
        return False

    logger.info(f"Attempting to save spectrum to: {path_obj}")
    try:
        path_obj.parent.mkdir(parents=True, exist_ok=True) # Ensure directory exists
        with path_obj.open('w', newline='', encoding=encoding) as f:
            if header_lines:
                for line in header_lines:
                    f.write(line + '\n') # Ensure newline character for header lines

            writer = csv.writer(f, delimiter=delimiter)
            
            fmt_wl = fmt[0] if isinstance(fmt, list) and len(fmt) > 0 else fmt
            fmt_int = fmt[1] if isinstance(fmt, list) and len(fmt) > 1 else fmt

            if wavelengths.size == 0:
                logger.info(f"Saving empty spectrum to {path_obj}.")
            else:
                for wl, inten in zip(wavelengths, intensities):
                    writer.writerow([fmt_wl % wl, fmt_int % inten])
        
        logger.info(f"Spectrum successfully saved to {path_obj}.")
        return True
    except IOError as e:
        logger.error(f"IOError saving spectrum to {path_obj}: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error saving spectrum to {path_obj}: {e}")
        return False

# --- HDF5 Mapping Data I/O ---

def load_mapping_data_from_hdf5(filepath: str) -> Optional[Tuple[List['LIBSpectrum'], Tuple[int, int]]]:
    """
    Loads a full 2D mapping dataset from a specific HDF5 file structure.

    Args:
        filepath: The path to the HDF5 file.

    Returns:
        A tuple containing:
        - A list of LIBSpectrum objects, one for each point in the map.
        - A tuple of map dimensions (width, height).
        Returns None if loading fails.
    """
    if not H5PY_AVAILABLE:
        logger.critical("Cannot load HDF5 file: 'h5py' library is not installed. Please run 'pip install h5py'.")
        raise ImportError("h5py library is required for HDF5 support.")
    
    if not runtime or not hasattr(runtime, 'LIBSpectrum'):
        logger.error("LIBSpectrum data model not available. Cannot create spectrum objects.")
        return None

    path_obj = Path(filepath)
    if not path_obj.is_file():
        logger.error(f"HDF5 file not found: {filepath}")
        return None
    
    logger.info(f"Attempting to load mapping data from HDF5 file: {path_obj.name}")

    try:
        with h5py.File(filepath, 'r') as hf:
            if 'measurements' not in hf:
                raise KeyError("HDF5 file missing 'measurements' group.")
            
            # Dynamically find the first (and likely only) measurement group
            measurement_group_keys = list(hf['measurements'].keys())
            if not measurement_group_keys:
                raise KeyError("HDF5 'measurements' group is empty.")
            measurement_group_name = measurement_group_keys[0]
            logger.debug(f"Found measurement group: {measurement_group_name}")

            base_path = f'measurements/{measurement_group_name}/libs/'
            global_meta_path = f'measurements/{measurement_group_name}/global_metadata/'

            # Read datasets into memory
            wavelengths = hf[base_path + 'calibration'][:]
            intensities_matrix = hf[base_path + 'data'][:]
            x_coords = hf[base_path + 'metadata/X_pos'][:]
            y_coords = hf[base_path + 'metadata/Y_pos'][:]
            
            # Read dimensions from global metadata (these are often single-element arrays)
            map_width = int(hf[global_meta_path + 'xPosCount'][0])
            map_height = int(hf[global_meta_path + 'yPosCount'][0])

            # --- Validate dataset shapes and sizes ---
            num_spectra, num_wl_points = intensities_matrix.shape
            if num_spectra != len(x_coords) or num_spectra != len(y_coords):
                raise ValueError(f"Shape mismatch: Number of spectra in data matrix ({num_spectra}) does not match "
                                 f"coordinate array lengths (X: {len(x_coords)}, Y: {len(y_coords)}).")
            if num_wl_points != len(wavelengths):
                raise ValueError(f"Shape mismatch: Number of wavelength points in data matrix ({num_wl_points}) "
                                 f"does not match calibration array length ({len(wavelengths)}).")
            
            logger.info(f"HDF5 data validated. Found {num_spectra} spectra with {num_wl_points} points each. Map dimensions: {map_width}x{map_height}.")

            # --- Create LIBSpectrum objects ---
            spectra_list = []
            for i in range(num_spectra):
                spectrum = runtime.LIBSpectrum(
                    raw_wavelengths=wavelengths,
                    raw_intensities=intensities_matrix[i, :],
                    filename=f"map_point_{i}.h5_slice", # Generate a placeholder filename
                    filepath=filepath,
                    x_coord=x_coords[i],
                    y_coord=y_coords[i]
                )
                spectra_list.append(spectrum)
            
            logger.info(f"Successfully created {len(spectra_list)} LIBSpectrum objects from HDF5 file.")
            return (spectra_list, (map_width, map_height))

    except (KeyError, ValueError) as e:
        logger.error(f"Failed to load HDF5 mapping data due to structure error: {e}", exc_info=True)
        return None
    except Exception as e:
        logger.error(f"An unexpected error occurred while loading HDF5 file '{filepath}': {e}", exc_info=True)
        return None

# --- LIBSProject File I/O ---

def save_project_to_file(project: 'LIBSProject', filepath: Optional[Union[str, os.PathLike]] = None) -> bool:
    """
    Saves a LIBSProject object to a JSON file.
    """
    if not runtime or not hasattr(runtime, 'LIBSProject'):
        logger.error("LIBSProject data model not available. Cannot save project.")
        return False
    if not isinstance(project, runtime.LIBSProject):
        logger.error("Invalid object type provided for project saving.")
        return False

    target_path: Path
    if filepath:
        target_path = Path(filepath)
    elif project.project_filepath:
        target_path = Path(project.project_filepath)
    else:
        logger.error("No filepath provided and project has no associated filepath.")
        return False

    try:
        target_path.parent.mkdir(parents=True, exist_ok=True)
        project_data = project.to_dict()
        with target_path.open('w', encoding='utf-8') as f:
            json.dump(project_data, f, indent=4)
        logger.info(f"Project '{project.project_name}' successfully saved to {target_path}")
        return True
    except Exception as e:
        logger.error(f"Error saving project to {target_path}: {e}", exc_info=True)
        return False

def load_project_from_file(filepath: Union[str, os.PathLike]) -> Optional['LIBSProject']:
    """
    Loads a LIBSProject object from a JSON file.
    """
    if not runtime or not hasattr(runtime, 'LIBSProject'):
        logger.error("LIBSProject data model not available. Cannot load project.")
        return None

    target_path = Path(filepath)
    if not target_path.exists() or not target_path.is_file():
        logger.error(f"Project file not found: {target_path}")
        return None

    try:
        with target_path.open('r', encoding='utf-8') as f:
            project_data = json.load(f)
        project = runtime.LIBSProject.from_dict(project_data)
        project.project_filepath = str(target_path)
        logger.info(f"Project successfully loaded from {target_path}")
        return project
    except json.JSONDecodeError as e:
        logger.error(f"Error decoding JSON from project file {target_path}: {e}")
        return None
    except Exception as e:
        logger.error(f"Error loading project from {target_path}: {e}", exc_info=True)
        return None

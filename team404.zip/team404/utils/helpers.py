# team404/utils/helpers.py

"""
General helper functions and utility classes for SpectraMapper Pro.
These are miscellaneous utilities that don't fit into more specific modules
like core algorithms, GUI widgets, or plotting.
"""

import logging
import os
import re
import datetime
import sys
from typing import Any, Optional, Union, List, Tuple, Dict
import numpy as np
import numbers # For checking numeric types robustly

logger = logging.getLogger(__name__)

# --- String Manipulation ---

def sanitize_filename(filename: str, replacement_char: str = '_') -> str:
    """
    Sanitizes a string to be suitable for use as a filename.
    Replaces or removes characters that are problematic in filenames.

    Args:
        filename: The input string.
        replacement_char: Character to replace invalid characters with.

    Returns:
        A sanitized string suitable for a filename.
    """
    if not filename:
        return f"untitled_{get_timestamp_str(compact=True)}"

    # Remove or replace invalid characters. This list can be expanded.
    # Common invalid characters: / \ : * ? " < > |
    # Also, control characters (ASCII 0-31)
    sanitized = re.sub(r'[<>:"/\\|?*\x00-\x1F]', replacement_char, filename)
    
    # Remove leading/trailing problematic characters like spaces or the replacement_char
    sanitized = sanitized.strip(f" .{replacement_char}")

    # Limit length (many filesystems have a limit around 255 characters for the whole path)
    # This is a simple truncation, more robust would consider extension.
    max_len = 100 # Arbitrary safe length for a single filename component
    if len(sanitized) > max_len:
        name_part, ext_part = os.path.splitext(sanitized)
        name_part = name_part[:max_len - len(ext_part) -1] # -1 for the dot if ext exists
        sanitized = name_part + ext_part
        
    if not sanitized: # If all chars were invalid and removed
        return f"sanitized_file_{get_timestamp_str(compact=True)}"
        
    return sanitized

def get_timestamp_str(compact: bool = False, include_ms: bool = False) -> str:
    """
    Generates a timestamp string.

    Args:
        compact: If True, returns a compact format (YYYYMMDD_HHMMSS).
                 Otherwise, returns a more readable format (YYYY-MM-DD HH:MM:SS).
        include_ms: If True and compact is False, includes milliseconds.

    Returns:
        Formatted timestamp string.
    """
    now = datetime.datetime.now()
    if compact:
        return now.strftime("%Y%m%d_%H%M%S")
    else:
        if include_ms:
            return now.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] # Milliseconds
        else:
            return now.strftime("%Y-%m-%d %H:%M:%S")


# --- Numeric and Data Conversion ---

def robust_float_conversion(value: Any, default: Optional[float] = None) -> Optional[float]:
    """
    Attempts to convert a value to float robustly.
    Handles strings that might contain non-numeric parts (e.g., units, notes).

    Args:
        value: The value to convert.
        default: Value to return if conversion fails.

    Returns:
        The float value, or default if conversion fails.
    """
    if isinstance(value, numbers.Real): # Catches int, float, np.float, etc.
        return float(value)
    if isinstance(value, str):
        try:
            # Try direct conversion first
            return float(value)
        except ValueError:
            # Try to extract a number from the beginning of the string
            # This regex matches an optional sign, digits, optional decimal, more digits.
            # It stops at the first non-numeric character (excluding E for scientific notation).
            match = re.match(r"^\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)\s*", value)
            if match:
                try:
                    return float(match.group(1))
                except ValueError:
                    pass # Could not convert the extracted part
            logger.debug(f"Could not robustly convert string '{value}' to float.")
            return default
    logger.debug(f"Could not convert value of type '{type(value)}' to float.")
    return default

def robust_int_conversion(value: Any, default: Optional[int] = None) -> Optional[int]:
    """
    Attempts to convert a value to int robustly.
    First tries float conversion then int.
    """
    float_val = robust_float_conversion(value, default=None)
    if float_val is not None:
        try:
            return int(float_val)
        except (ValueError, TypeError):
            return default
    return default

def wavelength_intensity_to_points(wavelengths: np.ndarray, intensities: np.ndarray) -> np.ndarray:
    """
    Converts separate wavelength and intensity arrays into a 2D array of (x,y) points.
    Assumes wavelengths and intensities are of the same length.

    Args:
        wavelengths: 1D NumPy array of wavelengths.
        intensities: 1D NumPy array of intensities.

    Returns:
        2D NumPy array where each row is [wavelength, intensity].
        Returns an empty array if inputs are mismatched or empty.
    """
    if wavelengths is None or intensities is None or len(wavelengths) != len(intensities) or len(wavelengths) == 0:
        return np.array([])
    return np.vstack((wavelengths, intensities)).T


# --- Path and File System ---

def get_app_data_directory(app_name: str, org_name: Optional[str] = None) -> str:
    """
    Gets a platform-appropriate application data directory.
    Creates it if it doesn't exist.

    Args:
        app_name: Name of the application.
        org_name: Optional organization name (used for path structure on some OS).

    Returns:
        The path to the application data directory.
    """
    if sys.platform == "win32":
        path = os.getenv('APPDATA', os.path.expanduser("~"))
        if org_name:
            app_data_path = os.path.join(path, org_name, app_name)
        else:
            app_data_path = os.path.join(path, app_name)
    elif sys.platform == "darwin": # macOS
        path = os.path.expanduser("~/Library/Application Support")
        if org_name:
            app_data_path = os.path.join(path, org_name, app_name)
        else:
            app_data_path = os.path.join(path, app_name)
    else: # Linux and other Unix-like
        path = os.getenv('XDG_CONFIG_HOME', os.path.expanduser("~/.config"))
        if org_name:
            app_data_path = os.path.join(path, org_name, app_name)
        else:
            app_data_path = os.path.join(path, app_name)
    
    try:
        os.makedirs(app_data_path, exist_ok=True)
    except OSError as e:
        logger.error(f"Could not create application data directory {app_data_path}: {e}")
        # Fallback to a temporary directory or user's home if creation fails?
        # For now, just return the path and let calling code handle potential issues.
    return app_data_path


def find_closest_index(array: np.ndarray, value: float) -> int:
    """
    Finds the index of the element in a sorted 1D NumPy array
    that is closest to the given value.

    Args:
        array: Sorted 1D NumPy array.
        value: The value to find the closest element to.

    Returns:
        The index of the closest element.
        Returns -1 if array is empty.
    """
    if array is None or len(array) == 0:
        return -1
    # Ensure array is sorted if not guaranteed by caller (can be slow for large arrays)
    # if not np.all(np.diff(array) >= 0):
    #     logger.warning("Input array for find_closest_index is not sorted. Results may be incorrect.")

    idx = np.searchsorted(array, value, side="left")
    if idx == len(array): # Value is larger than all elements
        return len(array) - 1
    if idx == 0: # Value is smaller than all elements
        return 0
    
    # Check which neighbor is closer: array[idx-1] or array[idx]
    if abs(value - array[idx-1]) < abs(value - array[idx]):
        return idx - 1
    else:
        return idx


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)

    print("--- Testing String Manipulation ---")
    print(f"Sanitize 'my:file*name?.txt': {sanitize_filename('my:file*name?.txt')}")
    print(f"Sanitize '  leading/trailing spaces  ': {sanitize_filename('  leading/trailing spaces  ')}")
    long_fn = "a"*150 + ".log"
    print(f"Sanitize long filename (len {len(long_fn)}): '{sanitize_filename(long_fn)}' (len {len(sanitize_filename(long_fn))})")
    print(f"Timestamp (default): {get_timestamp_str()}")
    print(f"Timestamp (compact): {get_timestamp_str(compact=True)}")
    print(f"Timestamp (ms): {get_timestamp_str(include_ms=True)}")

    print("\n--- Testing Numeric Conversion ---")
    print(f"Float from '123.45 units': {robust_float_conversion('123.45 units')}")
    print(f"Float from '-1.2e-3 stuff': {robust_float_conversion('-1.2e-3 stuff')}")
    print(f"Float from 'abc': {robust_float_conversion('abc', default=0.0)}")
    print(f"Float from 10: {robust_float_conversion(10)}")
    print(f"Float from None: {robust_float_conversion(None)}")
    print(f"Int from '123.789 units': {robust_int_conversion('123.789 units')}")
    print(f"Int from 'abc': {robust_int_conversion('abc', default=-1)}")

    print("\n--- Testing Wavelength/Intensity to Points ---")
    wl = np.array([1.0, 2.0, 3.0])
    it = np.array([10, 20, 15])
    pts = wavelength_intensity_to_points(wl, it)
    print(f"Points array:\n{pts}")
    assert pts.shape == (3,2)

    print("\n--- Testing App Data Directory ---")
    app_dir = get_app_data_directory("TestApp", "MyOrg")
    print(f"App data directory: {app_dir}")
    assert os.path.exists(app_dir) # It should be created

    print("\n--- Testing Find Closest Index ---")
    sorted_arr = np.array([10.0, 20.0, 30.0, 40.0, 50.0])
    print(f"Array: {sorted_arr}")
    print(f"Closest to 23.0: index {find_closest_index(sorted_arr, 23.0)} (value {sorted_arr[find_closest_index(sorted_arr, 23.0)]})") # Expect 1 (20.0)
    print(f"Closest to 27.0: index {find_closest_index(sorted_arr, 27.0)} (value {sorted_arr[find_closest_index(sorted_arr, 27.0)]})") # Expect 2 (30.0)
    print(f"Closest to 5.0: index {find_closest_index(sorted_arr, 5.0)} (value {sorted_arr[find_closest_index(sorted_arr, 5.0)]})")   # Expect 0 (10.0)
    print(f"Closest to 55.0: index {find_closest_index(sorted_arr, 55.0)} (value {sorted_arr[find_closest_index(sorted_arr, 55.0)]})") # Expect 4 (50.0)
    print(f"Closest to 30.0: index {find_closest_index(sorted_arr, 30.0)} (value {sorted_arr[find_closest_index(sorted_arr, 30.0)]})") # Expect 2 (30.0)
    assert find_closest_index(sorted_arr, 23.0) == 1
    assert find_closest_index(sorted_arr, 27.0) == 2

    print("\nHelper functions tests completed.")
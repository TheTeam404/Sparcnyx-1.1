# team404/utils/__init__.py

"""
Utilities package for SpectraMapper Pro.

This package contains helper functions, constants, and other utility
modules that are used across the application but don't belong to a
specific core, GUI, or plotting domain.
"""

from .constants import (
    APP_NAME, APP_VERSION, ORG_NAME,
    DEFAULT_PROJECT_EXTENSION,
    DEFAULT_WAVELENGTH_UNIT, DEFAULT_INTENSITY_UNIT,
    # Add other constants you want to be easily accessible
    # from the 'utils' namespace
    MAX_PREVIEW_LINES,
    MIN_BOLTZMANN_LINES,
    DATABASE_TYPE_SQLITE,
    DATABASE_TYPE_CSV
)

# from .helpers import some_helper_function # Example
# from .logging_setup import setup_global_logger # Example

__all__ = [
    # Constants
    "APP_NAME", "APP_VERSION", "ORG_NAME",
    "DEFAULT_PROJECT_EXTENSION",
    "DEFAULT_WAVELENGTH_UNIT", "DEFAULT_INTENSITY_UNIT",
    "MAX_PREVIEW_LINES",
    "MIN_BOLTZMANN_LINES",
    "DATABASE_TYPE_SQLITE",
    "DATABASE_TYPE_CSV",

    # Helper functions/classes
    # "some_helper_function",
    # "setup_global_logger",
]
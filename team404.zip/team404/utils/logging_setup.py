import logging
import logging.handlers
import os
import sys
from typing import Optional, Union

# Import constants for log configuration
from .constants import APP_NAME, ORG_NAME, LOG_FILE_NAME, LOG_FORMAT, DEFAULT_LOG_LEVEL
from .helpers import get_app_data_directory # To get a platform-specific log directory

# Global variable to ensure setup is done only once
_logger_configured = False

def setup_global_logger(
    log_level: Optional[Union[str, int]] = None,
    log_to_console: bool = True,
    log_to_file: bool = True,
    log_directory: Optional[str] = None,
    max_file_size_mb: int = 5, # Max size of a single log file
    backup_count: int = 3 # Number of backup log files to keep
) -> logging.Logger:
    """
    Configures the root logger for the application.

    Args:
        log_level: The minimum logging level (e.g., "DEBUG", "INFO", logging.DEBUG).
                   If None, uses DEFAULT_LOG_LEVEL from constants.
        log_to_console: Whether to output logs to the console (stderr).
        log_to_file: Whether to output logs to a file.
        log_directory: Directory to store log files. If None, uses a subdirectory
                       within the application data directory.
        max_file_size_mb: Maximum size of a log file in megabytes before rotation.
        backup_count: Number of backup log files to keep.

    Returns:
        The configured root logger instance.
    """
    global _logger_configured
    if _logger_configured:
        logger = logging.getLogger() # Get root logger
        # Check if handlers are already present to avoid duplication if called again by mistake
        # This is a simple check; more robust would be to check handler names or types
        if any(isinstance(h, logging.StreamHandler) for h in logger.handlers) or \
           any(isinstance(h, logging.handlers.RotatingFileHandler) for h in logger.handlers):
            logger.debug("Logger already configured. Skipping redundant setup.")
            return logger

    # Get the root logger. All module-level loggers will inherit from this.
    logger = logging.getLogger() # Root logger
    
    # Determine logging level
    effective_log_level_str = log_level if isinstance(log_level, str) else DEFAULT_LOG_LEVEL
    numeric_level = getattr(logging, effective_log_level_str.upper(), None)
    if not isinstance(numeric_level, int): # Fallback if string is invalid
        numeric_level = logging.INFO
    if isinstance(log_level, int): # If an int level was passed directly
        numeric_level = log_level
        
    logger.setLevel(numeric_level)

    # Create formatter
    formatter = logging.Formatter(LOG_FORMAT)

    # --- Console Handler ---
    if log_to_console:
        console_handler = logging.StreamHandler(sys.stderr) # Or sys.stdout
        console_handler.setFormatter(formatter)
        console_handler.setLevel(numeric_level) # Console can have same or more verbose level
        logger.addHandler(console_handler)
        # logger.debug("Console logging configured.") # Logger not fully set up yet for this msg

    # --- File Handler (Rotating) ---
    if log_to_file:
        if log_directory is None:
            # Use a 'logs' subdirectory in the app's data directory
            app_data_dir = get_app_data_directory(APP_NAME, ORG_NAME)
            log_directory = os.path.join(app_data_dir, "logs")
        
        try:
            os.makedirs(log_directory, exist_ok=True)
            log_filepath = os.path.join(log_directory, LOG_FILE_NAME)

            # RotatingFileHandler automatically handles log file rotation
            file_handler = logging.handlers.RotatingFileHandler(
                log_filepath,
                maxBytes=max_file_size_mb * 1024 * 1024, # Convert MB to bytes
                backupCount=backup_count,
                encoding='utf-8'
            )
            file_handler.setFormatter(formatter)
            file_handler.setLevel(numeric_level) # File usually gets all messages at the set level
            logger.addHandler(file_handler)
            # logger.debug(f"File logging configured at: {log_filepath}")
        except Exception as e:
            # If file logging setup fails, log to console (if available) or print
            error_msg = f"Failed to configure file logging at {log_directory}: {e}"
            if console_handler:
                # Temporarily elevate console handler level for this critical warning if needed
                original_console_level = console_handler.level
                console_handler.setLevel(logging.WARNING)
                logger.warning(error_msg) # Use logger if console_handler was added
                console_handler.setLevel(original_console_level)
            else:
                print(f"ERROR: {error_msg}", file=sys.stderr) # Fallback to print

    if logger.hasHandlers():
        logger.info(f"Global logger configured. Level: {logging.getLevelName(logger.getEffectiveLevel())}")
        if any(isinstance(h, logging.handlers.RotatingFileHandler) for h in logger.handlers):
             logger.info(f"Logging to file: {log_filepath if log_to_file and 'log_filepath' in locals() else 'Disabled'}")
        if any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
             logger.info(f"Logging to console: {'Enabled' if log_to_console else 'Disabled'}")
    else:
        print("WARNING: Logger has no handlers configured after setup attempt.", file=sys.stderr)


    _logger_configured = True
    return logger


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    Convenience function to get a logger instance.
    If name is None, returns the root logger.
    Ensures global setup is called at least once if not already configured.

    Args:
        name: The name for the logger (typically __name__ of the calling module).

    Returns:
        A logging.Logger instance.
    """
    global _logger_configured
    if not _logger_configured:
        # If get_logger is called before explicit setup, run setup with defaults.
        # This is a fallback, explicit setup in main.py is preferred.
        print("Warning: Global logger setup initiated by get_logger. "
              "Explicit setup in main application entry point is recommended.", file=sys.stderr)
        setup_global_logger() # Use default settings

    if name:
        return logging.getLogger(name)
    else:
        return logging.getLogger() # Root logger

if __name__ == '__main__':
    # --- Example Usage ---
    print("Running logging_setup.py example...")

    # 1. Setup the global logger (typically done once at app startup)
    #    This call will print info/debug messages from setup_global_logger itself.
    #    For this test, let's use a specific test directory for logs.
    test_log_dir = os.path.join(os.getcwd(), "test_logs_temp") # Current dir for easy inspection
    if not os.path.exists(test_log_dir): os.makedirs(test_log_dir, exist_ok=True)
    
    print(f"Test log directory will be: {test_log_dir}")

    # First setup call (will configure)
    root_logger = setup_global_logger(
        log_level="DEBUG",
        log_to_console=True,
        log_to_file=True,
        log_directory=test_log_dir,
        max_file_size_mb=1, # Small for testing rotation
        backup_count=2
    )
    root_logger.info("Root logger test: This is an info message from root after setup.")
    root_logger.debug("Root logger test: This is a debug message from root after setup.")

    # 2. Get a logger for a specific module/component
    module_logger = get_logger(__name__) # Use __name__ for current module
    module_logger.info("Module logger test: Info message from 'logging_setup' module itself.")
    module_logger.warning("Module logger test: This is a warning.")
    
    another_component_logger = get_logger("MyComponent")
    another_component_logger.error("Component logger test: This is an error from 'MyComponent'.")

    # 3. Test logger already configured scenario
    print("\n--- Attempting redundant logger setup (should skip actual reconfiguration) ---")
    setup_global_logger(log_level="INFO") # Call again, should see "Logger already configured" debug message.

    # 4. Test log rotation (manual simulation)
    # To test rotation, you'd need to write > max_file_size_mb of logs.
    # This is harder to demo concisely here. The RotatingFileHandler handles it.
    # Example:
    # for i in range(20000): # Write many lines to force rotation if max_file_size_mb is small (e.g. 0.01 MB)
    #     another_component_logger.debug(f"Log rotation test line {i}: " + "abcdefghijklmnopqrstuvwxyz" * 2)
    # print("Log rotation test lines written. Check the test_log_dir.")

    print(f"\nLogging example finished. Check console output and log files in '{test_log_dir}'.")
    print(f"Log file should be: {os.path.join(test_log_dir, LOG_FILE_NAME)}")

    # Optional: Clean up test log directory after inspection
    # import shutil
    # try:
    #     shutil.rmtree(test_log_dir)
    #     print(f"Cleaned up test log directory: {test_log_dir}")
    # except Exception as e:
    #     print(f"Could not clean up test log directory {test_log_dir}: {e}")
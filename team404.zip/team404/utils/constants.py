# team404/utils/constants.py

"""
Application-wide constants for SpectraMapper Pro.
"""

# --- Application Information ---
APP_NAME: str = "Sparcnyx"
APP_VERSION: str = "0.1.0-alpha" # Should match version in about_dialog, setup.py, etc.
ORG_NAME: str = "Team404" # For QSettings, config paths
APP_COPYRIGHT_YEAR: str = "2024-2025"
APP_AUTHORS: str = "Team404 AI Developers & Contributors"


# --- File Extensions and Types ---
DEFAULT_PROJECT_EXTENSION: str = ".libs_proj"
PROJECT_FILE_FILTER: str = f"LIBS Project Files (*{DEFAULT_PROJECT_EXTENSION});;JSON Files (*.json)"
SPECTRAL_FILE_FILTER: str = "Spectral Files (*.txt *.csv *.asc *.spc);;Text Files (*.txt);;CSV Files (*.csv);;All Files (*)"
COORDINATE_FILE_FILTER: str = "Coordinate Files (*.csv *.txt);;CSV Files (*.csv);;Text Files (*.txt);;All Files (*)"
IMAGE_FILE_FILTER: str = "PNG Images (*.png);;JPEG Images (*.jpg *.jpeg);;TIFF Images (*.tif *.tiff);;All Files (*)"
DATABASE_SQLITE_FILTER: str = "SQLite Database (*.db *.sqlite *.sqlite3)"


# --- Default Units ---
DEFAULT_WAVELENGTH_UNIT: str = "nm"
DEFAULT_INTENSITY_UNIT: str = "a.u." # Arbitrary Units
DEFAULT_ENERGY_UNIT_EV: str = "eV"
DEFAULT_ENERGY_UNIT_CM_INV: str = "cm⁻¹" # Using superscript minus one


# --- UI Defaults and Limits ---
MAX_PREVIEW_LINES: int = 20 # For FileFormatDialog preview
MAX_RECENT_PROJECTS: int = 10
DEFAULT_PLOT_DPI: int = 100
STATUS_BAR_MSG_TIMEOUT_MS: int = 3000 # Default timeout for status messages


# --- Analysis Parameter Defaults/Limits ---
# Peak Detection
DEFAULT_PEAK_PROMINENCE: float = 0.1
DEFAULT_PEAK_DISTANCE_POINTS: int = 5

# Peak Fitting
DEFAULT_FIT_WINDOW_NM: float = 1.0
MIN_POINTS_FOR_FIT: int = 4 # Minimum data points in ROI for fitting

# Elemental ID
DEFAULT_ID_TOLERANCE_NM: float = 0.1

# Boltzmann Plot
MIN_BOLTZMANN_LINES: int = 2 # Minimum lines required for a Boltzmann plot


# --- Database Related ---
DATABASE_TYPE_SQLITE: str = "sqlite"
DATABASE_TYPE_CSV: str = "csv"
USER_CUSTOM_DB_FILENAME: str = "user_lines.sqlite" # Default name for user's custom DB


# --- Plotting Styles & Colors (can reference from plot_styles if preferred) ---
# Example:
# PLOT_PRIMARY_COLOR = "#007ACC" # from plot_styles.SPECTRAMAPPER_COLORS
# PLOT_GRID_STYLE = ":"


# --- Logging ---
DEFAULT_LOG_LEVEL: str = "INFO" # e.g., DEBUG, INFO, WARNING, ERROR, CRITICAL
LOG_FORMAT: str = "%(asctime)s - %(levelname)s - %(name)s (%(module)s.%(funcName)s:%(lineno)d) - %(message)s"
LOG_FILE_NAME: str = "Sparcnyx.log" # To be stored in user's app data/logs directory


# --- Configuration File Names ---
APP_PREFERENCES_FILENAME: str = "app_preferences.json"


# --- Regex Patterns (examples) ---
# Could be more specific if needed for parsing filenames or text
REGEX_FLOAT_NUMBER: str = r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?"
# Example for parsing "x<num>_y<num>" from filenames, numbers can be int or float
# Captures 'num' for x and y. \d+ for integer, \d*\.?\d+ for float.
# Non-capturing group (?:...) used for optional parts or grouping without capturing.
FILENAME_XY_PATTERN_EXAMPLE: str = r"x([-_]?\d+\.?\d*)_y([-_]?\d+\.?\d*)"


# --- Placeholder texts for UI ---
PLACEHOLDER_NO_DATA: str = "N/A"
PLACEHOLDER_SELECT_ITEM: str = "-- Select --"


# --- Keys for Settings/Project Data (to avoid magic strings) ---
# Example for project settings dictionary
SETTING_KEY_DB_PATHS = "database_paths"
SETTING_KEY_NIST_SQLITE = "nist_sqlite_db_path"
SETTING_KEY_NIST_CSV_DIR = "nist_csv_dir_path"
SETTING_KEY_USER_DB = "user_custom_db_path"

SETTING_KEY_PEAK_DETECT_PARAMS = "peak_detection_params"
SETTING_KEY_ID_PARAMS = "elemental_id_params"

# ... add more constants as your application grows ...

if __name__ == '__main__':
    # This block can be used to print out constants for verification if needed
    print(f"Application Name: {APP_NAME} (v{APP_VERSION})")
    print(f"Default Project Extension: {DEFAULT_PROJECT_EXTENSION}")
    print(f"Log file name: {LOG_FILE_NAME}")
    print(f"Default User Custom DB filename: {USER_CUSTOM_DB_FILENAME}")
    print(f"Example XY Filename Pattern: {FILENAME_XY_PATTERN_EXAMPLE}")
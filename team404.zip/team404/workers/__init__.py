# team404/workers/__init__.py

"""
Worker Threads package for SpectraMapper Pro.

This package contains QObject subclasses designed to be moved to QThread
instances for performing long-running, non-GUI tasks in the background.
This helps keep the main GUI responsive.
"""

from .base_worker import BaseWorker
# from .nist_online_search_worker import NISTOnlineSearchWorker # Example
# from .batch_processing_worker import BatchProcessingWorker # Example
# from .mapping_generation_worker import MappingGenerationWorker # Example
# from .model_training_worker import ModelTrainingWorker # Example
# from .file_import_worker import FileImportWorker # Example


__all__ = [
    "BaseWorker",
    # Add other specific worker classes here as they are created
    # "NISTOnlineSearchWorker",
    # "BatchProcessingWorker",
    # "MappingGenerationWorker",
    # "ModelTrainingWorker",
    # "FileImportWorker",
]
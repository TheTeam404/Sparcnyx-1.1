# team404/workers/nist_online_search_worker.py

import logging
from typing import List, Dict, Any, Optional, Union

import numpy as np
from PyQt5.QtCore import QObject
from PyQt5.QtWidgets import QApplication

from .base_worker import BaseWorker
try:
    from astroquery.nist import Nist
    from astropy.table import Table, Row
    import astropy.units as u
    ASTROQUERY_AVAILABLE = True
except ImportError:
    ASTROQUERY_AVAILABLE = False
    Nist, Table, Row, u = None, None, None, None

from ..core.data_models import ElementalLine
from ..utils.helpers import robust_float_conversion, robust_int_conversion

logger = logging.getLogger(__name__)

if not ASTROQUERY_AVAILABLE:
    logger.warning("Astroquery/Astropy not found. Online NIST searches are disabled.")

class NISTOnlineSearchWorker(BaseWorker):
    def __init__(self,
                 wavelength_min_nm: float,
                 wavelength_max_nm: float,
                 linename: Optional[str] = None,
                 energy_level_unit: str = "eV",
                 output_order: str = "wavelength",
                 query_reference: Optional[Any] = None,
                 parent: Optional[QObject] = None):
        
        super().__init__(parent)
        self.p_wavelength_min_nm = wavelength_min_nm
        self.p_wavelength_max_nm = wavelength_max_nm
        self.p_linename = linename
        self.p_energy_level_unit = energy_level_unit.lower().replace(" ", "")
        self.p_output_order = output_order
        self.p_query_reference = query_reference
        if not ASTROQUERY_AVAILABLE:
            raise ImportError("Astroquery/Astropy libraries are not installed.")

    # MODIFIED: A much more robust parsing function.
    def _parse_nist_table_to_elementallines(self, nist_table: Optional[Table]) -> List[ElementalLine]:
        lines: List[ElementalLine] = []
        if nist_table is None or len(nist_table) == 0:
            return lines
        
        # Helper function to get a value from a row, trying multiple column names.
        # It now correctly accepts a default value.
        def get_val(row: Row, potential_names: List[str], default: Any = None) -> Any:
            for name in potential_names:
                if name in row.colnames:
                    val = row[name]
                    # Handle Astropy's masked values (where data is missing)
                    if hasattr(val, 'mask') and val.mask:
                        continue
                    # Handle empty strings or numpy's string representation of None
                    if isinstance(val, (str, np.str_)) and not val.strip():
                        continue
                    return val
            return default

        for row_idx, row_data in enumerate(nist_table):
            if self.check_interruption(): break
            try:
                # Wavelength: Prioritize Ritz (calculated), fallback to Observed
                wl_ritz = get_val(row_data, ['Ritz Wavelength', 'Ritz', 'ritz_wl_vac(A)'])
                wl_obs = get_val(row_data, ['Observed Wavelength', 'Observed', 'obs_wl_vac(A)', 'obs_wl_air(A)'])
                wl_A_val = wl_ritz if wl_ritz is not None else wl_obs
                
                if wl_A_val is None: continue # Skip row if no wavelength found
                wavelength_nm = robust_float_conversion(wl_A_val)
                if wavelength_nm is None: continue
                # NIST provides data in Angstroms, convert to nm
                if wavelength_nm > 10000: # Heuristic: if it's a large number, it's likely still in Angstroms
                    wavelength_nm /= 10.0

                element_symbol = str(get_val(row_data, ['Element Symbol', 'Element'], "Unk")).strip()
                spectrum_full = str(get_val(row_data, ['Spectrum', 'Ion'], "Unk ?")).strip()
                ion_stage_str = spectrum_full.split()[-1]

                aki_raw = get_val(row_data, ['Aki', 'A_ki(10^8 s^-1)'])
                aki = robust_float_conversion(aki_raw)
                # Some versions of astroquery return Aki in units of 10^8 s^-1
                if aki is not None and isinstance(aki_raw, str) and '10^8' in aki_raw:
                    aki *= 1e8
                
                ek_val = robust_float_conversion(get_val(row_data, [f'E_k({self.p_energy_level_unit})', 'Ek']))
                gk_val = robust_int_conversion(get_val(row_data, ['g_k', 'gk']))
                rel_int_str = str(get_val(row_data, ['Rel. Int.', 'intens'], '')).strip()

                lines.append(ElementalLine(
                    wavelength_nm=wavelength_nm, element=element_symbol, ion_stage=ion_stage_str,
                    Aki=aki, Ek_ev=ek_val if self.p_energy_level_unit == 'ev' else None, gk=gk_val,
                    intensity_db_str=rel_int_str, source_db="NIST_Online_ASD"
                ))
            except Exception as e:
                # Log the error but continue processing other rows
                logger.warning(f"Could not parse row {row_idx} from NIST. Error: {e}")
        return lines

    def _perform_task(self) -> Dict[str, Any]:
        wl_min_unit = self.p_wavelength_min_nm * u.nm
        wl_max_unit = self.p_wavelength_max_nm * u.nm
        
        query_kwargs = {
            "linename": self.p_linename,
            "energy_level_unit": self.p_energy_level_unit,
            "output_order": self.p_output_order,
        }
        final_query_kwargs = {k: v for k, v in query_kwargs.items() if v is not None}

        try:
            if self.check_interruption(): return {"lines_found": [], "message": "Cancelled."}
            
            self.progress.emit(25, 100, "Sending query to NIST...")
            QApplication.processEvents()

            nist_result_table = Nist.query(wl_min_unit, wl_max_unit, **final_query_kwargs)

        except Exception as e:
            if "did not contain a table" in str(e).lower():
                logger.info("NIST query returned a non-table result (no lines found).")
                nist_result_table = None 
            else:
                err_msg = f"Error during Nist.query call. Error: {e}"
                logger.error(err_msg, exc_info=True)
                raise RuntimeError(err_msg) from e

        if self.check_interruption(): return {"lines_found": [], "message": "Cancelled."}

        self.progress.emit(75, 100, "Parsing results...")
        QApplication.processEvents()
        
        if nist_result_table is None or len(nist_result_table) == 0:
            message = "Search Operation was Successful but No lines found matching criteria 😔 , try broadening your search or removing element filter."
            found_lines = []
        else:
            found_lines = self._parse_nist_table_to_elementallines(nist_result_table)
            message = f"Found {len(found_lines)} lines."
        
        self.progress.emit(100, 100, "Complete.")
        return {
            "lines_found": found_lines, 
            "message": message, 
            "query_reference": self.p_query_reference
        }
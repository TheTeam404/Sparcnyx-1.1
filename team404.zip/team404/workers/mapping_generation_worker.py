# team404/workers/mapping_generation_worker.py

"""
MappingGenerationWorker for SpectraMapper Pro.
A worker dedicated to generating a single 2D elemental map using a MappingProcessor.
This is kept separate from MappingProcessor itself because the generation of *one map*
can be a long task if it involves fitting peaks for every spectrum in the map dataset.
"""

import logging
from typing import Dict, Any, Optional
from PyQt5.QtWidgets import (QMessageBox)
from PyQt5.QtCore import pyqtSignal, Qt
import numpy as np

from .base_worker import BaseWorker
from ..core.mapping_processor import MappingProcessor # The class that does the actual map generation logic
from ..core.data_models import ElementalMapData # The expected result type

logger = logging.getLogger(__name__)

class MappingGenerationWorker(BaseWorker):
    """
    Worker to generate a single 2D elemental map using a MappingProcessor instance.
    The MappingProcessor should already be initialized with its spectra and batch-preprocessed.
    """

    def __init__(self,
                 mapping_processor: MappingProcessor,
                 element_label: str,
                 target_wavelength: float,
                 quantification_method: str,
                 quant_params: Optional[Dict[str, Any]] = None,
                 *args, **kwargs):
        """
        Args:
            mapping_processor: An initialized MappingProcessor instance.
            element_label: User-friendly label for the map (e.g., "Ca II 393.366nm").
            target_wavelength: The wavelength (nm) of the line to map.
            quantification_method: Method to extract intensity ("peak_height", "peak_area", "voigt_fit").
            quant_params: Additional parameters for the quantification method.
        """
        super().__init__(*args, **kwargs)
        self.mapping_processor = mapping_processor
        self.element_label = element_label
        self.target_wavelength = target_wavelength
        self.quantification_method = quantification_method
        self.quant_params = quant_params if quant_params else {}

    def _report_progress_adapter(self, current_step: int, total_steps: int):
        """Adapts the MappingProcessor's progress callback to the BaseWorker's progress signal."""
        # The MappingProcessor's generate_elemental_map progress is per spectrum.
        # The BaseWorker's progress signal takes an additional message string.
        # We can create a generic message or pass it through if the processor provided one.
        self.progress.emit(current_step, total_steps, f"Mapping point {current_step}/{total_steps}")

    def _perform_task(self) -> Optional[ElementalMapData]:
        """
        Calls the MappingProcessor to generate the elemental map.

        Returns:
            An ElementalMapData object if successful, otherwise None.
            The result is also emitted via `result_ready` or implicitly via `finished`.
        """
        if not self.mapping_processor:
            logger.error("MappingGenerationWorker: MappingProcessor instance is not provided.")
            # self.error.emit("ConfigurationError", "MappingProcessor not available.") # BaseWorker handles this
            raise ValueError("MappingProcessor not available for map generation.")

        logger.info(f"MappingGenerationWorker: Starting map generation for '{self.element_label}' "
                    f"at {self.target_wavelength:.2f} nm using method '{self.quantification_method}'.")

        # The generate_elemental_map method in MappingProcessor now takes a progress_callback.
        # We need to adapt it to our worker's progress signal.
        
        map_data: Optional[ElementalMapData] = self.mapping_processor.generate_elemental_map(
            element_label=self.element_label,
            target_wavelength=self.target_wavelength,
            quantification_method=self.quantification_method,
            quant_params=self.quant_params,
            progress_callback=self._report_progress_adapter # Pass the adapter
        )

        if self.check_interruption(): # Check if cancelled during map generation
            logger.info(f"MappingGenerationWorker: Map generation for '{self.element_label}' was interrupted.")
            return None # Or a specific "CancelledMapData" object / status

        if map_data:
            logger.info(f"MappingGenerationWorker: Successfully generated map '{self.element_label}'.")
            return map_data
        else:
            logger.warning(f"MappingGenerationWorker: Map generation for '{self.element_label}' returned no data.")
            # self.error.emit("GenerationError", f"Map generation for '{self.element_label}' failed.") # BaseWorker handles this
            raise RuntimeError(f"Map generation for '{self.element_label}' failed to produce data.")


if __name__ == '__main__':
    import sys
    import time
    from PyQt5.QtWidgets import QApplication, QPushButton, QVBoxLayout, QWidget, QTextEdit, QProgressDialog
    from PyQt5.QtCore import QThread
    
    # Need LIBSpectrum, ProcessingStep, ElementalMapData for testing
    from ..core.data_models import LIBSpectrum, ProcessingStep, ElementalMapData
    # Need MappingProcessor for testing
    from ..core.mapping_processor import MappingProcessor

    logging.basicConfig(level=logging.DEBUG)
    app = QApplication(sys.argv)

    class TestMapGenWindow(QWidget):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("MappingGenerationWorker Test")
            self.layout = QVBoxLayout(self)
            
            self.start_button = QPushButton("Start Map Generation")
            self.start_button.clicked.connect(self.start_map_task)
            self.layout.addWidget(self.start_button)

            self.cancel_button = QPushButton("Cancel Map Generation")
            self.cancel_button.clicked.connect(self.cancel_map_task)
            self.cancel_button.setEnabled(False)
            self.layout.addWidget(self.cancel_button)

            self.log_display = QTextEdit()
            self.log_display.setReadOnly(True)
            self.layout.addWidget(self.log_display)
            
            self.progress_dialog: Optional[QProgressDialog] = None

            self.worker_thread: Optional[QThread] = None
            self.map_worker: Optional[MappingGenerationWorker] = None

            # Prepare dummy MappingProcessor with data
            self.dummy_map_processor = self._create_dummy_map_processor()

        def _create_dummy_map_processor(self) -> Optional[MappingProcessor]:
            try:
                num_x, num_y = 10, 8 # Small map for quick test
                spectra = []
                base_wl = np.linspace(200, 800, 100)
                for yi in range(num_y):
                    for xi in range(num_x):
                        intensity = (xi + yi * 2 + 10) * np.exp(-((base_wl - (300 + xi))**2) / (2 * 2**2)) + \
                                    np.random.rand(len(base_wl)) * 5 + (5 + xi*0.1)
                        spec = LIBSpectrum(base_wl, intensity, filename=f"map_x{xi}_y{yi}.txt",
                                           x_coord=float(xi), y_coord=float(yi))
                        spectra.append(spec)
                
                # Dummy pipeline (MappingProcessor expects it, even if empty)
                pipeline = [ProcessingStep("mock_step", {})] # Or an actual step
                
                # MappingProcessor's __init__ now does batch preprocessing
                # For testing worker, assume processor is already initialized and preprocessed
                mp = MappingProcessor(spectra, (num_x, num_y), preprocessing_pipeline=pipeline)
                # The batch_preprocess_spectra is called in MappingProcessor's init.
                # For this test, it will use the _placeholder_apply_processing_pipeline
                # unless the real one from spectrum_handler is fully functional and imported.
                return mp
            except Exception as e:
                self.log_message(f"Error creating dummy MappingProcessor: {e}")
                return None


        def log_message(self, message: str):
            self.log_display.append(message)
            QApplication.processEvents()

        def start_map_task(self):
            if self.worker_thread and self.worker_thread.isRunning():
                self.log_message("Map generation worker is already running.")
                return
            
            if not self.dummy_map_processor:
                self.log_message("Dummy MappingProcessor failed to initialize. Cannot start task.")
                QMessageBox.critical(self, "Setup Error", "Failed to create dummy data for test.")
                return

            self.log_message("Starting map generation task...")
            self.start_button.setEnabled(False)
            self.cancel_button.setEnabled(True)

            self.progress_dialog = QProgressDialog(
                "Generating elemental map...", "Cancel", 0,
                len(self.dummy_map_processor.spectra_collection), self
            )
            self.progress_dialog.setWindowModality(Qt.WindowModal)
            self.progress_dialog.setAutoClose(True); self.progress_dialog.setAutoReset(True)
            self.progress_dialog.setMinimumDuration(0); self.progress_dialog.setValue(0)
            self.progress_dialog.canceled.connect(self.cancel_map_task)


            self.worker_thread = QThread()
            self.map_worker = MappingGenerationWorker(
                mapping_processor=self.dummy_map_processor,
                element_label="Test Peak at 300nm",
                target_wavelength=300.0,
                quantification_method="peak_height", # Simplest for test
                quant_params={}
            )
            self.map_worker.moveToThread(self.worker_thread)

            self.map_worker.started.connect(lambda: self.log_message("Map Worker: Started"))
            self.map_worker.finished.connect(self.on_map_finished)
            self.map_worker.progress.connect(self.on_map_progress) # Worker uses adapter
            self.map_worker.error.connect(
                lambda err_type, err_msg: self.log_message(f"Map Worker ERROR: Type: {err_type}, Msg: {err_msg}")
            )
            self.map_worker.result_ready.connect(self.on_map_result_ready)
            self.map_worker.cancelled.connect(lambda: self.log_message("Map Worker: Operation Cancelled"))

            self.worker_thread.finished.connect(self.map_worker.deleteLater)
            self.worker_thread.finished.connect(self.worker_thread.deleteLater)
            self.worker_thread.finished.connect(self._reset_after_thread_finish)

            self.worker_thread.started.connect(self.map_worker.run)
            self.worker_thread.start()

        def cancel_map_task(self):
            if self.map_worker and self.map_worker.is_running():
                self.log_message("Requesting map worker interruption...")
                self.map_worker.request_interruption()
                if self.progress_dialog: self.progress_dialog.cancel()
            else:
                self.log_message("No active map worker to cancel.")
            self.cancel_button.setEnabled(False)

        def on_map_progress(self, current: int, total: int, msg: str):
            self.log_message(f"Progress: {current}/{total} - {msg}")
            if self.progress_dialog:
                if self.progress_dialog.wasCanceled():
                    if self.map_worker and self.map_worker.is_running():
                        self.map_worker.request_interruption()
                    return
                self.progress_dialog.setMaximum(total) # Ensure max is correct
                self.progress_dialog.setValue(current)
                self.progress_dialog.setLabelText(msg if msg else f"Processing point {current}/{total}...")

        def on_map_result_ready(self, map_data_obj: ElementalMapData):
            self.log_message(f"Map Worker: Result Ready - Map '{map_data_obj.element_label}' "
                             f"({map_data_obj.intensity_matrix.shape[1]}x{map_data_obj.intensity_matrix.shape[0]} points)")
            # In a real app, you'd display this map_data_obj

        def on_map_finished(self, success: bool, result_or_message: Any):
            self.log_message(f"Map Worker: Finished. Success: {success}.")
            if isinstance(result_or_message, ElementalMapData):
                 self.log_message(f"  Final map data label: '{result_or_message.element_label}'")
            elif isinstance(result_or_message, str): # Error message or cancel message
                 self.log_message(f"  Message: '{result_or_message}'")

            if self.progress_dialog:
                self.progress_dialog.setValue(self.progress_dialog.maximum())

        def _reset_after_thread_finish(self):
            self.start_button.setEnabled(True)
            self.cancel_button.setEnabled(False)
            self.log_message("Map worker thread has finished.")
            self.worker_thread = None
            self.map_worker = None
            if self.progress_dialog:
                self.progress_dialog.deleteLater()
                self.progress_dialog = None

        def closeEvent(self, event):
            self.cancel_map_task()
            if self.worker_thread and self.worker_thread.isRunning():
                self.worker_thread.quit(); self.worker_thread.wait(1000)
            super().closeEvent(event)

    window = TestMapGenWindow()
    window.resize(500, 400)
    window.show()
    app.exec_()
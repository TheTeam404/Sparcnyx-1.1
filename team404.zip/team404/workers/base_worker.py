# team404/workers/base_worker.py

"""
BaseWorker class for performing tasks in a separate thread using QThread.
Provides a standard set of signals for communication with the main GUI thread.
"""

import logging
import traceback # For detailed error logging
from typing import Any, Optional

from PyQt5.QtCore import QObject, pyqtSignal, QThread # QThread for type hinting only

logger = logging.getLogger(__name__)

class BaseWorker(QObject):
    """
    A base QObject class for performing tasks in a separate thread.
    Subclasses must implement _perform_task().

    Signals:
        started: Emitted when the worker's run() method begins execution.
        finished: Emitted on completion or cancellation.
                  Payload: success (bool), result_data_or_error_message (Any)
        progress: Emitted for progress updates during the task.
                  Payload: current_step (int), total_steps (int), message (str)
                  If total_steps is 0, progress is indeterminate.
        error: Emitted for critical, unexpected errors during task execution.
               Payload: error_type_name (str), error_message (str)
        cancelled: Emitted if the operation was gracefully cancelled by request.
        result_ready: Emitted specifically with the successful result data from _perform_task.
                      Payload: result_data (Any) - This is often the same as the second argument
                               of 'finished' signal when success is True.
    """
    started = pyqtSignal()
    finished = pyqtSignal(bool, object)
    progress = pyqtSignal(int, int, str)
    error = pyqtSignal(str, str)
    cancelled = pyqtSignal()
    result_ready = pyqtSignal(object)

    def __init__(self, parent: Optional[QObject] = None, *args, **kwargs):
        """
        Args:
            parent: Parent QObject, typically None if moved to a thread.
            *args, **kwargs: Arguments to be passed to the _perform_task method.
        """
        super().__init__(parent)
        self._is_running: bool = False
        self._is_interruption_requested: bool = False
        self._args = args
        self._kwargs = kwargs
        logger.debug(f"BaseWorker {self.__class__.__name__} initialized.")

    def run(self):
        """
        Main execution method. This is typically connected to QThread.started().
        It calls the _perform_task() method implemented by subclasses.
        """
        if self._is_running:
            logger.warning(f"Worker {self.__class__.__name__} is already running. Ignoring run request.")
            return

        self._is_running = True
        self._is_interruption_requested = False # Reset interruption flag at start of new run
        self.started.emit()
        logger.info(f"Worker {self.__class__.__name__} started.")

        try:
            # Perform the actual task implemented by the subclass
            result = self._perform_task(*self._args, **self._kwargs)

            if self.check_interruption(): # Check if interruption was requested during the task
                self.cancelled.emit()
                self.finished.emit(False, "Operation cancelled by user.")
                logger.info(f"Worker {self.__class__.__name__} operation cancelled by request during task execution.")
            else:
                self.result_ready.emit(result) # Emit the specific result payload
                self.finished.emit(True, result) # Indicate successful completion with the result
                logger.info(f"Worker {self.__class__.__name__} finished successfully.")

        except ImportError as ie: # Handle specific import errors (e.g. missing optional libraries)
            error_msg = f"A required library is missing: {ie}"
            logger.error(f"Worker {self.__class__.__name__}: {error_msg}", exc_info=False) # No need for full stack for simple import error
            self.error.emit(type(ie).__name__, error_msg)
            self.finished.emit(False, error_msg)
        except RuntimeError as re: # Often raised by C extensions or specific libraries on critical failure
            if "cancelled" in str(re).lower() or self.check_interruption(): # Check if RuntimeError is due to cancellation
                self.cancelled.emit()
                self.finished.emit(False, "Operation cancelled by user (RuntimeError).")
                logger.info(f"Worker {self.__class__.__name__} operation cancelled by request (RuntimeError).")
            else:
                error_msg = f"Runtime error during task: {re}"
                logger.error(f"Worker {self.__class__.__name__}: {error_msg}", exc_info=True)
                detailed_tb = traceback.format_exc()
                self.error.emit(type(re).__name__, f"{error_msg}\n\nTraceback:\n{detailed_tb}")
                self.finished.emit(False, error_msg)
        except Exception as e:
            error_msg = f"An unexpected error occurred: {e}"
            logger.error(f"Worker {self.__class__.__name__} encountered an unhandled error in _perform_task: {e}", exc_info=True)
            detailed_tb = traceback.format_exc()
            self.error.emit(type(e).__name__, f"{error_msg}\n\nTraceback:\n{detailed_tb}")
            self.finished.emit(False, error_msg) # Indicate failure and pass the error message
        finally:
            self._is_running = False
            logger.debug(f"Worker {self.__class__.__name__} run method concluded.")

    def _perform_task(self, *args, **kwargs) -> Any:
        """
        Abstract method to be implemented by subclasses.
        This method contains the core logic of the worker's task.
        It should periodically call self.check_interruption() to allow for
        graceful cancellation.

        Returns:
            The result of the task. This result will be emitted via the
            `result_ready` signal and the `finished` signal (if successful).
        
        Raises:
            NotImplementedError: If not overridden by a subclass.
            Any Exception: If an error occurs during task execution.
        """
        raise NotImplementedError("Subclasses of BaseWorker must implement the _perform_task method.")

    def request_interruption(self):
        """
        Sets a flag to request the worker to interrupt its current task.
        The _perform_task method should check this flag periodically.
        """
        if self._is_running:
            logger.debug(f"Worker {self.__class__.__name__}: Interruption requested.")
            self._is_interruption_requested = True
        else:
            logger.debug(f"Worker {self.__class__.__name__}: Interruption requested, but worker is not running.")


    def check_interruption(self) -> bool:
        """
        Called by _perform_task periodically to see if an interruption was requested.
        If interruption is requested, the method should clean up and return.
        """
        # QApplication.processEvents() # Optional: process events to keep GUI responsive during check
        if self._is_interruption_requested:
            logger.info(f"Worker {self.__class__.__name__}: Task interruption acknowledged by check_interruption().")
        return self._is_interruption_requested

    def is_running(self) -> bool:
        """Returns True if the worker's run() method is currently executing."""
        return self._is_running

    def is_interruption_requested(self) -> bool:
        """Returns True if an interruption has been requested."""
        return self._is_interruption_requested
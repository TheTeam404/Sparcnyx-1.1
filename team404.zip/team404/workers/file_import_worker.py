# team404/workers/file_import_worker.py

"""
FileImportWorker for SpectraMapper Pro.
A worker designed to import multiple spectral files in the background,
parsing each file and creating LIBSpectrum objects.
"""

import logging
import os
from typing import List, Dict, Any, Optional, Tuple
from PyQt5.QtCore import pyqtSignal, Qt

import numpy as np

from .base_worker import BaseWorker
from ..core.data_models import LIBSpectrum
from ..core.file_io import load_spectrum_from_file # The actual file parsing function

logger = logging.getLogger(__name__)

class FileImportWorker(BaseWorker):
    """
    Worker to import a list of spectral files in the background.
    Emits LIBSpectrum objects as they are successfully imported, or a final list.
    """
    # Signal to emit each successfully imported LIBSpectrum object individually
    spectrum_imported = pyqtSignal(LIBSpectrum, int, int) # spectrum_obj, current_index, total_files
    # Or, if you prefer to emit all at once:
    # all_spectra_imported = pyqtSignal(list) # List[LIBSpectrum]

    def __init__(self,
                 filepaths_to_import: List[str],
                 import_parameters: Dict[str, Any], # Params for load_spectrum_from_file
                 parse_coords_from_filename_pattern: Optional[str] = None, # Regex
                 *args, **kwargs):
        """
        Args:
            filepaths_to_import: List of absolute filepaths to import.
            import_parameters: Dictionary of parameters to pass to `load_spectrum_from_file`
                               (e.g., delimiter, skip_header, wl_col_idx, int_col_idx).
            parse_coords_from_filename_pattern: Optional regex pattern to extract X,Y coordinates
                                                from filenames. Example: r"x(\d+)_y(\d+)"
        """
        super().__init__(*args, **kwargs)
        self.filepaths = filepaths_to_import
        self.import_params = import_parameters
        self.coord_pattern_str = parse_coords_from_filename_pattern
        self.coord_regex = None
        if self.coord_pattern_str:
            try:
                import re
                self.coord_regex = re.compile(self.coord_pattern_str)
            except re.error as e:
                logger.error(f"Invalid regex pattern for coordinate parsing: '{self.coord_pattern_str}'. Error: {e}")
                self.coord_regex = None # Disable parsing if pattern is bad

    def _parse_coordinates_from_filename(self, filename: str) -> Tuple[Optional[float], Optional[float]]:
        """Attempts to parse X, Y coordinates from a filename using the compiled regex."""
        if not self.coord_regex:
            return None, None

        match = self.coord_regex.search(filename)
        if match and len(match.groups()) >= 2: # Expect at least two capturing groups
            try:
                x_coord_str = match.group(1)
                y_coord_str = match.group(2)
                # Allow for float coordinates by trying to convert robustly
                from ..utils.helpers import robust_float_conversion # Import here to avoid top-level issues
                x_coord = robust_float_conversion(x_coord_str)
                y_coord = robust_float_conversion(y_coord_str)
                if x_coord is not None and y_coord is not None:
                    return x_coord, y_coord
                else:
                    logger.warning(f"Could not convert parsed coordinates '{x_coord_str}', '{y_coord_str}' to float for {filename}.")
            except IndexError:
                logger.warning(f"Regex pattern '{self.coord_pattern_str}' did not yield enough groups for coordinates in {filename}.")
            except Exception as e:
                logger.error(f"Error parsing coordinates from {filename} with pattern '{self.coord_pattern_str}': {e}")
        return None, None


    def _perform_task(self) -> Dict[str, Any]:
        """
        Imports each file and creates LIBSpectrum objects.

        Returns:
            A dictionary with results: {"imported_count": int, "error_count": int, "message": str, "imported_spectra": List[LIBSpectrum]}
        """
        if not self.filepaths:
            logger.info("FileImportWorker: No filepaths to import.")
            return {"imported_count": 0, "error_count": 0, "message": "No files provided.", "imported_spectra": []}

        total_files = len(self.filepaths)
        imported_count = 0
        error_count = 0
        successfully_imported_spectra: List[LIBSpectrum] = []
        
        logger.info(f"FileImportWorker: Starting to import {total_files} files.")

        for i, filepath in enumerate(self.filepaths):
            if self.check_interruption():
                logger.info("FileImportWorker: Interruption requested during file import.")
                return {"imported_count": imported_count, "error_count": error_count,
                        "message": "Import cancelled.", "imported_spectra": successfully_imported_spectra}

            filename = os.path.basename(filepath)
            self.progress.emit(i + 1, total_files, f"Importing: {filename}")
            
            try:
                loaded_data = load_spectrum_from_file(filepath, **self.import_params)
                if loaded_data:
                    wl, inten, meta = loaded_data
                    
                    x_coord, y_coord = None, None
                    if self.coord_regex:
                        x_coord, y_coord = self._parse_coordinates_from_filename(filename)
                        if x_coord is not None: meta['parsed_x_coord'] = x_coord
                        if y_coord is not None: meta['parsed_y_coord'] = y_coord

                    spectrum_obj = LIBSpectrum(
                        wavelengths=wl,
                        intensities=inten,
                        filename=filename,
                        metadata=meta,
                        x_coord=x_coord,
                        y_coord=y_coord
                    )
                    successfully_imported_spectra.append(spectrum_obj)
                    self.spectrum_imported.emit(spectrum_obj, imported_count + 1, total_files) # Emit individual spectrum
                    imported_count += 1
                    logger.debug(f"Successfully imported spectrum from: {filepath}")
                else:
                    error_count += 1
                    logger.warning(f"Failed to load spectrum data from {filepath} (load_spectrum_from_file returned None).")
                    self.error.emit(filename, "Failed to parse spectral data.")
            except Exception as e:
                error_count += 1
                logger.error(f"Error importing spectrum from {filepath}: {e}", exc_info=True)
                self.error.emit(filename, str(e))

        msg = f"File import finished. Imported: {imported_count}, Errors: {error_count}."
        logger.info(msg)
        # self.all_spectra_imported.emit(successfully_imported_spectra) # Alternative signal
        return {"imported_count": imported_count, "error_count": error_count,
                "message": msg, "imported_spectra": successfully_imported_spectra}


if __name__ == '__main__':
    import sys
    import time
    from PyQt5.QtWidgets import QApplication, QPushButton, QVBoxLayout, QWidget, QTextEdit, QProgressDialog
    from PyQt5.QtCore import QThread
    
    # Need LIBSpectrum for testing
    from ..core.data_models import LIBSpectrum
    # For testing, we can use the real load_spectrum_from_file if file_io.py is available
    # or mock it if it has complex dependencies not suitable for this isolated test.
    # Let's assume file_io.load_spectrum_from_file is available and relatively simple.

    logging.basicConfig(level=logging.DEBUG)
    app = QApplication(sys.argv)

    class TestFileImportWindow(QWidget):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("FileImportWorker Test")
            self.layout = QVBoxLayout(self)
            
            self.start_button = QPushButton("Start File Import")
            self.start_button.clicked.connect(self.start_import_task)
            self.layout.addWidget(self.start_button)

            self.cancel_button = QPushButton("Cancel Import")
            self.cancel_button.clicked.connect(self.cancel_import_task)
            self.cancel_button.setEnabled(False)
            self.layout.addWidget(self.cancel_button)

            self.log_display = QTextEdit()
            self.log_display.setReadOnly(True)
            self.layout.addWidget(self.log_display)
            
            self.progress_dialog: Optional[QProgressDialog] = None

            self.worker_thread: Optional[QThread] = None
            self.import_worker: Optional[FileImportWorker] = None

            # Prepare dummy files for testing
            self.test_file_dir = "test_import_files_temp"
            os.makedirs(self.test_file_dir, exist_ok=True)
            self.dummy_filepaths = []
            for i in range(5): # Create 5 dummy files
                fn = f"test_spec_x{i*10}_y{i*5+3}.txt"
                fp = os.path.join(self.test_file_dir, fn)
                with open(fp, 'w') as f:
                    f.write(f"# Dummy spectrum {i+1} with coords in name\n")
                    f.write("Wavelength\tIntensity\n")
                    for j in range(10):
                        f.write(f"{200+j*10:.1f}\t{np.random.randint(50,150):.1f}\n")
                self.dummy_filepaths.append(fp)
            # Add a deliberately malformed file
            fp_bad = os.path.join(self.test_file_dir, "bad_format.txt")
            with open(fp_bad, 'w') as f:
                f.write("This is not a spectrum\nJust text\n")
            self.dummy_filepaths.append(fp_bad)


        def log_message(self, message: str):
            self.log_display.append(message)
            QApplication.processEvents()

        def start_import_task(self):
            if self.worker_thread and self.worker_thread.isRunning():
                self.log_message("Import worker is already running.")
                return

            self.log_message(f"Starting import for {len(self.dummy_filepaths)} files...")
            self.start_button.setEnabled(False)
            self.cancel_button.setEnabled(True)

            self.progress_dialog = QProgressDialog(
                "Importing files...", "Cancel", 0, len(self.dummy_filepaths), self
            )
            self.progress_dialog.setWindowModality(Qt.WindowModal)
            self.progress_dialog.setAutoClose(True); self.progress_dialog.setAutoReset(True)
            self.progress_dialog.setMinimumDuration(0); self.progress_dialog.setValue(0)
            self.progress_dialog.canceled.connect(self.cancel_import_task)


            self.worker_thread = QThread()
            import_params = {"delimiter": "\t", "skip_header": 2, "wl_col_idx":0, "int_col_idx":1}
            coord_pattern = r"x(\d+)_y(\d+)" # Example pattern
            self.import_worker = FileImportWorker(
                filepaths_to_import=self.dummy_filepaths,
                import_parameters=import_params,
                parse_coords_from_filename_pattern=coord_pattern
            )
            self.import_worker.moveToThread(self.worker_thread)

            self.import_worker.started.connect(lambda: self.log_message("Import Worker: Started"))
            self.import_worker.finished.connect(self.on_import_finished)
            self.import_worker.progress.connect(self.on_import_progress)
            self.import_worker.error.connect(
                lambda item_id, err_msg: self.log_message(f"Import Worker ERROR: File '{item_id}', Msg: '{err_msg}'")
            )
            self.import_worker.spectrum_imported.connect(self.on_single_spectrum_imported)
            self.import_worker.cancelled.connect(lambda: self.log_message("Import Worker: Operation Cancelled by worker logic"))

            self.worker_thread.finished.connect(self.import_worker.deleteLater)
            self.worker_thread.finished.connect(self.worker_thread.deleteLater)
            self.worker_thread.finished.connect(self._reset_after_thread_finish)

            self.worker_thread.started.connect(self.import_worker.run)
            self.worker_thread.start()

        def cancel_import_task(self):
            if self.import_worker and self.import_worker.is_running():
                self.log_message("Requesting import worker interruption...")
                self.import_worker.request_interruption()
                if self.progress_dialog: self.progress_dialog.cancel()
            else:
                self.log_message("No active import worker to cancel.")
            self.cancel_button.setEnabled(False)


        def on_import_progress(self, current: int, total: int, msg: str):
            self.log_message(f"Progress: {current}/{total} - {msg}")
            if self.progress_dialog:
                if self.progress_dialog.wasCanceled():
                    if self.import_worker and self.import_worker.is_running():
                        self.import_worker.request_interruption()
                    return
                self.progress_dialog.setValue(current)
                self.progress_dialog.setLabelText(msg if msg else f"Importing {current}/{total}...")

        def on_single_spectrum_imported(self, spec_obj: LIBSpectrum, current_idx: int, total_files: int):
            self.log_message(f"  Imported {current_idx}/{total_files}: {spec_obj.filename} "
                             f"(Points: {len(spec_obj.raw_wavelengths)}, "
                             f"Coords: X={spec_obj.x_coord}, Y={spec_obj.y_coord})")
            # In a real app, you'd add spec_obj to your ProjectManager here.

        def on_import_finished(self, success: bool, result_dict: Dict):
            self.log_message(f"Import Worker: Finished. Success: {success}. Result: {result_dict}")
            if self.progress_dialog:
                self.progress_dialog.setValue(self.progress_dialog.maximum())
            
            # result_dict["imported_spectra"] contains the list of LIBSpectrum objects
            # In a real app, you'd pass this list to ProjectManager or update the UI.
            # For this test, we already logged individual imports via spectrum_imported signal.


        def _reset_after_thread_finish(self):
            self.start_button.setEnabled(True)
            self.cancel_button.setEnabled(False)
            self.log_message("Import worker thread has finished.")
            self.worker_thread = None
            self.import_worker = None
            if self.progress_dialog:
                self.progress_dialog.deleteLater()
                self.progress_dialog = None

        def closeEvent(self, event):
            self.cancel_import_task()
            if self.worker_thread and self.worker_thread.isRunning():
                self.worker_thread.quit(); self.worker_thread.wait(1000)
            # Clean up dummy files
            try:
                import shutil
                shutil.rmtree(self.test_file_dir)
                self.log_message(f"Cleaned up test directory: {self.test_file_dir}")
            except Exception as e:
                self.log_message(f"Error cleaning up test directory: {e}")
            super().closeEvent(event)

    window = TestFileImportWindow()
    window.resize(500, 400)
    window.show()
    app.exec_() # Changed from sys.exit(app.exec_()) to just app.exec_() for cleanup to run
    
# team404/workers/batch_processing_worker.py

"""
BatchProcessingWorker for SpectraMapper Pro.
A worker designed to apply a preprocessing pipeline to a batch of spectra.
"""

import logging
from typing import List, Any, Optional, Dict

import numpy as np

from .base_worker import BaseWorker
# Assuming these are in the correct relative path for the project
# For standalone __main__ testing, these paths might need adjustment or mocking
try:
    from ..core.data_models import LIBSpectrum, ProcessingStep
    from ..core.spectrum_handler import apply_processing_pipeline
except ImportError:
    # Fallback for standalone testing or if structure is different
    # This allows the file to be imported even if dependencies are not perfectly met initially,
    # but runtime errors will occur if the classes are actually used without proper setup.
    if __name__ != '__main__': # Only raise if not running as main (main has its own mocks)
        logging.getLogger(__name__).warning(
            "Could not import core_data_models or spectrum_handler. BatchProcessingWorker might not function."
        )
    # Define dummy classes if needed for basic parsing of this file
    class LIBSpectrum: pass
    class ProcessingStep: pass
    def apply_processing_pipeline(*args, **kwargs): raise NotImplementedError("Real apply_processing_pipeline not loaded")


logger = logging.getLogger(__name__)

class BatchProcessingWorker(BaseWorker):
    """
    Worker to apply a preprocessing pipeline to a list of LIBSpectrum objects.
    The LIBSpectrum objects in the input list are modified in-place.
    """

    def __init__(self,
                 spectra_to_process: List[LIBSpectrum],
                 pipeline_to_apply: List[ProcessingStep],
                 msc_ref_spectrum_data: Optional[tuple] = None,
                 msc_dataset_for_ref: Optional[np.ndarray] = None,
                 *args, **kwargs):
        """
        Args:
            spectra_to_process: List of LIBSpectrum objects to process.
                                These objects will be modified.
            pipeline_to_apply: List of ProcessingStep objects defining the pipeline.
            msc_ref_spectrum_data: Optional reference spectrum data (wavelengths, intensities) for MSC.
            msc_dataset_for_ref: Optional dataset (2D numpy array of intensities) for calculating MSC reference.
        """
        super().__init__(*args, **kwargs)
        self.spectra = spectra_to_process
        self.pipeline = pipeline_to_apply # Consider deepcopy if ProcessingSteps are mutable and reused
        self.msc_ref_spectrum_data = msc_ref_spectrum_data
        self.msc_dataset_for_ref = msc_dataset_for_ref
        logger.debug(
            f"BatchProcessingWorker initialized with {len(spectra_to_process)} spectra "
            f"and {len(pipeline_to_apply)} pipeline steps."
        )

    def _perform_task(self) -> Dict[str, Any]:
        """
        Applies the preprocessing pipeline to each spectrum in the batch.
        Modifies the LIBSpectrum objects in self.spectra directly.

        Returns:
            A dictionary with results: {"processed_count": int, "error_count": int, "message": str}
        """
        if not self.spectra:
            logger.info("BatchProcessingWorker: No spectra to process.")
            return {"processed_count": 0, "error_count": 0, "message": "No spectra provided."}
        
        total_spectra = len(self.spectra)
        if not self.pipeline:
            logger.info("BatchProcessingWorker: No pipeline to apply. Spectra remain unchanged.")
            for i in range(total_spectra):
                if self.check_interruption(): # Still check for interruption even if no work
                     logger.info("BatchProcessingWorker: Interruption requested (no pipeline).")
                     return {"processed_count": i, "error_count": 0, "message": "Processing skipped (no pipeline) and cancelled."}
                self.progress.emit(i + 1, total_spectra, f"Spectrum {i+1}/{total_spectra} (skipped - no pipeline)")
            return {"processed_count": total_spectra, "error_count": 0, "message": "No pipeline applied; all spectra skipped."}

        processed_count = 0
        error_count = 0
        
        logger.info(f"BatchProcessingWorker: Starting to process {total_spectra} spectra.")

        for i, spectrum_obj in enumerate(self.spectra):
            if self.check_interruption():
                logger.info(f"BatchProcessingWorker: Interruption requested after processing {i} spectra.")
                return {
                    "processed_count": processed_count,
                    "error_count": error_count,
                    "message": f"Processing cancelled by user after {i} spectra."
                }

            # Try to get a meaningful short ID for the spectrum
            spectrum_id_display = "Unknown Spectrum"
            if hasattr(spectrum_obj, 'filename') and spectrum_obj.filename:
                spectrum_id_display = spectrum_obj.filename
            elif hasattr(spectrum_obj, 'spectrum_id') and spectrum_obj.spectrum_id:
                spectrum_id_display = spectrum_obj.spectrum_id[:15] + ('...' if len(spectrum_obj.spectrum_id) > 15 else '')
            
            self.progress.emit(i + 1, total_spectra, f"Processing: {spectrum_id_display}")
            
            try:
                # apply_processing_pipeline is expected to modify spectrum_obj in-place
                # and set its .processing_pipeline attribute.
                # It should return True on success, False on manageable failure for that spectrum.
                success = apply_processing_pipeline(
                    spectrum_obj,
                    self.pipeline,
                    msc_ref_spectrum_data=self.msc_ref_spectrum_data,
                    msc_dataset_for_ref=self.msc_dataset_for_ref
                )
                if success:
                    processed_count += 1
                    logger.debug(f"Successfully processed spectrum: {spectrum_id_display}")
                else:
                    error_count += 1
                    # This warning assumes apply_processing_pipeline logs its own specific reasons for returning False.
                    logger.warning(f"Pipeline application reported non-critical issues for spectrum: {spectrum_id_display}")
            except Exception as e:
                error_count += 1
                logger.error(f"Unhandled error processing spectrum {spectrum_id_display}: {e}", exc_info=True)
                self.error.emit(f"Spectrum: {spectrum_id_display}", str(e)) # Emit specific error signal

        msg = (f"Batch processing finished. "
               f"Successfully processed: {processed_count}/{total_spectra}. "
               f"Errors encountered: {error_count}.")
        logger.info(msg)
        return {"processed_count": processed_count, "error_count": error_count, "message": msg}


if __name__ == '__main__':
    import sys
    import time
    from PyQt5.QtWidgets import QApplication, QPushButton, QVBoxLayout, QWidget, QTextEdit, QProgressDialog
    from PyQt5.QtCore import QThread, Qt # Added Qt

    # --- Mocking for standalone test ---
    # This section allows the __main__ to run without the full project structure.
    class MockLIBSpectrum:
        def __init__(self, wavelengths, intensities, filename=None, spectrum_id=None):
            self.raw_wavelengths = np.array(wavelengths)
            self.raw_intensities = np.array(intensities)
            self.processed_wavelengths = np.array(wavelengths)
            self.processed_intensities = np.array(intensities)
            self.filename = filename or "N/A"
            self.spectrum_id = spectrum_id or f"mock_id_{time.time_ns()}"
            self.processing_pipeline: List[MockProcessingStep] = []
            self.metadata = {}

        def set_processed_data(self, intensities, wavelengths=None):
            self.processed_intensities = np.array(intensities)
            if wavelengths is not None:
                self.processed_wavelengths = np.array(wavelengths)
        
        @property
        def wavelengths(self): return self.processed_wavelengths
        @property
        def intensities(self): return self.processed_intensities


    class MockProcessingStep:
        def __init__(self, name: str, parameters: Optional[Dict[str, Any]] = None):
            self.name = name
            self.parameters = parameters or {}
            self.enabled = True
    
    # Replace actual classes with mocks for the test
    LIBSpectrum = MockLIBSpectrum # type: ignore
    ProcessingStep = MockProcessingStep # type: ignore

    _original_apply_pipeline = None # To store the original if it exists

    def mock_apply_processing_pipeline_func(spectrum: MockLIBSpectrum, pipeline: List[MockProcessingStep], **kwargs) -> bool:
        logger.debug(f"Mock applying {len(pipeline)} steps to {spectrum.spectrum_id if spectrum else 'N/A'}")
        if not spectrum: return False
        time.sleep(0.05) # Simulate work
        # Simulate a modification; in reality, this would be complex
        spectrum.set_processed_data(spectrum.raw_intensities * np.random.uniform(0.7, 0.9))
        spectrum.processing_pipeline = pipeline
        # Simulate occasional "managed" failure by the pipeline function
        if np.random.rand() < 0.05: # 5% chance of a non-critical processing issue
            logger.warning(f"Mock pipeline: Non-critical issue for spectrum {spectrum.filename}")
            return False # Indicates a problem, but not an unhandled exception
        return True

    # Attempt to monkey patch the apply_processing_pipeline used by the worker
    # This is tricky because the worker imports it at the module level.
    # For a robust test, it's better if apply_processing_pipeline can be injected or
    # if the worker module is imported *after* the patch.
    # For this simple test, we'll re-assign it globally here, hoping it gets picked up.
    apply_processing_pipeline = mock_apply_processing_pipeline_func # type: ignore

    # --- End Mocking ---

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    logger.info("Starting BatchProcessingWorker test application...")


    class TestBatchWindow(QWidget):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("BatchProcessingWorker Test")
            self.layout = QVBoxLayout(self)
            
            self.start_button = QPushButton("Start Batch Processing (20 spectra)")
            self.start_button.clicked.connect(self.start_batch_task)
            self.layout.addWidget(self.start_button)

            self.start_empty_button = QPushButton("Start with Empty Spectra List")
            self.start_empty_button.clicked.connect(lambda: self.start_batch_task(empty_spectra=True))
            self.layout.addWidget(self.start_empty_button)

            self.start_no_pipeline_button = QPushButton("Start with No Pipeline")
            self.start_no_pipeline_button.clicked.connect(lambda: self.start_batch_task(no_pipeline=True))
            self.layout.addWidget(self.start_no_pipeline_button)

            self.cancel_button = QPushButton("Cancel Batch")
            self.cancel_button.clicked.connect(self.cancel_batch_task)
            self.cancel_button.setEnabled(False)
            self.layout.addWidget(self.cancel_button)

            self.log_display = QTextEdit()
            self.log_display.setReadOnly(True)
            self.layout.addWidget(self.log_display)
            
            self.progress_dialog: Optional[QProgressDialog] = None
            self.worker_thread: Optional[QThread] = None
            self.batch_worker: Optional[BatchProcessingWorker] = None

        def log_message(self, message: str):
            self.log_display.append(f"{time.strftime('%H:%M:%S')} - {message}")
            QApplication.processEvents()

        def start_batch_task(self, empty_spectra=False, no_pipeline=False):
            if self.worker_thread and self.worker_thread.isRunning():
                self.log_message("Batch worker is already running.")
                return

            self.log_message("Preparing batch processing task...")
            self.set_buttons_for_task_running(True)

            # Prepare dummy data
            dummy_spectra_list: List[LIBSpectrum] = []
            if not empty_spectra:
                for i in range(20): # Create 20 dummy spectra
                    wl = np.linspace(200, 800, np.random.randint(100, 200))
                    inte = np.random.rand(len(wl)) * 100 + np.sin(wl / (50 + i*2)) * 20 + 50
                    dummy_spectra_list.append(LIBSpectrum(wl, inte, filename=f"spec_{i+1}.txt")) # type: ignore
            
            dummy_pipeline_list: List[ProcessingStep] = []
            if not no_pipeline:
                 dummy_pipeline_list = [
                    ProcessingStep(name="baseline_als_mock", parameters={"lam": 1e4, "p": 0.01}), # type: ignore
                    ProcessingStep(name="smooth_savgol_mock", parameters={"window": 5, "order": 2}) # type: ignore
                ]

            # --- Setup Progress Dialog ---
            num_items_for_dialog = len(dummy_spectra_list) if dummy_spectra_list else 1 # Avoid 0 max for dialog
            self.progress_dialog = QProgressDialog(
                "Batch preprocessing spectra...", "Cancel Operation", 0, num_items_for_dialog, self
            )
            self.progress_dialog.setWindowModality(Qt.WindowModal)
            self.progress_dialog.setAutoClose(True)
            self.progress_dialog.setAutoReset(True)
            self.progress_dialog.setMinimumDuration(0) 
            self.progress_dialog.setValue(0)
            self.progress_dialog.canceled.connect(self.cancel_batch_task)


            self.worker_thread = QThread()
            # Ensure the worker uses the mocked apply_processing_pipeline by it being in the global scope
            # when the worker module is effectively "imported" or its class instantiated.
            self.batch_worker = BatchProcessingWorker(
                spectra_to_process=dummy_spectra_list,
                pipeline_to_apply=dummy_pipeline_list
            )
            self.batch_worker.moveToThread(self.worker_thread)

            self.batch_worker.started.connect(lambda: self.log_message("Worker Event: Started"))
            self.batch_worker.finished.connect(self.on_batch_finished)
            self.batch_worker.progress.connect(self.on_batch_progress)
            self.batch_worker.error.connect(
                lambda item_id, err_msg: self.log_message(f"Worker Event ERROR: Item '{item_id}', Msg: '{err_msg}'")
            )
            self.batch_worker.cancelled.connect(lambda: self.log_message("Worker Event: Operation Cancelled (internally)"))

            # Thread lifecycle connections
            self.worker_thread.started.connect(self.batch_worker.run)
            self.worker_thread.finished.connect(self.batch_worker.deleteLater)
            self.worker_thread.finished.connect(self.worker_thread.deleteLater)
            self.worker_thread.finished.connect(self._reset_after_thread_finish)
            
            self.worker_thread.start()
            self.log_message(f"Worker thread started for {len(dummy_spectra_list)} spectra, {len(dummy_pipeline_list)} steps.")


        def cancel_batch_task(self):
            if self.batch_worker and self.batch_worker.is_running():
                self.log_message("User requested worker interruption...")
                self.batch_worker.request_interruption()
                # Dialog cancellation is handled by its own 'canceled' signal if user clicks dialog's cancel.
                # If this method is called programmatically, we might need to also update the dialog:
                if self.progress_dialog and not self.progress_dialog.wasCanceled():
                     self.progress_dialog.setLabelText("Cancellation requested...")
                     # self.progress_dialog.cancel() # Could also call this
            else:
                self.log_message("No active batch worker to cancel or already cancelling.")
            self.cancel_button.setEnabled(False)


        def on_batch_progress(self, current_val: int, total_val: int, msg: str):
            self.log_message(f"Progress: {current_val}/{total_val} - {msg}")
            if self.progress_dialog:
                if self.progress_dialog.wasCanceled(): # Important: Check if user cancelled via dialog
                    if self.batch_worker and self.batch_worker.is_running():
                        self.log_message("Progress dialog was cancelled by user, requesting worker stop.")
                        self.batch_worker.request_interruption()
                    return # Stop updating dialog if it was cancelled
                self.progress_dialog.setMaximum(total_val) # Ensure max is correct
                self.progress_dialog.setValue(current_val)
                self.progress_dialog.setLabelText(msg if msg else f"Processing {current_val}/{total_val}...")

        def on_batch_finished(self, success_flag: bool, result: Dict):
            self.log_message(f"Worker Event: Finished. Success: {success_flag}. Result: {result}")
            if self.progress_dialog:
                self.progress_dialog.setValue(self.progress_dialog.maximum()) # Ensure it completes/closes
            # Buttons and thread state reset in _reset_after_thread_finish

        def set_buttons_for_task_running(self, is_running: bool):
            self.start_button.setEnabled(not is_running)
            self.start_empty_button.setEnabled(not is_running)
            self.start_no_pipeline_button.setEnabled(not is_running)
            self.cancel_button.setEnabled(is_running)

        def _reset_after_thread_finish(self):
            self.log_message("Worker thread has finished. Resetting UI components.")
            self.set_buttons_for_task_running(False)
            self.worker_thread = None # Allow GC
            self.batch_worker = None  # Allow GC
            if self.progress_dialog:
                # It might auto-close, but ensure it's cleaned up if not
                self.progress_dialog.deleteLater() 
                self.progress_dialog = None


        def closeEvent(self, event):
            self.log_message("Close event received. Cleaning up...")
            self.cancel_batch_task() 
            if self.worker_thread and self.worker_thread.isRunning():
                self.log_message("Waiting for worker thread to finish...")
                self.worker_thread.quit() # Request cooperative exit
                if not self.worker_thread.wait(2000): # Wait up to 2 seconds
                    self.log_message("Worker thread did not quit gracefully, terminating.")
                    self.worker_thread.terminate() # Force terminate if stuck
                    self.worker_thread.wait() # Wait for termination
            super().closeEvent(event)

    app_instance = QApplication.instance() 
    if app_instance is None:
        app_instance = QApplication(sys.argv)

    window = TestBatchWindow()
    window.resize(600, 500)
    window.show()
    
    exit_code = app_instance.exec_()
    
    # Restore original if it was patched (though not strictly necessary for this test's structure)
    # if _original_apply_pipeline:
    #    apply_processing_pipeline = _original_apply_pipeline
    #    logger.info("Restored original apply_processing_pipeline function (if it was patched).")
        
    sys.exit(exit_code)
# team404/workers/model_training_worker.py

"""
ModelTrainingWorker for SpectraMapper Pro.
A worker designed for training chemometric models (PLS-R, Classifiers)
in the background, as this can be computationally intensive.
"""

import logging
from typing import Dict, Any, Optional, Union, List
import numpy as np
import pandas as pd # For handling target variables/labels if loaded from CSV

from .base_worker import BaseWorker
# Import the actual model training functions from chemometrics_tools
from ..core.chemometrics_tools import (
    perform_pls_regression,
    train_classifier_model
    # _preprocess_spectra_for_chemometrics # This should be done before starting the worker
)
from ..core.data_models import LIBSpectrum # For potential type hinting if passing spectra list directly

logger = logging.getLogger(__name__)

class ModelTrainingWorker(BaseWorker):
    """
    Worker to train a chemometric model (PLS-R or a classifier).
    Assumes spectral data (X_matrix) is already preprocessed for chemometrics.
    """

    MODEL_TYPE_PLS_R = "pls_r"
    MODEL_TYPE_CLASSIFICATION = "classification"

    def __init__(self,
                 model_type: str, # "pls_r" or "classification"
                 X_matrix: np.ndarray,
                 y_data: np.ndarray, # Target variable for PLS-R or class labels for classification
                 model_specific_params: Optional[Dict[str, Any]] = None,
                 # For classification, might need classifier_type like 'lda', 'svm', 'knn'
                 classifier_type: Optional[str] = None, # Only if model_type is "classification"
                 scale_data: bool = True, # General scaling option for X
                 # PLS-R specific
                 pls_n_components: Optional[int] = None,
                 pls_cross_validate: bool = False,
                 pls_cv_folds: int = 5,
                 # Classification specific
                 class_test_size: float = 0.25,
                 class_random_state: Optional[int] = None,
                 *args, **kwargs):
        """
        Args:
            model_type: Type of model to train ("pls_r" or "classification").
            X_matrix: Preprocessed spectral data (samples x features).
            y_data: Target variable (for PLS-R) or class labels (for classification).
            model_specific_params: Dictionary of parameters specific to the chosen model
                                   (e.g., for SVM: {"C": 1.0, "kernel": "rbf"}).
            classifier_type: If model_type is "classification", specifies the classifier
                             (e.g., "lda", "svm", "knn").
            scale_data: Whether to scale X_matrix (and y for PLS-R if its function handles it).
            pls_n_components: Number of components for PLS-R.
            pls_cross_validate: Whether to perform cross-validation for PLS-R.
            pls_cv_folds: Number of folds for PLS-R CV.
            class_test_size: Test set size for classification.
            class_random_state: Random state for classification train/test split.
        """
        super().__init__(*args, **kwargs)
        self.model_type = model_type.lower()
        self.X_matrix = X_matrix
        self.y_data = y_data # Should be 1D for PLS-R y, 1D for classification labels
        self.model_specific_params = model_specific_params if model_specific_params else {}
        self.classifier_type = classifier_type.lower() if classifier_type else None
        
        self.scale_data = scale_data
        self.pls_n_components = pls_n_components
        self.pls_cross_validate = pls_cross_validate
        self.pls_cv_folds = pls_cv_folds
        self.class_test_size = class_test_size
        self.class_random_state = class_random_state

        if self.model_type == self.MODEL_TYPE_CLASSIFICATION and not self.classifier_type:
            raise ValueError("classifier_type must be specified when model_type is 'classification'.")
        if self.model_type == self.MODEL_TYPE_PLS_R and self.pls_n_components is None:
            raise ValueError("pls_n_components must be specified for PLS-R.")


    def _perform_task(self) -> Dict[str, Any]:
        """
        Trains the specified chemometric model.

        Returns:
            A dictionary containing the trained model and relevant metrics/results.
            The structure of this dictionary depends on the model_type.
        """
        if self.X_matrix is None or self.y_data is None:
            raise ValueError("X_matrix (spectral data) and y_data (targets/labels) must be provided.")
        if self.X_matrix.shape[0] != len(self.y_data):
            raise ValueError(f"Number of samples in X_matrix ({self.X_matrix.shape[0]}) "
                             f"must match length of y_data ({len(self.y_data)}).")

        logger.info(f"ModelTrainingWorker: Starting training for model type '{self.model_type}'.")
        # Emit progress for start (0% of 1 step, or multiple steps if CV is involved)
        self.progress.emit(0, 1, f"Initializing {self.model_type.upper()} model training...")

        results_dict: Dict[str, Any] = {"model_type": self.model_type}

        if self.check_interruption(): return {"message": "Training cancelled before start."}

        if self.model_type == self.MODEL_TYPE_PLS_R:
            pls_results = perform_pls_regression(
                X_matrix=self.X_matrix,
                y_vector=self.y_data,
                n_components=self.pls_n_components,
                scale_data=self.scale_data, # chemometrics_tools handles internal scaling
                cross_validate=self.pls_cross_validate,
                cv_folds=self.pls_cv_folds
            )
            if "error" in pls_results:
                raise RuntimeError(f"PLS-R training failed: {pls_results['error']}")
            results_dict.update(pls_results)
            # 'model' key in pls_results contains the trained PLSRegression object

        elif self.model_type == self.MODEL_TYPE_CLASSIFICATION:
            if not self.classifier_type: # Should have been caught in __init__
                 raise ValueError("Classifier type not specified for classification model.")
            
            class_results = train_classifier_model(
                X_matrix=self.X_matrix,
                y_labels=self.y_data,
                model_type=self.classifier_type,
                scale_data=self.scale_data, # chemometrics_tools handles internal scaling
                test_size=self.class_test_size,
                random_state=self.class_random_state,
                **self.model_specific_params # Pass C, kernel, n_neighbors etc.
            )
            if "error" in class_results:
                raise RuntimeError(f"Classification training ({self.classifier_type}) failed: {class_results['error']}")
            results_dict.update(class_results)
            # 'model' key in class_results contains the trained classifier object
        else:
            raise ValueError(f"Unsupported model_type: {self.model_type}")

        if self.check_interruption(): return {"message": "Training cancelled after completion."} # Unlikely but possible
        
        # Emit progress for end (100% of 1 step)
        self.progress.emit(1, 1, f"{self.model_type.upper()} model training complete.")
        logger.info(f"ModelTrainingWorker: Training for '{self.model_type}' completed.")
        return results_dict


if __name__ == '__main__':
    import sys
    import time
    from PyQt5.QtWidgets import QApplication, QPushButton, QVBoxLayout, QWidget, QTextEdit, QProgressDialog
    from PyQt5.QtCore import QThread
    
    logging.basicConfig(level=logging.DEBUG)
    app = QApplication(sys.argv)

    class TestModelTrainingWindow(QWidget):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("ModelTrainingWorker Test")
            self.layout = QVBoxLayout(self)
            
            self.start_pls_button = QPushButton("Start PLS-R Training")
            self.start_pls_button.clicked.connect(lambda: self.start_training_task(ModelTrainingWorker.MODEL_TYPE_PLS_R))
            self.layout.addWidget(self.start_pls_button)

            self.start_class_button = QPushButton("Start Classification (LDA) Training")
            self.start_class_button.clicked.connect(lambda: self.start_training_task(ModelTrainingWorker.MODEL_TYPE_CLASSIFICATION, classifier_type='lda'))
            self.layout.addWidget(self.start_class_button)

            self.cancel_button = QPushButton("Cancel Training")
            self.cancel_button.clicked.connect(self.cancel_training_task)
            self.cancel_button.setEnabled(False)
            self.layout.addWidget(self.cancel_button)

            self.log_display = QTextEdit()
            self.log_display.setReadOnly(True)
            self.layout.addWidget(self.log_display)
            
            self.worker_thread: Optional[QThread] = None
            self.model_worker: Optional[ModelTrainingWorker] = None

            # Prepare dummy data (already preprocessed for chemometrics)
            self.X_dummy = np.random.rand(50, 100) # 50 samples, 100 features
            self.y_pls_dummy = self.X_dummy[:, 0] * 2 + self.X_dummy[:, 1] * -1.5 + np.random.rand(50) * 0.5 # Target for PLS
            self.y_class_dummy = np.array(['A'] * 25 + ['B'] * 25) # Labels for classification
            np.random.shuffle(self.y_class_dummy)


        def log_message(self, message: str):
            self.log_display.append(message)
            QApplication.processEvents()

        def start_training_task(self, model_type: str, classifier_type: Optional[str] = None):
            if self.worker_thread and self.worker_thread.isRunning():
                self.log_message("A model training worker is already running.")
                return

            self.log_message(f"Starting {model_type.upper()} training task...")
            self.start_pls_button.setEnabled(False)
            self.start_class_button.setEnabled(False)
            self.cancel_button.setEnabled(True)

            y_data_current = self.y_pls_dummy if model_type == ModelTrainingWorker.MODEL_TYPE_PLS_R else self.y_class_dummy

            self.worker_thread = QThread()
            self.model_worker = ModelTrainingWorker(
                model_type=model_type,
                X_matrix=self.X_dummy,
                y_data=y_data_current,
                # Example specific params (can be passed from UI in real app)
                model_specific_params= {"C": 0.5} if classifier_type == 'svm' else {},
                classifier_type=classifier_type,
                pls_n_components=3 if model_type == ModelTrainingWorker.MODEL_TYPE_PLS_R else None
            )
            self.model_worker.moveToThread(self.worker_thread)

            self.model_worker.started.connect(lambda: self.log_message("Model Worker: Started"))
            self.model_worker.finished.connect(self.on_training_finished)
            self.model_worker.progress.connect(
                lambda curr, total, msg: self.log_message(f"Progress: {curr}/{total} - {msg}")
            )
            self.model_worker.error.connect(
                lambda err_type, err_msg: self.log_message(f"Model Worker ERROR: Type: {err_type}, Msg: {err_msg}")
            )
            self.model_worker.result_ready.connect(self.on_training_result_ready) # Result is the dict from _perform_task
            self.model_worker.cancelled.connect(lambda: self.log_message("Model Worker: Operation Cancelled"))


            self.worker_thread.finished.connect(self.model_worker.deleteLater)
            self.worker_thread.finished.connect(self.worker_thread.deleteLater)
            self.worker_thread.finished.connect(self._reset_after_thread_finish)

            self.worker_thread.started.connect(self.model_worker.run)
            self.worker_thread.start()

        def cancel_training_task(self):
            if self.model_worker and self.model_worker.is_running():
                self.log_message("Requesting model worker interruption...")
                self.model_worker.request_interruption()
            else:
                self.log_message("No active model worker to cancel.")
            self.cancel_button.setEnabled(False)

        def on_training_result_ready(self, results_dict: Dict):
            self.log_message(f"Model Worker: Result Ready (details in 'Finished' signal). Model type: {results_dict.get('model_type')}")
            if results_dict.get('model_type') == ModelTrainingWorker.MODEL_TYPE_PLS_R:
                self.log_message(f"  PLS Train R²: {results_dict.get('r2_train', 'N/A'):.3f}")
            elif results_dict.get('model_type') == ModelTrainingWorker.MODEL_TYPE_CLASSIFICATION:
                self.log_message(f"  Classification Accuracy: {results_dict.get('accuracy', 'N/A'):.3f}")
            # The full result_dict is also passed to on_training_finished

        def on_training_finished(self, success: bool, result_or_message: Union[Dict, str]):
            self.log_message(f"Model Worker: Finished. Success: {success}.")
            if isinstance(result_or_message, dict):
                 self.log_message(f"  Final Result Dict Keys: {list(result_or_message.keys())}")
            elif isinstance(result_or_message, str):
                 self.log_message(f"  Message: '{result_or_message}'")
            # In a real app, you would store/use the trained model from result_or_message['model']

        def _reset_after_thread_finish(self):
            self.start_pls_button.setEnabled(True)
            self.start_class_button.setEnabled(True)
            self.cancel_button.setEnabled(False)
            self.log_message("Model worker thread has finished.")
            self.worker_thread = None
            self.model_worker = None

        def closeEvent(self, event):
            self.cancel_training_task()
            if self.worker_thread and self.worker_thread.isRunning():
                self.worker_thread.quit(); self.worker_thread.wait(1000)
            super().closeEvent(event)

    window = TestModelTrainingWindow()
    window.resize(500, 400)
    window.show()
    sys.exit(app.exec_())
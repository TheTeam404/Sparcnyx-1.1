# team404/__init__.py

"""
SpectraMapper Pro (Team404 LIBS Analysis) Application Package.

This is the main package for the SpectraMapper Pro application.
It brings together the core logic, GUI, utilities, and other components.
"""

import logging

# --- Application Version ---
# Central place for the application version.
# Can be updated by build scripts or manually.
__version__ = "0.1.0-alpha"
__author__ = "Team404 AI Developers & Contributors"
__app_name__ = "SpectraMapper Pro"
__org_name__ = "Team404"


# --- Basic Logging Setup (Optional Fallback) ---
# It's generally better to have explicit logging setup in main.py using logging_setup.py.
# However, having a minimal configuration here can be useful if modules are imported
# and used in contexts where main.py's setup hasn't run (e.g., standalone testing of a module).
# This will set up a basic console logger if no handlers are already configured for the root logger.
_root_logger = logging.getLogger()
if not _root_logger.hasHandlers():
    _handler = logging.StreamHandler()
    _formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)'
    )
    _handler.setFormatter(_formatter)
    _root_logger.addHandler(_handler)
    _root_logger.setLevel(logging.INFO) # Default to INFO if not configured elsewhere
    _root_logger.debug(f"{__app_name__} root logger configured with basic console handler.")

# --- Expose Key Components (Optional) ---
# You might choose to expose some top-level classes or functions here for easier import,
# but often it's cleaner to import directly from submodules.
# Example:
# from .gui.main_window import MainWindow
# from .core.project_manager import ProjectManager

# This message will be logged when the 'team404' package is first imported.
logger = logging.getLogger(__name__)
logger.info(f"Initializing {__app_name__} package, version {__version__}.")


# --- Global Application Context (Advanced, Optional) ---
# For very complex applications, you might have a global context object
# that holds references to key singletons like ProjectManager, DB connectors, etc.
# This needs careful management to avoid circular dependencies and tight coupling.
# Example (conceptual):
# class ApplicationContext:
#     def __init__(self):
#         self.project_manager = None
#         self.nist_db_connector = None
#         # ...
#
# APP_CONTEXT = ApplicationContext()
#
# def initialize_application_context():
#     from .core.project_manager import ProjectManager # Delayed import
#     from .database.nist_db_connector import NISTDBConnector
#     APP_CONTEXT.project_manager = ProjectManager()
#     # APP_CONTEXT.nist_db_connector = NISTDBConnector(...) # Needs config
#     logger.info("Application context initialized.")

# For now, we will pass dependencies via constructors (Dependency Injection),
# which is generally a more robust and testable approach than a global context.
# team404/main.py

"""
Main entry point for the SpectraMapper Pro application.
Initializes the application, sets up logging, creates the main window,
and starts the Qt event loop.
"""

import sys
import os
import logging
import traceback # Added for last resort error handling in __main__

# --- Ensure the team404 package is in the Python path ---
# This is usually only needed if running main.py directly from within the team404 directory
# without having installed the package or having the parent directory in PYTHONPATH.
# For a proper package structure, running `python -m team404.main` from the directory
# containing Team404_LIBS_Analysis usually handles this.
try:
    import team404 # Try importing the package itself
except ImportError:
    # If the above fails, it might mean team404 is not directly in sys.path
    # or this script is being run in a way that Python can't find the 'team404' package.
    # This attempts to add the parent directory of 'team404' to sys.path
    # if main.py is inside team404 and Team404_LIBS_Analysis is the project root.
    current_dir = os.path.dirname(os.path.abspath(__file__)) # team404/
    project_root = os.path.dirname(current_dir) # Team404_LIBS_Analysis/
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
        # Using print for this very early stage, as logger might not be set up.
        print(f"INFO: Added project root '{project_root}' to sys.path for development.")
    try:
        import team404 # Re-try import
    except ImportError as e:
        print(f"CRITICAL ERROR: Could not properly set up Python path to import the 'team404' package. "
              f"Ensure you are running from the project root or have the package installed.\nError: {e}",
              file=sys.stderr)
        sys.exit(1)


from PyQt5.QtWidgets import QApplication, QMessageBox
from PyQt5.QtCore import QCoreApplication, Qt

# Import application components
from team404 import app_config # Application configurations (contains LOG_TO_CONSOLE etc.)
from team404 import __version__, __app_name__ as PKG_APP_NAME, __org_name__ as PKG_ORG_NAME # From team404/__init__.py
from team404.utils.logging_setup import setup_global_logger, get_logger
# Import specific constants if needed, but QCoreApplication setup should use app_config or __init__ values
# from team404.utils.constants import ORG_NAME as CONST_ORG_NAME, APP_NAME as CONST_APP_NAME
from team404.core.project_manager import ProjectManager
from team404.gui.main_window import MainWindow


def main():
    """
    Main function to launch the SpectraMapper Pro application.
    """
    # --- Application Setup for Qt ---
    # Set application attributes for QSettings and other Qt features
    # Use values consistently, preferably from one source (e.g., app_config or __init__)
    QCoreApplication.setOrganizationName(app_config.ORGANIZATION_NAME)
    QCoreApplication.setOrganizationDomain(app_config.ORGANIZATION_DOMAIN)
    QCoreApplication.setApplicationName(app_config.APP_NAME)
    QCoreApplication.setApplicationVersion(__version__) # From team404/__init__.py

    # --- Logging Setup ---
    # This should be one of the first things initialized.
    try:
        setup_global_logger(
            log_level=app_config.DEFAULT_LOG_LEVEL,
            log_to_console=app_config.LOG_TO_CONSOLE,
            log_to_file=app_config.LOG_TO_FILE,
            max_file_size_mb=app_config.LOG_MAX_FILE_SIZE_MB,
            backup_count=app_config.LOG_BACKUP_COUNT
        )
    except Exception as e:
        print(f"CRITICAL ERROR: Failed to initialize logging system: {e}", file=sys.stderr)
        # Depending on severity, might exit or try to continue.
        # If console logging fallback in team404/__init__.py worked, some logs might still appear.

    main_logger = get_logger(__name__) # Logger for this main.py module
    main_logger.info(f"--- Starting {app_config.APP_NAME} v{__version__} ---")
    main_logger.info(f"Organization: {QCoreApplication.organizationName()}, Domain: {QCoreApplication.organizationDomain()}")
    main_logger.info(f"Application Name for Settings: {QCoreApplication.applicationName()}")
    main_logger.info(f"Application Version for Settings: {QCoreApplication.applicationVersion()}")
    main_logger.info(f"Python version: {sys.version.split()[0]}")
    try:
        from PyQt5.QtCore import PYQT_VERSION_STR, QT_VERSION_STR
        main_logger.info(f"PyQt version: {PYQT_VERSION_STR}, Qt Runtime version: {QT_VERSION_STR}")
    except ImportError:
        main_logger.warning("Could not retrieve PyQt/Qt version strings.")


    # --- High DPI Scaling (Optional, but recommended for modern displays) ---
    if hasattr(Qt, 'AA_EnableHighDpiScaling'):
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
        main_logger.debug("Qt.AA_EnableHighDpiScaling attribute set.")
    if hasattr(Qt, 'AA_UseHighDpiPixmaps'):
        QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
        main_logger.debug("Qt.AA_UseHighDpiPixmaps attribute set.")


    # --- Create QApplication Instance ---
    app = QApplication(sys.argv)


    # --- Initialize Core Components ---
    main_logger.info("Initializing core components...")
    try:
        project_manager = ProjectManager()
    except Exception as e:
        main_logger.critical(f"Failed to initialize core components: {e}", exc_info=True)
        QMessageBox.critical(None, "Initialization Error", f"Critical error initializing core components: {e}\nApplication will now exit.")
        sys.exit(1)


    # --- Create and Show Main Window ---
    main_logger.info("Creating main window...")
    try:
        main_window = MainWindow(project_manager=project_manager)
        main_window.show()
        main_logger.info("MainWindow shown. Starting Qt event loop.")
    except Exception as e:
        main_logger.critical(f"Failed to create or show MainWindow: {e}", exc_info=True)
        QMessageBox.critical(None, "Application Startup Error", f"Could not start the main application window: {e}\nApplication will now exit.")
        sys.exit(1)

    # --- Start Qt Event Loop ---
    exit_code = app.exec_()
    main_logger.info(f"Application event loop finished. Exit code: {exit_code}")


    # --- Application Shutdown ---
    logging.shutdown() # Flushes and closes all logging handlers
    sys.exit(exit_code)


if __name__ == "__main__":
    try:
        main()
    except SystemExit: # Allow sys.exit() to propagate for clean exits
        # logging.shutdown() might have already been called if exit is from main()
        # but call again just in case of direct sys.exit from elsewhere before main's finally.
        if logging.getLogger().hasHandlers(): logging.shutdown()
        raise
    except Exception as e:
        # Last resort error handling
        error_message = f"UNHANDLED CRITICAL ERROR AT SCRIPT LEVEL: {e}\n"
        error_message += "".join(traceback.format_exception(type(e), e, e.__traceback__))
        print(error_message, file=sys.stderr)
        
        # Try to log it if logger might exist and has handlers
        # (it might if basic setup in __init__.py worked but main setup failed)
        root_log = logging.getLogger()
        if root_log.hasHandlers():
            root_log.critical("Unhandled critical error at script level:", exc_info=True)
        
        # Attempt to show a GUI message box if QApplication was initialized
        if QApplication.instance() is not None:
            QMessageBox.critical(None, "Fatal Application Error",
                                 "An unrecoverable error occurred. Please check logs for details.\n\n" + str(e))
        sys.exit(1)
    finally:
        # Ensure logging is shut down in all exit paths if it was set up
        if logging.getLogger().hasHandlers():
            logging.shutdown()
# team404/plotting/__init__.py

"""
Plotting package for SpectraMapper Pro.

This package contains classes and utilities related to Matplotlib integration
with PyQt5 for displaying scientific plots.
"""

from .plot_canvas import PlotCanvas
# from .plot_styles import apply_default_plot_style, get_plot_colors # Example
# from .plot_functions import create_specific_plot # Example if you have generic plot creation routines

__all__ = [
    "PlotCanvas",
    # "apply_default_plot_style",
    # "get_plot_colors",
    # "create_specific_plot",
]
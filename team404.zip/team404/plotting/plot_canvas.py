# team404/plotting/plot_canvas.py

"""
PlotCanvas class for SpectraMapper Pro.
A QWidget that embeds a Matplotlib FigureCanvas for plotting.
This is a foundational class that can be used by more specialized plot widgets.
"""

import logging
from typing import Optional # Added Optional

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QSizePolicy, QLabel # Added QLabel
from PyQt5.QtCore import pyqtSignal, Qt # Added Qt

import matplotlib
matplotlib.use('Qt5Agg') # Ensure Qt5Agg backend is used
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.axes import Axes # For type hinting
from matplotlib.backend_bases import MouseEvent # For more specific type hinting

logger = logging.getLogger(__name__)

class PlotCanvas(QWidget):
    """
    A reusable QWidget that embeds a Matplotlib Figure and Canvas.
    It provides the Matplotlib Figure and a primary Axes object for plotting.
    More specialized plot widgets (like SpectrumPlotWidget) can inherit from this
    or contain an instance of it.
    """
    # Signal emitted when a click occurs within the plot axes
    # Emits (x_data_coord, y_data_coord, matplotlib_mouse_event: MouseEvent)
    canvas_clicked = pyqtSignal(float, float, object) # Using 'object' for event for wider compatibility in signals
    # region_selected = pyqtSignal(float, float, float, float) # xmin, ymin, xmax, ymax

    def __init__(self, parent: Optional[QWidget] = None,
                 width: float = 5, height: float = 4, dpi: int = 100,
                 enable_interactive_features: bool = True):
        """
        Initializes the PlotCanvas.

        Args:
            parent: Parent QWidget.
            width: Width of the figure in inches.
            height: Height of the figure in inches.
            dpi: Dots per inch for the figure.
            enable_interactive_features: If True, connects basic mouse events.
        """
        super().__init__(parent)

        self.figure: Optional[Figure] = None
        self.canvas: FigureCanvas | QWidget # Type hint for canvas (can be FigureCanvas or dummy QWidget)
        self.ax: Optional[Axes] = None # Primary axes

        try:
            self.figure = Figure(figsize=(width, height), dpi=dpi, constrained_layout=True) # Added constrained_layout
            self.canvas = FigureCanvas(self.figure)
        except Exception as e:
            logger.critical(f"Failed to initialize Matplotlib Figure or Canvas: {e}", exc_info=True)
            self.figure = None # Ensure figure is None
            self.ax = None     # Ensure ax is None
            self.canvas = QWidget(self) # Dummy widget as canvas
            layout = QVBoxLayout(self)
            error_label = QLabel(f"Matplotlib Initialization Error:\n{str(e)}\n\nPlotting will not be available.")
            error_label.setWordWrap(True)
            error_label.setAlignment(Qt.AlignCenter)
            error_label.setStyleSheet("QLabel { color: red; font-weight: bold; }")
            layout.addWidget(error_label)
            self.setLayout(layout)
            return # Stop further initialization

        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        # self.canvas.updateGeometry() # updateGeometry is usually called by layout management

        # Add a default subplot (axes)
        self.add_subplot(111) # Add default axes, sets self.ax

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.canvas)
        self.setLayout(layout)

        if enable_interactive_features:
            self._connect_default_events()

    def _connect_default_events(self):
        """Connects default Matplotlib events to Qt signals or handlers."""
        if isinstance(self.canvas, FigureCanvas): # Ensure canvas is the actual Matplotlib canvas
            self.canvas.mpl_connect('button_press_event', self._on_button_press)
            # Example for other events:
            # self.canvas.mpl_connect('motion_notify_event', self._on_mouse_motion)
            # self.canvas.mpl_connect('pick_event', self._on_pick)

    def _on_button_press(self, event: MouseEvent):
        """Handles mouse button press events on the canvas."""
        # Check if the click was inside any axes
        if event.inaxes:
            if event.xdata is not None and event.ydata is not None: # Valid data coordinates
                if event.inaxes == self.ax: # Click was inside the primary axes
                    logger.debug(
                        f"PlotCanvas clicked in primary ax at (data coords): "
                        f"X={event.xdata:.3f}, Y={event.ydata:.3f}, Button={event.button}"
                    )
                else: # Click was in some other axes on the figure
                    logger.debug(
                        f"PlotCanvas clicked in other axes '{event.inaxes.get_label() or 'N/A'}' "
                        f"at (data coords): X={event.xdata:.3f}, Y={event.ydata:.3f}, Button={event.button}"
                    )
                self.canvas_clicked.emit(event.xdata, event.ydata, event)
        else:
            logger.debug(f"PlotCanvas clicked outside any axes. Pixel: ({event.x}, {event.y})")


    def get_figure(self) -> Figure:
        """Returns the Matplotlib Figure object."""
        if self.figure is None:
            raise RuntimeError("Matplotlib Figure was not initialized due to an error.")
        return self.figure

    def get_canvas(self) -> FigureCanvas:
        """Returns the Matplotlib FigureCanvasQTAgg object."""
        if not isinstance(self.canvas, FigureCanvas):
             raise RuntimeError("Matplotlib Canvas was not initialized due to an error or is a dummy widget.")
        return self.canvas

    def get_axes(self, create_if_none: bool = True) -> Optional[Axes]:
        """
        Returns the primary Matplotlib Axes object.
        Creates a default subplot and assigns it to self.ax if one doesn't exist
        and create_if_none is True.
        """
        if self.ax is None and create_if_none:
            if self.figure:
                # If figure has axes, pick the first one, otherwise add a new one
                if self.figure.get_axes():
                    self.ax = self.figure.get_axes()[0]
                    logger.debug("Re-assigned self.ax to the first existing axes on figure.")
                else:
                    self.ax = self.figure.add_subplot(111)
                    logger.debug("Created and assigned new default subplot to self.ax.")
            else:
                # Figure itself failed to initialize or is None
                return None
        return self.ax

    def add_subplot(self, *args, **kwargs) -> Axes:
        """
        Adds a subplot to the figure. If `set_as_primary=True` (default),
        this new subplot becomes `self.ax`.
        Clears the figure before adding if `clear_figure=True`.
        If `clear_figure` is not specified, it defaults to True if no axes exist yet.

        Args:
            *args: Positional arguments for `figure.add_subplot()`.
            **kwargs: Keyword arguments for `figure.add_subplot()`.
                      `clear_figure` (bool): Clears entire figure before adding.
                      `set_as_primary` (bool): Sets this new subplot as `self.ax`. Default True.

        Returns:
            The created Axes object.
        """
        if self.figure is None:
             raise RuntimeError("Cannot add subplot, Matplotlib Figure not initialized.")

        clear_figure = kwargs.pop('clear_figure', not bool(self.figure.get_axes()))
        set_as_primary = kwargs.pop('set_as_primary', True)

        if clear_figure:
            self.figure.clear()
            self.ax = None # Previous self.ax is gone
            
        new_ax = self.figure.add_subplot(*args, **kwargs)
        if set_as_primary or self.ax is None: # Set as primary if requested or if no primary exists
            self.ax = new_ax
        return new_ax

    def draw(self):
        """Redraws the canvas. Alias for canvas.draw_idle()."""
        if isinstance(self.canvas, FigureCanvas):
            self.canvas.draw_idle()
        elif self.figure is not None: # Should not happen if canvas is not FigureCanvas
             logger.warning("draw() called, but canvas is not a FigureCanvas. Figure might exist.")


    def clear(self, clear_figure_if_no_primary_ax: bool = True):
        """
        Clears the primary axes `self.ax`.
        If `self.ax` is None and `clear_figure_if_no_primary_ax` is True,
        it clears the entire figure and re-adds a default primary axes.
        """
        if self.ax:
            self.ax.clear()
            self.draw()
        elif self.figure and clear_figure_if_no_primary_ax:
            logger.info("Primary axes (self.ax) is None. Clearing entire figure and re-adding default axes.")
            self.figure.clear()
            self.ax = self.figure.add_subplot(111) # Re-add default axes
            self.draw()
        elif self.figure:
            logger.info("Primary axes (self.ax) is None. Figure not cleared as per clear_figure_if_no_primary_ax=False.")
        # If self.figure is None, nothing happens, which is correct.


if __name__ == '__main__':
    import sys
    import numpy as np # Added numpy import
    from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QHBoxLayout # Added QHBoxLayout

    # Ensure an application instance exists
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)

    logging.basicConfig(level=logging.DEBUG)

    main_win = QMainWindow()
    main_win.setWindowTitle("PlotCanvas Test")
    main_win.setGeometry(200, 200, 800, 600)

    central_widget = QWidget()
    layout = QVBoxLayout(central_widget)
    main_win.setCentralWidget(central_widget)

    # Create PlotCanvas instance
    plot_canvas_widget = PlotCanvas(main_win, width=7, height=5, dpi=100)
    
    if plot_canvas_widget.figure is None: # Check if Matplotlib initialization failed
        # The PlotCanvas itself shows an error message. We just add it to the layout.
        layout.addWidget(plot_canvas_widget)
        logger.critical("PlotCanvas could not initialize Matplotlib. Test will be limited.")
    else:
        layout.addWidget(plot_canvas_widget)

        # Example: Get axes and plot something
        ax = plot_canvas_widget.get_axes() # Should get the default 111 subplot
        if ax:
            ax.set_title("Test Plot on PlotCanvas")
            ax.set_xlabel("X-axis")
            ax.set_ylabel("Y-axis")
            x_data = np.linspace(0, 10, 100)
            y_data_sin = np.sin(x_data)
            ax.plot(x_data, y_data_sin, label="sin(x)")
            ax.legend()
            ax.grid(True)
            plot_canvas_widget.draw()
        else:
            logger.error("Failed to get axes from PlotCanvas.")


        # Connect to the click signal
        def handle_canvas_click(x_coord, y_coord, mp_event: MouseEvent):
            button_name = {1: "Left", 2: "Middle", 3: "Right"}.get(mp_event.button, f"Button {mp_event.button}")
            print(f"PlotCanvas received click: X={x_coord:.2f}, Y={y_coord:.2f}, Button={button_name}, InAxes={mp_event.inaxes}")
            
            # Add a marker where clicked, only if click was in an axes with data coords
            # and if self.ax is the axes that was clicked (or any axes if self.ax is None but event.inaxes is not)
            if mp_event.inaxes: # mp_event.inaxes is the axes object clicked in
                mp_event.inaxes.plot(x_coord, y_coord, 'ro', markersize=5) # Plot on the actually clicked axes
                plot_canvas_widget.draw()

        plot_canvas_widget.canvas_clicked.connect(handle_canvas_click)

        # Button to test clearing and replotting
        button_layout = QHBoxLayout()
        clear_button = QPushButton("Clear Primary Axes")
        clear_button.clicked.connect(lambda: plot_canvas_widget.clear(clear_figure_if_no_primary_ax=False)) # Clear only self.ax
        button_layout.addWidget(clear_button)
        
        clear_figure_button = QPushButton("Clear Figure (Reset)")
        clear_figure_button.clicked.connect(lambda: plot_canvas_widget.clear(clear_figure_if_no_primary_ax=True)) # Clear whole figure if self.ax is None
        button_layout.addWidget(clear_figure_button)


        replot_button = QPushButton("Replot Cosine")
        def replot_data():
            current_ax = plot_canvas_widget.get_axes(create_if_none=True) # Get/create primary
            if current_ax:
                current_ax.clear()
                y_data_cos = np.cos(x_data) # Assumes x_data is still in scope
                current_ax.plot(x_data, y_data_cos, label="cos(x)", color='green')
                current_ax.set_title("Replot: Cosine Wave")
                current_ax.legend()
                current_ax.grid(True)
                plot_canvas_widget.draw()
        replot_button.clicked.connect(replot_data)
        button_layout.addWidget(replot_button)
        
        add_sec_ax_button = QPushButton("Add Second Axes")
        def add_secondary_axes():
            if plot_canvas_widget.figure:
                # Add a new subplot, don't clear the figure, don't set as primary by default
                # (or set as primary if that's the desired test)
                ax2 = plot_canvas_widget.add_subplot(212, set_as_primary=False) # Example: 2 rows, 1 col, 2nd plot
                x_data_tan = np.tan(x_data/3)
                ax2.plot(x_data, x_data_tan, label="tan(x/3)", color='purple')
                ax2.set_title("Secondary Axes: Tangent")
                ax2.set_ylim(-5, 5) # Tan can go to infinity
                ax2.legend()
                ax2.grid(True)
                
                # Adjust layout if using multiple subplots
                try:
                    plot_canvas_widget.figure.tight_layout()
                except Exception as e:
                    logger.warning(f"Could not apply tight_layout: {e}")
                plot_canvas_widget.draw()
        add_sec_ax_button.clicked.connect(add_secondary_axes)
        button_layout.addWidget(add_sec_ax_button)

        layout.addLayout(button_layout)

    main_win.show()
    sys.exit(app.exec_())
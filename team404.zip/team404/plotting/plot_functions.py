# team404/plotting/plot_functions.py

"""
Reusable Matplotlib plotting functions for SpectraMapper Pro.
These functions take Matplotlib Axes objects and data as input
and perform specific plotting operations.
"""

import logging
import numpy as np
import matplotlib.axes
import matplotlib.pyplot as plt # For colormaps or other utilities
from typing import List, Tuple, Optional, Any, Union

logger = logging.getLogger(__name__)

# --- Generic Spectrum Plotting ---

def plot_single_spectrum_on_axes(
    ax: matplotlib.axes.Axes,
    wavelengths: np.ndarray,
    intensities: np.ndarray,
    label: Optional[str] = None,
    color: Optional[str] = None,
    linestyle: str = '-',
    linewidth: float = 1.0,
    xlabel: str = "Wavelength (nm)",
    ylabel: str = "Intensity (a.u.)",
    title: Optional[str] = None,
    show_grid: bool = True,
    clear_axes: bool = True
) -> None:
    """
    Plots a single spectrum on the given Matplotlib Axes.

    Args:
        ax: The Matplotlib Axes object to plot on.
        wavelengths: NumPy array of wavelengths.
        intensities: NumPy array of intensities.
        label: Label for the legend.
        color: Color of the line.
        linestyle: Style of the line (e.g., '-', '--', ':').
        linewidth: Width of the line.
        xlabel: Label for the x-axis.
        ylabel: Label for the y-axis.
        title: Title for the plot.
        show_grid: Whether to display a grid.
        clear_axes: If True, clears the axes before plotting.
    """
    if clear_axes:
        ax.clear()

    ax.plot(wavelengths, intensities, label=label, color=color, linestyle=linestyle, linewidth=linewidth)
    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    if title:
        ax.set_title(title, fontsize=10)
    if show_grid:
        ax.grid(True, linestyle=':', alpha=0.7)
    ax.tick_params(axis='both', which='major', labelsize=8)
    
    # Add legend only if there are labeled items
    if label or any(line.get_label() and not line.get_label().startswith('_') for line in ax.get_lines()):
        ax.legend(fontsize=8)


def plot_multiple_spectra_on_axes(
    ax: matplotlib.axes.Axes,
    spectra_data: List[dict[str, Union[np.ndarray, str, None]]], # List of {"x": wl, "y": int, "label": name, "color": c}
    xlabel: str = "Wavelength (nm)",
    ylabel: str = "Intensity (a.u.)",
    title: Optional[str] = None,
    show_grid: bool = True,
    clear_axes: bool = True
) -> None:
    """
    Plots multiple spectra on the same Matplotlib Axes.

    Args:
        ax: The Matplotlib Axes object.
        spectra_data: A list of dictionaries. Each dictionary should contain:
                      "x": wavelength array
                      "y": intensity array
                      "label": (optional) series label
                      "color": (optional) line color
                      "linestyle": (optional) line style
        xlabel, ylabel, title, show_grid, clear_axes: Same as plot_single_spectrum_on_axes.
    """
    if clear_axes:
        ax.clear()

    for spec_info in spectra_data:
        wl = spec_info.get("x")
        inten = spec_info.get("y")
        if wl is None or inten is None:
            logger.warning("Skipping spectrum due to missing x or y data.")
            continue
        
        ax.plot(
            wl, inten,
            label=spec_info.get("label"),
            color=spec_info.get("color"),
            linestyle=spec_info.get("linestyle", '-'),
            linewidth=spec_info.get("linewidth", 1.0)
        )

    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    if title:
        ax.set_title(title, fontsize=10)
    if show_grid:
        ax.grid(True, linestyle=':', alpha=0.7)
    ax.tick_params(axis='both', which='major', labelsize=8)
    
    # Add legend if any series have labels
    if any(spec.get("label") for spec in spectra_data):
        ax.legend(fontsize=8)


# --- Map Plotting ---
def plot_2d_map_on_axes(
    ax: matplotlib.axes.Axes,
    intensity_matrix: np.ndarray,
    x_coords: Optional[np.ndarray] = None,
    y_coords: Optional[np.ndarray] = None,
    xlabel: str = "X Coordinate",
    ylabel: str = "Y Coordinate",
    title: Optional[str] = None,
    colormap: str = 'viridis',
    interpolation: str = 'nearest',
    add_colorbar: bool = True,
    colorbar_label: str = 'Intensity (a.u.)',
    clear_axes: bool = True
) -> matplotlib.image.AxesImage: # Returns the image artist
    """
    Plots a 2D elemental map on the given Matplotlib Axes using imshow.

    Args:
        ax: The Matplotlib Axes object.
        intensity_matrix: 2D NumPy array of intensity values.
        x_coords, y_coords: Optional 1D arrays for X and Y axis ticks/extent.
                            If None, pixel indices are used.
        colormap: Matplotlib colormap name.
        interpolation: Interpolation method for imshow.
        add_colorbar: If True, adds a colorbar.
        clear_axes: If True, clears axes before plotting.

    Returns:
        The Matplotlib AxesImage object created by imshow.
    """
    if clear_axes:
        ax.clear()

    if x_coords is None: x_coords = np.arange(intensity_matrix.shape[1])
    if y_coords is None: y_coords = np.arange(intensity_matrix.shape[0])

    # Determine extent for imshow [left, right, bottom, top]
    # This assumes coords are centers, so edges are halfway between points,
    # or for regular grids, min/max with slight adjustment for full pixel coverage.
    dx = (x_coords[-1] - x_coords[0]) / (len(x_coords) - 1) if len(x_coords) > 1 else 1
    dy = (y_coords[-1] - y_coords[0]) / (len(y_coords) - 1) if len(y_coords) > 1 else 1
    extent = [
        x_coords.min() - dx/2, x_coords.max() + dx/2,
        y_coords.min() - dy/2, y_coords.max() + dy/2
    ]

    im = ax.imshow(intensity_matrix, aspect='auto', cmap=colormap, interpolation=interpolation,
                   origin='lower', extent=extent)

    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    if title:
        ax.set_title(title, fontsize=10)
    ax.tick_params(axis='both', which='major', labelsize=8)

    if add_colorbar:
        # Check if a colorbar for this image already exists to avoid duplicates if not clearing figure
        # A bit hacky, better if figure is cleared or specific colorbar management is in place
        # For now, assume if add_colorbar is true, we want one, and clear_axes was likely true.
        cbar = ax.figure.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.ax.tick_params(labelsize=8)
        cbar.set_label(colorbar_label, fontsize=9)
    
    return im


# --- Scatter Plotting ---
def plot_scatter_on_axes(
    ax: matplotlib.axes.Axes,
    x_data: np.ndarray,
    y_data: np.ndarray,
    s: Union[float, np.ndarray] = 20, # Size of markers
    c: Any = None, # Color, sequence, or sequence of color specifications
    marker: str = 'o',
    alpha: float = 0.7,
    label: Optional[str] = None,
    xlabel: str = "X",
    ylabel: str = "Y",
    title: Optional[str] = None,
    show_grid: bool = True,
    clear_axes: bool = True
) -> matplotlib.collections.PathCollection: # Returns the scatter artist
    """
    Creates a scatter plot on the given Matplotlib Axes.
    """
    if clear_axes:
        ax.clear()

    scatter_artist = ax.scatter(x_data, y_data, s=s, c=c, marker=marker, alpha=alpha, label=label)
    
    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    if title:
        ax.set_title(title, fontsize=10)
    if show_grid:
        ax.grid(True, linestyle=':', alpha=0.7)
    ax.tick_params(axis='both', which='major', labelsize=8)
    if label or any(artist.get_label() and not artist.get_label().startswith('_') for artist in ax.collections):
        ax.legend(fontsize=8)
        
    return scatter_artist


# --- Specialized Plots ---
def plot_boltzmann_on_axes(
    ax: matplotlib.axes.Axes,
    x_ek: np.ndarray,
    y_ln_term: np.ndarray,
    slope: float,
    intercept: float,
    inlier_mask: Optional[np.ndarray] = None, # For RANSAC highlighting
    xlabel: str = "Upper Energy Level, E_k",
    ylabel: str = "ln(Iλ / Ag)",
    title: Optional[str] = None,
    clear_axes: bool = True
) -> None:
    """
    Plots Boltzmann data and the fitted line on the given Matplotlib Axes.
    """
    if clear_axes:
        ax.clear()

    # Plot all points first (or only inliers if mask is exclusive)
    if inlier_mask is not None:
        outlier_mask = ~inlier_mask
        ax.scatter(x_ek[outlier_mask], y_ln_term[outlier_mask], label="Outliers", color='gray', marker='x', alpha=0.6)
        ax.scatter(x_ek[inlier_mask], y_ln_term[inlier_mask], label="Inliers", color='blue', marker='o', alpha=0.7)
    else:
        ax.scatter(x_ek, y_ln_term, label="Data Points", color='blue', marker='o', alpha=0.7)
    
    # Plot the fitted line across the range of x_ek
    if len(x_ek) > 0 :
        fit_x_range = np.array([np.min(x_ek), np.max(x_ek)])
        fit_y_range = slope * fit_x_range + intercept
        ax.plot(fit_x_range, fit_y_range, 'r-', label=f"Linear Fit (Slope: {slope:.2e})")
    else: # No data points, can't plot fit line range
        ax.plot([],[], 'r-', label=f"Linear Fit (Slope: {slope:.2e})")


    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    if title:
        ax.set_title(title, fontsize=10)
    ax.grid(True, linestyle=':', alpha=0.7)
    ax.tick_params(axis='both', which='major', labelsize=8)
    ax.legend(fontsize=8)


def add_peak_annotations_to_axes(
    ax: matplotlib.axes.Axes,
    highlights: List[Tuple[float, str]], # List of (wavelength, label_text)
    spectrum_line_index: int = 0 # Index of the spectrum line on the axes to get y-coords from
):
    """Adds annotations (labels and arrows) for specified peaks on an existing spectrum plot."""
    if not ax.lines or spectrum_line_index >= len(ax.lines):
        logger.warning("No spectrum line found on axes to add peak annotations.")
        return

    line = ax.lines[spectrum_line_index]
    xdata, ydata = line.get_xdata(), line.get_ydata()
    max_y = np.max(ydata) if len(ydata) > 0 else 1.0 # For offsetting annotation

    for wl, label in highlights:
        try:
            idx = np.abs(xdata - wl).argmin() # Find closest x-point
            y_coord = ydata[idx]
            
            # Smart annotation placement could be added here to avoid overlap
            ax.annotate(label, xy=(xdata[idx], y_coord),
                        xytext=(xdata[idx], y_coord + 0.05 * max_y), # Offset text slightly above point
                        arrowprops=dict(facecolor='black', shrink=0.05, width=0.5, headwidth=4, headlength=6),
                        fontsize=7, color='purple', ha='center',
                        bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="purple", lw=0.5, alpha=0.7))
        except (IndexError, ValueError) as e:
            logger.warning(f"Could not annotate peak at {wl} nm: {e}")


if __name__ == '__main__':
    # This __main__ block is for testing the functions directly with Matplotlib
    # It won't show a PyQt window unless you embed these in a FigureCanvas.
    # The SpectrumPlotWidget's __main__ is better for visual Qt tests.

    logging.basicConfig(level=logging.DEBUG)

    fig_test, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 10))
    fig_test.suptitle("plot_functions.py Test Plots")

    # Test plot_single_spectrum_on_axes
    wl_s = np.linspace(200, 300, 500)
    int_s = 50 * np.exp(-((wl_s - 250)**2) / (2 * 2**2)) + np.random.rand(500) * 5 + 10
    plot_single_spectrum_on_axes(ax1, wl_s, int_s, label="Test Spectrum", title="Single Spectrum Test")

    # Test plot_multiple_spectra_on_axes on the same axes (clear_axes=False for the second one)
    int_s2 = 40 * np.exp(-((wl_s - 260)**2) / (2 * 3**2)) + np.random.rand(500) * 3 + 8
    spectra_list_data = [
        {"x": wl_s, "y": int_s, "label": "Spectrum A", "color": "blue"},
        {"x": wl_s, "y": int_s2, "label": "Spectrum B", "color": "red", "linestyle": "--"}
    ]
    # ax1_multi = fig_test.add_subplot(313) # New axes for multi test
    # plot_multiple_spectra_on_axes(ax1_multi, spectra_list_data, title="Multiple Spectra Test")
    # For now, let's just overlay on ax1 by calling single plot twice with clear_axes=False
    plot_single_spectrum_on_axes(ax1, wl_s, int_s2, label="Overlay Spectrum", color="green", clear_axes=False, title="Overlay Test")
    ax1.legend() # Explicitly call legend if adding multiple without full clear

    # Test plot_2d_map_on_axes
    map_matrix_test = np.random.rand(10, 15) * 100
    plot_2d_map_on_axes(ax2, map_matrix_test, title="2D Map Test")
    
    # Test annotations (would typically be on ax1)
    highlights_test = [(250.0, "Peak A"), (260.0, "Peak B (Overlay)")]
    add_peak_annotations_to_axes(ax1, highlights_test)


    fig_test.tight_layout(rect=[0, 0, 1, 0.96]) # Adjust for suptitle
    plt.show() # Shows a standard Matplotlib window

    print("plot_functions.py tests completed (manual inspection of Matplotlib window needed).")
# team404/plotting/plot_styles.py

"""
Plot Styles for SpectraMapper Pro.
Contains functions to apply consistent styling to Matplotlib plots,
define color palettes, and manage other visual aspects.
"""

import logging
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.style as mplstyle
from cycler import cycler # For custom color cycles
from typing import List, Dict, Any, Optional, Union

import numpy as np

logger = logging.getLogger(__name__)

# --- Define Custom Color Palettes ---
# These can be expanded or customized
SPECTRAMAPPER_COLORS = {
    "primary_blue": "#007ACC",   # A vibrant blue
    "secondary_orange": "#F07C28", # A complementary orange
    "accent_green": "#5CB85C",   # A clear green
    "error_red": "#D9534F",      # A distinct red for errors/outliers
    "neutral_gray": "#777777",   # A neutral gray for secondary info
    "highlight_purple": "#5C2C9D",# For highlighting specific features
    "background_light": "#F0F0F0",# Light background for plots
    "grid_light": "#D0D0D0",     # Light grid lines
}

# Example color cycle for multiple lines on a plot
DEFAULT_LINE_COLOR_CYCLE = cycler(color=[
    SPECTRAMAPPER_COLORS["primary_blue"],
    SPECTRAMAPPER_COLORS["secondary_orange"],
    SPECTRAMAPPER_COLORS["accent_green"],
    SPECTRAMAPPER_COLORS["highlight_purple"],
    "#17A2B8", # Teal
    "#FD7E14", # Orange (different shade)
    "#28A745", # Green (different shade)
    "#6F42C1", # Indigo
])

# --- Matplotlib Style Definitions ---

# A custom Matplotlib style dictionary
# See https://matplotlib.org/stable/gallery/style_sheets/style_sheets_reference.html
SPECTRAMAPPER_MPL_STYLE = {
    # Lines
    "lines.linewidth": 1.5,
    "lines.markersize": 5,
    "lines.antialiased": True,

    # Axes
    "axes.titlesize": 12, # Slightly larger for main titles
    "axes.labelsize": 10, # For x and y labels
    "axes.labelcolor": SPECTRAMAPPER_COLORS["neutral_gray"],
    "axes.edgecolor": SPECTRAMAPPER_COLORS["neutral_gray"],
    "axes.facecolor": "white", # Axes background
    "axes.grid": True,
    "axes.prop_cycle": DEFAULT_LINE_COLOR_CYCLE, # Custom color cycle

    # Ticks
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "xtick.color": SPECTRAMAPPER_COLORS["neutral_gray"],
    "ytick.color": SPECTRAMAPPER_COLORS["neutral_gray"],
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.major.size": 4,
    "ytick.major.size": 4,
    "xtick.minor.size": 2, # If minor ticks are enabled
    "ytick.minor.size": 2,

    # Grid
    "grid.color": SPECTRAMAPPER_COLORS["grid_light"],
    "grid.linestyle": ":",
    "grid.linewidth": 0.7,
    "grid.alpha": 0.8,

    # Legend
    "legend.fontsize": 9,
    "legend.frameon": False, # No frame around legend by default
    "legend.loc": "best",

    # Figure
    "figure.facecolor": SPECTRAMAPPER_COLORS["background_light"],
    "figure.edgecolor": SPECTRAMAPPER_COLORS["background_light"],
    "figure.dpi": 100,
    "figure.titleweight": "bold",

    # Font (can be overridden by system/Qt settings if not explicitly set everywhere)
    # "font.family": "sans-serif",
    # "font.sans-serif": ["Arial", "DejaVu Sans", "Liberation Sans", "Bitstream Vera Sans", "sans-serif"],

    # Saving figures
    "savefig.dpi": 150,
    "savefig.format": "png",
    "savefig.transparent": False,
    "savefig.bbox": "tight", # Good default for tight layout
}

# --- Functions to Apply Styles ---

_style_applied_globally = False

def apply_global_spectramapper_style(force_reapply: bool = False):
    """
    Applies the custom SpectraMapperPro Matplotlib style globally.
    Uses a flag to apply only once unless forced.
    """
    global _style_applied_globally
    if not _style_applied_globally or force_reapply:
        try:
            # You can either use a predefined style sheet if you have one
            # mplstyle.use('seaborn-v0_8-pastel') # Example using a built-in style
            
            # Or apply the custom dictionary directly
            plt.rcParams.update(SPECTRAMAPPER_MPL_STYLE)
            
            logger.info("Applied SpectraMapperPro global Matplotlib style.")
            _style_applied_globally = True
        except Exception as e:
            logger.error(f"Failed to apply global Matplotlib style: {e}")


def use_temporary_style(style: Union[str, Dict[str, Any]] = SPECTRAMAPPER_MPL_STYLE):
    """
    Returns a Matplotlib style context manager.
    Usage:
        with use_temporary_style():
            plt.plot(...) # Plots inside this block will use the style
        # Style reverts to previous outside the block
    """
    return mplstyle.context(style)


def set_axes_style(ax: matplotlib.axes.Axes, style_dict: Optional[Dict[str, Any]] = None):
    """
    Applies specific style elements to a given Matplotlib Axes object.
    This is for more granular control if global style is not desired or needs overrides.

    Args:
        ax: The Matplotlib Axes object to style.
        style_dict: A dictionary of style parameters to apply. If None, uses parts
                    of SPECTRAMAPPER_MPL_STYLE relevant to axes.
    """
    if style_dict is None:
        # Apply relevant parts of the default style
        ax.set_xlabel(ax.get_xlabel(), fontsize=SPECTRAMAPPER_MPL_STYLE["axes.labelsize"], color=SPECTRAMAPPER_MPL_STYLE["axes.labelcolor"])
        ax.set_ylabel(ax.get_ylabel(), fontsize=SPECTRAMAPPER_MPL_STYLE["axes.labelsize"], color=SPECTRAMAPPER_MPL_STYLE["axes.labelcolor"])
        ax.set_title(ax.get_title(), fontsize=SPECTRAMAPPER_MPL_STYLE["axes.titlesize"])
        ax.tick_params(axis='x', labelsize=SPECTRAMAPPER_MPL_STYLE["xtick.labelsize"], colors=SPECTRAMAPPER_MPL_STYLE["xtick.color"], direction=SPECTRAMAPPER_MPL_STYLE["xtick.direction"])
        ax.tick_params(axis='y', labelsize=SPECTRAMAPPER_MPL_STYLE["ytick.labelsize"], colors=SPECTRAMAPPER_MPL_STYLE["ytick.color"], direction=SPECTRAMAPPER_MPL_STYLE["ytick.direction"])
        ax.grid(SPECTRAMAPPER_MPL_STYLE["axes.grid"], color=SPECTRAMAPPER_MPL_STYLE["grid.color"],
                linestyle=SPECTRAMAPPER_MPL_STYLE["grid.linestyle"], linewidth=SPECTRAMAPPER_MPL_STYLE["grid.linewidth"],
                alpha=SPECTRAMAPPER_MPL_STYLE["grid.alpha"])
        ax.set_facecolor(SPECTRAMAPPER_MPL_STYLE["axes.facecolor"])
        ax.spines['top'].set_color(SPECTRAMAPPER_MPL_STYLE["axes.edgecolor"])
        ax.spines['bottom'].set_color(SPECTRAMAPPER_MPL_STYLE["axes.edgecolor"])
        ax.spines['left'].set_color(SPECTRAMAPPER_MPL_STYLE["axes.edgecolor"])
        ax.spines['right'].set_color(SPECTRAMAPPER_MPL_STYLE["axes.edgecolor"])
        
        # Apply color cycle if not already applied (e.g. if axes created outside global style context)
        if not hasattr(ax, '_got_prop_cycle') or not ax._got_prop_cycle:
             ax.set_prop_cycle(SPECTRAMAPPER_MPL_STYLE["axes.prop_cycle"])

    else: # Apply user-provided style_dict (more manual)
        if "title" in style_dict: ax.set_title(style_dict["title"].get("label"), fontsize=style_dict["title"].get("fontsize", 12))
        if "xlabel" in style_dict: ax.set_xlabel(style_dict["xlabel"].get("label"), fontsize=style_dict["xlabel"].get("fontsize", 10))
        # ... and so on for other elements
        logger.warning("Custom style_dict application in set_axes_style is not fully implemented. Using default subset for now.")
        # Revert to applying default subset for safety if style_dict is passed but not fully handled
        set_axes_style(ax, style_dict=None)


def get_next_color_from_cycle(ax: Optional[matplotlib.axes.Axes] = None) -> str:
    """
    Gets the next color from the current Matplotlib Axes' property cycle
    or the default global property cycle.

    Args:
        ax: Optional Matplotlib Axes. If None, uses plt.gca().

    Returns:
        A color string (e.g., hex code).
    """
    if ax is None:
        ax = plt.gca() # Get current axes
    
    # Access the property cycler of the axes
    prop_cycler = ax._get_lines.prop_cycler
    
    # Get current state or reset if needed (this is a bit of a hack)
    # A more robust way is to manage a counter or an iterator.
    # For simplicity, let's assume we just want the "next" color as if we were plotting.
    # This example just fetches the first color of the cycle if called repeatedly without plotting.
    # To truly cycle, you'd need to advance the cycler.
    
    # A simple way to get a color if you know the cycle:
    # For this example, let's just return the first color of our default cycle.
    # A better way would be to maintain an iterator for the cycle.
    
    # Let's try to get the current cycle and pick one
    # This doesn't advance the cycle, just shows what it contains.
    try:
        current_cycle = plt.rcParams['axes.prop_cycle']
        first_color_in_cycle = next(iter(current_cycle))['color']
        return first_color_in_cycle
    except Exception:
        return SPECTRAMAPPER_COLORS["primary_blue"] # Fallback


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)

    # Apply the global style for this test script
    apply_global_spectramapper_style()

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
    fig.suptitle("plot_styles.py Test with SpectraMapperPro Style")

    # --- Plot 1: Uses global style ---
    ax1.set_title("Plot with Global Style")
    x = np.linspace(0, 10, 100)
    for i in range(4):
        ax1.plot(x, np.sin(x + i * np.pi / 4), label=f'sin(x + {i}π/4)')
    ax1.legend()

    # --- Plot 2: Temporarily use a different style ---
    with use_temporary_style('seaborn-v0_8-darkgrid'): # Matplotlib built-in style
        ax2.set_title("Plot with Temporary 'seaborn-darkgrid' Style")
        for i in range(4):
            ax2.plot(x, np.cos(x + i * np.pi / 4), label=f'cos(x + {i}π/4)')
        ax2.legend()
    
    # After 'with' block, style should revert if it was different before global apply.
    # Since we applied global, further plots will use global unless another context is used.

    fig.tight_layout(rect=[0, 0.05, 1, 0.95])
    plt.show()

    # Test get_next_color_from_cycle (will likely return the first color of the cycle)
    print(f"Example color from cycle: {get_next_color_from_cycle()}")

    # Test applying style to specific axes after creation
    fig_ax_style, ax3 = plt.subplots(figsize=(5,4))
    ax3.plot(x, x**2, label="x^2 (Pre-style)")
    ax3.set_title("Before set_axes_style")
    ax3.legend()
    plt.show() # Show it first

    set_axes_style(ax3) # Apply our custom style subset
    ax3.set_title("After set_axes_style") # Title might be overwritten by set_axes_style if not careful
    # Note: set_axes_style might re-apply legend if not handled.
    # The legend might need to be re-created or updated if line properties change.
    # For simplicity, we'll just redraw.
    fig_ax_style.canvas.draw()
    plt.show() # Show it again to see changes


    print("plot_styles.py tests completed.")
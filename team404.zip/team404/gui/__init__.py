# team404/gui/__init__.py

"""
GUI package for SpectraMapper Pro.

This package contains all Qt-based graphical user interface components,
including the main window, dialogs, custom widgets, and functional tabs.
"""

# Make key GUI classes easily importable from the 'gui' namespace
from .main_window import MainWindow

# You might also expose other top-level GUI elements if needed,
# but typically MainWindow is the primary entry point from this package.

# from .dialogs import AboutDialog, PreferencesDialog # etc.
# from .tabs import LIBSProjectTab, PreprocessingTab # etc.
# from .widgets import SpectrumPlotWidget # etc.


__all__ = [
    "MainWindow",
    # Add other main GUI components here if they are directly launched or globally accessed
]
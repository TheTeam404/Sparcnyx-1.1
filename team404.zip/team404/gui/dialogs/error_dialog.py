# team404/gui/dialogs/error_dialog.py

"""
ErrorDialog for SpectraMapper Pro.
Provides a standardized way to display error messages to the user,
optionally with a "Details" section for more technical information.
"""

import sys
import traceback
import logging
from typing import Optional

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QMessageBox,
    QTextEdit, QApplication, QSizePolicy, QSpacerItem, QDialogButtonBox, QStyle, QWidget
)
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import Qt

logger = logging.getLogger(__name__)

# Assuming app_config.py might hold app name or paths to standard icons
# from ...app_config import APP_NAME
try:
    # from ... import app_config
    # APP_NAME = app_config.APP_NAME
    raise ImportError("app_config not yet implemented for this example")
except ImportError:
    APP_NAME_FALLBACK = "Application Error"
    # APP_NAME = APP_NAME_FALLBACK


class ErrorDialog(QDialog):
    """
    A dialog to display error messages with an optional expandable "Details" section
    for stack traces or more technical information.
    """

    def __init__(self,
                 title: str,
                 message: str,
                 details: Optional[str] = None,
                 parent: Optional[QWidget] = None, # Corrected type hint
                 icon_type: QMessageBox.Icon = QMessageBox.Critical):
        """
        Initializes the ErrorDialog.

        Args:
            title: The title for the dialog window.
            message: The main error message to display to the user.
            details: Optional detailed error information (e.g., stack trace).
                     If provided, a "Show Details" button will be available.
            parent: The parent widget.
            icon_type: The QMessageBox.Icon to display (Critical, Warning, Information).
        """
        super().__init__(parent)

        self.setWindowTitle(title or APP_NAME_FALLBACK)
        self.setMinimumWidth(450) # Increased min width slightly
        self.setModal(True)

        self._message = message
        self._details = details if details and details.strip() else None # Ensure details are not just whitespace
        self._icon_type = icon_type

        self.details_text_edit: Optional[QTextEdit] = None # For type hinting
        self.details_button: Optional[QPushButton] = None # For type hinting

        self._init_ui()
        self.adjustSize() # Initial adjust size

    def _get_standard_icon_pixmap(self, icon_type: QMessageBox.Icon, size: int = 48) -> QPixmap:
        """Gets a standard QStyle icon pixmap based on QMessageBox.Icon type."""
        style = self.style() or QApplication.style() # Get current style
        icon_enum = QStyle.SP_MessageBoxCritical
        if icon_type == QMessageBox.Warning:
            icon_enum = QStyle.SP_MessageBoxWarning
        elif icon_type == QMessageBox.Information:
            icon_enum = QStyle.SP_MessageBoxInformation
        elif icon_type == QMessageBox.Question:
            icon_enum = QStyle.SP_MessageBoxQuestion
        
        return style.standardIcon(icon_enum).pixmap(size, size)

    def _init_ui(self):
        """Initialize the UI components of the dialog."""
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(15) # Add some spacing between sections

        # --- Icon and Message Area ---
        content_layout = QHBoxLayout()
        content_layout.setSpacing(10)

        icon_label = QLabel(self)
        pixmap = self._get_standard_icon_pixmap(self._icon_type)
        icon_label.setPixmap(pixmap)
        icon_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        content_layout.addWidget(icon_label, 0, Qt.AlignTop)

        message_label = QLabel(self._message, self)
        message_label.setWordWrap(True)
        # message_label.setTextFormat(Qt.RichText) # Use RichText if you need simple HTML like <b>
        message_label.setTextInteractionFlags(Qt.TextBrowserInteraction) # Allow selecting text
        message_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        content_layout.addWidget(message_label)

        main_layout.addLayout(content_layout)

        # --- Details Section (collapsible) ---
        if self._details:
            self.details_text_edit = QTextEdit(self)
            self.details_text_edit.setPlainText(self._details)
            self.details_text_edit.setReadOnly(True)
            # Use a monospaced font common across platforms
            font = self.details_text_edit.font()
            font.setFamily("Monospace") # Or "Courier New", "Consolas"
            font.setStyleHint(font.Monospace)
            self.details_text_edit.setFont(font)
            
            self.details_text_edit.setVisible(False)
            self.details_text_edit.setLineWrapMode(QTextEdit.NoWrap)
            
            # Set preferred size for details box when visible
            self.details_text_edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
            self.details_text_edit.setFixedHeight(200) # Fixed height when visible
            main_layout.addWidget(self.details_text_edit)


        # --- Buttons ---
        button_box = QDialogButtonBox(self) # Parent it to the dialog for proper destruction

        ok_button = button_box.addButton(QDialogButtonBox.Ok)
        ok_button.clicked.connect(self.accept)
        ok_button.setDefault(True)


        if self._details:
            self.details_button = button_box.addButton("Show Details", QDialogButtonBox.ActionRole)
            self.details_button.clicked.connect(self._toggle_details_visibility)
        
        main_layout.addWidget(button_box)
        self.setLayout(main_layout)
        
        # Store the initial size before details are shown for better restoration
        self._initial_size_no_details = self.sizeHint()


    def _toggle_details_visibility(self):
        """Toggles the visibility of the details text edit and resizes dialog."""
        if not self.details_text_edit or not self.details_button:
            logger.warning("Details components not initialized, cannot toggle visibility.")
            return

        is_visible = self.details_text_edit.isVisible()
        self.details_text_edit.setVisible(not is_visible)

        if not is_visible: # Details are now visible
            self.details_button.setText("Hide Details")
            # Calculate new height. We want to expand by details_text_edit's height + layout spacing.
            # sizeHint() gives preferred size.
            current_geom = self.geometry()
            new_height = self._initial_size_no_details.height() + self.details_text_edit.height() + self.layout().spacing()
            # Ensure it doesn't get too large if the screen is small
            screen_height = QApplication.desktop().screenGeometry(self).height()
            max_height = int(screen_height * 0.8)
            self.setFixedHeight(min(new_height, max_height))

        else: # Details are now hidden
            self.details_button.setText("Show Details")
            # Restore to a more compact size, similar to initial.
            self.setFixedHeight(self._initial_size_no_details.height())
        
        # Optional: Center the dialog after resize if it moved off-screen,
        # but usually fixed height changes don't require this.
        # self.adjustSize() # This might override fixed height. Let's rely on setFixedHeight.

    @staticmethod
    def show_error(
        title: str,
        message: str,
        details: Optional[str] = None,
        parent: Optional[QWidget] = None, # Corrected type hint
        icon_type: QMessageBox.Icon = QMessageBox.Critical
    ) -> int: # Return type is QDialog.Accepted or QDialog.Rejected
        """Static method to conveniently create and show an error dialog."""
        dialog = ErrorDialog(title, message, details, parent, icon_type)
        return dialog.exec_()

    @staticmethod
    def from_exception(
        ex: Exception,
        title: Optional[str] = "An Error Occurred",
        message_prefix: Optional[str] = "An unexpected error occurred.",
        parent: Optional[QWidget] = None # Corrected type hint
    ) -> int:
        """
        Creates and shows an error dialog from an exception object.
        The exception's message will be the main message, and the stack trace
        will be in the details section.
        """
        error_message = str(ex)
        if not error_message: # Some exceptions might have empty string representation
            error_message = type(ex).__name__ # Use class name if message is empty

        if message_prefix:
            full_message = f"{message_prefix}\n\n<b>{error_message}</b>" # Make error bold
        else:
            full_message = f"<b>{error_message}</b>"

        try:
            tb_lines = traceback.format_exception(type(ex), ex, ex.__traceback__)
            details_text = "".join(tb_lines)
        except Exception as e_trace:
            logger.error(f"Failed to format traceback for exception dialog: {e_trace}")
            details_text = f"Could not retrieve full traceback. Original error type: {type(ex).__name__}"

        # Log the full exception to console/file for debugging, regardless of dialog display
        logger.error(f"Displaying error dialog for: {title} - {error_message}", exc_info=ex)

        return ErrorDialog.show_error(title, full_message, details_text, parent, QMessageBox.Critical)


if __name__ == '__main__':
    # Basic logging setup to see warnings/errors from the dialog code.
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
                        
    # Ensure QWidget is imported if not already, for type hinting in main
    from PyQt5.QtWidgets import QWidget 

    app = QApplication(sys.argv)

    # --- Test Cases ---
    def run_tests():
        logger.info("Showing simple error dialog...")
        ErrorDialog.show_error(
            "File Not Found",
            "The specified file 'example.txt' could not be located. Please check the path and try again.",
            parent=None # Explicitly None
        )

        logger.info("\nShowing error dialog with details...")
        details_content = "More detailed information about this error:\n" \
                        "Error Code: E_NO_ACCESS_001\n" \
                        "Module: file_io.py\n" \
                        "Line: 78\n" \
                        "This could be due to permissions or network issues."
        ErrorDialog.show_error(
            "Access Denied",
            "Could not access the requested resource.",
            details=details_content,
            icon_type=QMessageBox.Warning,
            parent=None
        )

        logger.info("\nShowing error dialog from a caught exception...")
        try:
            # Induce a more complex traceback
            def func_c():
                return 1 / 0
            def func_b():
                return func_c()
            def func_a():
                return func_b()
            x = func_a()
        except ZeroDivisionError as e:
            ErrorDialog.from_exception(e, title="Calculation Error", message_prefix="Failed to perform calculation:")
        
        # Test dialog with a long message and long details
        long_message = "This is a very long error message that should wrap properly within the dialog box. " * 10
        long_details = ("This is line 1 of very long details.\n" + \
                    "This is line 2 which might be quite wide and should ideally enable horizontal scrolling if NoWrap is set.\n" * 5 + \
                    "A\nB\nC\n"*20 + "End of long details.")

        logger.info("\nShowing error dialog with long message and details...")
        ErrorDialog.show_error(
            "Long Content Test",
            long_message,
            details=long_details,
            parent=None
        )

        logger.info("\nShowing error dialog with no details (details string is empty)...")
        ErrorDialog.show_error(
            "No Details Test",
            "This dialog should not have a details button because the details string is empty.",
            details="   ", # Whitespace only
            parent=None
        )
        
        logger.info("\nShowing error dialog for an exception with an empty message string...")
        class CustomEmptyMsgException(Exception):
            def __str__(self):
                return ""
        try:
            raise CustomEmptyMsgException()
        except CustomEmptyMsgException as e:
            ErrorDialog.from_exception(e, title="Empty Message Exception Test")


    # Run tests which show dialogs sequentially
    run_tests()
    
    logger.info("\nErrorDialog tests completed. Main application loop will now start. Manually close any open dialogs if needed, then the app.")
    # sys.exit(app.exec_()) # Keep app running to inspect dialogs.
                           # User must close the last dialog to exit the app.
                           # Or comment out if you want script to auto-exit after showing.
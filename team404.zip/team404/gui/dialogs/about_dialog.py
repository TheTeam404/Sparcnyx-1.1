import sys
import platform
import logging
from pathlib import Path

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTextBrowser,
    QApplication, QSizePolicy, QSpacerItem, QStyle
)
from PyQt5.QtGui import QPixmap, QDesktopServices, QFont
from PyQt5.QtCore import Qt, QUrl, PYQT_VERSION_STR

logger = logging.getLogger(__name__)

# --- Application Configuration ---
# Ideally, these would be in a central app_config.py
# from ...app_config import APP_NAME, APP_VERSION, APP_AUTHORS, APP_YEAR, APP_DESCRIPTION, GITHUB_URL, LICENSE_NAME
try:
    # This is a placeholder for a real configuration module
    # from ... import app_config
    # APP_NAME = app_config.APP_NAME
    # APP_VERSION = app_config.APP_VERSION
    # ... and so on
    raise ImportError("app_config not yet implemented for this example")
except ImportError:
    logger.warning("Using placeholder application configuration for AboutDialog.")
    APP_NAME = "Sparcnyx"
    APP_VERSION = "0.1.0-alpha"
    APP_AUTHORS = "Team404 AI Developers"
    APP_YEAR = "2024-2025"
    APP_DESCRIPTION = (
        "Sparcnyx is an advanced analysis software for "
        "Laser-Induced Breakdown Spectroscopy (LIBS) data. "
        "It provides tools for data import, preprocessing, peak analysis, "
        "elemental identification, quantitative analysis, 2D elemental mapping, "
        "and advanced chemometrics."
    )
    GITHUB_URL = "https://github.com/your_org/Team404_LIBS_Analysis" # Placeholder
    LICENSE_NAME = "[Your License Name Here]" # Placeholder

# --- Version Information ---
PYTHON_VERSION = platform.python_version()
PYQT_BINDINGS_VERSION = PYQT_VERSION_STR # Version of the PyQt5 bindings

try:
    from PyQt5.QtCore import QT_VERSION_STR as QT_COMPILE_TIME_VERSION
    # QT_COMPILE_TIME_VERSION is the version of Qt PyQt5 was compiled against.
except ImportError:
    QT_COMPILE_TIME_VERSION = "N/A"

try:
    from PyQt5.QtCore import qVersion
    QT_RUNTIME_VERSION = qVersion()
    if not QT_RUNTIME_VERSION: # qVersion can return empty string if not available
        QT_RUNTIME_VERSION = "N/A (Runtime qVersion() failed)"
except ImportError:
    QT_RUNTIME_VERSION = "N/A (PyQt5.QtCore.qVersion not found)"

OS_INFO = f"{platform.system()} {platform.release()} ({platform.machine()})"


class AboutDialog(QDialog):
    """
    A dialog window to display "About" information for the application.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"About {APP_NAME}")
        self.setMinimumSize(550, 450) # Adjusted minimum size
        self.setModal(True)

        self._init_ui()

    def _get_app_icon_pixmap(self, size=64) -> QPixmap:
        """Loads the application icon, falling back to a standard Qt icon."""
        try:
            # Assumes icon is in team404/assets/icons/app_icon.png
            # Path relative to this file: ../../assets/icons/app_icon.png
            icon_path = Path(__file__).resolve().parent.parent.parent / "assets" / "icons" / "app_icon.png"
            if icon_path.exists():
                pixmap = QPixmap(str(icon_path))
                if not pixmap.isNull():
                    return pixmap.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                else:
                    logger.warning(f"App icon at {icon_path} is null or unreadable.")
            else:
                logger.warning(f"Application icon not found at: {icon_path}")
        except Exception as e:
            logger.error(f"Error loading application icon: {e}")

        # Fallback to a standard Qt icon
        logger.info("Using standard Qt information icon as fallback for app icon.")
        style = self.style() or QApplication.style() # Get current style
        return style.standardPixmap(QStyle.SP_MessageBoxInformation).scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)


    def _build_html_content(self) -> str:
        """Builds the HTML content for the details browser."""
        acknowledgements_html = """
        <h4>Acknowledgements:</h4>
        <ul>
            <li>Built with Python and the Qt framework (via PyQt5).</li>
            <li>Utilizes NumPy, SciPy, and other scientific libraries for data processing and analysis.</li>
            <li>Spectral line data should be sourced from reliable databases (e.g., NIST ASD), managed by the user.</li>
        </ul>
        """
        
        project_link_html = f"<a href='{GITHUB_URL}'>Project Repository</a>"
        license_info_html = f"This software is provided under the {LICENSE_NAME} license."

        # Using f-strings for easier construction
        html_content = f"""
        <html>
        <head>
            <style type="text/css">
                p {{ margin-bottom: 0.5em; }}
                ul {{ margin-top: 0.2em; margin-bottom: 0.8em; }}
                li {{ margin-bottom: 0.2em; }}
                h4 {{ margin-bottom: 0.2em; margin-top: 0.8em;}}
            </style>
        </head>
        <body>
            <p>{APP_NAME} by {APP_AUTHORS}, © {APP_YEAR}.</p>
            <p><i>{APP_DESCRIPTION}</i></p>
            <hr>
            <h4>Technical Details:</h4>
            <ul>
                <li>Python: {PYTHON_VERSION}</li>
                <li>PyQt Bindings: {PYQT_BINDINGS_VERSION}</li>
                <li>Qt (Compile Time): {QT_COMPILE_TIME_VERSION}</li>
                <li>Qt (Runtime): {QT_RUNTIME_VERSION}</li>
                <li>Operating System: {OS_INFO}</li>
            </ul>
            {acknowledgements_html}
            <hr>
            <p>{license_info_html}</p>
            <p>{project_link_html}</p>
        </body>
        </html>
        """
        return html_content

    def _init_ui(self):
        """Initialize the UI components of the dialog."""
        main_layout = QVBoxLayout(self)

        # --- Application Icon and Name ---
        header_layout = QHBoxLayout()
        
        icon_label = QLabel(self)
        icon_pixmap = self._get_app_icon_pixmap()
        icon_label.setPixmap(icon_pixmap)
        icon_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        header_layout.addWidget(icon_label)

        title_version_layout = QVBoxLayout()
        app_name_label = QLabel(f"<b>{APP_NAME}</b>")
        # Use application default font and make it larger & bold
        font_name = QApplication.font()
        font_name.setPointSize(font_name.pointSize() + 4) # Larger
        font_name.setBold(True)
        app_name_label.setFont(font_name)
        title_version_layout.addWidget(app_name_label)

        app_version_label = QLabel(f"Version {APP_VERSION}")
        font_version = QApplication.font() # Start with default app font
        # font_version.setPointSize(font_version.pointSize() -1) # Slightly smaller
        app_version_label.setFont(font_version)
        title_version_layout.addWidget(app_version_label)
        
        title_version_layout.addStretch() # Vertical stretch if needed

        header_layout.addLayout(title_version_layout)
        header_layout.addStretch() # Horizontal stretch to push title/icon left
        main_layout.addLayout(header_layout)
        
        main_layout.addSpacing(10)

        # --- Details Text Browser ---
        details_browser = QTextBrowser(self)
        details_browser.setOpenExternalLinks(True)
        details_browser.setReadOnly(True)
        details_browser.setFont(QApplication.font()) # Use application default font
        
        details_browser.setHtml(self._build_html_content())
        main_layout.addWidget(details_browser)

        main_layout.addSpacing(10)

        # --- Buttons ---
        button_layout = QHBoxLayout()
        button_layout.addStretch() # Push buttons to the right

        ok_button = QPushButton("OK", self)
        ok_button.setDefault(True)
        ok_button.clicked.connect(self.accept)
        button_layout.addWidget(ok_button)

        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)

    @staticmethod
    def show_about_dialog(parent=None):
        """Static method to easily show the About dialog."""
        dialog = AboutDialog(parent)
        dialog.exec_()


if __name__ == '__main__':
    # Basic logging setup to see warnings/errors from the dialog code.
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    app = QApplication(sys.argv)

    # For testing, create a dummy icon file if it doesn't exist to test loading
    # This part is optional and specific to the test environment
    test_icon_created = False
    try:
        # team404/assets/icons/app_icon.png
        icon_dir = Path(__file__).resolve().parent.parent.parent / "assets" / "icons"
        icon_file = icon_dir / "app_icon.png"
        if not icon_file.exists():
            icon_dir.mkdir(parents=True, exist_ok=True)
            # Create a tiny placeholder PNG (1x1 red pixel) for testing
            # This avoids needing a real icon just for this test script to run
            # For a real app, the icon should exist.
            # from PIL import Image
            # img = Image.new('RGB', (64, 64), color = 'red')
            # img.save(icon_file)
            # logger.info(f"Created dummy icon at {icon_file} for testing.")
            # test_icon_created = True
            logger.info(f"Test icon file '{icon_file}' not found and not created by this script. Fallback icon will be used if not present.")
    except Exception as e:
        logger.error(f"Could not create dummy icon for testing: {e}")


    AboutDialog.show_about_dialog(None)

    # Clean up dummy icon if created by this test
    # if test_icon_created and icon_file.exists():
    #     try:
    #         icon_file.unlink()
    #         logger.info(f"Removed dummy icon {icon_file}.")
    #     except Exception as e:
    #         logger.error(f"Could not remove dummy icon: {e}")

    sys.exit(app.exec_())
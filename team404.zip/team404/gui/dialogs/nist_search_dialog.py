# team404/gui/dialogs/nist_search_dialog.py

import logging
from typing import Optional, Any, List

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QDialogButtonBox,
    QGroupBox, QMessageBox, QDoubleSpinBox, QHBoxLayout, QAbstractItemView, QProgressDialog
)
from PyQt5.QtCore import Qt, QThread

from ...workers.nist_online_search_worker import NISTOnlineSearchWorker, ASTROQUERY_AVAILABLE
from ..widgets.results_table_widget import ResultsTableWidget
from ...core.data_models import ElementalLine
from ...database.user_custom_db import UserCustomDB
from ...utils.helpers import get_app_data_directory
from ...utils.constants import USER_CUSTOM_DB_FILENAME, APP_NAME, ORG_NAME
from pathlib import Path


logger = logging.getLogger(__name__)

class NISTSearchDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)

        if not ASTROQUERY_AVAILABLE:
            QMessageBox.critical(self, "Dependency Error", "The 'astroquery' library is required for online searches but is not installed.")
        
        self.setWindowTitle("Advanced NIST ASD Online Search")
        self.setMinimumSize(800, 650) # Made slightly wider
        self.setModal(True)

        # ADDED: Instance of the user's custom database for saving results.
        user_db_path = get_app_data_directory(APP_NAME, ORG_NAME)
        self.user_custom_db = UserCustomDB(str(Path(user_db_path) / USER_CUSTOM_DB_FILENAME))

        self.worker_thread: Optional[QThread] = None
        self.nist_worker: Optional[NISTOnlineSearchWorker] = None
        self.progress_dialog: Optional[QProgressDialog] = None # QProgressDialog is in QtWidgets
        self.found_lines: List[ElementalLine] = [] # Store the successful search results
        
        self._init_ui()
        if not ASTROQUERY_AVAILABLE:
            self.search_button.setEnabled(False)
            self.search_button.setText("Search (astroquery missing)")

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        self.setLayout(main_layout)

        params_group = QGroupBox("Search Criteria")
        params_layout = QFormLayout(params_group)
        self.wavelength_edit = QLineEdit("300-310"); params_layout.addRow("Wavelength Range (nm):", self.wavelength_edit)
        self.tolerance_spinbox = QDoubleSpinBox(); self.tolerance_spinbox.setDecimals(3); self.tolerance_spinbox.setRange(0.001, 10.0); self.tolerance_spinbox.setValue(0.1); self.tolerance_spinbox.setSuffix(" nm")
        params_layout.addRow("Tolerance (for single λ):", self.tolerance_spinbox)
        self.element_filter_edit = QLineEdit(); self.element_filter_edit.setPlaceholderText("Optional (e.g., Fe, Ca II, Fe I-II)")
        params_layout.addRow("Element/Ion Filter:", self.element_filter_edit)
        main_layout.addWidget(params_group)

        self.search_button = QPushButton("Search NIST Online")
        self.search_button.clicked.connect(self._start_search)
        main_layout.addWidget(self.search_button)

        results_group = QGroupBox("Search Results")
        results_layout = QVBoxLayout(results_group)
        self.results_table = ResultsTableWidget()
        self.results_table.setSelectionMode(QAbstractItemView.ExtendedSelection) # Allow multi-select
        results_layout.addWidget(self.results_table)
        
        # ADDED: New layout for buttons below the results table.
        results_button_layout = QHBoxLayout()
        self.save_selected_button = QPushButton("Save Selected to User DB")
        self.save_selected_button.setToolTip("Save the selected lines from the table to your personal database.")
        self.save_selected_button.clicked.connect(self._save_selected_lines)
        self.save_selected_button.setEnabled(False) # Disabled until there are results
        results_button_layout.addStretch()
        results_button_layout.addWidget(self.save_selected_button)
        results_layout.addLayout(results_button_layout)
        
        main_layout.addWidget(results_group)

        self.button_box = QDialogButtonBox(QDialogButtonBox.Close)
        self.button_box.rejected.connect(self.reject)
        main_layout.addWidget(self.button_box)

    def _start_search(self):
        if self.worker_thread and self.worker_thread.isRunning(): return
        try:
            wl_input = self.wavelength_edit.text().strip()
            if '-' in wl_input: min_s, max_s = wl_input.split('-', 1); min_w, max_w = float(min_s), float(max_s)
            else: center_w = float(wl_input); tol = self.tolerance_spinbox.value(); min_w, max_w = center_w - tol, center_w + tol
            if min_w >= max_w: raise ValueError("Min wavelength must be less than max.")
        except ValueError as e: QMessageBox.warning(self, "Invalid Input", f"Invalid wavelength input: {e}"); return
            
        element_filter = self.element_filter_edit.text().strip() or None
        self.search_button.setEnabled(False); self.save_selected_button.setEnabled(False)
        self.progress_dialog = QProgressDialog("Querying NIST...", "Cancel", 0, 100, self)
        self.progress_dialog.canceled.connect(self._cancel_search); self.progress_dialog.show()

        self.worker_thread = QThread()
        self.nist_worker = NISTOnlineSearchWorker(wavelength_min_nm=min_w, wavelength_max_nm=max_w, linename=element_filter)
        self.nist_worker.moveToThread(self.worker_thread)
        self.worker_thread.started.connect(self.nist_worker.run); self.nist_worker.finished.connect(self._on_search_finished)
        self.nist_worker.progress.connect(self.progress_dialog.setValue)
        self.nist_worker.finished.connect(self.worker_thread.quit); self.nist_worker.finished.connect(self.nist_worker.deleteLater)
        self.worker_thread.finished.connect(self.worker_thread.deleteLater); self.worker_thread.finished.connect(self._reset_worker_state)
        self.worker_thread.start()

    def _on_search_finished(self, success: bool, result_or_message: Any):
        if success:
            self.found_lines = result_or_message.get("lines_found", [])
            message = result_or_message.get("message", "Search complete.")
            
            if not self.found_lines:
                QMessageBox.information(self, "Search Complete", 
                    "Search Operation was Successful but No lines found matching criteria.\n\n"
                    "Suggestions:\n"
                    "  - Broaden your wavelength range.\n"
                    "  - Check or remove the element/ion filter.\n"
                    "  - Add this line manually using the 'Add Line to User Database' feature.")
                self.results_table.clearContents(); self.results_table.setRowCount(0)
            else:
                QMessageBox.information(self, "Search Complete", message)
                
                # MODIFIED: Create a formatted list for display
                data_for_table = []
                for line in self.found_lines:
                    data_for_table.append({
                        "wavelength_nm": line.wavelength_nm,
                        "element": line.element,
                        "ion_stage": line.ion_stage,
                        "intensity_db_str": line.intensity_db_str,
                        "Aki": line.Aki,
                        "Ek_ev": line.Ek_ev,
                        "gk": line.gk,
                        "source_db": line.source_db,
                    })
                
                # Use populate_from_list_of_dicts to correctly handle the data
                self.results_table.populate_from_list_of_dicts(data_for_table)
                self.save_selected_button.setEnabled(True)
        else:
            QMessageBox.critical(self, "Search Error", f"The online search failed:\n{result_or_message}")
            self.results_table.clearContents(); self.results_table.setRowCount(0)

    # ADDED: New method to save selected lines to the user's database.
    def _save_selected_lines(self):
        selected_rows = self.results_table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.information(self, "No Selection", "Please select one or more lines from the results table to save.")
            return

        saved_count = 0
        duplicate_count = 0
        for index in selected_rows:
            row_index = index.row()
            if 0 <= row_index < len(self.found_lines):
                line_to_save = self.found_lines[row_index]
                # The user_custom_db's add_line method returns an ID on success, None on failure (e.g., duplicate)
                if self.user_custom_db.add_line(line_to_save, source_reference="NIST Online Search") is not None:
                    saved_count += 1
                else:
                    duplicate_count += 1
        
        summary_message = f"Successfully saved {saved_count} new line(s) to your user database."
        if duplicate_count > 0:
            summary_message += f"\nSkipped {duplicate_count} line(s) that were already in the database."
        QMessageBox.information(self, "Save Complete", summary_message)

    # --- Unchanged methods from here ---
    def _cancel_search(self):
        if self.nist_worker: self.nist_worker.request_interruption()
    def _reset_worker_state(self):
        self.search_button.setEnabled(ASTROQUERY_AVAILABLE)
        self.worker_thread = None; self.nist_worker = None
        if self.progress_dialog: self.progress_dialog.close(); self.progress_dialog = None
    def closeEvent(self, event):
        self._cancel_search()
        if self.worker_thread and self.worker_thread.isRunning():
            self.worker_thread.quit(); self.worker_thread.wait(1000)
        super().closeEvent(event)
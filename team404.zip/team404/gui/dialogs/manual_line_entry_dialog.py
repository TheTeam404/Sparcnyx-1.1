# team404/gui/dialogs/manual_line_entry_dialog.py

import logging
import webbrowser
from typing import Optional

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QDialogButtonBox,
    QGroupBox, QMessageBox, QDoubleSpinBox, QSpinBox, QTextEdit
)
from PyQt5.QtCore import Qt

from ...core.data_models import ElementalLine

logger = logging.getLogger(__name__)
NIST_ASD_URL = "https://physics.nist.gov/PhysRefData/ASD/lines_form.html"

class ManualLineEntryDialog(QDialog):
    # MODIFIED: Added initial_wavelength to the constructor.
    def __init__(self, initial_wavelength: Optional[float] = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Manual Spectral Line Entry")
        self.setMinimumWidth(450)
        self.setModal(True)
        self.line_data: Optional[ElementalLine] = None
        
        self._init_ui()

        # MODIFIED: If an initial wavelength is provided, set the value.
        if initial_wavelength is not None:
            self.wavelength_edit.setValue(initial_wavelength)
            self.element_edit.setFocus() # Move focus to the next logical field

    def _init_ui(self):
        # This method's content is unchanged.
        main_layout = QVBoxLayout(self); self.setLayout(main_layout)
        form_group = QGroupBox("Atomic Line Data"); form_layout = QFormLayout(form_group)
        self.wavelength_edit = QDoubleSpinBox(); self.wavelength_edit.setDecimals(4); self.wavelength_edit.setRange(0, 30000); self.wavelength_edit.setSuffix(" nm")
        self.element_edit = QLineEdit(); self.element_edit.setPlaceholderText("e.g., Fe, Ca")
        self.ion_stage_edit = QLineEdit(); self.ion_stage_edit.setPlaceholderText("e.g., I, II")
        form_layout.addRow("Wavelength (nm) *:", self.wavelength_edit); form_layout.addRow("Element Symbol *:", self.element_edit); form_layout.addRow("Ionization Stage *:", self.ion_stage_edit)
        self.aki_edit = QLineEdit(); self.aki_edit.setPlaceholderText("e.g., 1.4e8")
        self.ek_ev_edit = QDoubleSpinBox(); self.ek_ev_edit.setDecimals(4); self.ek_ev_edit.setRange(-100, 1000)
        self.gk_edit = QSpinBox(); self.gk_edit.setRange(0, 1000)
        form_layout.addRow("Aki (s⁻¹):", self.aki_edit); form_layout.addRow("Upper Energy (Ek) eV:", self.ek_ev_edit); form_layout.addRow("Upper Stat. Weight (gk):", self.gk_edit)
        self.notes_edit = QTextEdit(); self.notes_edit.setPlaceholderText("Source of data, observations, etc."); self.notes_edit.setFixedHeight(60)
        form_layout.addRow("Notes/Source:", self.notes_edit); main_layout.addWidget(form_group)
        self.nist_button = QPushButton("Launch NIST ASD Website..."); self.nist_button.clicked.connect(self._launch_nist_website)
        main_layout.addWidget(self.nist_button)
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel); self.button_box.accepted.connect(self._on_accept); self.button_box.rejected.connect(self.reject)
        main_layout.addWidget(self.button_box)
    
    def _launch_nist_website(self):
        try: webbrowser.open(NIST_ASD_URL)
        except Exception as e: QMessageBox.warning(self, "Browser Error", f"Could not open the web browser: {e}")

    def _on_accept(self):
        wavelength = self.wavelength_edit.value(); element = self.element_edit.text().strip().capitalize(); ion_stage = self.ion_stage_edit.text().strip().upper()
        if not (element and ion_stage and wavelength > 0):
            QMessageBox.warning(self, "Input Error", "Wavelength, Element, and Ion Stage are required fields."); return
        try:
            aki_str = self.aki_edit.text().strip(); aki = float(aki_str) if aki_str else None
            ek_ev = self.ek_ev_edit.value() if self.ek_ev_edit.value() > 0 else None
            gk = self.gk_edit.value() if self.gk_edit.value() > 0 else None
        except ValueError: QMessageBox.warning(self, "Input Error", "Aki must be a valid number (e.g., 1.2e8)."); return
        self.line_data = ElementalLine(wavelength_nm=wavelength, element=element, ion_stage=ion_stage, Aki=aki, Ek_ev=ek_ev, gk=gk)
        self.accept()

    def get_line_data(self) -> Optional[ElementalLine]: return self.line_data
    def get_notes(self) -> str: return self.notes_edit.toPlainText()
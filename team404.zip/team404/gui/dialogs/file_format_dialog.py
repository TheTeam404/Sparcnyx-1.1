# team404/gui/dialogs/file_format_dialog.py

"""
FileFormatDialog for SpectraMapper Pro.
Allows users to specify or confirm parsing parameters for text-based
spectral data files (e.g., CSV, TXT, ASC).
"""

import sys
import os # For os.path.basename
import csv
import logging
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import collections

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QGridLayout, QLabel, QLineEdit, QSpinBox,
    QComboBox, QPushButton, QDialogButtonBox, QGroupBox, QMessageBox,
    QApplication, QTableWidget, QTableWidgetItem, QHeaderView
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QColor, QBrush

logger = logging.getLogger(__name__)

# --- Constants ---
MAX_PREVIEW_LINES_DISPLAY = 20 # Max lines shown in the table
MAX_LINES_TO_READ_FOR_PREVIEW = 100 # Max lines read from file for analysis/preview
DELIMITER_SNIFF_SAMPLE_SIZE = 10 # Number of data lines to use for CSV sniffer
DEFAULT_ENCODING = 'utf-8'

COMMON_ENCODINGS = ['utf-8', 'latin-1', 'ascii', 'utf-16', 'windows-1252']
COMMON_DELIMITERS_DISPLAY = {
    'Auto-detect': None, # Special case
    'Comma (,)': ',',
    'Tab (\\t)': '\t',
    'Semicolon (;)': ';',
    'Space ( )': ' '
    # Custom can be entered directly
}


class FileFormatDialog(QDialog):
    """
    A dialog to configure parameters for parsing text-based spectral data files.
    It also shows a preview of how the data will be parsed.
    """
    parameters_accepted = pyqtSignal(dict)

    def __init__(self, filepath: str, initial_params: Optional[Dict] = None, parent=None):
        super().__init__(parent)
        self.filepath = Path(filepath)
        self.raw_file_lines_preview: List[str] = []
        self.detected_encoding: str = DEFAULT_ENCODING

        if not self.filepath.is_file():
            QMessageBox.critical(self, "File Error", f"File not found or is not accessible:\n{self.filepath}")
            # We should ideally not proceed or handle this more gracefully.
            # For now, it will try to load and fail in _load_file_preview.
            # A better approach might be to check before creating the dialog.
            self.close() # Close immediately if file is bad
            return


        self.setWindowTitle(f"Configure File Format: {self.filepath.name}")
        self.setMinimumWidth(700) # Increased width for better preview
        self.setMinimumHeight(550)
        self.setModal(True)

        self._load_file_preview() # Loads lines and detects encoding
        self._initial_params = initial_params if initial_params else {}

        self._init_ui()
        self._populate_initial_params()
        self._update_preview_table() # Initial preview based on loaded/initial params

    def _load_file_preview(self):
        """Loads the first few lines of the file and attempts to detect encoding."""
        encodings_to_try = [self._initial_params.get('encoding', DEFAULT_ENCODING)] + \
                           [enc for enc in COMMON_ENCODINGS if enc != self._initial_params.get('encoding')]
        
        content_loaded = False
        for enc in encodings_to_try:
            try:
                with self.filepath.open('r', encoding=enc) as f:
                    self.raw_file_lines_preview = [
                        f.readline().rstrip('\n') for _ in range(MAX_LINES_TO_READ_FOR_PREVIEW) if f.readable()
                    ]
                    # Filter out potential null bytes read by mistake due to wrong encoding (often at EOF)
                    self.raw_file_lines_preview = [line for line in self.raw_file_lines_preview if '\x00' not in line]

                self.detected_encoding = enc
                content_loaded = True
                logger.debug(f"Successfully read preview with encoding: {enc}")
                break
            except UnicodeDecodeError:
                logger.debug(f"UnicodeDecodeError with encoding: {enc} for file {self.filepath.name}")
                self.raw_file_lines_preview = []
                continue
            except Exception as e:
                logger.error(f"Error loading file preview for {self.filepath.name} with encoding {enc}: {e}")
                self.raw_file_lines_preview = [f"Error loading preview: {str(e)[:100]}"] # Show limited error in preview
                self.detected_encoding = DEFAULT_ENCODING # Fallback
                return # Stop trying other encodings if a general error occurs

        if not content_loaded:
            logger.warning(f"Could not decode file {self.filepath.name} with common encodings.")
            self.raw_file_lines_preview = [f"Error: Could not decode file with tried encodings."]
            self.detected_encoding = DEFAULT_ENCODING

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(10)

        params_group = QGroupBox("Parsing Parameters", self)
        params_layout = QGridLayout(params_group)
        params_layout.setSpacing(10)

        row = 0
        params_layout.addWidget(QLabel("File Encoding:", self), row, 0)
        self.encoding_combo = QComboBox(self)
        self.encoding_combo.addItems(list(set([self.detected_encoding] + COMMON_ENCODINGS))) # Ensure detected is first
        self.encoding_combo.setCurrentText(self.detected_encoding)
        self.encoding_combo.currentTextChanged.connect(self._on_encoding_change)
        params_layout.addWidget(self.encoding_combo, row, 1, 1, 2) # Span 2 columns

        row += 1
        params_layout.addWidget(QLabel("Delimiter:", self), row, 0)
        self.delimiter_combo = QComboBox(self)
        self.delimiter_combo.setEditable(True)
        self.delimiter_combo.addItems(list(COMMON_DELIMITERS_DISPLAY.keys()))
        self.delimiter_combo.currentTextChanged.connect(self._on_param_change_no_reload)
        params_layout.addWidget(self.delimiter_combo, row, 1, 1, 2)

        row += 1
        params_layout.addWidget(QLabel("Skip Header Lines:", self), row, 0)
        self.skip_header_spinbox = QSpinBox(self)
        self.skip_header_spinbox.setRange(0, MAX_LINES_TO_READ_FOR_PREVIEW - 1) # Max skip limited by preview read
        self.skip_header_spinbox.setToolTip("Number of lines at the beginning of the file to ignore.")
        self.skip_header_spinbox.valueChanged.connect(self._on_param_change_no_reload)
        params_layout.addWidget(self.skip_header_spinbox, row, 1, 1, 2)

        row += 1
        params_layout.addWidget(QLabel("Comment Character:", self), row, 0)
        self.comment_char_edit = QLineEdit(self)
        self.comment_char_edit.setMaxLength(1)
        self.comment_char_edit.setPlaceholderText("e.g., #, !, %")
        self.comment_char_edit.setToolTip("Lines starting with this character will be ignored (after skipped headers).")
        self.comment_char_edit.textChanged.connect(self._on_param_change_no_reload)
        params_layout.addWidget(self.comment_char_edit, row, 1, 1, 2)
        
        row += 1
        params_layout.addWidget(QLabel("Wavelength Column:", self), row, 0)
        self.wl_col_spinbox = QSpinBox(self)
        self.wl_col_spinbox.setRange(0, 50) # 0-based index
        self.wl_col_spinbox.setToolTip("0-based index of the column containing wavelength data.")
        self.wl_col_spinbox.valueChanged.connect(self._on_param_change_no_reload)
        params_layout.addWidget(self.wl_col_spinbox, row, 1)
        
        params_layout.addWidget(QLabel("Intensity Column:", self), row, 2)
        self.int_col_spinbox = QSpinBox(self)
        self.int_col_spinbox.setRange(0, 50) # 0-based index
        self.int_col_spinbox.setToolTip("0-based index of the column containing intensity data.")
        self.int_col_spinbox.valueChanged.connect(self._on_param_change_no_reload)
        params_layout.addWidget(self.int_col_spinbox, row, 3)
        
        main_layout.addWidget(params_group)

        preview_group = QGroupBox(f"File Preview (first {MAX_PREVIEW_LINES_DISPLAY} relevant lines)", self)
        preview_layout = QVBoxLayout(preview_group)
        self.preview_table = QTableWidget(self)
        self.preview_table.setMinimumHeight(250)
        self.preview_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.preview_table.setAlternatingRowColors(True)
        self.preview_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.preview_table.verticalHeader().setVisible(True) # Show line numbers
        preview_layout.addWidget(self.preview_table)
        main_layout.addWidget(preview_group)

        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self._on_accept)
        self.button_box.rejected.connect(self.reject)
        main_layout.addWidget(self.button_box)

        self.setLayout(main_layout)

    def _populate_initial_params(self):
        self.encoding_combo.setCurrentText(self._initial_params.get("encoding", self.detected_encoding))

        initial_delimiter_display = self._initial_params.get("delimiter_display_str", "Auto-detect")
        if initial_delimiter_display in COMMON_DELIMITERS_DISPLAY:
            self.delimiter_combo.setCurrentText(initial_delimiter_display)
        elif self._initial_params.get("delimiter"): # Custom delimiter was set
            self.delimiter_combo.setEditText(self._initial_params.get("delimiter"))
        else: # Default to Auto-detect
            self.delimiter_combo.setCurrentText("Auto-detect")
            
        self.skip_header_spinbox.setValue(self._initial_params.get("skip_header", 0))
        self.comment_char_edit.setText(self._initial_params.get("comment_char", "#"))
        self.wl_col_spinbox.setValue(self._initial_params.get("wl_col_idx", 0))
        self.int_col_spinbox.setValue(self._initial_params.get("int_col_idx", 1))

    def _get_current_parameters(self) -> Dict:
        current_delimiter_display = self.delimiter_combo.currentText()
        actual_delimiter_char: Optional[str]
        
        if current_delimiter_display == "Auto-detect":
            # Attempt detection based on current preview lines and other params
            actual_delimiter_char = self._try_detect_delimiter(
                self.raw_file_lines_preview,
                self.skip_header_spinbox.value(),
                self.comment_char_edit.text() or None
            )
        elif current_delimiter_display in COMMON_DELIMITERS_DISPLAY:
            actual_delimiter_char = COMMON_DELIMITERS_DISPLAY[current_delimiter_display]
        else: # Custom delimiter entered in editable QComboBox
            actual_delimiter_char = current_delimiter_display
            if actual_delimiter_char == '\\t': # User might type \t literally
                actual_delimiter_char = '\t'

        return {
            "encoding": self.encoding_combo.currentText(),
            "delimiter": actual_delimiter_char,
            "delimiter_display_str": current_delimiter_display, # For repopulating dialog
            "skip_header": self.skip_header_spinbox.value(),
            "comment_char": self.comment_char_edit.text() or None,
            "wl_col_idx": self.wl_col_spinbox.value(),
            "int_col_idx": self.int_col_spinbox.value()
        }

    def _on_encoding_change(self):
        """Reload file preview and update table when encoding changes."""
        new_encoding = self.encoding_combo.currentText()
        if new_encoding != self.detected_encoding: # Only reload if changed significantly
            self._initial_params['encoding'] = new_encoding # Update for next reload attempt
            self._load_file_preview() # This updates self.raw_file_lines_preview and self.detected_encoding
            self.encoding_combo.setCurrentText(self.detected_encoding) # Reflect actually used encoding
        self._update_preview_table()

    def _on_param_change_no_reload(self):
        """Update preview table when non-encoding parameters change."""
        self._update_preview_table()

    def _try_detect_delimiter(self, lines: List[str], skip_header: int, comment_char: Optional[str]) -> Optional[str]:
        sample_lines_for_sniff = []
        for i, line_content in enumerate(lines):
            if i < skip_header:
                continue
            line_strip = line_content.strip()
            if not line_strip or (comment_char and line_strip.startswith(comment_char)):
                continue
            sample_lines_for_sniff.append(line_content) # Sniffer needs raw line
            if len(sample_lines_for_sniff) >= DELIMITER_SNIFF_SAMPLE_SIZE:
                break
        
        if not sample_lines_for_sniff:
            return None

        try:
            # Join with newline as sniffer expects a single string or iterable of strings
            dialect = csv.Sniffer().sniff("\n".join(sample_lines_for_sniff))
            # Check if the detected delimiter is plausible (e.g., not alphanumeric if data is numeric)
            # This is a simple check; more sophisticated heuristics might be needed.
            if dialect.delimiter.isalnum() and any(c.isdigit() for c in sample_lines_for_sniff[0]):
                logger.debug(f"CSV Sniffer found alphanumeric delimiter '{dialect.delimiter}', might be incorrect. Trying heuristics.")
                # Fall through to heuristic if sniffer gives suspicious delimiter
            else:
                logger.debug(f"CSV Sniffer detected delimiter: '{dialect.delimiter}'")
                return dialect.delimiter
        except csv.Error:
            logger.debug("CSV Sniffer failed to detect delimiter. Trying common delimiters heuristic.")

        # Fallback: simple heuristic if sniffer fails or gives suspicious result
        delimiter_counts = collections.defaultdict(int)
        for line_to_check in sample_lines_for_sniff:
            stripped_line = line_to_check.strip()
            for delim_char_display, delim_char_val in COMMON_DELIMITERS_DISPLAY.items():
                if delim_char_val is None: continue # Skip 'Auto-detect' entry
                if delim_char_val in stripped_line:
                    num_parts = len(stripped_line.split(delim_char_val))
                    if num_parts > 1: # Must split into at least two parts
                        delimiter_counts[delim_char_val] += 1
        
        if delimiter_counts:
            # Prefer non-space delimiters if counts are similar
            sorted_delimiters = sorted(delimiter_counts.items(), key=lambda item: (item[1], item[0] != ' '), reverse=True)
            detected_heuristic = sorted_delimiters[0][0]
            logger.debug(f"Heuristic detected delimiter: '{detected_heuristic}'")
            return detected_heuristic
        
        logger.debug("Delimiter detection failed (sniffer and heuristic).")
        return None

    def _update_preview_table(self):
        params = self._get_current_parameters()
        delimiter = params["delimiter"]
        skip_header = params["skip_header"]
        comment_char = params["comment_char"]
        wl_col = params["wl_col_idx"]
        int_col = params["int_col_idx"]

        self.preview_table.clearContents()
        self.preview_table.setRowCount(0)
        self.preview_table.setColumnCount(0) # Will be set based on parsed data

        max_cols_found = 0
        display_row_count = 0
        
        actual_line_numbers_for_preview: List[int] = []
        rows_data_for_table: List[Tuple[str, List[str], int]] = [] # (type, content_parts, original_line_idx)

        for original_line_idx, line_content in enumerate(self.raw_file_lines_preview):
            line_strip = line_content.strip()
            row_type = "raw" # Default type
            content_parts = [line_content] # Default content

            if original_line_idx < skip_header:
                row_type = "header"
            elif not line_strip or (comment_char and line_strip.startswith(comment_char)):
                row_type = "comment"
            elif delimiter: # Attempt to parse data line
                row_type = "data"
                if delimiter == ' ': # Handle multiple spaces as one, and strip leading/trailing spaces first
                    content_parts = [p for p in line_strip.split() if p]
                else:
                    content_parts = [p.strip() for p in line_strip.split(delimiter)]
            # If no delimiter, it remains "raw" with [line_content]

            max_cols_found = max(max_cols_found, len(content_parts))
            rows_data_for_table.append((row_type, content_parts, original_line_idx))

        # Set column count and headers
        if max_cols_found == 0 and self.raw_file_lines_preview: max_cols_found = 1 # Ensure at least one col if there are lines
        self.preview_table.setColumnCount(max_cols_found)
        self.preview_table.setHorizontalHeaderLabels([f"Column {j}" for j in range(max_cols_found)])
        
        # Populate table rows
        for row_type, content_parts, original_line_idx in rows_data_for_table:
            if display_row_count >= MAX_PREVIEW_LINES_DISPLAY:
                break

            self.preview_table.insertRow(display_row_count)
            actual_line_numbers_for_preview.append(original_line_idx + 1) # Store 1-based line number

            for col_idx, cell_text in enumerate(content_parts):
                item = QTableWidgetItem(cell_text)
                
                base_tooltip = f"Original Line: {original_line_idx + 1}\n"
                
                if row_type == "header":
                    item.setBackground(QColor(Qt.lightGray))
                    item.setToolTip(base_tooltip + "Skipped Header Line")
                elif row_type == "comment":
                    item.setBackground(QColor("#FFFACD")) # LemonChiffon
                    item.setForeground(QBrush(Qt.darkGray))
                    item.setToolTip(base_tooltip + "Comment Line")
                elif row_type == "data":
                    is_data_cell = True
                    cell_tooltip = ""
                    if col_idx == wl_col:
                        item.setBackground(QColor("#ADD8E6")) # LightBlue
                        cell_tooltip = f"Wavelength Column (Index {wl_col})"
                    elif col_idx == int_col:
                        item.setBackground(QColor("#FFB6C1")) # LightPink
                        cell_tooltip = f"Intensity Column (Index {int_col})"
                    else: # Regular data cell
                        pass # Default background
                    
                    # Attempt to parse as float for data cells to indicate parsability
                    try:
                        float(cell_text.replace(',','.')) # Handle comma decimal
                    except ValueError:
                        if is_data_cell and (col_idx == wl_col or col_idx == int_col):
                            item.setForeground(QBrush(Qt.red)) # Red text if parsing fails for key columns
                            cell_tooltip += " (Non-numeric)"
                    item.setToolTip(base_tooltip + cell_tooltip)

                self.preview_table.setItem(display_row_count, col_idx, item)
            
            if len(content_parts) == 1 and max_cols_found > 1 and row_type != "data":
                self.preview_table.setSpan(display_row_count, 0, 1, max_cols_found)
            
            display_row_count += 1
        
        self.preview_table.setVerticalHeaderLabels([str(num) for num in actual_line_numbers_for_preview])
        self.preview_table.resizeColumnsToContents()
        if max_cols_found > 0: self.preview_table.horizontalHeader().setStretchLastSection(True)

    def _on_accept(self):
        final_params = self._get_current_parameters()
        
        if final_params["wl_col_idx"] == final_params["int_col_idx"]:
            QMessageBox.warning(self, "Validation Error",
                                "Wavelength and Intensity column indices cannot be the same.")
            return
        
        if final_params["delimiter_display_str"] == "Auto-detect" and final_params["delimiter"] is None:
            reply = QMessageBox.question(self, "Delimiter Not Detected",
                                         "Could not auto-detect a delimiter. "
                                         "Proceeding without a delimiter might lead to parsing errors for multi-column data. "
                                         "Do you want to proceed or specify one manually?",
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.No:
                return
            # If Yes, delimiter remains None. The loading function should handle this.

        self.parameters_accepted.emit(final_params)
        self.accept()

    def get_parameters(self) -> Dict:
        """Public method to get the accepted parameters after dialog is closed with OK."""
        return self._get_current_parameters()


if __name__ == '__main__':
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    app = QApplication(sys.argv)

    # Create a dummy test file in a temporary directory
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    dummy_file_path = Path(temp_dir.name) / "dummy_spectral_data.txt"

    file_content = (
        "# This is a test file for FileFormatDialog\n"
        "# Column A is Wavelength, Column B is Intensity\n"
        "Metadata: Sample X, Date: 2023-01-01\n" # Header
        "Instrument: SpectroAnalyzer 3000\n"     # Header
        "200.0, 100.5, Some other data\n"        # Data line
        "201.1, 150.2 # Spike here\n"            # Data with comment
        "202.2; 200.7; Comment after data\n"     # Mixed delimiter for testing
        "203.3\t300.1\tVal3\tVal4\n"             # Tab separated
        "  204.5   500.6   Extra   Info  \n"     # Space separated, with extra spaces
        "! This is another comment style\n"
        "205,0,123.45 # European decimal for testing\n"
    )
    # Add more lines for robust preview & skip header test
    for i in range(MAX_PREVIEW_LINES_DISPLAY + 5):
         file_content += f"{210 + i * 0.5:.1f}\t{400 + i * 10 - (i % 3) * 50:.1f}\tINFO_{i}\n"

    with open(dummy_file_path, "w", encoding='utf-8') as f:
        f.write(file_content)

    def on_params_accepted(params_dict):
        print("Dialog Parameters Accepted:", params_dict)

    logger.info("Testing dialog with auto-detection...")
    dialog_auto = FileFormatDialog(filepath=str(dummy_file_path))
    dialog_auto.parameters_accepted.connect(on_params_accepted)
    result_auto = dialog_auto.exec_()
    if result_auto == QDialog.Accepted:
        print("Dialog (auto) parameters were accepted.")
    else:
        print("Dialog (auto) cancelled.")

    logger.info("\nTesting dialog with initial parameters (Tab delimited)...")
    initial_tab = {
        "delimiter_display_str": "Tab (\\t)", "delimiter": "\t", "skip_header": 4,
        "comment_char": "#", "wl_col_idx": 0, "int_col_idx": 1,
        "encoding": "utf-8"
    }
    dialog_initial_tab = FileFormatDialog(filepath=str(dummy_file_path), initial_params=initial_tab)
    dialog_initial_tab.parameters_accepted.connect(on_params_accepted)
    result_initial_tab = dialog_initial_tab.exec_()
    if result_initial_tab == QDialog.Accepted:
        print("Dialog (initial tab) parameters were accepted.")
    else:
        print("Dialog (initial tab) cancelled.")

    logger.info("\nTesting dialog with different comment char and col indices...")
    initial_custom = {
        "delimiter_display_str": "Comma (,)", "delimiter": ",", "skip_header": 2,
        "comment_char": "!", "wl_col_idx": 1, "int_col_idx": 0, # Swapped
        "encoding": "utf-8"
    }
    dialog_initial_custom = FileFormatDialog(filepath=str(dummy_file_path), initial_params=initial_custom)
    dialog_initial_custom.parameters_accepted.connect(on_params_accepted)
    result_initial_custom = dialog_initial_custom.exec_()
    if result_initial_custom == QDialog.Accepted:
        print("Dialog (initial custom) parameters were accepted.")
    else:
        print("Dialog (initial custom) cancelled.")
        
    # Clean up
    temp_dir.cleanup()
    logger.info("\nFileFormatDialog tests completed.")
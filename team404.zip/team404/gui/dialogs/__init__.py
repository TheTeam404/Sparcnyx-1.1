# team404/gui/dialogs/__init__.py

"""
Dialog sub-package for SpectraMapper Pro.

This package contains reusable QDialog subclasses for various purposes
such as "About" information, preferences, error messages, etc.
"""

# Import dialog classes to make them easily accessible from the gui.dialogs namespace
from .about_dialog import AboutDialog
from .preferences_dialog import PreferencesDialog
# from .preferences_dialog import PreferencesDialog # To be created
# from .file_format_dialog import FileFormatDialog # To be created
# from .error_dialog import ErrorDialog # To be created

__all__ = [
    "AboutDialog",
    "PreferencesDialog",
    "FileFormatDialog",
    "ErrorDialog",
]

# You can also define a function here if needed, e.g., a generic message box
# from PyQt5.QtWidgets import QMessageBox
# def show_message(parent, title, message, icon=QMessageBox.Information):
#     QMessageBox.information(parent, title, message, icon)
# team404/gui/dialogs/database_mapper_dialog.py

"""
DatabaseMapperDialog for SpectraMapper Pro.
Allows users to map columns from their custom database files (CSV, etc.)
to the fields required by the software.
"""

import logging
from pathlib import Path
from typing import List, Dict, Optional, Any

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLabel, QPushButton, QDialogButtonBox,
    QGroupBox, QMessageBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QComboBox
)
from PyQt5.QtCore import Qt
import pandas as pd

logger = logging.getLogger(__name__)

# Define the fields our software needs, their display names, and if they are required.
SOFTWARE_FIELDS = [
    {"name": "wavelength_nm", "label": "Wavelength (nm)", "required": True, "tooltip": "The column containing the spectral line's wavelength."},
    {"name": "element", "label": "Element Symbol", "required": True, "tooltip": "The column with the element's chemical symbol (e.g., 'Fe', 'Ca')."},
    {"name": "ion_stage", "label": "Ionization Stage", "required": True, "tooltip": "The column with the ion's stage in Roman numerals (e.g., 'I', 'II')."},
    {"name": "Aki", "label": "Aki (Transition Prob.)", "required": False, "tooltip": "Optional: Transition probability (s⁻¹). Needed for some quantitative work."},
    {"name": "Ek_ev", "label": "Upper Energy (Ek) in eV", "required": False, "tooltip": "Optional: Upper energy level in electron-volts. Needed for Boltzmann plots."},
    {"name": "gk", "label": "Upper Stat. Weight (gk)", "required": False, "tooltip": "Optional: Statistical weight of the upper energy level. Needed for Boltzmann plots."},
    {"name": "Ei_ev", "label": "Lower Energy (Ei) in eV", "required": False, "tooltip": "Optional: Lower energy level in electron-volts."},
    {"name": "gi", "label": "Lower Stat. Weight (gi)", "required": False, "tooltip": "Optional: Statistical weight of the lower energy level."},
]

class DatabaseMapperDialog(QDialog):
    """
    A dialog for mapping user-provided database columns to internal field names.
    """
    def __init__(self, filepath: str, delimiter: str = ',', parent=None):
        super().__init__(parent)
        self.filepath = Path(filepath)
        self.delimiter = delimiter
        self.user_columns: List[str] = []
        self.mapping_combos: List[QComboBox] = []

        self.setWindowTitle(f"Map Columns for: {self.filepath.name}")
        self.setMinimumSize(700, 600)
        self.setModal(True)

        self._load_headers()
        self._init_ui()
        self._update_preview_table()

    def _load_headers(self):
        """Reads only the header row of the file to get column names."""
        try:
            # Use pandas to robustly read just the header
            df_header = pd.read_csv(self.filepath, delimiter=self.delimiter, nrows=0)
            self.user_columns = [str(col) for col in df_header.columns]
        except Exception as e:
            logger.error(f"Failed to read headers from {self.filepath}: {e}")
            QMessageBox.critical(self, "File Read Error", f"Could not read column headers from the file:\n{e}")
            self.user_columns = []

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        self.setLayout(main_layout)

        info_label = QLabel(
            "Please map the required software fields to the corresponding columns found in your file. "
            "A live preview of the mapped data is shown below."
        )
        info_label.setWordWrap(True)
        main_layout.addWidget(info_label)

        # --- Mapping Table ---
        map_group = QGroupBox("Column Mapping")
        map_layout = QVBoxLayout(map_group)
        self.map_table = QTableWidget()
        self.map_table.setColumnCount(2)
        self.map_table.setHorizontalHeaderLabels(["Software Field", "Your File's Column"])
        self.map_table.setRowCount(len(SOFTWARE_FIELDS))
        self.map_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.map_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.map_table.verticalHeader().setVisible(False)

        combo_options = ["--- Do Not Map ---"] + self.user_columns

        for i, field_def in enumerate(SOFTWARE_FIELDS):
            # Column 0: Software Field Name
            label_text = f"{field_def['label']}{' *' if field_def['required'] else ''}"
            item = QTableWidgetItem(label_text)
            item.setFlags(item.flags() & ~Qt.ItemIsEditable)
            item.setToolTip(field_def['tooltip'])
            self.map_table.setItem(i, 0, item)

            # Column 1: ComboBox for User's Columns
            combo = QComboBox()
            combo.addItems(combo_options)
            combo.currentIndexChanged.connect(self._update_preview_table)
            self.map_table.setCellWidget(i, 1, combo)
            self.mapping_combos.append(combo)

        map_layout.addWidget(self.map_table)
        main_layout.addWidget(map_group)

        # --- Preview Table ---
        preview_group = QGroupBox("Mapped Data Preview (First 10 Rows)")
        preview_layout = QVBoxLayout(preview_group)
        self.preview_table = QTableWidget()
        self.preview_table.setAlternatingRowColors(True)
        self.preview_table.setEditTriggers(QTableWidget.NoEditTriggers)
        preview_layout.addWidget(self.preview_table)
        main_layout.addWidget(preview_group)

        # --- Buttons ---
        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        self.button_box.accepted.connect(self._on_accept)
        self.button_box.rejected.connect(self.reject)
        main_layout.addWidget(self.button_box)

    def _update_preview_table(self):
        """Updates the bottom table based on the current mapping selections."""
        current_mapping = self.get_mapping()
        if not current_mapping:
            self.preview_table.clear()
            self.preview_table.setColumnCount(0)
            return

        try:
            # Read first 10 data rows
            preview_df = pd.read_csv(self.filepath, delimiter=self.delimiter, nrows=10)
            
            # Create a reverse mapping for renaming: {user_col: software_col}
            rename_map = {v: k for k, v in current_mapping.items()}
            
            # Rename columns and select only the ones that were mapped
            preview_df.rename(columns=rename_map, inplace=True)
            mapped_columns = list(current_mapping.keys())
            display_df = preview_df[[col for col in mapped_columns if col in preview_df.columns]]

            # Populate the QTableWidget
            self.preview_table.setRowCount(len(display_df))
            self.preview_table.setColumnCount(len(display_df.columns))
            self.preview_table.setHorizontalHeaderLabels(display_df.columns)
            
            for r in range(len(display_df)):
                for c in range(len(display_df.columns)):
                    value = display_df.iloc[r, c]
                    self.preview_table.setItem(r, c, QTableWidgetItem(str(value)))
            
            self.preview_table.resizeColumnsToContents()
        except Exception as e:
            logger.error(f"Error updating preview table: {e}")
            self.preview_table.clear()
            self.preview_table.setColumnCount(1)
            self.preview_table.setRowCount(1)
            self.preview_table.setItem(0, 0, QTableWidgetItem(f"Error generating preview: {e}"))

    def get_mapping(self) -> Dict[str, str]:
        """Returns the current mapping from software field names to user column names."""
        mapping = {}
        for i, combo in enumerate(self.mapping_combos):
            selected_col = combo.currentText()
            if selected_col != "--- Do Not Map ---":
                software_field_name = SOFTWARE_FIELDS[i]["name"]
                mapping[software_field_name] = selected_col
        return mapping

    def _on_accept(self):
        """Validates the mapping before accepting the dialog."""
        current_mapping = self.get_mapping()
        missing_required = []
        for field_def in SOFTWARE_FIELDS:
            if field_def["required"] and field_def["name"] not in current_mapping:
                missing_required.append(field_def["label"])
        
        if missing_required:
            QMessageBox.warning(
                self, "Missing Required Fields",
                "Please map all required fields (marked with *):\n\n" + "\n".join(missing_required)
            )
            return

        self.accept()

if __name__ == '__main__':
    import sys
    from PyQt5.QtWidgets import QApplication

    logging.basicConfig(level=logging.DEBUG)

    # Create a dummy CSV file for testing
    dummy_file = Path("test_mapping_db.csv")
    dummy_data = {
        "Wavelength_nm": [248.32, 250.11, 393.36],
        "Element_Symbol": ["Fe", "Fe", "Ca"],
        "Stage": ["I", "I", "II"],
        "A_ki": [1.2e8, 8.0e7, 1.4e8],
        "Notes": ["Strong", "Weak", "Very Strong"]
    }
    pd.DataFrame(dummy_data).to_csv(dummy_file, index=False)
    
    app = QApplication(sys.argv)
    
    dialog = DatabaseMapperDialog(filepath=str(dummy_file))
    result = dialog.exec_()
    
    if result == QDialog.Accepted:
        print("Dialog Accepted. Final Mapping:")
        print(dialog.get_mapping())
    else:
        print("Dialog Cancelled.")
        
    # Clean up the dummy file
    dummy_file.unlink()
    
    sys.exit()
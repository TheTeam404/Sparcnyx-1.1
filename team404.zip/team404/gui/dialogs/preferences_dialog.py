"""
PreferencesDialog for SpectraMapper Pro.
Allows users to configure application-wide settings, such as default paths,
analysis parameters, and UI preferences.
Settings are typically saved to a configuration file (e.g., JSON, INI).
"""

import sys
import os
import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QTabWidget, QWidget, QFormLayout,
    QLineEdit, QPushButton, QFileDialog, QCheckBox, QSpinBox,
    QComboBox, QDialogButtonBox, QApplication, QLabel, QGroupBox,
    QSizePolicy, QMessageBox, QDoubleSpinBox
)
from PyQt5.QtCore import Qt, QStandardPaths, pyqtSignal

logger = logging.getLogger(__name__)

# Define keys for settings to be used with QSettings or JSON file
ORG_NAME = "Team404"
APP_CFG_NAME = "SpectraMapperPro" # Used by QSettings and for directory structure

# For JSON config file
CONFIG_FILENAME = "app_preferences.json"

# --- Configuration Helper Class ---
class AppSettingsManager:
    """Handles loading, saving, and providing access to application settings."""
    
    def __init__(self, org_name: str, app_name: str, config_filename: str):
        self.org_name = org_name
        self.app_name = app_name
        self.config_filename = config_filename
        self.settings: Dict[str, Any] = {}
        self._config_filepath: Optional[Path] = None
        self._ensure_config_filepath()
        self.load()

    def _ensure_config_filepath(self) -> Path:
        if self._config_filepath is None:
            # Use QStandardPaths for robust cross-platform config directory location
            config_dir_str = QStandardPaths.writableLocation(QStandardPaths.AppConfigLocation)
            if not config_dir_str: # Fallback if QStandardPaths fails (unlikely)
                logger.warning("QStandardPaths.AppConfigLocation failed. Using fallback for config path.")
                if sys.platform == "win32":
                    app_data_path_str = os.getenv('APPDATA') or os.path.expanduser("~")
                elif sys.platform == "darwin":
                    app_data_path_str = os.path.expanduser("~/Library/Application Support")
                else:
                    app_data_path_str = os.getenv('XDG_CONFIG_HOME') or os.path.expanduser("~/.config")
                config_dir_str = os.path.join(app_data_path_str, self.org_name, self.app_name)
            
            config_dir = Path(config_dir_str)
            try:
                config_dir.mkdir(parents=True, exist_ok=True)
            except OSError as e:
                logger.error(f"Could not create config directory {config_dir}: {e}. Using current directory as fallback.")
                config_dir = Path(".") # Fallback to current directory if creation fails
            self._config_filepath = config_dir / self.config_filename
        return self._config_filepath

    def get_config_filepath(self) -> Path:
        return self._ensure_config_filepath()

    def get_default_settings(self) -> Dict[str, Any]:
        """Defines the structure and default values for all settings."""
        user_data_dir_str = QStandardPaths.writableLocation(QStandardPaths.AppLocalDataLocation)
        if not user_data_dir_str: # Fallback if QStandardPaths fails
            user_data_dir_str = os.path.join(str(self.get_config_filepath().parent), "user_data")
        
        user_data_dir = Path(user_data_dir_str)
        user_data_dir.mkdir(parents=True, exist_ok=True)

        return {
            "paths": {
                "default_project_dir": QStandardPaths.writableLocation(QStandardPaths.DocumentsLocation) or os.path.expanduser("~"),
                "nist_sqlite_db_path": "",
                "nist_csv_dir_path": "",
                "user_custom_db_path": str(user_data_dir / "user_lines.sqlite")
            },
            "analysis": {
                "default_element_id_tolerance_nm": 0.05,
                "default_peak_fitting_window_nm": 0.5,
                "auto_apply_preprocessing_on_load": False,
            },
            "ui": {
                "theme": "SystemDefault",
                "show_tooltips": True,
                "max_preview_lines_in_file_format_dialog": 20
            },
        }

    def _merge_settings(self, default: Dict, loaded: Dict) -> Dict:
        merged = default.copy()
        for key, value in loaded.items():
            if key in merged and isinstance(value, dict) and isinstance(merged[key], dict):
                merged[key] = self._merge_settings(merged[key], value)
            elif key in merged: # Only update if key exists in defaults and types match (or loaded is None)
                if type(merged[key]) == type(value) or value is None:
                    merged[key] = value
                else:
                    logger.warning(f"Type mismatch for setting '{key}'. Default: {type(default[key])}, Loaded: {type(value)}. Using default.")
            # else: logger.debug(f"Ignoring unknown or obsolete key '{key}' from loaded settings.")
        return merged

    def load(self):
        config_file = self.get_config_filepath()
        default_settings = self.get_default_settings()
        
        if config_file.exists() and config_file.is_file():
            try:
                with config_file.open('r', encoding='utf-8') as f:
                    loaded_settings = json.load(f)
                self.settings = self._merge_settings(default_settings, loaded_settings)
                logger.info(f"Preferences loaded from {config_file}")
                return
            except json.JSONDecodeError as e:
                logger.error(f"Error decoding preferences file {config_file}: {e}. Using defaults.")
            except Exception as e:
                logger.error(f"Error loading preferences from {config_file}: {e}. Using defaults.")
        
        logger.info("Preferences file not found or failed to load. Using default settings.")
        self.settings = default_settings

    def save(self):
        config_file = self.get_config_filepath()
        try:
            with config_file.open('w', encoding='utf-8') as f:
                json.dump(self.settings, f, indent=4, ensure_ascii=False)
            logger.info(f"Preferences saved to {config_file}")
        except Exception as e:
            logger.error(f"Error saving preferences to {config_file}: {e}")
            QMessageBox.warning(None, "Save Error", f"Could not save preferences to {config_file}:\n{e}")

    def get_value(self, category: str, key: str, default_override: Optional[Any] = None) -> Any:
        if default_override is not None:
            return self.settings.get(category, {}).get(key, default_override)
        # Fallback to master defaults if key somehow missing from self.settings
        return self.settings.get(category, {}).get(key, self.get_default_settings().get(category, {}).get(key))

    def set_value(self, category: str, key: str, value: Any):
        if category not in self.settings:
            self.settings[category] = {}
        self.settings[category][key] = value

# Global instance of settings manager
app_settings_manager = AppSettingsManager(ORG_NAME, APP_CFG_NAME, CONFIG_FILENAME)


class PreferencesDialog(QDialog):
    """
    A dialog for managing application-wide preferences.
    Preferences are organized into tabs.
    """
    # Signal to notify main application of settings changes that require action
    settings_applied_signal = pyqtSignal(dict) 

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Preferences")
        self.setMinimumSize(600, 500) # Adjusted size
        self.setModal(True)

        # Store a working copy of settings for the dialog to modify
        self.current_dialog_settings = json.loads(json.dumps(app_settings_manager.settings)) # Deep copy

        self._init_ui()
        self._populate_fields_from_dialog_settings()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        self.tab_widget = QTabWidget(self)

        self.tab_widget.addTab(self._create_paths_tab(), "Paths")
        self.tab_widget.addTab(self._create_analysis_tab(), "Analysis")
        self.tab_widget.addTab(self._create_ui_tab(), "User Interface")

        main_layout.addWidget(self.tab_widget)

        self.button_box = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel | QDialogButtonBox.Apply, self
        )
        self.button_box.button(QDialogButtonBox.Apply).clicked.connect(self._on_apply_settings)
        self.button_box.accepted.connect(self._on_accept_settings)
        self.button_box.rejected.connect(self.reject)
        main_layout.addWidget(self.button_box)

        self.setLayout(main_layout)

    def _create_paths_tab(self) -> QWidget:
        tab = QWidget(self)
        layout = QFormLayout(tab)
        layout.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        layout.setSpacing(10)

        self.proj_dir_edit = self._create_path_edit_row(layout, "Default Project Directory:", "Select default directory for new projects.", is_dir=True)
        self.nist_sqlite_edit = self._create_path_edit_row(layout, "NIST SQLite DB Path:", "Path to NIST ASD SQLite database file.", file_filter="SQLite DB (*.db *.sqlite *.sqlite3)")
        self.nist_csv_dir_edit = self._create_path_edit_row(layout, "NIST CSV Data Directory:", "Directory containing NIST ASD CSV files (if not using SQLite).", is_dir=True)
        self.user_db_edit = self._create_path_edit_row(layout, "User Custom Lines DB Path:", "Path to your custom spectral lines SQLite database.", file_filter="SQLite DB (*.sqlite *.db)", save_mode=True)
        
        return tab

    def _create_path_edit_row(self, form_layout: QFormLayout, label_text: str, tooltip: str, 
                              is_dir: bool = False, file_filter: Optional[str] = None, save_mode: bool = False) -> QLineEdit:
        line_edit = QLineEdit(self)
        line_edit.setToolTip(tooltip)
        browse_button = QPushButton("Browse...", self)
        if is_dir:
            browse_button.clicked.connect(lambda: self._browse_directory(line_edit))
        else:
            browse_button.clicked.connect(lambda: self._browse_file(line_edit, file_filter or "All Files (*)", save_mode))
        
        path_layout = QVBoxLayout()
        path_layout.addWidget(line_edit)
        path_layout.addWidget(browse_button)
        form_layout.addRow(label_text, path_layout)
        return line_edit

    def _create_analysis_tab(self) -> QWidget:
        tab = QWidget(self)
        layout = QFormLayout(tab)
        layout.setSpacing(10)

        self.el_id_tolerance_spinbox = QDoubleSpinBox(self)
        self.el_id_tolerance_spinbox.setDecimals(3)
        self.el_id_tolerance_spinbox.setRange(0.001, 5.0)
        self.el_id_tolerance_spinbox.setSingleStep(0.01)
        self.el_id_tolerance_spinbox.setToolTip("Default wavelength tolerance (nm) for elemental identification.")
        layout.addRow("Element ID Tolerance (nm):", self.el_id_tolerance_spinbox)

        self.peak_fit_window_spinbox = QDoubleSpinBox(self)
        self.peak_fit_window_spinbox.setDecimals(2)
        self.peak_fit_window_spinbox.setRange(0.1, 20.0)
        self.peak_fit_window_spinbox.setSingleStep(0.1)
        self.peak_fit_window_spinbox.setToolTip("Default window size (nm) around a peak for fitting routines.")
        layout.addRow("Peak Fitting Window (nm):", self.peak_fit_window_spinbox)

        self.auto_preprocess_checkbox = QCheckBox("Auto-apply default preprocessing on spectrum load", self)
        self.auto_preprocess_checkbox.setToolTip("If checked, predefined preprocessing steps will be automatically applied when a new spectrum is loaded.")
        layout.addRow(self.auto_preprocess_checkbox)
        
        return tab

    def _create_ui_tab(self) -> QWidget:
        tab = QWidget(self)
        layout = QFormLayout(tab)
        layout.setSpacing(10)

        self.theme_combo = QComboBox(self)
        self.theme_combo.addItems(["SystemDefault", "Light", "Dark"]) # "CustomQSS" removed for simplicity
        self.theme_combo.setToolTip("Select the application visual theme. Requires restart.")
        layout.addRow("Application Theme:", self.theme_combo)

        self.show_tooltips_checkbox = QCheckBox("Show tooltips for UI elements", self)
        self.show_tooltips_checkbox.setToolTip("Enable or disable helpful tooltips throughout the application.")
        layout.addRow(self.show_tooltips_checkbox)
        
        self.max_preview_lines_spinbox = QSpinBox(self)
        self.max_preview_lines_spinbox.setRange(5, 100)
        self.max_preview_lines_spinbox.setSingleStep(5)
        self.max_preview_lines_spinbox.setToolTip("Maximum number of lines to display in the file format configuration preview.")
        layout.addRow("Max lines in file preview:", self.max_preview_lines_spinbox)
        
        return tab

    def _browse_directory(self, line_edit_widget: QLineEdit):
        current_path = line_edit_widget.text()
        start_dir = current_path if current_path and Path(current_path).is_dir() else str(Path.home())
        directory = QFileDialog.getExistingDirectory(self, "Select Directory", start_dir)
        if directory:
            line_edit_widget.setText(directory)

    def _browse_file(self, line_edit_widget: QLineEdit, file_filter: str, save_mode: bool = False):
        current_path_str = line_edit_widget.text()
        start_dir = str(Path(current_path_str).parent) if current_path_str and Path(current_path_str).parent.exists() else str(Path.home())

        if save_mode:
             filename, _ = QFileDialog.getSaveFileName(self, "Set File Path", start_dir, file_filter)
        else:
            filename, _ = QFileDialog.getOpenFileName(self, "Select File", start_dir, file_filter)
        
        if filename:
            line_edit_widget.setText(filename)

    def _populate_fields_from_dialog_settings(self):
        # Paths
        self.proj_dir_edit.setText(self.current_dialog_settings["paths"]["default_project_dir"])
        self.nist_sqlite_edit.setText(self.current_dialog_settings["paths"]["nist_sqlite_db_path"])
        self.nist_csv_dir_edit.setText(self.current_dialog_settings["paths"]["nist_csv_dir_path"])
        self.user_db_edit.setText(self.current_dialog_settings["paths"]["user_custom_db_path"])
        # Analysis
        self.el_id_tolerance_spinbox.setValue(self.current_dialog_settings["analysis"]["default_element_id_tolerance_nm"])
        self.peak_fit_window_spinbox.setValue(self.current_dialog_settings["analysis"]["default_peak_fitting_window_nm"])
        self.auto_preprocess_checkbox.setChecked(self.current_dialog_settings["analysis"]["auto_apply_preprocessing_on_load"])
        # UI
        self.theme_combo.setCurrentText(self.current_dialog_settings["ui"]["theme"])
        self.show_tooltips_checkbox.setChecked(self.current_dialog_settings["ui"]["show_tooltips"])
        self.max_preview_lines_spinbox.setValue(self.current_dialog_settings["ui"]["max_preview_lines_in_file_format_dialog"])

    def _collect_settings_into_dialog_copy(self):
        # Paths
        self.current_dialog_settings["paths"]["default_project_dir"] = self.proj_dir_edit.text()
        self.current_dialog_settings["paths"]["nist_sqlite_db_path"] = self.nist_sqlite_edit.text()
        self.current_dialog_settings["paths"]["nist_csv_dir_path"] = self.nist_csv_dir_edit.text()
        self.current_dialog_settings["paths"]["user_custom_db_path"] = self.user_db_edit.text()
        # Analysis
        self.current_dialog_settings["analysis"]["default_element_id_tolerance_nm"] = self.el_id_tolerance_spinbox.value()
        self.current_dialog_settings["analysis"]["default_peak_fitting_window_nm"] = self.peak_fit_window_spinbox.value()
        self.current_dialog_settings["analysis"]["auto_apply_preprocessing_on_load"] = self.auto_preprocess_checkbox.isChecked()
        # UI
        self.current_dialog_settings["ui"]["theme"] = self.theme_combo.currentText()
        self.current_dialog_settings["ui"]["show_tooltips"] = self.show_tooltips_checkbox.isChecked()
        self.current_dialog_settings["ui"]["max_preview_lines_in_file_format_dialog"] = self.max_preview_lines_spinbox.value()


    def _on_apply_settings(self):
        self._collect_settings_into_dialog_copy()
        # Update the global settings manager with the dialog's current state
        app_settings_manager.settings = json.loads(json.dumps(self.current_dialog_settings)) # Deep copy
        app_settings_manager.save()
        self.settings_applied_signal.emit(app_settings_manager.settings)
        # QMessageBox.information(self, "Preferences Applied", "Settings have been saved. Some changes may require an application restart.")
        logger.info("Preferences applied by user.")
        # The 'Apply' button in QDialogButtonBox does not close the dialog by default.

    def _on_accept_settings(self):
        self._on_apply_settings() # Apply first
        self.accept() # Then accept (closes dialog)

    @staticmethod
    def edit_preferences(parent=None) -> bool:
        dialog = PreferencesDialog(parent)
        result = dialog.exec_()
        return result == QDialog.Accepted


if __name__ == '__main__':
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    app = QApplication(sys.argv)
    
    # QStandardPaths needs a properly set application and organization name for consistency
    QApplication.setOrganizationName(ORG_NAME)
    QApplication.setApplicationName(APP_CFG_NAME)


    logger.info(f"Using config file at: {app_settings_manager.get_config_filepath()}")

    # Optionally, clear existing test config file for a fresh start
    # test_config_file = app_settings_manager.get_config_filepath()
    # if test_config_file.exists():
    #     try:
    #         test_config_file.unlink()
    #         logger.info(f"Removed existing test config file: {test_config_file}")
    #     except OSError as e:
    #         logger.error(f"Could not remove test config file {test_config_file}: {e}")


    logger.info("Showing Preferences dialog...")
    # Example of connecting to the signal
    def handle_settings_applied(new_settings):
        logger.info("Signal 'settings_applied_signal' received by test handler.")
        # print("Applied settings in handler:", json.dumps(new_settings, indent=2))
        # In a real app, update relevant parts of the UI or application logic here
        if new_settings["ui"]["theme"] != app_settings_manager.settings["ui"]["theme"]: # Example check
            logger.info(f"Theme changed to: {new_settings['ui']['theme']}. App restart might be needed.")

    # Create dialog and connect signal before exec_
    # preferences_dialog = PreferencesDialog(None)
    # preferences_dialog.settings_applied_signal.connect(handle_settings_applied)
    # accepted = preferences_dialog.exec_()
    # Using static method:
    accepted = PreferencesDialog.edit_preferences(None)


    if accepted:
        logger.info("Preferences dialog accepted (OK or Apply then OK).")
        logger.info("Current saved settings after dialog:")
        logger.info(json.dumps(app_settings_manager.settings, indent=2))
    else:
        logger.info("Preferences dialog cancelled.")

    logger.info("\nPreferencesDialog tests completed.")
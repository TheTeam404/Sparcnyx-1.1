# team404/gui/ui_utils.py

"""
UI Utilities for SpectraMapper Pro.
Contains helper functions and classes for common GUI tasks,
such as creating standard dialogs, formatting, or utility widgets.
"""

import logging
import sys
from PyQt5.QtWidgets import (
    QMessageBox, QWidget, QInputDialog, QFontDialog, QColorDialog,
    QApplication, QLineEdit, QTextEdit, QDoubleSpinBox, QSpinBox,
    QComboBox, QLabel, QVBoxLayout, QAbstractSpinBox # Added QLabel, QVBoxLayout for example
)
from PyQt5.QtGui import QColor, QFont
from typing import Optional, Tuple, Any, List # Added List

logger = logging.getLogger(__name__)

# --- Standard Message Boxes ---

def show_info_message(parent: Optional[QWidget], title: str, message: str):
    """Displays a standard information message box."""
    QMessageBox.information(parent, title, message)
    logger.info(f"Info dialog shown: '{title}' - '{message}'")

def show_warning_message(parent: Optional[QWidget], title: str, message: str):
    """Displays a standard warning message box."""
    QMessageBox.warning(parent, title, message)
    logger.warning(f"Warning dialog shown: '{title}' - '{message}'")

def show_critical_message(parent: Optional[QWidget], title: str, message: str):
    """Displays a standard critical error message box."""
    QMessageBox.critical(parent, title, message)
    logger.error(f"Critical dialog shown: '{title}' - '{message}'")

def confirm_action(parent: Optional[QWidget], title: str, message: str,
                   default_button: QMessageBox.StandardButton = QMessageBox.No) -> bool:
    """
    Displays a confirmation dialog (Yes/No).

    Args:
        parent: Parent widget.
        title: Dialog title.
        message: Confirmation message.
        default_button: Which button is focused by default.

    Returns:
        True if "Yes" was clicked, False otherwise.
    """
    reply = QMessageBox.question(parent, title, message,
                                 QMessageBox.Yes | QMessageBox.No, default_button)
    logger.debug(f"Confirmation dialog '{title}': User chose {'Yes' if reply == QMessageBox.Yes else 'No'}")
    return reply == QMessageBox.Yes

# --- Standard Input Dialogs ---

def get_text_input(parent: Optional[QWidget], title: str, label: str,
                   default_text: str = "") -> Tuple[Optional[str], bool]:
    """
    Gets text input from the user.

    Returns:
        A tuple (text_string, ok_pressed). text_string is None if cancelled.
    """
    text, ok = QInputDialog.getText(parent, title, label, QLineEdit.Normal, default_text)
    if ok:
        logger.debug(f"Text input dialog '{title}': User entered '{text}' (OK)")
        return text, True
    logger.debug(f"Text input dialog '{title}': Cancelled by user.")
    return None, False

def get_integer_input(parent: Optional[QWidget], title: str, label: str,
                      default_value: int = 0, min_val: int = -2147483648,
                      max_val: int = 2147483647, step: int = 1) -> Tuple[Optional[int], bool]:
    """
    Gets integer input from the user.

    Returns:
        A tuple (integer_value, ok_pressed). integer_value is None if cancelled.
    """
    value, ok = QInputDialog.getInt(parent, title, label, default_value, min_val, max_val, step)
    if ok:
        logger.debug(f"Integer input dialog '{title}': User entered {value} (OK)")
        return value, True
    logger.debug(f"Integer input dialog '{title}': Cancelled by user.")
    return None, False

def get_double_input(parent: Optional[QWidget], title: str, label: str,
                     default_value: float = 0.0, min_val: float = -1.79e+308, # sys.float_info.min is too small
                     max_val: float = 1.79e+308,  # sys.float_info.max
                     decimals: int = 2) -> Tuple[Optional[float], bool]: # Step removed as QInputDialog.getDouble doesn't support it
    """
    Gets double/float input from the user.
    Note: QInputDialog.getDouble does not have a 'step' argument.

    Returns:
        A tuple (float_value, ok_pressed). float_value is None if cancelled.
    """
    value, ok = QInputDialog.getDouble(parent, title, label, default_value, min_val, max_val, decimals)
    if ok:
        logger.debug(f"Double input dialog '{title}': User entered {value} (OK)")
        return value, True
    logger.debug(f"Double input dialog '{title}': Cancelled by user.")
    return None, False

def get_item_from_list(parent: Optional[QWidget], title: str, label: str,
                       items: List[str], current_index: int = 0,
                       editable: bool = False) -> Tuple[Optional[str], bool]:
    """
    Gets an item selection from a list.

    Returns:
        A tuple (selected_item_string, ok_pressed). selected_item_string is None if cancelled.
    """
    # Ensure current_index is valid
    if not (0 <= current_index < len(items)) and items:
        logger.warning(f"Invalid current_index {current_index} for items list of length {len(items)}. Defaulting to 0.")
        current_index = 0
    elif not items: # No items, cannot select
        logger.warning(f"get_item_from_list called with empty items list for dialog '{title}'.")
        return None, False


    item, ok = QInputDialog.getItem(parent, title, label, items, current_index, editable)
    if ok:
        logger.debug(f"Item selection dialog '{title}': User selected '{item}' (OK)")
        return item, True # item can be an empty string if editable and user clears it
    logger.debug(f"Item selection dialog '{title}': Cancelled by user.")
    return None, False


# --- Standard Dialogs for Font and Color ---

def choose_font(parent: Optional[QWidget] = None, initial_font: Optional[QFont] = None,
                title: str = "Select Font") -> Tuple[Optional[QFont], bool]:
    """
    Opens a QFontDialog to let the user choose a font.

    Returns:
        A tuple (selected_font, ok_pressed). selected_font is None if cancelled.
    """
    if initial_font:
        font, ok = QFontDialog.getFont(initial_font, parent, title)
    else:
        font, ok = QFontDialog.getFont(QFont(), parent, title) # Pass a default QFont
    
    if ok:
        logger.debug(f"Font dialog: User selected font '{font.family()}' size {font.pointSize()} (OK)")
        return font, True
    logger.debug(f"Font dialog: Cancelled by user.")
    return None, False

def choose_color(parent: Optional[QWidget] = None, initial_color: Optional[QColor] = None,
                 title: str = "Select Color") -> Tuple[Optional[QColor], bool]:
    """
    Opens a QColorDialog to let the user choose a color.

    Returns:
        A tuple (selected_color, ok_pressed). selected_color is None if cancelled.
    """
    current_color = initial_color if initial_color else None
    color = QColorDialog.getColor(current_color, parent, title)
    
    if color.isValid():
        logger.debug(f"Color dialog: User selected color {color.name()} (OK)")
        return color, True
    logger.debug(f"Color dialog: Cancelled by user (or invalid color).")
    return None, False


# --- Other UI Helper Functions ---

def set_widget_read_only_recursive(widget: QWidget, read_only: bool):
    """
    Recursively sets the read-only state for a widget and its editable children.
    Supports QLineEdit, QTextEdit, QSpinBox, QDoubleSpinBox, QComboBox.
    """
    if isinstance(widget, (QLineEdit, QTextEdit)):
        widget.setReadOnly(read_only)
    elif isinstance(widget, (QSpinBox, QDoubleSpinBox)):
        widget.setReadOnly(read_only)
        widget.setButtonSymbols(QAbstractSpinBox.NoButtons if read_only else QAbstractSpinBox.UpDownArrows)
    elif isinstance(widget, QComboBox):
        if widget.isEditable():
            widget.lineEdit().setReadOnly(read_only)
        # Disabling the widget is the most common way to make a QComboBox "read-only"
        # in terms of preventing user interaction and selection changes.
        widget.setEnabled(not read_only)
    # For other complex widgets, specific handling might be needed.

    # Recursively apply to children. Using findChildren(QWidget) is broad.
    # Consider only children that are direct layout children or specific types
    # if performance becomes an issue on very complex UIs.
    # For now, this is generally acceptable.
    for child in widget.findChildren(QWidget):
        # Avoid re-processing the same widget if it's a child of itself (not typical)
        # or if the parent type already handled it (e.g. QComboBox lineEdit).
        # The current approach might call setReadOnly on a QComboBox's QLineEdit twice,
        # once through QComboBox case, once through QLineEdit case if findChildren picks it up.
        # This is harmless.
        if child != widget : # Basic check to avoid self-recursion on widget itself if it lists itself as child
            set_widget_read_only_recursive(child, read_only)


def get_clipboard_text() -> Optional[str]:
    """Gets text from the system clipboard."""
    clipboard = QApplication.clipboard()
    if clipboard is None: # Should not happen in a running QApplication
        logger.warning("QApplication.clipboard() returned None.")
        return None
    return clipboard.text()

def set_clipboard_text(text: str):
    """Sets text to the system clipboard."""
    clipboard = QApplication.clipboard()
    if clipboard is None:
        logger.warning("QApplication.clipboard() returned None. Cannot set text.")
        return
    clipboard.setText(text)
    logger.debug(f"Text copied to clipboard: '{text[:50]}{'...' if len(text) > 50 else ''}'")


if __name__ == '__main__':
    # Ensure an application instance exists for dialogs and clipboard
    app = QApplication.instance() 
    if app is None:
        app = QApplication(sys.argv)

    logging.basicConfig(level=logging.DEBUG) # Show debug logs for testing

    # --- Test Message Boxes ---
    print("\n--- Testing Message Boxes ---")
    show_info_message(None, "Information", "This is an informational message.")
    confirmed = confirm_action(None, "Confirmation", "Are you sure you want to proceed?")
    print(f"Action confirmed: {confirmed}")
    if not confirmed:
        show_warning_message(None, "Action Cancelled", "The previous action was cancelled by the user.")
    show_critical_message(None, "Critical Test", "This is a test critical message.")
    
    # --- Test Input Dialogs ---
    print("\n--- Testing Input Dialogs ---")
    name, ok_name = get_text_input(None, "Enter Name", "Please enter your name:", "User")
    if ok_name: print(f"Name entered: {name}")

    age, ok_age = get_integer_input(None, "Enter Age", "Your age:", 25, 0, 120)
    if ok_age: print(f"Age entered: {age}")

    value, ok_val = get_double_input(None, "Enter Value", "Measurement:", 10.5, 0.0, 100.0, 3)
    if ok_val: print(f"Value entered: {value}")

    items = ["Apple", "Banana", "", "Cherry", "Date"] # Added empty string as valid item
    choice, ok_choice = get_item_from_list(None, "Select Fruit", "Favorite fruit:", items, 1)
    if ok_choice: print(f"Fruit selected: '{choice}'") # Quoted to show empty string if selected

    # --- Test Font and Color Dialogs ---
    print("\n--- Testing Font and Color Dialogs ---")
    dummy_label_font = QLabel("Test Font Here") # Create a widget to apply font
    
    font, ok_font = choose_font(None)
    if ok_font:
        print(f"Font selected: {font.family()}, Size: {font.pointSize()}")
        dummy_label_font.setFont(font)
        dummy_label_font.setWindowTitle("Font Test")
        dummy_label_font.show()
        show_info_message(dummy_label_font, "Font Applied", "Check the font on the 'Test Font Here' label. Close it to continue.")
        dummy_label_font.close()


    dummy_widget_color = QWidget()
    dummy_widget_color.setFixedSize(100,50)
    dummy_widget_color.setWindowTitle("Color Test")

    color, ok_color = choose_color(None, initial_color=QColor("blue"))
    if ok_color:
        print(f"Color selected: RGB={color.red()},{color.green()},{color.blue()}, Name: {color.name()}")
        dummy_widget_color.setStyleSheet(f"background-color: {color.name()};")
        dummy_widget_color.show()
        show_info_message(dummy_widget_color, "Color Applied", f"Check the background color ({color.name()}). Close it to continue.")
        dummy_widget_color.close()


    # --- Test Clipboard ---
    print("\n--- Testing Clipboard ---")
    original_clipboard = get_clipboard_text() # Save original clipboard content
    test_clip_text = "Hello from SpectraMapper Pro UI Utils! Test."
    set_clipboard_text(test_clip_text)
    retrieved_text = get_clipboard_text()
    print(f"Clipboard test: Set text, retrieved '{retrieved_text}'")
    assert retrieved_text == test_clip_text, "Clipboard text mismatch!"
    if original_clipboard is not None : set_clipboard_text(original_clipboard) # Restore original

    # --- Test set_widget_read_only_recursive ---
    print("\n--- Testing Read-Only Recursive Setter ---")
    test_container = QWidget()
    test_layout = QVBoxLayout(test_container)
    
    le = QLineEdit("Editable LineEdit")
    te = QTextEdit("Editable TextEdit")
    sb = QSpinBox(); sb.setValue(5); sb.setPrefix("Val: ")
    dsb = QDoubleSpinBox(); dsb.setValue(3.14); dsb.setSuffix(" units")
    cb_non_editable = QComboBox(); cb_non_editable.addItems(["Choice A", "Choice B"])
    cb_editable = QComboBox(); cb_editable.addItems(["Edit X", "Edit Y"]); cb_editable.setEditable(True)
    
    test_layout.addWidget(QLabel("Test various widgets:"))
    test_layout.addWidget(le)
    test_layout.addWidget(te)
    test_layout.addWidget(sb)
    test_layout.addWidget(dsb)
    test_layout.addWidget(QLabel("Non-Editable ComboBox:"))
    test_layout.addWidget(cb_non_editable)
    test_layout.addWidget(QLabel("Editable ComboBox:"))
    test_layout.addWidget(cb_editable)
    
    test_container.setWindowTitle("Read-Only Test Container")
    test_container.show()
    
    show_info_message(test_container, "Initial State", "Widgets are now editable. Verify, then click OK.")
    
    print("Setting widgets to read-only...")
    set_widget_read_only_recursive(test_container, True)
    test_container.setWindowTitle("Read-Only Test Container (Read-Only Mode)") # Update title
    show_info_message(test_container, "Read-Only State", "Widgets should now be read-only/disabled. Verify, then click OK.")
    
    print("Setting widgets back to editable...")
    set_widget_read_only_recursive(test_container, False)
    test_container.setWindowTitle("Read-Only Test Container (Editable Mode)") # Update title
    show_info_message(test_container, "Editable State Again", "Widgets should be editable again. Verify, then click OK to finish tests.")
    
    test_container.close() # Close the test container

    print("\nAll UI Utilities tests completed.")
    # sys.exit(app.exec_()) # Not strictly needed if all test windows are closed.
                           # However, if any test widget remains, app.exec_() is required.
                           # Since we explicitly close test widgets, this can be omitted or kept for safety.
    if app: # Only exit if we created the app instance here for testing.
        # sys.exit(app.exec_()) # This might be problematic if run in an env that already has an event loop (e.g. Jupyter)
        pass # Let the script end, app will terminate.
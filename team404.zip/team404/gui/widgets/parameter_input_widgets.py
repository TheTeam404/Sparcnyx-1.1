# team404/gui/widgets/parameter_input_widgets.py

"""
ParameterInputWidgets for SpectraMapper Pro.
Provides dynamic widgets for inputting various types of parameters.
"""

import logging
import sys
from PyQt5.QtWidgets import (
    QWidget, QFormLayout, QLabel, QLineEdit, QSpinBox, QDoubleSpinBox,
    QComboBox, QCheckBox, QPushButton, QFileDialog, QHBoxLayout,
    QSizePolicy, QApplication, QDialog, QVBoxLayout, QSpacerItem
)
from PyQt5.QtCore import pyqtSignal, Qt
from typing import Dict, Any, List, Tuple, Union, Callable, Optional
import os

logger = logging.getLogger(__name__)

# Define supported parameter types
PARAM_TYPE_INT = "int"
PARAM_TYPE_FLOAT = "float"
PARAM_TYPE_STRING = "str"
PARAM_TYPE_BOOL = "bool"
PARAM_TYPE_CHOICE = "choice" # For QComboBox
PARAM_TYPE_FILEPATH = "filepath"
PARAM_TYPE_DIRPATH = "dirpath"
# PARAM_TYPE_ROI = "roi" # More complex, would need a dedicated widget/dialog

class ParameterPanel(QWidget):
    """
    A dynamic panel that creates input widgets based on a list of parameter definitions.
    Each parameter definition is a dictionary specifying its name, type, default value,
    and other type-specific options (e.g., range for numbers, choices for combo box).
    """
    parameters_changed = pyqtSignal(dict) # Emits the full dict of current parameters

    def __init__(self, param_definitions: List[Dict[str, Any]], parent=None):
        """
        Initializes the ParameterPanel.

        Args:
            param_definitions: A list of dictionaries, where each dictionary defines a parameter.
                Example definition:
                {
                    "name": "my_param_name",  # Internal key
                    "label": "My Parameter Label:", # Display label
                    "type": "int" / "float" / "str" / "bool" / "choice",
                    "default": 10,
                    "tooltip": "Helpful description.",
                    # Type-specific options:
                    "range": (0, 100),        # For int/float (min, max)
                    "step": 1,                # For int/float
                    "decimals": 2,            # For float
                    "choices": ["A", "B"],    # For choice
                    "editable_choice": False, # For choice (QComboBox.setEditable)
                    "file_filter": "Text Files (*.txt)", # For filepath
                    "placeholder": "Enter text" # For str
                }
            parent: Parent widget.
        """
        super().__init__(parent)
        self.param_definitions = param_definitions
        self.param_widgets: Dict[str, QWidget] = {} # name: QWidget

        self._init_ui()
        self._apply_initial_focus()

    def _init_ui(self):
        layout = QFormLayout(self)
        layout.setContentsMargins(0, 0, 0, 0) # No margins if embedded
        layout.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        self.setLayout(layout)

        for p_def in self.param_definitions:
            name = p_def.get("name")
            label_text = p_def.get("label", name.replace("_", " ").title() + ":") # Auto-generate label
            param_type = p_def.get("type", PARAM_TYPE_STRING)
            default_value = p_def.get("default")
            tooltip = p_def.get("tooltip", "")

            widget: Optional[QWidget] = None

            if param_type == PARAM_TYPE_INT:
                min_val, max_val = p_def.get("range", (0, 1000000))
                step = p_def.get("step", 1)
                spinbox = QSpinBox()
                spinbox.setRange(min_val, max_val)
                spinbox.setSingleStep(step)
                spinbox.setValue(int(default_value) if default_value is not None else min_val)
                spinbox.valueChanged.connect(self._emit_parameters_changed)
                widget = spinbox
            
            elif param_type == PARAM_TYPE_FLOAT:
                min_val, max_val = p_def.get("range", (0.0, 1e9))
                step = p_def.get("step", 0.1)
                decimals = p_def.get("decimals", 2)
                dbl_spinbox = QDoubleSpinBox()
                dbl_spinbox.setDecimals(decimals)
                dbl_spinbox.setRange(min_val, max_val)
                dbl_spinbox.setSingleStep(step)
                dbl_spinbox.setValue(float(default_value) if default_value is not None else min_val)
                dbl_spinbox.valueChanged.connect(self._emit_parameters_changed)
                widget = dbl_spinbox

            elif param_type == PARAM_TYPE_STRING:
                line_edit = QLineEdit()
                line_edit.setText(str(default_value) if default_value is not None else "")
                if "placeholder" in p_def:
                    line_edit.setPlaceholderText(p_def["placeholder"])
                line_edit.textChanged.connect(self._emit_parameters_changed)
                widget = line_edit

            elif param_type == PARAM_TYPE_BOOL:
                checkbox = QCheckBox()
                checkbox.setChecked(bool(default_value) if default_value is not None else False)
                checkbox.toggled.connect(self._emit_parameters_changed)
                # For QFormLayout, QCheckBox often looks better if the label is part of the checkbox text
                label_text = "" # Clear separate label
                checkbox.setText(p_def.get("label", name.replace("_", " ").title()))
                layout.addRow(checkbox) # Add directly without a separate label
                self.param_widgets[name] = checkbox
                if tooltip: checkbox.setToolTip(tooltip)
                continue # Skip standard addRow for checkbox

            elif param_type == PARAM_TYPE_CHOICE:
                combobox = QComboBox()
                choices = p_def.get("choices", [])
                if isinstance(choices, dict): # Allow {display_name: value}
                    for display, val_choice in choices.items():
                        combobox.addItem(display, val_choice) # Store actual value in UserData
                else: # List of strings
                    combobox.addItems(choices)
                
                if default_value is not None:
                    idx = combobox.findData(default_value) if isinstance(choices, dict) else combobox.findText(str(default_value))
                    if idx != -1:
                        combobox.setCurrentIndex(idx)
                combobox.setEditable(p_def.get("editable_choice", False))
                combobox.currentTextChanged.connect(self._emit_parameters_changed)
                widget = combobox

            elif param_type == PARAM_TYPE_FILEPATH or param_type == PARAM_TYPE_DIRPATH:
                path_widget = QWidget()
                path_layout = QHBoxLayout(path_widget)
                path_layout.setContentsMargins(0,0,0,0)
                
                path_edit = QLineEdit()
                path_edit.setText(str(default_value) if default_value is not None else "")
                if "placeholder" in p_def:
                    path_edit.setPlaceholderText(p_def["placeholder"])
                path_edit.textChanged.connect(self._emit_parameters_changed)
                
                browse_button = QPushButton("Browse...")
                if param_type == PARAM_TYPE_FILEPATH:
                    file_filter = p_def.get("file_filter", "All Files (*)")
                    save_mode = p_def.get("save_mode", False)
                    browse_button.clicked.connect(lambda checked=False, le=path_edit, filt=file_filter, sm=save_mode: self._browse_path(le, filt, directory=False, save_mode=sm))
                else: # DIRPATH
                    browse_button.clicked.connect(lambda checked=False, le=path_edit: self._browse_path(le, directory=True))
                
                path_layout.addWidget(path_edit)
                path_layout.addWidget(browse_button)
                widget = path_widget
                # Special handling for widget retrieval for path types
                self.param_widgets[name] = path_edit # Store the QLineEdit for get_parameters
                if tooltip: path_edit.setToolTip(tooltip) # Tooltip on line edit
            
            else:
                widget = QLabel(f"Unsupported param type: {param_type}")

            if widget and name and param_type != PARAM_TYPE_BOOL: # BOOL handled above
                if tooltip: widget.setToolTip(tooltip)
                layout.addRow(label_text, widget)
                if param_type not in [PARAM_TYPE_FILEPATH, PARAM_TYPE_DIRPATH]: # Path types already stored QLineEdit
                    self.param_widgets[name] = widget
        
        layout.addItem(QSpacerItem(20, 10, QSizePolicy.Minimum, QSizePolicy.Expanding))


    def _apply_initial_focus(self):
        """Sets focus to the first input widget if available."""
        if self.param_definitions:
            first_param_name = self.param_definitions[0]["name"]
            if first_param_name in self.param_widgets:
                widget_to_focus = self.param_widgets[first_param_name]
                # For path types, focus the QLineEdit part
                if isinstance(widget_to_focus, QWidget) and not isinstance(widget_to_focus, QLineEdit) and \
                   self.param_definitions[0].get("type") in [PARAM_TYPE_FILEPATH, PARAM_TYPE_DIRPATH]:
                    # This logic is a bit fragile. Assumes the line edit is the first child of the QHBoxLayout widget
                    try:
                        line_edit_child = widget_to_focus.layout().itemAt(0).widget()
                        if isinstance(line_edit_child, QLineEdit):
                            widget_to_focus = line_edit_child
                    except AttributeError:
                        pass # Could not find line edit child

                widget_to_focus.setFocus()


    def _emit_parameters_changed(self):
        self.parameters_changed.emit(self.get_parameters())

    def _browse_path(self, line_edit_widget: QLineEdit, file_filter: str = "", directory: bool = False, save_mode: bool = False):
        current_path = line_edit_widget.text()
        start_dir = os.path.dirname(current_path) if current_path and os.path.exists(os.path.dirname(current_path)) \
                    else os.path.expanduser("~")
        
        path = ""
        if directory:
            path = QFileDialog.getExistingDirectory(self, "Select Directory", start_dir)
        elif save_mode:
            path, _ = QFileDialog.getSaveFileName(self, "Set File Path", start_dir, file_filter)
        else: # Open file
            path, _ = QFileDialog.getOpenFileName(self, "Select File", start_dir, file_filter)
        
        if path:
            line_edit_widget.setText(path)
            # self._emit_parameters_changed() # textChanged on QLineEdit will already do this

    def get_parameters(self) -> Dict[str, Any]:
        """Returns a dictionary of the current parameter values."""
        current_params = {}
        for p_def in self.param_definitions:
            name = p_def["name"]
            widget = self.param_widgets.get(name)
            param_type = p_def.get("type")

            if widget:
                if param_type == PARAM_TYPE_INT:
                    current_params[name] = widget.value()
                elif param_type == PARAM_TYPE_FLOAT:
                    current_params[name] = widget.value()
                elif param_type == PARAM_TYPE_STRING:
                    current_params[name] = widget.text()
                elif param_type == PARAM_TYPE_BOOL: # QCheckBox
                    current_params[name] = widget.isChecked()
                elif param_type == PARAM_TYPE_CHOICE: # QComboBox
                    if isinstance(p_def.get("choices"), dict): # Stored data in UserRole
                        current_params[name] = widget.currentData()
                    else: # Stored text
                        current_params[name] = widget.currentText()
                elif param_type in [PARAM_TYPE_FILEPATH, PARAM_TYPE_DIRPATH]: # QLineEdit (stored in self.param_widgets)
                    current_params[name] = widget.text()
            else:
                logger.warning(f"Widget for parameter '{name}' not found during get_parameters.")
        return current_params

    def set_parameters(self, params_to_set: Dict[str, Any]):
        """Sets the values of the UI widgets based on a dictionary."""
        for p_def in self.param_definitions:
            name = p_def["name"]
            widget = self.param_widgets.get(name)
            param_type = p_def.get("type")

            if name in params_to_set and widget:
                value = params_to_set[name]
                try:
                    if param_type == PARAM_TYPE_INT:
                        widget.setValue(int(value))
                    elif param_type == PARAM_TYPE_FLOAT:
                        widget.setValue(float(value))
                    elif param_type == PARAM_TYPE_STRING:
                        widget.setText(str(value))
                    elif param_type == PARAM_TYPE_BOOL:
                        widget.setChecked(bool(value))
                    elif param_type == PARAM_TYPE_CHOICE:
                        idx = -1
                        if isinstance(p_def.get("choices"), dict):
                            idx = widget.findData(value)
                        else:
                            idx = widget.findText(str(value))
                        if idx != -1: widget.setCurrentIndex(idx)
                        else: logger.warning(f"Choice '{value}' not found for parameter '{name}'.")
                    elif param_type in [PARAM_TYPE_FILEPATH, PARAM_TYPE_DIRPATH]:
                        widget.setText(str(value))
                except Exception as e:
                    logger.error(f"Error setting parameter '{name}' to value '{value}': {e}")
        self._emit_parameters_changed() # Emit after setting all


if __name__ == '__main__':
    app = QApplication(sys.argv)

    # Example Parameter Definitions
    example_definitions = [
        {"name": "threshold", "label": "Detection Threshold:", "type": PARAM_TYPE_FLOAT, "default": 10.5, "range": (0, 1000), "step": 0.1, "decimals": 2, "tooltip": "Minimum signal intensity."},
        {"name": "window_size", "label": "Window Size (points):", "type": PARAM_TYPE_INT, "default": 5, "range": (3, 51), "step": 2, "tooltip": "Must be an odd integer."},
        {"name": "filter_method", "label": "Filter Method:", "type": PARAM_TYPE_CHOICE, "default": "Gaussian", "choices": ["Mean", "Median", "Gaussian"], "tooltip": "Select the smoothing filter."},
        {"name": "output_filename", "label": "Output File:", "type": PARAM_TYPE_STRING, "default": "results.txt", "placeholder": "Enter filename"},
        {"name": "enable_correction", "label": "Enable Correction Feature", "type": PARAM_TYPE_BOOL, "default": True},
        {"name": "data_file", "label": "Input Data File:", "type": PARAM_TYPE_FILEPATH, "default": "", "file_filter": "Text files (*.txt);;CSV files (*.csv)"},
        {"name": "output_dir", "label": "Output Directory:", "type": PARAM_TYPE_DIRPATH, "default": os.path.expanduser("~")},
        {"name": "mode_selection_data", "label": "Processing Mode (Data):", "type": PARAM_TYPE_CHOICE, "default": "B",
         "choices": {"Alpha Mode": "A", "Beta Mode": "B", "Gamma Mode": "C"}, "tooltip":"Select processing mode based on data."}
    ]

    dialog = QDialog()
    dialog.setWindowTitle("Parameter Panel Test")
    layout = QVBoxLayout(dialog)
    
    param_panel = ParameterPanel(example_definitions)
    param_panel.parameters_changed.connect(lambda p: print("Parameters changed:", p))
    
    layout.addWidget(param_panel)
    
    get_button = QPushButton("Get Current Parameters")
    get_button.clicked.connect(lambda: print("Button Get:", param_panel.get_parameters()))
    layout.addWidget(get_button)

    set_button = QPushButton("Set Some Parameters")
    def set_some():
        param_panel.set_parameters({
            "threshold": 55.7,
            "filter_method": "Median", # Matches display text if choices is a list
            "output_filename": "new_results.csv",
            "enable_correction": False,
            "mode_selection_data": "C" # Matches value if choices is a dict
        })
        print("Set parameters externally. Current:", param_panel.get_parameters())
    set_button.clicked.connect(set_some)
    layout.addWidget(set_button)

    dialog.show()
    sys.exit(app.exec_())
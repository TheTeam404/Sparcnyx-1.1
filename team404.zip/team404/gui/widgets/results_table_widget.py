# team404/gui/widgets/results_table_widget.py

"""
ResultsTableWidget for SpectraMapper Pro.
A custom QTableWidget subclass tailored for displaying various types of
tabular results (e.g., peak lists, elemental ID matches, model metrics).
"""

import logging
import sys
from PyQt5.QtWidgets import (
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QMenu, QAction, QApplication, QStyledItemDelegate, QStyleOptionViewItem,
    QStyle, QLabel, QVBoxLayout, QDialog
)
from PyQt5.QtCore import Qt, QPoint, pyqtSignal, QModelIndex
from PyQt5.QtGui import QColor, QBrush
from typing import List, Dict, Any, Optional, Union
import numpy as np
import pandas as pd # For easy conversion from/to DataFrame

logger = logging.getLogger(__name__)

class NumericItemDelegate(QStyledItemDelegate):
    """Delegate to right-align numeric data and format floats."""
    def __init__(self, precision: int = 3, parent=None):
        super().__init__(parent)
        self.precision = precision

    def displayText(self, value: Any, locale) -> str:
        try:
            # Try to convert to float for formatting
            num_value = float(value)
            # Check if it's essentially an integer
            if num_value == int(num_value):
                return f"{int(num_value)}" # Format as int if no decimal part
            return f"{num_value:.{self.precision}f}"
        except (ValueError, TypeError):
            return str(value) # Return as string if not a number

    def initStyleOption(self, option: QStyleOptionViewItem, index: QModelIndex):
        super().initStyleOption(option, index)
        # Right-align numeric data (could also check data type if stored)
        try:
            float(index.model().data(index, Qt.DisplayRole)) # Check if convertible to float
            option.displayAlignment = Qt.AlignRight | Qt.AlignVCenter
        except (ValueError, TypeError):
            option.displayAlignment = Qt.AlignLeft | Qt.AlignVCenter


class ResultsTableWidget(QTableWidget):
    """
    A specialized QTableWidget for displaying results with common features like
    sorting, context menus, and easy data population from lists of dicts or DataFrames.
    """
    # Signal(s) for specific interactions if needed, e.g., row double-clicked
    # row_double_clicked_data = pyqtSignal(dict) # Emits data of the double-clicked row

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_default_settings()
        self._column_data_types: List[Optional[type]] = [] # To store type info for sorting/delegates
        self._numeric_delegate = NumericItemDelegate(precision=3, parent=self)

    def _init_default_settings(self):
        """Applies common default settings to the table."""
        self.setEditTriggers(QAbstractItemView.NoEditTriggers) # Default to read-only
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setSelectionMode(QAbstractItemView.SingleSelection) # Default to single row select
        self.setAlternatingRowColors(True)
        self.setSortingEnabled(True)
        self.horizontalHeader().setStretchLastSection(True)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive) # Allow user resize
        self.verticalHeader().setVisible(False) # Hide row numbers by default
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._default_context_menu)

    def set_column_data_types(self, types: List[Optional[type]]):
        """
        Sets the data types for columns to enable better sorting and display.
        Example: [str, float, int, None, float]
        None means default string handling.
        """
        self._column_data_types = types
        # Apply numeric delegate to float/int columns
        for col_idx, col_type in enumerate(types):
            if col_type in [float, int]:
                self.setItemDelegateForColumn(col_idx, self._numeric_delegate)
            else:
                # Reset to default delegate if type is not numeric or None
                self.setItemDelegateForColumn(col_idx, QStyledItemDelegate(self))


    def populate_from_list_of_dicts(self, data: List[Dict[str, Any]], headers: Optional[List[str]] = None):
        """
        Populates the table from a list of dictionaries.
        If headers are not provided, keys from the first dictionary are used.

        Args:
            data: List of dictionaries, where each dict represents a row.
            headers: Optional list of header strings (column names). If provided,
                     these keys will be looked up in the dictionaries.
        """
        self.setSortingEnabled(False) # Turn off sorting during population for speed
        self.clearContents()
        self.setRowCount(0)

        if not data:
            if headers: # Still set headers if data is empty but headers are given
                self.setColumnCount(len(headers))
                self.setHorizontalHeaderLabels(headers)
            else:
                self.setColumnCount(0)
            self.setSortingEnabled(True)
            return

        if headers is None:
            # Infer headers from keys of the first dictionary, maintaining order if Python 3.7+
            headers = list(data[0].keys())

        self.setColumnCount(len(headers))
        self.setHorizontalHeaderLabels(headers)
        self.setRowCount(len(data))

        for row_idx, row_data_dict in enumerate(data):
            for col_idx, header_key in enumerate(headers):
                value = row_data_dict.get(header_key)
                
                # Create QTableWidgetItem; handle numeric types for proper sorting
                item: QTableWidgetItem
                if isinstance(value, (int, float, np.integer, np.floating)):
                    item = QTableWidgetItem()
                    item.setData(Qt.EditRole, value) # Store actual numeric data for sorting
                elif value is None:
                    item = QTableWidgetItem("") # Empty string for None
                else:
                    item = QTableWidgetItem(str(value))
                
                self.setItem(row_idx, col_idx, item)
        
        self.resizeColumnsToContents()
        if self.columnCount() > 0:
            self.horizontalHeader().setStretchLastSection(True)
        self.setSortingEnabled(True)

    def populate_from_dataframe(self, df: pd.DataFrame):
        """Populates the table from a pandas DataFrame."""
        headers = list(df.columns)
        data_list_of_dicts = df.to_dict(orient='records')
        
        # Infer column types for delegate and sorting
        col_types = []
        for dtype in df.dtypes:
            if pd.api.types.is_integer_dtype(dtype):
                col_types.append(int)
            elif pd.api.types.is_float_dtype(dtype) or pd.api.types.is_numeric_dtype(dtype): # Catch other numeric like Decimal
                col_types.append(float)
            else:
                col_types.append(str) # Default to string for objects, bools, etc.
        self.set_column_data_types(col_types)
        
        self.populate_from_list_of_dicts(data_list_of_dicts, headers)


    def get_selected_rows_data(self) -> List[Dict[str, Any]]:
        """
        Returns data for all selected rows as a list of dictionaries.
        Keys in dict are header labels.
        """
        selected_data = []
        selected_rows_indices = sorted(list(set(index.row() for index in self.selectedIndexes())))
        
        headers = [self.horizontalHeaderItem(i).text() for i in range(self.columnCount())]

        for row_idx in selected_rows_indices:
            row_dict = {}
            for col_idx, header in enumerate(headers):
                item = self.item(row_idx, col_idx)
                if item:
                    # Try to get original data if numeric, otherwise text
                    data_val = item.data(Qt.EditRole) # For numeric items
                    if data_val is None: # If EditRole was not set, fall back to DisplayRole (text)
                        data_val = item.text()
                    row_dict[header] = data_val
            selected_data.append(row_dict)
        return selected_data

    def get_row_data_as_dict(self, row_index: int) -> Optional[Dict[str, Any]]:
        """Returns data for a specific row as a dictionary."""
        if not (0 <= row_index < self.rowCount()):
            return None
        
        headers = [self.horizontalHeaderItem(i).text() for i in range(self.columnCount())]
        row_dict = {}
        for col_idx, header in enumerate(headers):
            item = self.item(row_index, col_idx)
            if item:
                data_val = item.data(Qt.EditRole)
                if data_val is None: data_val = item.text()
                row_dict[header] = data_val
        return row_dict


    def _default_context_menu(self, position: QPoint):
        """Shows a default context menu with a 'Copy' action."""
        menu = QMenu(self)
        copy_action = QAction("Copy Selected Cell(s)", self)
        copy_action.triggered.connect(self._copy_selection_to_clipboard)
        copy_action.setEnabled(bool(self.selectedItems()))
        menu.addAction(copy_action)

        # Add more actions here if needed, or allow subclasses to extend
        self.add_custom_context_menu_actions(menu)

        if menu.actions(): # Only show if there are actions
            menu.exec_(self.viewport().mapToGlobal(position))

    def add_custom_context_menu_actions(self, menu: QMenu):
        """
        Placeholder for subclasses to add their own custom actions to the context menu.
        """
        pass # Subclasses can override this


    def _copy_selection_to_clipboard(self):
        """Copies the selected cells' text to the clipboard as tab-separated values."""
        if not self.selectedItems():
            return

        # Get data in the order of selection (top-left to bottom-right)
        selection_ranges = self.selectedRanges()
        if not selection_ranges:
            return

        # For simplicity, handling the first range. Multiple disjoint ranges are complex.
        first_range = selection_ranges[0]
        min_row, max_row = first_range.topRow(), first_range.bottomRow()
        min_col, max_col = first_range.leftColumn(), first_range.rightColumn()
        
        clipboard_text = []
        for r in range(min_row, max_row + 1):
            row_data = []
            for c in range(min_col, max_col + 1):
                item = self.item(r, c)
                if item:
                    # Use display text for copying
                    row_data.append(item.text())
                else:
                    row_data.append("") # Empty string for empty cells in selection
            clipboard_text.append("\t".join(row_data))
        
        QApplication.clipboard().setText("\n".join(clipboard_text))
        logger.info("Selected table data copied to clipboard.")


if __name__ == '__main__':
    app = QApplication(sys.argv)

    # --- Test ResultsTableWidget ---
    dialog = QDialog()
    dialog.setWindowTitle("ResultsTableWidget Test")
    layout = QVBoxLayout(dialog)

    results_table = ResultsTableWidget()
    
    # Test populate_from_list_of_dicts
    list_data = [
        {"ID": 1, "Name": "Alpha", "Value": 10.12345, "Valid": True},
        {"ID": 2, "Name": "Beta", "Value": -5.678, "Valid": False, "Notes": "Check this"},
        {"ID": 3, "Name": "Gamma", "Value": 123, "Valid": True},
        {"ID": 4, "Name": "Delta", "Value": None, "Valid": None} # Test None values
    ]
    results_table.set_column_data_types([int, str, float, bool, str]) # Specify types
    results_table.populate_from_list_of_dicts(list_data)
    layout.addWidget(results_table)

    # Test populate_from_dataframe
    df_data = {
        'Element': ['Fe', 'Ca', 'Mg', 'Si'],
        'Wavelength (nm)': [248.327, 393.366, 285.213, 288.158],
        'Intensity (a.u.)': [1500.75, 22000.1, 850.0, 120.555],
        'Identified': [True, True, False, True]
    }
    df = pd.DataFrame(df_data)
    
    df_table = ResultsTableWidget()
    df_table.populate_from_dataframe(df) # Types inferred from DataFrame dtypes
    layout.addWidget(QLabel("DataFrame Populated Table:"))
    layout.addWidget(df_table)
    
    # Test getting selected data
    def on_selection_changed():
        selected = results_table.get_selected_rows_data()
        if selected:
            print("Selected data (list_of_dicts):", selected)
        selected_df = df_table.get_selected_rows_data()
        if selected_df:
            print("Selected data (DataFrame table):", selected_df)

    results_table.itemSelectionChanged.connect(on_selection_changed)
    df_table.itemSelectionChanged.connect(on_selection_changed)
    
    # Allow multi-selection for testing copy
    results_table.setSelectionMode(QAbstractItemView.ExtendedSelection)


    dialog.resize(600, 500)
    dialog.show()
    sys.exit(app.exec_())
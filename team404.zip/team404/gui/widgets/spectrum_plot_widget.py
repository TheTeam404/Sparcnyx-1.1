# team404/gui/widgets/spectrum_plot_widget.py

"""
SpectrumPlotWidget for SpectraMapper Pro.
A custom QWidget that embeds a Matplotlib FigureCanvas for plotting spectra,
maps, and other analysis results with improved robustness and interactivity.
"""

import logging
from typing import Optional, List, Tuple, Any, Dict, Callable, Union

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QSizePolicy, QLabel, QApplication
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QFontMetrics # For button sizing

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
from matplotlib.artist import Artist
from matplotlib.axes import Axes as MplAxes # For type hinting self.axes
from matplotlib.lines import Line2D # For legend items
from matplotlib.collections import PathCollection # For scatter plot items
import matplotlib.pyplot as plt # For colormaps if needed by name
import numpy as np

logger = logging.getLogger(__name__)

MIN_PIXEL_DIM_FOR_MATPLOTLIB = 20 # Increased slightly
RESIZE_DEBOUNCE_MS = 75 # Milliseconds to wait after resize event before redrawing figure

class SpectrumPlotWidget(QWidget):
    """
    Custom Matplotlib plotting widget.
    Features: Debounced resizing, clear plot/message display, specific plot types,
              highlighting capabilities, and map click interactions.
    """
    map_pixel_clicked = pyqtSignal(float, float, object) # x_data, y_data, intensity_at_pixel

    def __init__(self, parent: Optional[QWidget] = None, width: int = 5, height: int = 4, dpi: int = 100):
        super().__init__(parent)

        self.figure = Figure(figsize=(width, height), dpi=dpi, constrained_layout=False) # Start with False
        # Using constrained_layout=True can help, but sometimes needs careful management.
        # We will call tight_layout manually where appropriate.
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self.toolbar = NavigationToolbar(self.canvas, self) # Parent toolbar to self

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)
        self.setLayout(layout)

        self.axes: Optional[MplAxes] = None
        self.axes2: Optional[MplAxes] = None # For secondary y-axis
        self.current_plot_type: Optional[str] = None
        self.active_cid_map_click: Optional[int] = None
        self._message_artist: Optional[Artist] = None # For text messages on canvas

        self._resize_timer = QTimer(self)
        self._resize_timer.setSingleShot(True)
        self._resize_timer.timeout.connect(self._debounced_resize_figure)
        self._last_known_canvas_size: Tuple[int, int] = (0, 0) # Store pixel size

        self._highlight_artists: List[Artist] = []

        self._initialize_plot() # Create initial axes

    def _initialize_plot(self):
        """Sets up the initial axes. Called by __init__ and clear_plot."""
        self._disconnect_map_click_event()
        self._remove_message_artist()
        self.clear_highlights_internal() # Internal call to avoid redraw yet

        self.figure.clear() # Clear entire figure
        self.axes = self.figure.add_subplot(111)
        self.axes2 = None # Reset secondary axis
        self.axes.grid(True, linestyle=':', alpha=0.6)
        self.current_plot_type = None
        # self.figure.tight_layout() # Apply after elements are added
        self.canvas.draw_idle()

    def _debounced_resize_figure(self):
        current_width, current_height = self.canvas.width(), self.canvas.height()
        if not self.isVisible() or current_width < MIN_PIXEL_DIM_FOR_MATPLOTLIB or current_height < MIN_PIXEL_DIM_FOR_MATPLOTLIB:
            return

        # Only resize if size actually changed significantly to avoid unnecessary redraws
        if abs(current_width - self._last_known_canvas_size[0]) < 2 and \
           abs(current_height - self._last_known_canvas_size[1]) < 2:
            return # Minimal change, skip redraw

        self._last_known_canvas_size = (current_width, current_height)

        dpi = self.figure.get_dpi()
        width_inches = current_width / dpi
        height_inches = current_height / dpi

        if width_inches <= 1e-3 or height_inches <= 1e-3:
            logger.warning(f"Debounced resize: non-positive/tiny inches ({width_inches:.2f}, {height_inches:.2f}). Skipping.")
            return
        
        try:
            # logger.debug(f"Debounced resize: Figure to {width_inches:.2f}x{height_inches:.2f} inches.")
            self.figure.set_size_inches(width_inches, height_inches, forward=True) # Forward=True might not be needed if canvas.draw_idle is called
            # self.figure.tight_layout() # Adjust layout after resize
            self.canvas.draw_idle() # Redraw the canvas
        except Exception as e:
            logger.error(f"Error during debounced set_size_inches: {e}. Size: [{width_inches},{height_inches}]", exc_info=True)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # Only trigger timer if widget is visible and meets minimum dimensions
        if self.isVisible() and self.canvas.width() >= MIN_PIXEL_DIM_FOR_MATPLOTLIB and self.canvas.height() >= MIN_PIXEL_DIM_FOR_MATPLOTLIB:
            self._resize_timer.start(RESIZE_DEBOUNCE_MS)

    def _remove_message_artist(self):
        if self._message_artist:
            try: self._message_artist.remove()
            except: pass
            self._message_artist = None

    def _setup_new_plot(self, title: str = "", x_label: str = "", y_label: str = "") -> MplAxes:
        """Clears figure and sets up a new primary axes."""
        self._initialize_plot() # This clears figure, highlights, messages, secondary axis
        assert self.axes is not None, "_initialize_plot should always create self.axes"
        self.axes.set_title(title, fontsize=10)
        self.axes.set_xlabel(x_label, fontsize=9)
        self.axes.set_ylabel(y_label, fontsize=9)
        self.axes.tick_params(axis='both', which='major', labelsize=8)
        return self.axes

    def clear_plot(self):
        """Clears the current plot and resets to a blank state."""
        self._initialize_plot() # Re-initializes the plot area completely
        self.show_message("Plot area ready.") # Default message for empty plot

    def show_message(self, message: str):
        self._initialize_plot() # Clear everything first
        if self.axes:
            self._message_artist = self.axes.text(
                0.5, 0.5, message, ha='center', va='center', 
                transform=self.axes.transAxes, color=(0.4, 0.4, 0.4), fontsize=11,
                bbox=dict(facecolor=(0.92, 0.92, 0.92), alpha=0.7, edgecolor='lightgrey', boxstyle='round,pad=0.6')
            )
        self.canvas.draw_idle()

    def set_title(self, title: str):
        if self.axes: self.axes.set_title(title, fontsize=10); self.canvas.draw_idle()

    def plot_spectrum(self, wavelengths: np.ndarray, intensities: np.ndarray,
                      title: str = "Spectrum", x_label: str = "Wavelength (nm)",
                      y_label: str = "Intensity (a.u.)", series_name: str = "Spectrum",
                      clear_previous: bool = True, color: Optional[str] = None, linestyle: str = '-'):
        if clear_previous or self.axes is None or self.current_plot_type != "spectrum":
            self._setup_new_plot(title, x_label, y_label)
        assert self.axes is not None
        
        if wavelengths is None or intensities is None or len(wavelengths) == 0 or len(intensities) == 0:
            self.show_message("No data provided for spectrum plot."); return

        self.axes.plot(wavelengths, intensities, label=series_name, color=color, linestyle=linestyle, linewidth=1.2)
        self._update_legend(); self.current_plot_type = "spectrum"
        # self.figure.tight_layout(); # Call after plotting
        self.canvas.draw_idle()

    def add_plot(self, x_data: np.ndarray, y_data: np.ndarray,
                 series_name: str, y_axis_label: Optional[str] = None,
                 use_secondary_y: bool = False, color: Optional[str] = None, linestyle: str = '-'):
        if self.axes is None: self._initialize_plot(); # Ensure axes exist
        assert self.axes is not None
        if x_data is None or y_data is None or len(x_data) == 0 or len(y_data) == 0:
            logger.warning(f"No data for series '{series_name}'. Skipping add_plot."); return

        ax_to_use = self.axes
        line_color = color
        if use_secondary_y:
            if self.axes2 is None or self.axes2.figure != self.figure: # Create if not exists or belongs to old figure
                if self.axes2 : self.axes2.remove() # Remove old one if it exists
                self.axes2 = self.axes.twinx()
            ax_to_use = self.axes2
            line_color = color if color else 'orangered' # Default for secondary
            if y_axis_label:
                self.axes2.set_ylabel(y_axis_label, color=line_color, fontsize=9)
                self.axes2.tick_params(axis='y', labelcolor=line_color, labelsize=8)
                self.axes2.grid(False) # Often turn off grid for secondary y-axis

        ax_to_use.plot(x_data, y_data, label=series_name, color=line_color, linestyle=linestyle, linewidth=1.2)
        self._update_legend(); # self.figure.tight_layout();
        self.canvas.draw_idle()

    def _update_legend(self):
        """Consolidates and draws legends from primary and secondary axes."""
        if not self.axes: return
        handles, labels = self.axes.get_legend_handles_labels()
        if self.axes2 and self.axes2.figure == self.figure:
            h2, l2 = self.axes2.get_legend_handles_labels()
            handles.extend(h2); labels.extend(l2)
        if handles: # Only show legend if there are labeled artists
            self.axes.legend(handles, labels, fontsize=8, loc='best')
        else: # Remove legend if no labeled artists
            if self.axes.get_legend() is not None: self.axes.get_legend().remove()
            if self.axes2 and self.axes2.get_legend() is not None: self.axes2.get_legend().remove()


    # --- Plotting Methods for Specific Analysis Types ---
    # (plot_scatter, plot_scatter_regression, plot_boltzmann, plot_elemental_map - largely same as previous,
    #  but ensure they call _setup_new_plot and handle self.axes assertions or creation)

    def plot_scatter(self, x_data, y_data, title="Scatter", x_label="X", y_label="Y", series_name="Data", labels=None, show_regression_line=False, color=None):
        self._setup_new_plot(title, x_label, y_label); assert self.axes is not None
        if x_data is None or y_data is None or len(x_data)==0: self.show_message("No data for scatter."); return
        self.axes.scatter(x_data, y_data, label=series_name, s=25, alpha=0.7, edgecolors='w', linewidths=0.5, color=color)
        if labels and len(labels)==len(x_data): [self.axes.annotate(txt,(x_data[i],y_data[i]),textcoords="offset points",xytext=(0,7),ha='center',fontsize=7) for i,txt in enumerate(labels) if txt]
        if show_regression_line and len(x_data)>=2:
            try: from scipy.stats import linregress; slope,intercept,r,_,_ = linregress(x_data,y_data); xr=np.array([np.min(x_data),np.max(x_data)]); self.axes.plot(xr,slope*xr+intercept,'r--',lw=1.5,label=f"Fit(R²={r**2:.3f})")
            except Exception as e: logger.error(f"Regression line error: {e}")
        self._update_legend(); self.current_plot_type="scatter"; # self.figure.tight_layout();
        self.canvas.draw_idle()

    def plot_scatter_regression(self, x_actual, y_predicted, title="Pred vs Actual", x_label="Actual", y_label="Predicted"):
        xa,yp = np.asarray(x_actual).flatten(), np.asarray(y_predicted).flatten()
        self.plot_scatter(xa,yp,title,x_label,y_label,series_name="Predictions",show_regression_line=True)
        if self.axes and xa.size>0: 
            all_vals = np.concatenate((xa, yp))
            min_val, max_val = np.min(all_vals), np.max(all_vals)
            lim_delta = (max_val - min_val) * 0.05 # 5% padding
            plot_min = min_val - lim_delta
            plot_max = max_val + lim_delta
            self.axes.plot([plot_min, plot_max], [plot_min, plot_max], 'k--', lw=1, label="Ideal (1:1)")
            self.axes.set_xlim(plot_min, plot_max); self.axes.set_ylim(plot_min, plot_max)
        self._update_legend(); self.canvas.draw_idle()


    def plot_boltzmann(self, x_ek, y_ln, slope, intercept, inlier_mask=None, title="Boltzmann", x_label="Ek", y_label="ln(Iλ/Ag)"):
        self._setup_new_plot(title,x_label,y_label); assert self.axes is not None
        if x_ek is None or y_ln is None or len(x_ek)==0: self.show_message("No data for Boltzmann."); return
        
        plot_kwargs_in = {'marker':'o', 'linestyle':'None', 'label':'Inliers', 's':40, 'alpha':0.8, 'color':'tab:blue'}
        plot_kwargs_out = {'marker':'x', 'linestyle':'None', 'label':'Outliers', 's':40, 'alpha':0.7, 'color':'tab:red'}

        if inlier_mask is not None and len(inlier_mask) == len(x_ek):
            self.axes.scatter(x_ek[inlier_mask], y_ln[inlier_mask], **plot_kwargs_in)
            outliers = ~inlier_mask
            if np.any(outliers):
                self.axes.scatter(x_ek[outliers], y_ln[outliers], **plot_kwargs_out)
        else: self.axes.scatter(x_ek,y_ln, **plot_kwargs_in) # All are inliers if no mask
        
        if len(x_ek) > 0 : # Ensure there are points before trying to plot fit line
            x_fit_ends=np.array([np.min(x_ek),np.max(x_ek)]) if len(x_ek)>1 else np.array([x_ek[0]-1, x_ek[0]+1]) # Handle single point case for line
            self.axes.plot(x_fit_ends,slope*x_fit_ends+intercept,'r--',label=f'Fit(m={slope:.2e})', lw=1.5)
        
        self._update_legend(); self.current_plot_type="boltzmann"; # self.figure.tight_layout();
        self.canvas.draw_idle()

    def plot_elemental_map(self, intensity_matrix, x_coords=None, y_coords=None, title="Map", cmap="viridis", interpolation='nearest'):
        self._setup_new_plot(title,"X-coordinate","Y-coordinate"); assert self.axes is not None
        if intensity_matrix is None or intensity_matrix.size==0: self.show_message("No data for map."); return
        
        # intensity_matrix should be (num_y_points, num_x_points)
        # Transpose if it's (num_x, num_y) for typical imshow (y_rows, x_cols)
        # This depends on how MappingProcessor structures it. Assume (y,x) for now.

        if x_coords is not None and y_coords is not None and len(x_coords)>0 and len(y_coords)>0:
            dx=np.mean(np.diff(sorted(x_coords))) if len(x_coords)>1 else 1.0; dy=np.mean(np.diff(sorted(y_coords))) if len(y_coords)>1 else 1.0
            ext=[x_coords.min()-dx/2, x_coords.max()+dx/2, y_coords.min()-dy/2, y_coords.max()+dy/2]; asp='auto'
        else: ext=None; asp='auto' # 'equal' can distort if not square pixel data without extent
        
        im=self.axes.imshow(intensity_matrix,cmap=cmap,interpolation=interpolation,origin='lower',aspect=asp,extent=ext)
        
        # Clear previous colorbars
        for cax in self.figure.axes:
            if cax != self.axes and hasattr(cax, '_colorbar'): cax.remove()
        
        self.figure.colorbar(im,ax=self.axes,label="Intensity / Value",fraction=0.046,pad=0.04) # Standard colorbar
        self.current_plot_type="map"; # self.figure.tight_layout();
        self.canvas.draw_idle()


    # --- Interactions and Highlighting ---
    def _disconnect_map_click_event(self):
        if self.active_cid_map_click is not None:
            try: self.canvas.mpl_disconnect(self.active_cid_map_click)
            except: pass; self.active_cid_map_click = None

    def enable_map_interactions(self, callback_on_click: Callable[[float, float, Optional[float]], None]):
        self._disconnect_map_click_event()
        def on_map_click(event):
            if event.inaxes==self.axes and self.current_plot_type=="map" and event.xdata is not None and event.ydata is not None:
                xd,yd=event.xdata,event.ydata; imgs=self.axes.get_images()
                if not imgs: return
                data=imgs[0].get_array(); ext=imgs[0].get_extent(); val=None; nr,nc=data.shape
                if ext: fx=(xd-ext[0])/(ext[1]-ext[0]); fy=(yd-ext[2])/(ext[3]-ext[2]); ci=int(fx*nc); ri=int(fy*nr)
                else: ci=int(round(xd)); ri=int(round(yd))
                if 0<=ri<nr and 0<=ci<nc: val=data[ri,ci]
                else: logger.debug(f"Map click ({xd:.2f},{yd:.2f}) outside image data bounds after index calc.")
                callback_on_click(xd,yd,val)
        self.active_cid_map_click = self.canvas.mpl_connect('button_press_event', on_map_click)
        logger.debug("Map click interaction enabled.")

    def clear_highlights_internal(self): # Internal version without redraw
        if self.axes:
            for artist in self._highlight_artists:
                try: artist.remove()
                except: pass
        self._highlight_artists = []

    def clear_highlights(self):
        """Removes all highlight artists from the plot and redraws."""
        self.clear_highlights_internal()
        if self.figure.canvas.manager: self.canvas.draw_idle()

    def add_highlight_marker(self, wavelength: float, label: str = "", color: str = "red",
                             linestyle: str = '--', text_offset_y_factor: float = 0.95,
                             redraw: bool = True):
        if not self.axes: logger.warning("Cannot add highlight: Axes N/A."); return
        ymin, ymax = self.axes.get_ylim()
        if abs(ymax - ymin) < 1e-9 : text_y_pos = ymax
        else: text_y_pos = ymin + text_offset_y_factor * (ymax - ymin)
        
        vline = self.axes.axvline(wavelength, color=color, linestyle=linestyle, linewidth=0.9, alpha=0.9)
        self._highlight_artists.append(vline)
        if label:
            text_artist = self.axes.text(wavelength, text_y_pos, label, color=color, rotation=90, ha='right', va='top', fontsize=7,
                                         backgroundcolor=(1,1,1,0.65))
            self._highlight_artists.append(text_artist)
        if redraw: self.canvas.draw_idle()
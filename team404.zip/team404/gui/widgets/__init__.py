# team404/gui/widgets/__init__.py

"""
Custom Widgets Sub-package for SpectraMapper Pro's GUI.

This package contains reusable custom QWidget subclasses. These widgets
either extend standard Qt widgets with application-specific functionality
or combine multiple widgets to create more complex UI elements tailored
for SpectraMapper Pro's needs.

Key widgets include:
- SpectrumPlotWidget: For displaying spectral data and related plots.
- CoordinateInputWidget: For user input of spatial coordinates or map dimensions.
"""

import logging

logger = logging.getLogger(__name__)

# Attempt to import defined widgets and prepare __all__
_exported_widgets = []

try:
    from .spectrum_plot_widget import SpectrumPlotWidget
    _exported_widgets.append("SpectrumPlotWidget")
except ImportError as e:
    logger.warning(f"Could not import SpectrumPlotWidget from .spectrum_plot_widget: {e}")

try:
    from .coordinate_input_widget import CoordinateInputWidget
    _exported_widgets.append("CoordinateInputWidget")
except ImportError as e:
    logger.warning(f"Could not import CoordinateInputWidget from .coordinate_input_widget: {e}")

# Add other confirmed custom widget imports here following the same pattern
# Example:
# try:
#     from .some_other_widget import SomeOtherWidget
#     _exported_widgets.append("SomeOtherWidget")
# except ImportError as e:
#     logger.warning(f"Could not import SomeOtherWidget: {e}")

__all__ = sorted(list(set(_exported_widgets))) # Ensure unique and sorted

if not __all__:
    logger.warning("No custom widgets were successfully imported in team404.gui.widgets.")

logger.debug(f"Exported widgets from team404.gui.widgets: {__all__}")
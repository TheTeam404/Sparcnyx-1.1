# team404/gui/widgets/progress_bar_widget.py

"""
Custom ProgressBar widgets for SpectraMapper Pro.
This includes an embeddable progress bar and a modal progress dialog.
"""

import logging
from typing import Optional

from PyQt5.QtWidgets import (
    QWidget, QProgressBar, QLabel, QVBoxLayout, QHBoxLayout,
    QPushButton, QApplication, QProgressDialog, QSizePolicy
)
from PyQt5.QtCore import Qt, pyqtSignal, QTimer

logger = logging.getLogger(__name__)


class EmbeddedProgressBar(QWidget):
    """
    A non-modal progress bar widget that can be embedded in other UI areas
    (e.g., a status bar or a specific processing panel).
    It includes a label, progress bar, and an optional cancel button.
    """
    cancelled = pyqtSignal() # Emitted when the cancel button is clicked

    def __init__(self, parent: Optional[QWidget] = None, show_cancel_button: bool = True):
        super().__init__(parent)
        self._show_cancel_button = show_cancel_button
        self._is_cancelled = False # Flag to track explicit cancellation
        self._init_ui()
        self.reset() # Initialize to hidden/default state

    def _init_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(2, 2, 2, 2)
        main_layout.setSpacing(5)

        self.progress_label = QLabel("Progress:", self)
        self.progress_label.setSizePolicy(QSizePolicy.MinimumExpanding, QSizePolicy.Preferred)
        main_layout.addWidget(self.progress_label)

        self.progress_bar = QProgressBar(self)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setRange(0, 100) # Default range
        self.progress_bar.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        main_layout.addWidget(self.progress_bar, 1) # Stretch factor for the bar

        if self._show_cancel_button:
            self.cancel_button = QPushButton("Cancel", self)
            self.cancel_button.setToolTip("Cancel the current operation")
            self.cancel_button.clicked.connect(self._emit_cancel_signal)
            fm = self.cancel_button.fontMetrics()
            self.cancel_button.setFixedWidth(fm.horizontalAdvance("Cancel") + fm.averageCharWidth() * 4)
            main_layout.addWidget(self.cancel_button)
        else:
            self.cancel_button = None

        self.setLayout(main_layout)

    def _emit_cancel_signal(self):
        logger.info("EmbeddedProgressBar: Cancel button clicked.")
        self._is_cancelled = True # Set cancellation flag
        self.cancelled.emit()
        self.hide() # Hide progress bar on cancel

    def set_label_text(self, text: str):
        self.progress_label.setText(text)

    def set_range(self, minimum: int, maximum: int):
        self.progress_bar.setRange(minimum, maximum)
        actual_min = self.progress_bar.minimum()
        actual_max = self.progress_bar.maximum()

        if actual_min == 0 and actual_max == 0: # Indeterminate state
            self.progress_bar.setValue(0)
        elif self.progress_bar.value() > actual_max:
            self.progress_bar.setValue(actual_max)
        elif self.progress_bar.value() < actual_min:
             self.progress_bar.setValue(actual_min)

    def set_value(self, value: int):
        self.progress_bar.setValue(value)

    def set_text_visible(self, visible: bool):
        self.progress_bar.setTextVisible(visible)

    def set_format(self, format_string: str):
        self.progress_bar.setFormat(format_string)

    def reset(self):
        """Resets the progress bar to its initial state and hides it."""
        self._is_cancelled = False # Reset cancellation flag
        self.progress_bar.reset()
        self.set_label_text("Progress:")
        if self.cancel_button:
            self.cancel_button.setEnabled(True)
            self.cancel_button.show()
        self.hide()

    def start(self, label_text: str = "Processing...", minimum: int = 0, maximum: int = 100, indeterminate: bool = False):
        """Shows the progress bar and sets its initial state."""
        self._is_cancelled = False # Reset cancellation flag on new start
        self.set_label_text(label_text)
        if indeterminate:
            self.set_range(0, 0)
        else:
            self.set_range(minimum, maximum)
            self.set_value(minimum)
        
        if self.cancel_button:
            self.cancel_button.setEnabled(True)
            self.cancel_button.show()
        self.show()
        QApplication.processEvents()

    def finish(self, success_message: Optional[str] = None, hide_delay_ms: int = 1500):
        """
        Marks operation as complete. Optionally shows a message before hiding.
        If the operation was cancelled, it will be reset without showing a success message.
        """
        if self._is_cancelled:
            logger.info("EmbeddedProgressBar: Finish called after explicit cancellation. Resetting.")
            self.reset() # Ensures clean state, hides, and resets _is_cancelled flag
            return

        if self.isHidden(): # Not cancelled by self, but hidden by other means
            logger.debug("EmbeddedProgressBar.finish() called while widget is hidden (not due to self-cancellation). Resetting.")
            self.reset() # Ensures clean state for next use
            return

        # If not hidden and not self-cancelled, proceed with normal finish logic
        if self.cancel_button:
            self.cancel_button.setEnabled(False) # Disable cancel on successful finish

        if success_message:
            if self.progress_bar.maximum() != 0: # Not indeterminate
                self.progress_bar.setValue(self.progress_bar.maximum()) # Show 100%
            self.set_label_text(success_message)
            if self.cancel_button:
                self.cancel_button.hide() # Hide cancel button on successful completion message
            QApplication.processEvents() # Ensure message and 100% are shown

            if hide_delay_ms > 0:
                QTimer.singleShot(hide_delay_ms, self.reset)
            else:
                self.reset() # Hide and reset immediately
        else:
            self.reset() # Just hide and reset


class ModalProgressDialog(QProgressDialog):
    """
    A standardized modal QProgressDialog for operations that block the UI.
    """
    def __init__(self, label_text: str = "Operation in progress...",
                 cancel_button_text: Optional[str] = "Cancel",
                 minimum: int = 0, maximum: int = 100,
                 parent: Optional[QWidget] = None,
                 window_title: str = "Processing..."):
        super().__init__(label_text, cancel_button_text, minimum, maximum, parent)
        
        self.setWindowTitle(window_title)
        self.setWindowModality(Qt.WindowModal)
        self.setAutoClose(True)
        self.setAutoReset(True)
        self.setMinimumDuration(200)

    def update_progress(self, value: int, label_text_update: Optional[str] = None):
        if self.wasCanceled():
            return
        
        self.setValue(value)

        if label_text_update:
            self.setLabelText(label_text_update)
        
        QApplication.processEvents()

    def complete(self, final_message: Optional[str] = None):
        if self.wasCanceled():
            return

        if final_message:
            self.setLabelText(final_message)
            if self.autoClose() and self.isVisible() and \
               self.value() < self.maximum() and self.maximum() > self.minimum():
                current_val = self.value()
                self.setValue(self.maximum() -1 if self.maximum() > self.minimum() else self.maximum())
                QApplication.processEvents()
                # Restore value if we don't want it to jump back, though setValue(max) is next
                # self.setValue(current_val) 
        
        self.setValue(self.maximum())
        QApplication.processEvents()


# --- Example Usage ---
if __name__ == '__main__':
    import sys
    logging.basicConfig(stream=sys.stdout, level=logging.INFO)

    app = QApplication(sys.argv)

    # --- Test EmbeddedProgressBar ---
    test_widget_embedded_container = QWidget()
    test_layout_embedded_container = QVBoxLayout(test_widget_embedded_container)
    
    embedded_pb = EmbeddedProgressBar(test_widget_embedded_container)
    test_layout_embedded_container.addWidget(embedded_pb)

    start_btn_emb = QPushButton("Start Embedded Progress (50 steps, 5s)")
    test_layout_embedded_container.addWidget(start_btn_emb)
    
    indeterminate_btn_emb = QPushButton("Start Indeterminate Embedded Progress (3s)")
    test_layout_embedded_container.addWidget(indeterminate_btn_emb)

    timer_emb = QTimer()
    counter_emb = 0
    max_steps_emb = 50

    def update_emb_progress():
        if embedded_pb._is_cancelled: # Example of checking the flag from outside
            timer_emb.stop()
            logger.info("Embedded progress timer stopped due to cancellation flag.")
            # Buttons are re-enabled by on_emb_cancelled_signal
            return
            
        counter_emb += 1
        embedded_pb.set_value(counter_emb)
        embedded_pb.set_label_text(f"Step {counter_emb}/{max_steps_emb}...")
        if counter_emb >= max_steps_emb:
            timer_emb.stop()
            embedded_pb.finish("Embedded Task Done!", 1500)
            start_btn_emb.setEnabled(True)
            indeterminate_btn_emb.setEnabled(True)
            logger.info("Embedded progress test finished.")

    timer_emb.timeout.connect(update_emb_progress)

    def on_start_emb_clicked():
        counter_emb = 0
        embedded_pb.start("Processing items...", 0, max_steps_emb)
        timer_emb.start(100)
        start_btn_emb.setEnabled(False)
        indeterminate_btn_emb.setEnabled(False)

    def handle_indeterminate_finish():
        # Check if it was cancelled before finishing
        if not embedded_pb._is_cancelled:
            embedded_pb.finish("Indeterminate Done!", 1500)
            logger.info("Indeterminate embedded progress test finished.")
        else:
            logger.info("Indeterminate embedded progress was cancelled before finish.")
        start_btn_emb.setEnabled(True)
        indeterminate_btn_emb.setEnabled(True)


    def on_start_indeterminate_emb_clicked():
        embedded_pb.start("Working (indeterminate)...", indeterminate=True)
        start_btn_emb.setEnabled(False)
        indeterminate_btn_emb.setEnabled(False)
        QTimer.singleShot(3000, handle_indeterminate_finish)


    start_btn_emb.clicked.connect(on_start_emb_clicked)
    indeterminate_btn_emb.clicked.connect(on_start_indeterminate_emb_clicked)
    
    def on_emb_cancelled_signal():
        timer_emb.stop() 
        start_btn_emb.setEnabled(True)
        indeterminate_btn_emb.setEnabled(True)
        logger.info("Embedded progress CANCELLED by user signal.")
        # embedded_pb.reset() is called by finish() or implicitly by hide() + next start()
    embedded_pb.cancelled.connect(on_emb_cancelled_signal)

    test_widget_embedded_container.setWindowTitle("EmbeddedProgressBar Test")
    test_widget_embedded_container.resize(450, 150)
    test_widget_embedded_container.show()


    # --- Test ModalProgressDialog ---
    test_widget_modal_launcher = QWidget() 
    test_layout_modal_launcher = QVBoxLayout(test_widget_modal_launcher)
    start_btn_modal = QPushButton("Start Modal Progress (30 steps, 3s)")
    test_layout_modal_launcher.addWidget(start_btn_modal)
    
    start_btn_modal_no_cancel = QPushButton("Start Modal (No Cancel Button, 2s)")
    test_layout_modal_launcher.addWidget(start_btn_modal_no_cancel)


    modal_dialog: Optional[ModalProgressDialog] = None 
    timer_modal = QTimer()
    counter_modal = 0
    total_modal_steps_test = 30 
    total_modal_steps_no_cancel = 20

    def update_modal_progress():
        if not modal_dialog or modal_dialog.wasCanceled():
            timer_modal.stop()
            start_btn_modal.setEnabled(True)
            start_btn_modal_no_cancel.setEnabled(True)
            if modal_dialog and modal_dialog.wasCanceled():
                 logger.info("Modal progress was cancelled by user.")
            return

        counter_modal += 1
        current_total_steps = modal_dialog.maximum()
        modal_dialog.update_progress(counter_modal, f"Processing task {counter_modal} of {current_total_steps}")

        if counter_modal >= current_total_steps:
            timer_modal.stop()
            modal_dialog.complete("Modal Task Finished Successfully!")
            start_btn_modal.setEnabled(True)
            start_btn_modal_no_cancel.setEnabled(True)

    timer_modal.timeout.connect(update_modal_progress)
    
    def on_modal_dialog_cancelled():
        timer_modal.stop() 
        start_btn_modal.setEnabled(True)
        start_btn_modal_no_cancel.setEnabled(True)
        logger.info("ModalProgressDialog 'canceled' signal received.")

    def on_modal_dialog_finished(result_code):
        logger.info(f"ModalProgressDialog 'finished' signal with result: {result_code}.")
        # Buttons are usually re-enabled by the completion/cancellation logic handling the timer

    def launch_modal_dialog(cancel_text, max_steps, title):
        counter_modal = 0
        
        modal_dialog = ModalProgressDialog(
            label_text="Starting modal operation...",
            cancel_button_text=cancel_text,
            minimum=0, maximum=max_steps,
            parent=test_widget_modal_launcher,
            window_title=title
        )
        modal_dialog.canceled.connect(on_modal_dialog_cancelled)
        modal_dialog.finished.connect(on_modal_dialog_finished)
        
        timer_modal.start(100) 
        start_btn_modal.setEnabled(False)
        start_btn_modal_no_cancel.setEnabled(False)

    def on_start_modal_clicked():
        launch_modal_dialog("Abort Task", total_modal_steps_test, "Modal Test in Progress")

    def on_start_modal_no_cancel_clicked():
        launch_modal_dialog(None, total_modal_steps_no_cancel, "Modal Test (No Cancel)")

    start_btn_modal.clicked.connect(on_start_modal_clicked)
    start_btn_modal_no_cancel.clicked.connect(on_start_modal_no_cancel_clicked)

    test_widget_modal_launcher.setWindowTitle("ModalProgressDialog Test Launcher")
    test_widget_modal_launcher.resize(300, 150)
    test_widget_modal_launcher.show()
    
    sys.exit(app.exec_())
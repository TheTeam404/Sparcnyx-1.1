# team404/gui/widgets/coordinate_input_widget.py

"""
CoordinateInputWidget for SpectraMapper Pro.
A reusable widget to input X, Y coordinates or map dimensions.
It can also handle loading coordinates from a file or parsing from filenames.
"""

import logging
import os
import re # For regex pattern validation
from pathlib import Path
from typing import Optional, Dict, Any

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QFormLayout, QLabel, QSpinBox, QDoubleSpinBox,
    QRadioButton, QHBoxLayout, QLineEdit, QPushButton, QFileDialog,
    QMessageBox, QGroupBox, QComboBox, QCheckBox, QApplication
)
from PyQt5.QtCore import Qt, pyqtSignal
import numpy as np
import pandas as pd # For CSV coordinate file reading

logger = logging.getLogger(__name__)

class CoordinateInputWidget(QWidget):
    """
    A widget for users to define how coordinates for mapping data are provided.
    Options:
    1. Manual dimensions (X points, Y points) for ordered data, with scan order.
    2. Load X, Y coordinates from a separate file (CSV/TXT).
    3. Parse from filenames using a regex pattern.
    """
    coordinates_defined = pyqtSignal(dict) # Emitted when valid configuration is retrieved

    def __init__(self, expected_num_spectra: Optional[int] = None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.expected_num_spectra = expected_num_spectra

        self._init_ui()
        self.set_expected_spectra_count(expected_num_spectra) # Initial status update
        self._on_method_change() # Set initial visibility of panels

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        self.setLayout(main_layout)

        self.coord_input_group = QGroupBox("Map Coordinate Definition")
        group_layout = QVBoxLayout(self.coord_input_group)
        main_layout.addWidget(self.coord_input_group)

        self.status_label = QLabel("Load spectral data for mapping first.")
        self.status_label.setWordWrap(True)
        group_layout.addWidget(self.status_label)

        # --- Method Selection ---
        method_selection_layout = QHBoxLayout()
        self.method_by_dimensions_radio = QRadioButton("Grid Dimensions (ordered spectra)")
        self.method_by_file_radio = QRadioButton("Load X,Y from File")
        self.method_by_filename_pattern_radio = QRadioButton("Parse from Filenames (Regex)")

        self.method_by_dimensions_radio.setChecked(True) # Default method
        method_selection_layout.addWidget(self.method_by_dimensions_radio)
        method_selection_layout.addWidget(self.method_by_file_radio)
        method_selection_layout.addWidget(self.method_by_filename_pattern_radio)
        group_layout.addLayout(method_selection_layout)

        self.method_by_dimensions_radio.toggled.connect(self._on_method_change)
        self.method_by_file_radio.toggled.connect(self._on_method_change)
        self.method_by_filename_pattern_radio.toggled.connect(self._on_method_change)

        # --- Panel for Dimensions Input ---
        self.dimensions_panel = QWidget()
        dim_layout = QFormLayout(self.dimensions_panel)
        dim_layout.setSpacing(8)
        
        self.x_points_spinbox = QSpinBox()
        self.x_points_spinbox.setRange(1, 10000); self.x_points_spinbox.setValue(10)
        self.x_points_spinbox.setToolTip("Number of data points in the X direction.")
        self.x_points_spinbox.valueChanged.connect(self._validate_dimensions_match)
        dim_layout.addRow("Number of X Points:", self.x_points_spinbox)

        self.y_points_spinbox = QSpinBox()
        self.y_points_spinbox.setRange(1, 10000); self.y_points_spinbox.setValue(10)
        self.y_points_spinbox.setToolTip("Number of data points in the Y direction.")
        self.y_points_spinbox.valueChanged.connect(self._validate_dimensions_match)
        dim_layout.addRow("Number of Y Points:", self.y_points_spinbox)

        self.scan_order_combo = QComboBox()
        self.scan_order_combo.addItems([
            "Row-major (scan X, then step Y)",      # X changes fastest (inner loop)
            "Column-major (scan Y, then step X)",   # Y changes fastest (inner loop)
            "Serpentine Row-major",
            "Serpentine Column-major"
        ])
        self.scan_order_combo.setToolTip("Order in which spectra were acquired for grid measurements.")
        dim_layout.addRow("Scan Order:", self.scan_order_combo)
        
        self.total_points_label = QLabel("Total Points: 100") # Initial based on 10x10
        dim_layout.addRow(self.total_points_label)
        group_layout.addWidget(self.dimensions_panel)

        # --- Panel for File Input ---
        self.file_panel = QWidget()
        file_params_layout = QFormLayout(self.file_panel)
        file_params_layout.setSpacing(8)

        self.coord_file_edit = QLineEdit()
        self.coord_file_edit.setPlaceholderText("Path to CSV or TXT file")
        self.coord_file_edit.setReadOnly(True)
        browse_button = QPushButton("Browse...")
        browse_button.clicked.connect(self._browse_coord_file)
        file_path_layout = QHBoxLayout()
        file_path_layout.addWidget(self.coord_file_edit, 1) # Give line edit more stretch
        file_path_layout.addWidget(browse_button)
        file_params_layout.addRow("Coordinate File:", file_path_layout)

        self.x_col_coord_file_spinbox = QSpinBox()
        self.x_col_coord_file_spinbox.setRange(0, 50); self.x_col_coord_file_spinbox.setValue(0)
        self.x_col_coord_file_spinbox.setToolTip("0-based index of the column containing X coordinates in the file.")
        file_params_layout.addRow("X Column Index (0-based):", self.x_col_coord_file_spinbox)

        self.y_col_coord_file_spinbox = QSpinBox()
        self.y_col_coord_file_spinbox.setRange(0, 50); self.y_col_coord_file_spinbox.setValue(1)
        self.y_col_coord_file_spinbox.setToolTip("0-based index of the column containing Y coordinates in the file.")
        file_params_layout.addRow("Y Column Index (0-based):", self.y_col_coord_file_spinbox)
        
        self.coord_file_has_header_checkbox = QCheckBox("File has a header row to skip")
        self.coord_file_has_header_checkbox.setChecked(False) # Default: no header
        self.coord_file_has_header_checkbox.setToolTip("Check if the first line of the coordinate file is a header and should be ignored.")
        file_params_layout.addRow(self.coord_file_has_header_checkbox)

        self.coord_file_delimiter_edit = QLineEdit()
        self.coord_file_delimiter_edit.setPlaceholderText("Auto (comma, tab, space)")
        self.coord_file_delimiter_edit.setToolTip("Delimiter for coordinate file. Leave empty for auto-detection (tries comma, tab, space).")
        file_params_layout.addRow("Delimiter:", self.coord_file_delimiter_edit)

        self.coord_file_status_label = QLabel("No coordinate file loaded.")
        self.coord_file_status_label.setWordWrap(True)
        file_params_layout.addRow(self.coord_file_status_label)
        group_layout.addWidget(self.file_panel)

        # --- Panel for Filename Pattern Input ---
        self.filename_pattern_panel = QWidget()
        pattern_layout = QFormLayout(self.filename_pattern_panel)
        pattern_layout.setSpacing(8)
        
        self.filename_regex_edit = QLineEdit()
        self.filename_regex_edit.setPlaceholderText(r"e.g., .*_x(\d+\.?\d*)_y(\d+\.?\d*)\..*")
        self.filename_regex_edit.setToolTip(
            "Regular expression to extract X and Y coordinates from filenames.\n"
            "Must contain two capturing groups: the first for X, the second for Y.\n"
            r"Example: 'prefix_x(\d+)_y(\d+)_suffix.txt' or 'Scan_(\d+\.\d+)_(\d+\.\d+).spc'"
        )
        pattern_layout.addRow("Filename Regex Pattern:", self.filename_regex_edit)
        group_layout.addWidget(self.filename_pattern_panel)


    def _on_method_change(self):
        """Shows the relevant panel based on the selected radio button."""
        self.dimensions_panel.setVisible(self.method_by_dimensions_radio.isChecked())
        self.file_panel.setVisible(self.method_by_file_radio.isChecked())
        self.filename_pattern_panel.setVisible(self.method_by_filename_pattern_radio.isChecked())
        self._validate_dimensions_match() # Update validation message if dimensions panel is shown/hidden

    def set_expected_spectra_count(self, count: Optional[int]):
        self.expected_num_spectra = count
        if count is not None and count > 0:
            self.status_label.setText(f"{count} spectra loaded for mapping. Configure coordinates below:")
            # Auto-guess dimensions if "Grid Dimensions" is active and current dims don't match
            if self.method_by_dimensions_radio.isChecked():
                current_x = self.x_points_spinbox.value()
                current_y = self.y_points_spinbox.value()
                if current_x * current_y != count:
                    sqrt_n = int(np.sqrt(count))
                    if sqrt_n * sqrt_n == count: # Perfect square
                        self.x_points_spinbox.setValue(sqrt_n)
                        self.y_points_spinbox.setValue(sqrt_n)
                    else: # Default to N x 1 if not a square
                        self.x_points_spinbox.setValue(count)
                        self.y_points_spinbox.setValue(1)
        else:
            self.status_label.setText("Load spectral data for mapping first, or set expected count.")
        self._validate_dimensions_match()


    def _validate_dimensions_match(self):
        """Validates X*Y points against expected_num_spectra and updates label, only if dimensions method is active."""
        if not self.method_by_dimensions_radio.isChecked():
            self.total_points_label.setText("") # Clear if not using dimensions method
            return

        x_pts = self.x_points_spinbox.value()
        y_pts = self.y_points_spinbox.value()
        total_from_dims = x_pts * y_pts
        
        message = f"Total Points from Dimensions: {total_from_dims}"
        if self.expected_num_spectra is not None and self.expected_num_spectra > 0:
            if total_from_dims == self.expected_num_spectra:
                message += f" <font color='green'>(Matches {self.expected_num_spectra} expected spectra)</font>"
            else:
                message += f" <font color='red'>(Mismatch: {self.expected_num_spectra} expected spectra)</font>"
        elif self.expected_num_spectra is None: # Expected count not set yet
             message += " (Expected spectra count not yet set)"
        else: # Expected count is 0 or invalid
             message += " (No spectra expected or count invalid)"

        self.total_points_label.setText(message)

    def _browse_coord_file(self):
        default_dir = str(Path.home()) # Generic default
        # Try to get a more relevant default directory if possible (e.g., from project settings)
        # current_project = self.parent().get_current_project() # If part of a larger app structure
        # if current_project and current_project.project_path: default_dir = str(Path(current_project.project_path).parent)
        
        filepath_str, _ = QFileDialog.getOpenFileName(
            self, "Select Coordinate File", default_dir,
            "CSV Files (*.csv);;Text Files (*.txt);;All Files (*)"
        )
        if filepath_str:
            self.coord_file_edit.setText(filepath_str)
            self._preview_coord_file_info(filepath_str)

    def _preview_coord_file_info(self, filepath: str):
        """Tries to read the file and show basic info like number of lines."""
        try:
            skip_header = 1 if self.coord_file_has_header_checkbox.isChecked() else 0
            delimiter_str = self.coord_file_delimiter_edit.text().strip()
            
            # Use pandas for robust preview count, trying common delimiters if auto
            if not delimiter_str: # Auto-detect attempt
                delimiters_to_try = [',', '\t', ' ']
            else: # User specified
                if delimiter_str.lower() == '\\t': delimiter_str = '\t'
                delimiters_to_try = [delimiter_str]

            df_preview = None
            for delim in delimiters_to_try:
                try:
                    df_preview = pd.read_csv(filepath, header=None, skiprows=skip_header, 
                                             delimiter=delim, nrows=5) # Read only a few rows for col check
                    if not df_preview.empty: break # Found a working delimiter
                except (pd.errors.ParserError, pd.errors.EmptyDataError): continue # Try next delim
                except Exception: continue # Catch other potential pandas errors

            if df_preview is None or df_preview.empty:
                # Fallback to simple line count if pandas fails or returns empty
                with open(filepath, 'r', errors='ignore') as f:
                    num_coord_lines = sum(1 for line in f if line.strip()) - skip_header
                col_info = " (Could not determine columns)"
            else:
                num_coord_lines = len(pd.read_csv(filepath, header=None, skiprows=skip_header, delimiter=delim)) # Full count with working delim
                col_info = f" (Detected {df_preview.shape[1]} columns)"
            
            match_color = "green"
            if self.expected_num_spectra is not None and num_coord_lines != self.expected_num_spectra:
                match_color = "red"
            
            self.coord_file_status_label.setText(
                f"<font color='{match_color}'>File has {num_coord_lines} data lines{col_info}.</font>"
            )

        except Exception as e:
            logger.warning(f"Error previewing coordinate file {filepath}: {e}")
            self.coord_file_status_label.setText(f"<font color='red'>Error reading file: {str(e)[:50]}</font>")


    def get_configuration(self) -> Optional[Dict[str, Any]]:
        """
        Collects current coordinate definition settings, validates them, and emits
        `coordinates_defined` signal if successful.

        Returns:
            A dictionary describing the coordinate definition, or None if validation fails.
        """
        config: Dict[str, Any] = {}

        if self.method_by_dimensions_radio.isChecked():
            config["type"] = "dimensions"
            config["x_points"] = self.x_points_spinbox.value()
            config["y_points"] = self.y_points_spinbox.value()
            config["scan_order"] = self.scan_order_combo.currentText()
            if self.expected_num_spectra is not None and \
               config["x_points"] * config["y_points"] != self.expected_num_spectra:
                QMessageBox.warning(self, "Dimension Mismatch",
                                    f"Total points from dimensions ({config['x_points'] * config['y_points']}) "
                                    f"does not match expected spectra ({self.expected_num_spectra}). Please correct.")
                return None
            if config["x_points"] <= 0 or config["y_points"] <= 0:
                QMessageBox.warning(self, "Invalid Dimensions", "X and Y points must be greater than zero.")
                return None

        elif self.method_by_file_radio.isChecked():
            config["type"] = "file"
            filepath_str = self.coord_file_edit.text().strip()
            if not filepath_str or not Path(filepath_str).is_file():
                QMessageBox.warning(self, "File Not Found", "Coordinate file path is invalid or file does not exist.")
                return None
            
            config["filepath"] = filepath_str
            config["x_col_idx"] = self.x_col_coord_file_spinbox.value()
            config["y_col_idx"] = self.y_col_coord_file_spinbox.value()
            config["has_header"] = self.coord_file_has_header_checkbox.isChecked()
            
            delimiter_str = self.coord_file_delimiter_edit.text().strip()
            if delimiter_str.lower() == '\\t': delimiter_str = '\t'
            config["delimiter"] = delimiter_str if delimiter_str else None # None for auto-detect by pandas

            if config["x_col_idx"] == config["y_col_idx"]:
                QMessageBox.warning(self, "Column Index Error", "X and Y coordinate column indices cannot be the same.")
                return None
            # Further validation of file content (number of lines, numeric data) can be done here
            # or deferred to the MappingProcessor. For now, just pass params.

        elif self.method_by_filename_pattern_radio.isChecked():
            config["type"] = "filename_pattern"
            pattern_str = self.filename_regex_edit.text().strip()
            if not pattern_str:
                QMessageBox.warning(self, "Input Required", "Filename Regex Pattern cannot be empty for this method.")
                return None
            try:
                compiled_regex = re.compile(pattern_str)
                if compiled_regex.groups != 2:
                    QMessageBox.warning(self, "Invalid Regex Pattern", 
                                         "The Regex pattern must contain exactly two capturing groups (for X and Y coordinates).")
                    return None
            except re.error as e:
                QMessageBox.warning(self, "Invalid Regex Pattern", f"The Regex pattern is invalid: {e}")
                return None
            config["pattern"] = pattern_str
        
        else:
            logger.error("No coordinate input method selected - UI logic error.")
            QMessageBox.critical(self, "Internal Error", "No coordinate input method selected.")
            return None

        self.coordinates_defined.emit(config) # Emit signal with valid config
        return config

    def set_configuration(self, config: Dict[str, Any]):
        """Populates UI fields based on a given configuration dictionary."""
        config_type = config.get("type", "dimensions") # Default to dimensions if type is missing

        if config_type == "dimensions":
            self.method_by_dimensions_radio.setChecked(True)
            self.x_points_spinbox.setValue(config.get("x_points", 1))
            self.y_points_spinbox.setValue(config.get("y_points", 1))
            self.scan_order_combo.setCurrentText(config.get("scan_order", "Row-major (scan X, then step Y)"))
        elif config_type == "file":
            self.method_by_file_radio.setChecked(True)
            self.coord_file_edit.setText(config.get("filepath", ""))
            self.x_col_coord_file_spinbox.setValue(config.get("x_col_idx", 0))
            self.y_col_coord_file_spinbox.setValue(config.get("y_col_idx", 1))
            self.coord_file_has_header_checkbox.setChecked(config.get("has_header", False))
            self.coord_file_delimiter_edit.setText(config.get("delimiter", "") or "") # Handle None from config
            if config.get("filepath"): self._preview_coord_file_info(config["filepath"]) # Update preview
        elif config_type == "filename_pattern":
            self.method_by_filename_pattern_radio.setChecked(True)
            self.filename_regex_edit.setText(config.get("pattern", ""))
        
        self._on_method_change() # Ensure correct panels are visible
        self._validate_dimensions_match() # Update validation labels


if __name__ == '__main__':
    import sys
    app = QApplication(sys.argv)

    class TestContainer(QWidget): # Use QWidget for main window in test
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Coordinate Input Widget Test Container")
            self.layout = QVBoxLayout(self)
            
            self.coord_widget = CoordinateInputWidget(expected_num_spectra=None, parent=self) # Start with None
            self.layout.addWidget(self.coord_widget)

            self.set_expected_button = QPushButton("Set Expected Spectra (e.g., 100)")
            self.set_expected_button.clicked.connect(lambda: self.coord_widget.set_expected_spectra_count(100))
            self.layout.addWidget(self.set_expected_button)

            self.get_config_button = QPushButton("Get Current Configuration")
            self.get_config_button.clicked.connect(self.test_get_config)
            self.layout.addWidget(self.get_config_button)
            
            self.load_config_button = QPushButton("Load Example Config (Dimensions 10x10)")
            self.load_config_button.clicked.connect(self.test_set_config)
            self.layout.addWidget(self.load_config_button)

            self.coord_widget.coordinates_defined.connect(self.on_coords_signal_received)
            self.resize(500, 400)

        def test_get_config(self):
            config = self.coord_widget.get_configuration()
            if config:
                print("Retrieved Configuration:", config)
                QMessageBox.information(self, "Config Retrieved", f"Configuration: {config}")
            else:
                print("Configuration retrieval failed validation or was cancelled.")
        
        def test_set_config(self):
            example_config = {
                "type": "dimensions", 
                "x_points": 10, 
                "y_points": 10, 
                "scan_order": "Column-major (scan Y, then step X)"
            }
            self.coord_widget.set_configuration(example_config)
            print("Loaded example configuration into widget.")

        def on_coords_signal_received(self, config_dict: dict):
            print(f"Signal 'coordinates_defined' received with data: {config_dict}")
            # This would typically be handled by the parent tab (e.g., MappingTab)

    test_win = TestContainer()
    test_win.show()
    
    # Create dummy coordinate file for testing "Load from File"
    dummy_coord_file_path = Path(".") / "test_dummy_coords.csv" # In current dir for test
    with open(dummy_coord_file_path, "w") as f:
        f.write("HeaderX,HeaderY,Other\n")
        f.write("10.1,20.2,A\n")
        f.write("10.5,20.8,B\n")
        f.write("11.0,21.2,C\n")
    print(f"Created dummy coordinate file: {dummy_coord_file_path.resolve()}")


    sys.exit(app.exec_())
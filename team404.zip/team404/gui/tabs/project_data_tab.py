import logging
import os # Keep os for os.path.join if used, though Path is preferred
from pathlib import Path
from typing import Optional, List, Dict, Any, TYPE_CHECKING

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
    QPushButton, QLabel, QListWidget, QListWidgetItem,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QFileDialog, QMessageBox, QSplitter, QInputDialog, QMenu,
    QSizePolicy, QApplication, QLineEdit
)
from PyQt5.QtCore import Qt, pyqtSignal, QPoint
from PyQt5.QtGui import QColor, QBrush
import numpy as np

from .base_tab import BaseTab
from ..widgets.spectrum_plot_widget import SpectrumPlotWidget
from ...core.data_models import LIBSpectrum, LIBSProject
from ...core.file_io import load_spectrum_from_file
# from ..dialogs.file_format_dialog import FileFormatDialog

if TYPE_CHECKING:
    from ..main_window import MainWindow
    from ...core.project_manager import ProjectManager

logger = logging.getLogger(__name__)


class LIBSProjectTab(BaseTab):
    """
    Tab for managing project data, spectra list, and spectrum preview.
    """
    # active_spectrum_selection_changed_signal is inherited from BaseTab

    def __init__(self, project_manager: 'ProjectManager', main_window: Optional['MainWindow'] = None, parent: Optional[QWidget] = None):
        super().__init__(project_manager, main_window, parent)
        # self.base_layout is created and set by BaseTab's __init__
        self._init_ui()

    def _init_ui(self):
        """Initialize the UI components for the Project Data tab."""
        main_splitter = QSplitter(Qt.Horizontal, self) # Parent to self (the tab)
        main_splitter.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # --- Left Panel: Spectra List and Controls ---
        left_panel_widget = QWidget() # No parent needed if added to splitter directly
        left_layout = QVBoxLayout() # No parent needed if set on widget
        left_layout.setContentsMargins(0,0,0,0)

        spectra_group = QGroupBox("Project Spectra")
        spectra_group_layout = QVBoxLayout(spectra_group)

        self.spectra_list_widget = QListWidget()
        self.spectra_list_widget.setToolTip("List of spectra in the current project. Select spectra to view details or batch process. Hold Ctrl/Shift for multiple selection.")
        self.spectra_list_widget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.spectra_list_widget.itemSelectionChanged.connect(self._on_spectrum_selection_changed)
        self.spectra_list_widget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.spectra_list_widget.customContextMenuRequested.connect(self._show_spectra_list_context_menu)
        spectra_group_layout.addWidget(self.spectra_list_widget)

        spectra_buttons_layout = QHBoxLayout()
        self.import_spectra_button = QPushButton("Import Spectra...")
        self.import_spectra_button.setToolTip("Import one or more spectral data files into the current project.")
        self.import_spectra_button.clicked.connect(self._import_spectra)
        spectra_buttons_layout.addWidget(self.import_spectra_button)
        
        self.remove_spectrum_button = QPushButton("Remove Selected")
        self.remove_spectrum_button.setToolTip("Remove the selected spectrum from the project.")
        self.remove_spectrum_button.clicked.connect(self._remove_selected_spectrum)
        self.remove_spectrum_button.setEnabled(False)
        spectra_buttons_layout.addWidget(self.remove_spectrum_button)
        spectra_group_layout.addLayout(spectra_buttons_layout)
        
        left_layout.addWidget(spectra_group)
        left_panel_widget.setLayout(left_layout) # Set layout on the intermediate widget
        main_splitter.addWidget(left_panel_widget)


        # --- Right Panel: Spectrum Plot Preview ---
        self.spectrum_preview_plot = SpectrumPlotWidget(self) # Parent to self (the tab)
        self.spectrum_preview_plot.set_title("Active Spectrum Preview")
        self.spectrum_preview_plot.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        main_splitter.addWidget(self.spectrum_preview_plot)

        # Set initial sizes for the splitter panes
        # Attempt to do this after it might have a parent and some size context
        QApplication.instance().processEvents() # Allow UI to settle slightly
        total_width = self.width() if self.width() > 200 else 800 # Use a reasonable default if width is tiny
        main_splitter.setSizes([int(total_width * 0.3), int(total_width * 0.7)])


        # Add the main_splitter to the base_layout from BaseTab
        self.base_layout.addWidget(main_splitter)
        # NO self.setLayout(self.base_layout) or self.setLayout(main_layout_of_tab) HERE

    def _update_spectra_list(self):
        self.spectra_list_widget.blockSignals(True)
        self.spectra_list_widget.clear()
        project = self.get_current_project()
        current_active_item: Optional[QListWidgetItem] = None
        first_item: Optional[QListWidgetItem] = None
        
        if project and project.spectra:
            # Sort spectra by filename or ID for consistent display
            sorted_spectra = sorted(project.spectra.items(), key=lambda item: item[1].filename or item[1].spectrum_id)
            for i, (spectrum_id, spectrum_obj) in enumerate(sorted_spectra):
                display_name = spectrum_obj.filename or spectrum_obj.spectrum_id
                item = QListWidgetItem(display_name)
                item.setData(Qt.UserRole, spectrum_id)
                self.spectra_list_widget.addItem(item)
                
                if i == 0:
                    first_item = item
                    
                if project.active_spectrum_id == spectrum_id:
                    current_active_item = item
        
        if current_active_item:
            self.spectra_list_widget.setCurrentItem(current_active_item)
        elif first_item:
            self.spectra_list_widget.setCurrentItem(first_item)
            current_active_item = first_item
        
        self.spectra_list_widget.blockSignals(False)
        self.remove_spectrum_button.setEnabled(bool(self.spectra_list_widget.selectedItems()))
        
        if not project or not project.active_spectrum_id:
            if current_active_item:
                self._on_spectrum_selection_changed()

    def _on_spectrum_selection_changed(self):
        if self.spectra_list_widget.signalsBlocked(): return

        selected_items = self.spectra_list_widget.selectedItems()
        active_spectrum: Optional[LIBSpectrum] = None
        
        if selected_items:
            # We'll treat the first selected item as the 'active' one for plotting purposes
            current_item = selected_items[0]
            spectrum_id = current_item.data(Qt.UserRole)
            project = self.get_current_project()
            if project:
                # Do NOT call project.set_active_spectrum(spectrum_id) here!
                # MainWindow handles project state updates so signals mirror correctly.
                active_spectrum = project.get_spectrum(spectrum_id)
        
        self.active_spectrum_selection_changed_signal.emit(active_spectrum)
        self.update_plot_for_spectrum(active_spectrum)
        self.remove_spectrum_button.setEnabled(bool(selected_items))
        if active_spectrum:
            if len(selected_items) > 1:
                self.update_status_message(f"{len(selected_items)} spectra selected", 2000)
            else:
                self.update_status_message(f"Selected: {active_spectrum.filename or active_spectrum.spectrum_id}", 2000)

    def update_plot_for_spectrum(self, spectrum: Optional[LIBSpectrum]):
        if spectrum and spectrum.is_valid_for_processing():
            self.spectrum_preview_plot.plot_spectrum(
                spectrum.wavelengths, spectrum.intensities,
                title=f"Preview: {spectrum.filename or spectrum.spectrum_id}",
                series_name=spectrum.filename or spectrum.spectrum_id
            )
        elif spectrum and spectrum.is_valid():
             self.spectrum_preview_plot.plot_spectrum(
                spectrum.raw_wavelengths, spectrum.raw_intensities,
                title=f"Raw Preview: {spectrum.filename or spectrum.spectrum_id}",
                series_name=f"{spectrum.filename or spectrum.spectrum_id} (Raw)"
            )
        else:
            self.spectrum_preview_plot.clear_plot()
            msg = "No spectrum selected or data is invalid."
            if spectrum: msg = f"Spectrum '{spectrum.filename or spectrum.spectrum_id}' has no plottable data."
            self.spectrum_preview_plot.show_message(msg)

    def _import_spectra(self):
        project = self.get_current_project()
        if not project:
            QMessageBox.warning(self, "No Project", "Create or open a project first to import spectra.")
            return

        default_dir = str(Path.home())
        if self.main_window and hasattr(self.main_window, 'app_settings_manager') and self.main_window.app_settings_manager:
            default_dir = self.main_window.app_settings_manager.get_value("paths", "last_import_dir", str(Path.home()))
        else: logger.warning("MainWindow or AppSettingsManager not available for default import directory. Using home.")

        filepaths, _ = QFileDialog.getOpenFileNames(
            self, "Import Spectral Files", default_dir,
            "Spectral Files (*.txt *.csv *.asc *.spc *.dat);;All Files (*)"
        )

        if filepaths:
            if self.main_window and hasattr(self.main_window, 'app_settings_manager') and self.main_window.app_settings_manager:
                self.main_window.app_settings_manager.set_value("paths", "last_import_dir", str(Path(filepaths[0]).parent))

            imported_count = 0; failed_files = []
            # TODO: Batch import in a worker thread with a progress dialog for many files
            self.update_status_message(f"Importing {len(filepaths)} files...", 0); QApplication.processEvents()
            for fpath_str in filepaths:
                fpath = Path(fpath_str)
                try:
                    loaded_data = load_spectrum_from_file(fpath_str)
                    if loaded_data:
                        wl, inten, meta = loaded_data
                        spectrum = LIBSpectrum(wl, inten, filename=fpath.name, filepath=str(fpath), metadata=meta)
                        project.add_spectrum(spectrum) # LIBSProject's add_spectrum should mark project dirty
                        imported_count += 1
                    else: failed_files.append(fpath.name)
                except Exception as e:
                    logger.error(f"Error importing file {fpath.name}: {e}", exc_info=True)
                    failed_files.append(fpath.name)
            
            self._update_spectra_list()
            if imported_count > 0: self.mark_project_dirty() # Ensure dirty marked if any successful
            
            summary_message = f"Imported {imported_count} of {len(filepaths)} spectra."
            if failed_files:
                failed_list_str = ", ".join(failed_files[:5]);
                if len(failed_files) > 5: failed_list_str += f", and {len(failed_files)-5} more..."
                summary_message += f"\nFailed to import: {failed_list_str}"
                QMessageBox.warning(self, "Import Issues", summary_message)
            elif imported_count > 0: QMessageBox.information(self, "Import Complete", summary_message)
            self.update_status_message(summary_message, 5000)

    def _remove_selected_spectrum(self):
        selected_items = self.spectra_list_widget.selectedItems()
        if not selected_items: return
        
        if len(selected_items) == 1:
            spectrum_display_name = selected_items[0].text()
            prompt = f"Are you sure you want to remove '{spectrum_display_name}' from the project?"
        else:
            prompt = f"Are you sure you want to remove {len(selected_items)} spectra from the project?"
            
        reply = QMessageBox.question(self, "Confirm Remove", prompt,
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            removed_count = 0
            for item in selected_items:
                spectrum_id_to_remove = item.data(Qt.UserRole)
                if self.project_manager.remove_spectrum_from_project(spectrum_id_to_remove):
                    removed_count += 1
                    
            if removed_count > 0:
                self._update_spectra_list()
                if removed_count == 1:
                    self.update_status_message(f"Removed spectrum.", 3000)
                else:
                    self.update_status_message(f"Removed {removed_count} spectra.", 3000)
            else: 
                QMessageBox.critical(self, "Error", "Failed to remove selected spectra.")

    def _show_spectra_list_context_menu(self, position: QPoint):
        item = self.spectra_list_widget.itemAt(position)
        if not item: return
        menu = QMenu(self)
        rename_action = menu.addAction("Rename Spectrum..."); remove_action = menu.addAction("Remove Spectrum")
        action = menu.exec_(self.spectra_list_widget.mapToGlobal(position))
        if action == rename_action: self._rename_selected_spectrum()
        elif action == remove_action: self._remove_selected_spectrum()

    def _rename_selected_spectrum(self):
        selected_items = self.spectra_list_widget.selectedItems()
        if not selected_items: return
        item = selected_items[0]; spectrum_id = item.data(Qt.UserRole)
        spectrum = self.project_manager.get_spectrum(spectrum_id)
        if not spectrum: return
        current_name = spectrum.filename or spectrum.spectrum_id
        new_name, ok = QInputDialog.getText(self, "Rename Spectrum", "New filename/display name:", QLineEdit.Normal, current_name)
        if ok and new_name and new_name.strip() != current_name:
            spectrum.filename = new_name.strip(); item.setText(spectrum.filename)
            self.mark_project_dirty()
            self.update_status_message(f"Spectrum renamed to '{spectrum.filename}'", 2000)
            if self.project_manager.get_active_spectrum() == spectrum:
                self.active_spectrum_selection_changed_signal.emit(spectrum)

    def highlight_wavelengths_on_plot(self, highlights_info: List[Dict[str, Any]]):
        if not self.spectrum_preview_plot: logger.warning("highlight_wavelengths_on_plot called but no preview plot."); return
        self.spectrum_preview_plot.clear_highlights()
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum or not active_spectrum.is_valid_for_processing(): return

        min_wl, max_wl = np.min(active_spectrum.wavelengths), np.max(active_spectrum.wavelengths)
        for info in highlights_info:
            wl = info.get("wavelength"); label = info.get("label", ""); color = info.get("color", "red")
            if wl is not None and min_wl <= wl <= max_wl:
                self.spectrum_preview_plot.add_highlight_marker(wl, label, color=color)
            elif wl is not None:
                logger.debug(f"Highlight wl {wl} outside current spectrum range ({min_wl:.2f}-{max_wl:.2f}), not shown.")
        self.spectrum_preview_plot.canvas.draw_idle()

    def _update_ui_for_active_spectrum(self):
        project = self.get_current_project(); active_spectrum = self.get_active_spectrum()
        self._update_spectra_list()
        self.update_plot_for_spectrum(active_spectrum)
        project_is_open = bool(project); spectrum_is_active = bool(active_spectrum)
        self.import_spectra_button.setEnabled(project_is_open)
        self.remove_spectrum_button.setEnabled(project_is_open and spectrum_is_active and bool(self.spectra_list_widget.selectedItems()))

    def on_tab_selected(self): super().on_tab_selected(); self._update_ui_for_active_spectrum()
    def on_project_loaded(self, project: Optional[LIBSProject] = None): super().on_project_loaded(project); self._update_ui_for_active_spectrum()
    def on_project_closed(self): super().on_project_closed(); self._update_ui_for_active_spectrum()
    def on_active_spectrum_changed(self, new_spectrum: Optional[LIBSpectrum] = None):
        super().on_active_spectrum_changed(new_spectrum)
        # _update_spectra_list ensures the correct item is selected in the list
        # update_plot_for_spectrum plots the new spectrum
        # remove_spectrum_button state is updated based on new selection
        self._update_ui_for_active_spectrum() # Consolidate updates here

    def on_preferences_updated(self, new_settings: Dict[str, Any]):
        super().on_preferences_updated(new_settings)
        logger.info(f"{self.__class__.__name__} received preference update notification.")


if __name__ == '__main__':
    import sys
    from pathlib import Path
    try: from ...core.data_models import LIBSProject, LIBSpectrum
    except ImportError:
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))
        from team404.core.data_models import LIBSProject, LIBSpectrum
    from team404.gui.dialogs.preferences_dialog import app_settings_manager

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG, format='%(asctime)s-%(name)s[%(levelname)s]%(module)s:%(lineno)d-%(message)s')

    app = QApplication(sys.argv)
    QApplication.setOrganizationName("Team404Test")
    QApplication.setApplicationName("ProjectDataTabTestApp")

    class MockMainWindow(QWidget):
        def __init__(self, project_manager):
            super().__init__()
            self.project_manager = project_manager
            self.app_settings_manager = app_settings_manager
            self.statusBar = lambda: self # Mock status bar
        def update_status_bar(self, main_message, project_message=None, timeout_ms=0): logger.info(f"MW_Status: {main_message} | Proj: {project_message}")
        def mark_project_dirty(self, dirty=True): self.project_manager.mark_project_dirty(dirty)

    class MockProjectManager: # Simplified
        def __init__(self): self.current_project: Optional[LIBSProject] = None
        def get_active_spectrum(self) -> Optional[LIBSpectrum]: return self.current_project.get_active_spectrum() if self.current_project else None
        def get_current_project(self) -> Optional[LIBSProject]: return self.current_project
        def mark_project_dirty(self, dirty=True): logger.info(f"MockPM: Project dirty={dirty}.")
        def remove_spectrum_from_project(self, spec_id): return self.current_project.remove_spectrum(spec_id) if self.current_project else False
        def get_spectrum(self, spec_id): return self.current_project.get_spectrum(spec_id) if self.current_project else None
        def get_project_settings(self): return app_settings_manager.settings # Use actual global instance

    pm = MockProjectManager()
    mock_main_win = MockMainWindow(pm)
    
    test_project = LIBSProject("Test Project Data Tab")
    wl = np.linspace(200, 800, 500); intensity1 = np.sin(wl / 50) * 100 + np.random.rand(500) * 10 + 110
    intensity2 = np.cos(wl / 30) * 80 + np.random.rand(500) * 15 + 120
    spec1 = LIBSpectrum(wl, intensity1, filename="Spectrum_Alpha.txt", spectrum_id="S1")
    spec2 = LIBSpectrum(wl, intensity2, filename="Spectrum_Beta.csv", spectrum_id="S2")
    test_project.add_spectrum(spec1); test_project.add_spectrum(spec2)
    test_project.set_active_spectrum(spec1.spectrum_id)
    pm.current_project = test_project

    tab = LIBSProjectTab(project_manager=pm, main_window=mock_main_win, parent=mock_main_win)
    
    mock_main_win.setLayout(QVBoxLayout()); mock_main_win.layout().addWidget(tab)
    mock_main_win.setWindowTitle("Project Data Tab Test"); mock_main_win.resize(900, 600)
    
    if pm.current_project:
        tab.on_project_loaded(pm.current_project)
        # active_spectrum_changed is indirectly called by on_project_loaded -> _update_ui_for_active_spectrum -> _update_spectra_list -> (selection) -> _on_spectrum_selection_changed -> emits signal
    tab.on_tab_selected() # This will also call _update_ui_for_active_spectrum
    
    mock_main_win.show()
    sys.exit(app.exec_())
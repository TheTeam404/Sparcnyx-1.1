# team404/gui/tabs/preprocessing_tab.py

"""
PreprocessingTab for SpectraMapper Pro.
Allows users to define and apply a sequence of preprocessing steps
to the active spectrum.
"""

import logging
from typing import List, Dict, Optional, Any, TYPE_CHECKING
import copy

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QPushButton, QLabel, QListWidget, QListWidgetItem, QComboBox,
    QStackedWidget, QSpinBox, QDoubleSpinBox, QLineEdit,
    QCheckBox, QSplitter, QMessageBox, QAbstractItemView, QScrollArea,
    QSizePolicy, QApplication, QProgressDialog
)
from PyQt5.QtCore import Qt, pyqtSignal
from matplotlib.path import Path
import numpy as np

from .base_tab import BaseTab
from ..widgets.spectrum_plot_widget import SpectrumPlotWidget # For live preview
from ...core.data_models import LIBSpectrum, ProcessingStep, LIBSProject # Corrected import
from ...core.spectrum_handler import SpectrumProcessor
from ...core.preprocessing_algorithms import PROCESSING_FUNCTION_REGISTRY, DEFAULT_PARAMS_SCHEMA

if TYPE_CHECKING:
    from ..main_window import MainWindow

logger = logging.getLogger(__name__)


class PreprocessingStepWidget(QWidget):
    """
    A widget to configure parameters for a single preprocessing step,
    dynamically generated based on a parameter schema.
    """
    parameters_changed = pyqtSignal(dict)

    def __init__(self, step_func_name: str, current_params: dict, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.step_func_name = step_func_name
        self.param_widgets: Dict[str, QWidget] = {}
        
        layout = QFormLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(8)
        self.setLayout(layout)

        step_schema = DEFAULT_PARAMS_SCHEMA.get(step_func_name, {})
        if not step_schema:
            layout.addRow(QLabel(f"No UI schema defined for '{step_func_name}'. Using defaults."))
            return

        for param_name, param_info in step_schema.items():
            label_text = param_info.get("label", param_name.replace("_", " ").title()) + ":"
            default_value = param_info.get("default")
            current_value = current_params.get(param_name, default_value)
            param_type = param_info.get("type", "float")
            tooltip = param_info.get("tooltip", f"Parameter: {param_name}")

            widget: Optional[QWidget] = None
            if param_type == "int":
                widget = self._add_spinbox(layout, param_name, current_value, 
                                  param_info.get("min", 0), param_info.get("max", 10000), 
                                  label_text, param_info.get("step", 1), param_info.get("suffix",""), tooltip)
            elif param_type == "float":
                widget = self._add_double_spinbox(layout, param_name, current_value,
                                         param_info.get("min", 0.0), param_info.get("max", 1e9),
                                         label_text, param_info.get("decimals", 3), 
                                         param_info.get("step", 0.01), param_info.get("suffix",""), tooltip)
            elif param_type == "str":
                if "options" in param_info:
                    widget = self._add_combobox(layout, param_name, current_value, param_info["options"], label_text, tooltip)
                else:
                    widget = self._add_line_edit(layout, param_name, current_value, label_text, param_info.get("placeholder",""), tooltip)
            elif param_type == "bool":
                widget = self._add_checkbox(layout, param_name, current_value, label_text, tooltip)
            else:
                logger.warning(f"Unsupported param type '{param_type}' in schema for {step_func_name}.{param_name}")
                layout.addRow(label_text, QLabel(f"Unsupported param type: {param_type}"))
            
            if widget:
                widget.setToolTip(tooltip)


    def _add_spinbox(self, layout: QFormLayout, name: str, value: Any, min_val: int, max_val: int, label: str, step: int =1, suffix: str ="", tooltip: str = "") -> QSpinBox:
        widget = QSpinBox()
        widget.setRange(min_val, max_val); widget.setValue(int(value if value is not None else min_val))
        widget.setSingleStep(step); 
        if suffix: widget.setSuffix(f" {suffix}")
        widget.valueChanged.connect(self._emit_parameters_changed)
        layout.addRow(label, widget); self.param_widgets[name] = widget
        return widget

    def _add_double_spinbox(self, layout: QFormLayout, name: str, value: Any, min_val: float, max_val: float, label: str, decimals: int =2, step: float =0.1, suffix: str ="", tooltip: str = "") -> QDoubleSpinBox:
        widget = QDoubleSpinBox()
        widget.setDecimals(decimals); widget.setRange(min_val, max_val)
        widget.setValue(float(value if value is not None else min_val)); widget.setSingleStep(step)
        if suffix: widget.setSuffix(f" {suffix}")
        widget.valueChanged.connect(self._emit_parameters_changed)
        layout.addRow(label, widget); self.param_widgets[name] = widget
        return widget
        
    def _add_line_edit(self, layout: QFormLayout, name: str, value: Any, label: str, placeholder: str ="", tooltip: str = "") -> QLineEdit:
        widget = QLineEdit(str(value if value is not None else ""))
        if placeholder: widget.setPlaceholderText(placeholder)
        widget.textChanged.connect(self._emit_parameters_changed)
        layout.addRow(label, widget); self.param_widgets[name] = widget
        return widget

    def _add_checkbox(self, layout: QFormLayout, name: str, value: Any, label: str, tooltip: str = "") -> QCheckBox:
        widget = QCheckBox(label) 
        widget.setChecked(bool(value if value is not None else False))
        widget.toggled.connect(self._emit_parameters_changed)
        layout.addRow(widget); self.param_widgets[name] = widget
        return widget
    
    def _add_combobox(self, layout: QFormLayout, name: str, value: Any, options: List[str], label: str, tooltip: str = "") -> QComboBox:
        widget = QComboBox()
        widget.addItems(options)
        if value in options:
            widget.setCurrentText(value)
        elif options: 
            widget.setCurrentIndex(0)
        widget.currentTextChanged.connect(self._emit_parameters_changed)
        layout.addRow(label, widget); self.param_widgets[name] = widget
        return widget

    def _emit_parameters_changed(self):
        self.parameters_changed.emit(self.get_parameters())

    def get_parameters(self) -> Dict[str, Any]:
        params = {}
        for name, widget in self.param_widgets.items():
            if isinstance(widget, (QSpinBox, QDoubleSpinBox)): params[name] = widget.value()
            elif isinstance(widget, QLineEdit): params[name] = widget.text()
            elif isinstance(widget, QCheckBox): params[name] = widget.isChecked()
            elif isinstance(widget, QComboBox): params[name] = widget.currentText()
        return params

class PreprocessingTab(BaseTab):
    """Tab for defining and applying a preprocessing pipeline."""
    def __init__(self, project_manager, main_window: Optional['MainWindow'] = None, parent: Optional[QWidget] = None):
        super().__init__(project_manager, main_window, parent)
        self.current_pipeline_ui: List[ProcessingStep] = []
        self.preview_spectrum: Optional[LIBSpectrum] = None
        self.spectrum_processor = SpectrumProcessor()

        self._init_ui()

    def _init_ui(self):
        main_splitter = QSplitter(Qt.Horizontal, self)

        controls_widget_scroll = QScrollArea()
        controls_widget_scroll.setWidgetResizable(True)
        controls_widget_scroll.setMinimumWidth(380)
        controls_widget_scroll.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)

        controls_widget = QWidget()
        controls_layout = QVBoxLayout(controls_widget)
        controls_layout.setSpacing(10)

        available_steps_group = QGroupBox("Available Preprocessing Steps")
        available_steps_layout = QHBoxLayout(available_steps_group)
        self.available_steps_combo = QComboBox()
        
        self.func_name_to_display_map: Dict[str, str] = PROCESSING_FUNCTION_REGISTRY
        self.display_name_to_func_map: Dict[str, str] = {v: k for k, v in PROCESSING_FUNCTION_REGISTRY.items()}
        
        self.available_steps_combo.addItems(sorted(list(self.display_name_to_func_map.keys())))
        self.available_steps_combo.setToolTip("Select a preprocessing step to add to the pipeline.")
        available_steps_layout.addWidget(self.available_steps_combo, 1)
        self.add_step_button = QPushButton("Add to Pipeline")
        self.add_step_button.setToolTip("Add the selected step to the end of the current pipeline.")
        self.add_step_button.clicked.connect(self._add_step_to_pipeline)
        available_steps_layout.addWidget(self.add_step_button)
        controls_layout.addWidget(available_steps_group)

        pipeline_group = QGroupBox("Current Processing Pipeline")
        pipeline_layout = QVBoxLayout(pipeline_group)
        self.pipeline_list_widget = QListWidget()
        self.pipeline_list_widget.setDragDropMode(QAbstractItemView.InternalMove)
        self.pipeline_list_widget.setToolTip("Current sequence of preprocessing steps. Drag to reorder. Select a step to edit its parameters.")
        self.pipeline_list_widget.currentRowChanged.connect(self._on_pipeline_step_selected)
        pipeline_layout.addWidget(self.pipeline_list_widget)

        pipeline_buttons_layout = QHBoxLayout()
        self.remove_step_button = QPushButton("Remove"); self.remove_step_button.setToolTip("Remove the selected step from the pipeline.")
        self.remove_step_button.clicked.connect(self._remove_selected_step)
        self.move_step_up_button = QPushButton("Move Up"); self.move_step_up_button.setToolTip("Move selected step up in the pipeline.")
        self.move_step_up_button.clicked.connect(lambda: self._move_selected_step(-1))
        self.move_step_down_button = QPushButton("Move Down"); self.move_step_down_button.setToolTip("Move selected step down in the pipeline.")
        self.move_step_down_button.clicked.connect(lambda: self._move_selected_step(1))
        for btn in [self.remove_step_button, self.move_step_up_button, self.move_step_down_button]: btn.setEnabled(False)
        pipeline_buttons_layout.addWidget(self.remove_step_button); pipeline_buttons_layout.addWidget(self.move_step_up_button)
        pipeline_buttons_layout.addWidget(self.move_step_down_button); pipeline_buttons_layout.addStretch()
        pipeline_layout.addLayout(pipeline_buttons_layout)
        controls_layout.addWidget(pipeline_group)

        self.step_params_group = QGroupBox("Step Parameters")
        step_params_outer_layout = QVBoxLayout(self.step_params_group)
        self.step_params_stack = QStackedWidget()
        step_params_outer_layout.addWidget(self.step_params_stack)
        self.step_params_group.setVisible(False)
        controls_layout.addWidget(self.step_params_group)
        
        actions_layout = QHBoxLayout()
        self.apply_pipeline_button = QPushButton("Apply Pipeline to Active Spectrum")
        self.apply_pipeline_button.setToolTip("Permanently apply the current UI pipeline to the active spectrum's processed data.")
        self.apply_pipeline_button.clicked.connect(self._apply_pipeline_to_active_spectrum)

        self.apply_all_button = QPushButton("Apply to All Project Spectra")
        self.apply_all_button.setToolTip("Batch apply the current UI pipeline to all spectra in the current project.")
        self.apply_all_button.clicked.connect(self._apply_pipeline_to_all_spectra)

        self.reset_preview_button = QPushButton("Reset Preview to Raw")
        self.reset_preview_button.setToolTip("Reset the preview plot to show the spectrum's original raw data.")
        self.reset_preview_button.clicked.connect(self._reset_preview_to_raw)
        
        actions_layout.addWidget(self.reset_preview_button)
        actions_layout.addWidget(self.apply_pipeline_button)
        actions_layout.addWidget(self.apply_all_button)
        controls_layout.addLayout(actions_layout)

        controls_layout.addStretch()
        controls_widget_scroll.setWidget(controls_widget)
        main_splitter.addWidget(controls_widget_scroll)

        self.preview_plot_widget = SpectrumPlotWidget(self)
        self.preview_plot_widget.set_title("Preprocessing Preview")
        main_splitter.addWidget(self.preview_plot_widget)
        main_splitter.setSizes([400, 700])

        self.base_layout.addWidget(main_splitter)

    def _get_default_params_for_func_name(self, func_name: str) -> dict:
        step_schema = DEFAULT_PARAMS_SCHEMA.get(func_name, {})
        defaults = {}
        for param_name, param_info in step_schema.items():
            defaults[param_name] = param_info.get("default")
        return defaults

    def _add_step_to_pipeline(self):
        display_name = self.available_steps_combo.currentText()
        step_func_name = self.display_name_to_func_map.get(display_name)

        if not step_func_name:
            QMessageBox.warning(self, "Step Error", f"Internal error: Could not map display name '{display_name}' to a function.")
            return

        default_params = self._get_default_params_for_func_name(step_func_name)
        new_step = ProcessingStep(name=step_func_name, parameters=default_params.copy(), enabled=True)
        
        self.current_pipeline_ui.append(new_step)
        self._update_pipeline_list_widget_and_params_stack()
        self.pipeline_list_widget.setCurrentRow(len(self.current_pipeline_ui) - 1)
        self._live_preview()

    def _update_pipeline_list_widget_and_params_stack(self):
        current_row_selected = self.pipeline_list_widget.currentRow()

        self.pipeline_list_widget.clear()
        while self.step_params_stack.count() > 0:
            widget = self.step_params_stack.widget(0)
            self.step_params_stack.removeWidget(widget)
            if widget: widget.deleteLater()

        for i, step in enumerate(self.current_pipeline_ui):
            display_name_prefix = self.func_name_to_display_map.get(step.name, step.name)
            item_text = f"{i+1}. {display_name_prefix}"
            if not step.enabled: item_text += " (Disabled)"
            
            list_item = QListWidgetItem(item_text, self.pipeline_list_widget)
            list_item.setData(Qt.UserRole, step)

            param_widget = PreprocessingStepWidget(step.name, step.parameters.copy())
            param_widget.parameters_changed.connect(
                lambda params, s=step: self._on_step_params_changed(s, params)
            )
            self.step_params_stack.addWidget(param_widget)
            
        if 0 <= current_row_selected < len(self.current_pipeline_ui):
            self.pipeline_list_widget.setCurrentRow(current_row_selected)
        elif self.current_pipeline_ui:
            self.pipeline_list_widget.setCurrentRow(len(self.current_pipeline_ui) - 1)
        
        self._on_pipeline_step_selected(self.pipeline_list_widget.currentRow())

    def _on_pipeline_step_selected(self, current_row: int):
        is_valid_selection = 0 <= current_row < len(self.current_pipeline_ui)
        self.remove_step_button.setEnabled(is_valid_selection)
        self.move_step_up_button.setEnabled(is_valid_selection and current_row > 0)
        self.move_step_down_button.setEnabled(is_valid_selection and current_row < len(self.current_pipeline_ui) - 1)

        if is_valid_selection:
            self.step_params_stack.setCurrentIndex(current_row)
            self.step_params_group.setVisible(True)
            step_obj: ProcessingStep = self.pipeline_list_widget.item(current_row).data(Qt.UserRole)
            step_display_name = self.func_name_to_display_map.get(step_obj.name, step_obj.name)
            self.step_params_group.setTitle(f"Parameters for: {step_display_name}")
        else:
            self.step_params_stack.setCurrentIndex(-1)
            self.step_params_group.setVisible(False)
            self.step_params_group.setTitle("Step Parameters")

    def _on_step_params_changed(self, step_object: ProcessingStep, new_params: Dict[str, Any]):
        step_object.parameters.update(new_params)
        logger.debug(f"UI Params for step '{step_object.name}' (in current_pipeline_ui) updated: {step_object.parameters}")
        self._live_preview()

    def _remove_selected_step(self):
        current_row = self.pipeline_list_widget.currentRow()
        if 0 <= current_row < len(self.current_pipeline_ui):
            removed_step_obj = self.current_pipeline_ui.pop(current_row)
            self._update_pipeline_list_widget_and_params_stack()
            logger.info(f"Removed step from UI pipeline: {removed_step_obj.name}")
            self._live_preview()

    def _move_selected_step(self, direction: int):
        current_row = self.pipeline_list_widget.currentRow()
        new_row = current_row + direction
        if not (0 <= current_row < len(self.current_pipeline_ui) and \
                0 <= new_row < len(self.current_pipeline_ui)): return

        self.current_pipeline_ui.insert(new_row, self.current_pipeline_ui.pop(current_row))
        self._update_pipeline_list_widget_and_params_stack()
        self.pipeline_list_widget.setCurrentRow(new_row)
        logger.info(f"Moved step in UI pipeline from row {current_row} to {new_row}")
        self._live_preview()

    def _live_preview(self):
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum or not active_spectrum.is_valid_for_processing():
            self.preview_plot_widget.clear_plot()
            self.preview_plot_widget.show_message("No valid active spectrum for preview.")
            return

        if not self.current_pipeline_ui:
            self.preview_plot_widget.plot_spectrum(
                active_spectrum.wavelengths, active_spectrum.intensities,
                title=f"Current State: {active_spectrum.spectrum_id} (No UI pipeline steps)"
            )
            return

        self.preview_spectrum = LIBSpectrum(
            active_spectrum.raw_wavelengths.copy(), active_spectrum.raw_intensities.copy(),
            spectrum_id=active_spectrum.spectrum_id + "_preview", filename=active_spectrum.filename,
            metadata=copy.deepcopy(active_spectrum.metadata)
        )
        if active_spectrum.peaks:
            self.preview_spectrum.peaks = copy.deepcopy(active_spectrum.peaks)

        try:
            self.spectrum_processor.apply_pipeline(self.preview_spectrum, self.current_pipeline_ui)
            self.preview_plot_widget.plot_spectrum(
                self.preview_spectrum.wavelengths, self.preview_spectrum.intensities,
                title=f"Preview: {active_spectrum.spectrum_id} ({len(self.current_pipeline_ui)} UI steps on raw)"
            )
        except Exception as e:
            logger.error(f"Error during live preview processing: {e}", exc_info=True)
            self.preview_plot_widget.clear_plot()
            preview_error_msg = f"Preview Error applying UI pipeline:\n{str(e)[:150]}"
            self.preview_plot_widget.show_message(preview_error_msg)
            self.update_status_message("Error in preview pipeline.", 3000)

    def _apply_pipeline_to_active_spectrum(self):
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum:
            QMessageBox.warning(self, "No Spectrum", "No active spectrum to apply pipeline to.")
            return
        
        pipeline_to_apply = copy.deepcopy(self.current_pipeline_ui)

        if not pipeline_to_apply:
            reply = QMessageBox.question(self, "Empty UI Pipeline",
                                       "The UI pipeline is empty. Applying this will reset the active spectrum's "
                                       "processing to its raw data state and clear its stored pipeline.\n"
                                       "Do you want to proceed?",
                                       QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.No: return

        try:
            self.spectrum_processor.apply_pipeline(active_spectrum, pipeline_to_apply) 
            self.mark_project_dirty()
            self.update_status_message("Preprocessing pipeline applied successfully to active spectrum.", 3000)
            logger.info(f"Applied UI pipeline (len {len(pipeline_to_apply)}) to spectrum {active_spectrum.spectrum_id}.")
            self._load_pipeline_from_active_spectrum()
            self._live_preview()
            self.active_spectrum_processed_externally.emit(active_spectrum.spectrum_id)
        except Exception as e:
            logger.error(f"Error applying pipeline to active spectrum: {e}", exc_info=True)
            QMessageBox.critical(self, "Pipeline Application Error", f"Failed to apply pipeline: {str(e)[:200]}")
            self.update_status_message("Error applying pipeline.", 5000)

    def _apply_pipeline_to_all_spectra(self):
        project = self.get_current_project()
        if not project or not project.spectra:
            QMessageBox.warning(self, "No Spectra", "No spectra in the project to apply pipeline to.")
            return

        pipeline_to_apply = copy.deepcopy(self.current_pipeline_ui)

        if not pipeline_to_apply:
            reply = QMessageBox.question(self, "Empty UI Pipeline",
                                       "The UI pipeline is empty. Applying this will reset ALL spectra's "
                                       "processing to their raw data state and clear their stored pipelines.\n"
                                       "Do you want to proceed?",
                                       QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.No: return

        self.update_status_message(f"Applying pipeline to {len(project.spectra)} spectra...", 0)
        progress = QProgressDialog("Batch Preprocessing Spectra...", "Cancel", 0, len(project.spectra), self)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(500)

        success_count = 0
        for i, (spec_id, spectrum) in enumerate(project.spectra.items()):
            if progress.wasCanceled():
                self.update_status_message("Batch processing canceled.", 3000)
                break
            
            progress.setValue(i)
            progress.setLabelText(f"Processing spectrum {i+1} of {len(project.spectra)}: {spectrum.filename or spectrum.spectrum_id}")
            QApplication.processEvents()

            try:
                self.spectrum_processor.apply_pipeline(spectrum, copy.deepcopy(pipeline_to_apply))
                success_count += 1
            except Exception as e:
                logger.error(f"Error applying pipeline to {spectrum.spectrum_id}: {e}", exc_info=True)
                
        progress.setValue(len(project.spectra))
        
        if success_count > 0:
            self.mark_project_dirty()
            
            active_spectrum = self.get_active_spectrum()
            if active_spectrum:
                self._load_pipeline_from_active_spectrum()
                self._live_preview()
                self.active_spectrum_processed_externally.emit(active_spectrum.spectrum_id)
                
            self.update_status_message(f"Pipeline applied successfully to {success_count} spectra.", 3000)
        else:
            self.update_status_message("Pipeline application failed on all spectra.", 5000)

    def _reset_preview_to_raw(self):
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum or not active_spectrum.is_valid_for_processing():
            self.preview_plot_widget.clear_plot()
            self.preview_plot_widget.show_message("No valid active spectrum.")
            return
        
        self.preview_plot_widget.plot_spectrum(
            active_spectrum.raw_wavelengths, active_spectrum.raw_intensities,
            title=f"Raw: {active_spectrum.spectrum_id}"
        )
        self.update_status_message("Preview reset to show raw data of active spectrum.", 2000)

    def _update_ui_for_active_spectrum(self):
        active_spectrum = self.get_active_spectrum()
        enable_actions = bool(active_spectrum and active_spectrum.is_valid_for_processing())
        
        self.add_step_button.setEnabled(enable_actions)
        self.apply_pipeline_button.setEnabled(enable_actions)
        self.apply_all_button.setEnabled(enable_actions)
        self.reset_preview_button.setEnabled(enable_actions)
        
        is_step_selected = self.pipeline_list_widget.currentRow() >= 0
        self.remove_step_button.setEnabled(is_step_selected)
        self.move_step_up_button.setEnabled(is_step_selected and self.pipeline_list_widget.currentRow() > 0)
        self.move_step_down_button.setEnabled(is_step_selected and self.pipeline_list_widget.currentRow() < len(self.current_pipeline_ui) -1)
        
        if active_spectrum:
            self._load_pipeline_from_active_spectrum()
            self._live_preview()
        else:
            self.current_pipeline_ui = []
            self._update_pipeline_list_widget_and_params_stack()
            self.preview_plot_widget.clear_plot()
            self.preview_plot_widget.show_message("No active spectrum.")

    def on_tab_selected(self):
        super().on_tab_selected()
        self._update_ui_for_active_spectrum()

    def on_project_loaded(self, project: Optional[LIBSProject] = None): # Changed LIBSProject to LIBSProject
        super().on_project_loaded(project)
        self.current_pipeline_ui = []
        self.preview_spectrum = None
        self._update_pipeline_list_widget_and_params_stack()
        self._update_ui_for_active_spectrum()

    def on_project_closed(self):
        super().on_project_closed()
        self.current_pipeline_ui = []
        self.preview_spectrum = None
        self._update_pipeline_list_widget_and_params_stack()
        self.preview_plot_widget.clear_plot()
        self.preview_plot_widget.show_message("No project open.")
        self._update_ui_for_active_spectrum()

    def on_active_spectrum_changed(self, new_spectrum: Optional[LIBSpectrum] = None):
        super().on_active_spectrum_changed(new_spectrum)
        self._update_ui_for_active_spectrum()

    def _load_pipeline_from_active_spectrum(self):
        active_spectrum = self.get_active_spectrum()
        if active_spectrum and active_spectrum.processing_pipeline:
            self.current_pipeline_ui = copy.deepcopy(active_spectrum.processing_pipeline)
        else:
            self.current_pipeline_ui = []
        self._update_pipeline_list_widget_and_params_stack()

    def on_preferences_updated(self, new_settings: dict):
        super().on_preferences_updated(new_settings)
        logger.info(f"{self.__class__.__name__} received preference update notification.")


if __name__ == '__main__':
    from PyQt5.QtWidgets import QApplication, QMainWindow
    import sys
    try:
        from ...core.data_models import LIBSProject, LIBSpectrum # For running as part of package
    except ImportError: # Fallback for running script directly
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))
        from team404.core.data_models import LIBSProject, LIBSpectrum


    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG, format='%(asctime)s - %(name)s [%(levelname)s] %(module)s:%(lineno)d - %(message)s')

    app = QApplication(sys.argv)
    
    class MockProjectManager:
        def __init__(self): self.current_project: Optional[LIBSProject] = None; self.default_project_settings = {}
        def get_current_project(self) -> Optional[LIBSProject]: return self.current_project
        def get_active_spectrum(self) -> Optional[LIBSpectrum]: return self.current_project.get_active_spectrum() if self.current_project else None
        def mark_dirty(self): print("MockProjectManager: Project marked dirty.")
        def get_project_settings(self) -> dict: return {}

    main_win = QMainWindow()
    pm = MockProjectManager()
    
    project = LIBSProject("Test Preprocessing Project")
    wl = np.linspace(200, 800, 1024)
    baseline = 50 + 0.05 * wl + np.sin(wl / 50) * 20
    peaks_signal = 200 * np.exp(-((wl - 300)**2) / (2 * 2**2)) + 150 * np.exp(-((wl - 500)**2) / (2 * 3**2))
    noise = np.random.normal(0, 5, size=wl.shape)
    inte = baseline + peaks_signal + noise
    
    spectrum1 = LIBSpectrum(wl.copy(), inte.copy(), filename="test_spec_preproc.txt", spectrum_id="spec_01")
    project.add_spectrum(spectrum1)
    project.set_active_spectrum(spectrum1.spectrum_id)
    pm.current_project = project

    tab = PreprocessingTab(project_manager=pm, main_window=main_win)
    
    main_win.setCentralWidget(tab)
    main_win.setWindowTitle("Preprocessing Tab Test")
    main_win.setGeometry(100, 100, 950, 750)
    main_win.show()
    
    # Simulate signals
    if pm.current_project:
        tab.on_project_loaded(pm.current_project) 
        if pm.current_project.get_active_spectrum():
            tab.on_active_spectrum_changed(pm.current_project.get_active_spectrum())
    tab.on_tab_selected() 

    sys.exit(app.exec_())
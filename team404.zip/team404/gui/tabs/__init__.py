# team404/gui/tabs/__init__.py

"""
Tabs sub-package for SpectraMapper Pro's GUI.

This package contains QWidget subclasses, each representing a major
functional tab in the main application window (e.g., Data Import,
Preprocessing, Peak Analysis, etc.).
"""

from .base_tab import BaseTab
# from .project_data_tab import LIBSProjectTab # To be created
# from .preprocessing_tab import PreprocessingTab # To be created
# from .peak_analysis_tab import PeakAnalysisTab # To be created
# from .elemental_id_tab import ElementalIdTab # To be created
# from .quantitative_tab import QuantitativeTab # To be created
# from .mapping_tab import MappingTab # To be created
# from .chemometrics_tab import ChemometricsTab # To be created


__all__ = [
    "BaseTab",
    # "LIBSProjectTab",
    # "PreprocessingTab",
    # "PeakAnalysisTab",
    # "ElementalIdTab",
    # "QuantitativeTab",
    # "MappingTab",
    # "ChemometricsTab",
]
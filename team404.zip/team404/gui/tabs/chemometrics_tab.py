# team404/gui/tabs/chemometrics_tab.py

"""
ChemometricsTab for SpectraMapper Pro.
Provides UI for performing multivariate analysis like PCA, PLS-R, and Classification.
"""

import logging
from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QPushButton, QGroupBox,
    QFormLayout, QSpinBox, QCheckBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QLabel, QSplitter, QFileDialog, QMessageBox, QScrollArea,
    QSizePolicy, QDoubleSpinBox, QProgressDialog, QApplication
)
from PyQt5.QtCore import Qt, pyqtSignal, QObject, QThread
import numpy as np
import pandas as pd

from .base_tab import BaseTab
from ..widgets.spectrum_plot_widget import SpectrumPlotWidget
from ...core.chemometrics_tools import (
    _preprocess_spectra_for_chemometrics,
    perform_pca,
    perform_pls_regression,
    train_classifier_model
)
from ...core.data_models import LIBSpectrum, LIBSProject
from ...core.file_io import load_spectrum_from_file

logger = logging.getLogger(__name__)

# --- MODIFIED: Added a worker for background data loading and preprocessing ---
class ChemometricsDataWorker(QObject):
    """Worker to load and preprocess a spectral dataset from file paths."""
    finished = pyqtSignal(dict) # Emits result dict on completion or error
    progress = pyqtSignal(int, int, str)

    def __init__(self, filepaths_or_spectra: list, params: dict):
        super().__init__()
        self.input_data = filepaths_or_spectra
        self.params = params
        self._is_cancelled = False

    def run(self):
        try:
            total_items = len(self.input_data)
            spectra_data_list = []
            sample_ids = []

            for i, item in enumerate(self.input_data):
                if self._is_cancelled:
                    self.finished.emit({"error": "Operation cancelled by user."})
                    return
                
                if isinstance(item, Path) or isinstance(item, str):
                    fpath = Path(item)
                    self.progress.emit(i, total_items + 1, f"Loading: {fpath.name}")
                    loaded_data = load_spectrum_from_file(fpath) # Uses default parsing for now
                    if loaded_data:
                        wl, inten, _ = loaded_data
                        spectra_data_list.append((wl, inten))
                        sample_ids.append(fpath.stem)
                    else:
                        logger.warning(f"Skipping chemometrics file due to load failure: {fpath}")
                else: 
                    # Treat item as LIBSpectrum
                    self.progress.emit(i, total_items + 1, f"Processing Project Spectrum: {item.filename or item.spectrum_id}")
                    wl = item.wavelengths if item.is_valid_for_processing() else item.raw_wavelengths
                    inten = item.intensities if item.is_valid_for_processing() else item.raw_intensities
                    if wl.size > 0 and inten.size > 0:
                        spectra_data_list.append((wl, inten))
                        sample_ids.append(item.filename or item.spectrum_id)

            if not spectra_data_list:
                raise ValueError("No valid spectra could be loaded or found in the project.")
            
            self.progress.emit(total_items, total_items + 1, "Preprocessing dataset...")
            
            X_matrix, wavelength_axis = _preprocess_spectra_for_chemometrics(
                spectra_data_list, **self.params
            )
            
            self.progress.emit(total_items + 1, total_items + 1, "Complete.")
            self.finished.emit({
                "success": True,
                "X_matrix": X_matrix,
                "wavelength_axis": wavelength_axis,
                "sample_ids": sample_ids
            })

        except Exception as e:
            logger.error(f"Error in ChemometricsDataWorker: {e}", exc_info=True)
            self.finished.emit({"error": str(e)})

    def cancel(self):
        self._is_cancelled = True

class ChemometricsTab(BaseTab):
    """Tab for performing chemometric analysis on spectral datasets."""

    def __init__(self, project_manager, main_window=None, parent=None):
        super().__init__(project_manager, main_window, parent)
        
        self.current_chem_data: Optional[np.ndarray] = None
        self.current_chem_wavelengths: Optional[np.ndarray] = None
        self.current_sample_ids: Optional[List[str]] = None
        self.current_target_y: Optional[np.ndarray] = None
        self.current_class_labels: Optional[np.ndarray] = None

        self.worker_thread: Optional[QThread] = None
        self.data_worker: Optional[ChemometricsDataWorker] = None
        
        self._init_ui()
        self._on_method_change(self.method_combo.currentText())
        self._on_baseline_method_change()

    def _init_ui(self):
        """Initialize the UI components for the Chemometrics tab."""
        main_splitter = QSplitter(Qt.Horizontal, self)

        controls_widget = QWidget()
        controls_layout = QVBoxLayout(controls_widget)
        controls_widget.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        controls_widget.setMinimumWidth(380)

        # --- MODIFIED: Data loading is now independent ---
        data_group = QGroupBox("Data for Analysis")
        data_form_layout = QFormLayout(data_group)
        button_layout = QHBoxLayout()
        self.load_spectra_folder_button = QPushButton("Load from Folder...")
        self.load_spectra_folder_button.setToolTip("Load and preprocess a folder of spectra from disk.")
        self.load_spectra_folder_button.clicked.connect(self._load_spectral_dataset_from_folder)
        button_layout.addWidget(self.load_spectra_folder_button)
        
        self.use_project_spectra_button = QPushButton("Use Project Spectra")
        self.use_project_spectra_button.setToolTip("Use all spectra currently loaded in the active project.")
        self.use_project_spectra_button.clicked.connect(self._use_project_spectra_for_analysis)
        button_layout.addWidget(self.use_project_spectra_button)

        data_form_layout.addRow(button_layout)
        
        self.data_status_label = QLabel("No data loaded.")
        self.data_status_label.setWordWrap(True)
        data_form_layout.addRow(self.data_status_label)
        controls_layout.addWidget(data_group)

        # --- MODIFIED: Preprocessing section with dynamic parameter widgets ---
        preproc_group = QGroupBox("Chemometrics Preprocessing")
        self.preproc_form_layout = QFormLayout(preproc_group)
        
        self.preproc_interpolate_checkbox = QCheckBox("Interpolate to common axis")
        self.preproc_interpolate_checkbox.setChecked(True)
        self.preproc_form_layout.addRow(self.preproc_interpolate_checkbox)

        self.preproc_interp_step_spinbox = QDoubleSpinBox()
        self.preproc_interp_step_spinbox.setDecimals(3); self.preproc_interp_step_spinbox.setRange(0.001, 5.0)
        self.preproc_interp_step_spinbox.setValue(0.05); self.preproc_interp_step_spinbox.setSuffix(" nm")
        self.preproc_form_layout.addRow("Interpolation Step:", self.preproc_interp_step_spinbox)
        self.preproc_interpolate_checkbox.toggled.connect(self.preproc_interp_step_spinbox.setEnabled)

        self.preproc_baseline_combo = QComboBox()
        self.preproc_baseline_combo.addItems(["None", "ALS", "Polynomial"])
        self.preproc_baseline_combo.setCurrentText("ALS")
        self.preproc_baseline_combo.currentTextChanged.connect(self._on_baseline_method_change)
        self.preproc_form_layout.addRow("Baseline Method:", self.preproc_baseline_combo)

        # Dynamic widgets for baseline parameters
        self.als_lambda_label = QLabel("ALS Lambda:")
        self.als_lambda_spinbox = QDoubleSpinBox(); self.als_lambda_spinbox.setDecimals(0); self.als_lambda_spinbox.setRange(1, 1e9); self.als_lambda_spinbox.setValue(1e5)
        self.preproc_form_layout.addRow(self.als_lambda_label, self.als_lambda_spinbox)

        self.als_p_label = QLabel("ALS 'p':")
        self.als_p_spinbox = QDoubleSpinBox(); self.als_p_spinbox.setDecimals(4); self.als_p_spinbox.setRange(0.0001, 0.9999); self.als_p_spinbox.setValue(0.01)
        self.preproc_form_layout.addRow(self.als_p_label, self.als_p_spinbox)

        self.poly_order_label = QLabel("Polynomial Order:")
        self.poly_order_spinbox = QSpinBox(); self.poly_order_spinbox.setRange(0, 15); self.poly_order_spinbox.setValue(3)
        self.preproc_form_layout.addRow(self.poly_order_label, self.poly_order_spinbox)

        self.preproc_norm_combo = QComboBox()
        self.preproc_norm_combo.addItems(["None", "SNV", "MSC", "Max", "Area"])
        self.preproc_norm_combo.setCurrentText("SNV")
        self.preproc_form_layout.addRow("Normalization:", self.preproc_norm_combo)
        controls_layout.addWidget(preproc_group)

        # --- Unchanged Analysis Method Group ---
        analysis_group = QGroupBox("Analysis Method")
        analysis_v_layout = QVBoxLayout(analysis_group)
        self.method_combo = QComboBox()
        self.method_combo.addItems([
            "Principal Component Analysis (PCA)",
            "Partial Least Squares Regression (PLS-R)",
            "Classification (LDA, SVM, k-NN)"
        ])
        self.method_combo.currentTextChanged.connect(self._on_method_change)
        analysis_v_layout.addWidget(self.method_combo)

        self.pca_controls_group = self._create_pca_controls()
        analysis_v_layout.addWidget(self.pca_controls_group)
        self.pls_controls_group = self._create_pls_controls()
        analysis_v_layout.addWidget(self.pls_controls_group)
        self.class_controls_group = self._create_class_controls()
        analysis_v_layout.addWidget(self.class_controls_group)
        
        self.run_analysis_button = QPushButton("Run Analysis")
        self.run_analysis_button.setToolTip("Execute the selected chemometric analysis.")
        self.run_analysis_button.clicked.connect(self._run_analysis)
        analysis_v_layout.addWidget(self.run_analysis_button)
        controls_layout.addWidget(analysis_group)

        controls_layout.addStretch()
        
        controls_widget_scroll = QScrollArea()
        controls_widget_scroll.setWidgetResizable(True)
        controls_widget_scroll.setWidget(controls_widget)
        main_splitter.addWidget(controls_widget_scroll)

        results_widget = QWidget()
        results_layout = QVBoxLayout(results_widget)
        results_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self.results_plot_widget = SpectrumPlotWidget(self)
        self.results_plot_widget.setMinimumHeight(300)
        results_layout.addWidget(self.results_plot_widget, 3)

        self.results_table_widget = QTableWidget(self)
        self.results_table_widget.setMinimumHeight(200)
        self.results_table_widget.setEditTriggers(QTableWidget.NoEditTriggers)
        self.results_table_widget.setAlternatingRowColors(True)
        self.results_table_widget.horizontalHeader().setStretchLastSection(True)
        results_layout.addWidget(self.results_table_widget, 2)

        main_splitter.addWidget(results_widget)
        main_splitter.setSizes([400, 600])

        self.base_layout.addWidget(main_splitter)

    def _create_pca_controls(self) -> QGroupBox:
        group = QGroupBox("PCA Settings")
        layout = QFormLayout(group)
        self.pca_n_components_spinbox = QSpinBox()
        self.pca_n_components_spinbox.setRange(1, 100)
        self.pca_n_components_spinbox.setValue(3)
        self.pca_n_components_spinbox.setToolTip("Number of principal components to compute.")
        layout.addRow("Number of Components:", self.pca_n_components_spinbox)
        
        self.pca_scale_checkbox = QCheckBox("Scale data (unit variance)")
        self.pca_scale_checkbox.setChecked(True)
        self.pca_scale_checkbox.setToolTip("Scale data to have unit variance before PCA.")
        layout.addRow(self.pca_scale_checkbox)
        return group

    def _create_pls_controls(self) -> QGroupBox:
        group = QGroupBox("PLS-R Settings")
        layout = QFormLayout(group)
        self.pls_load_y_button = QPushButton("Load Target Variable (Y - CSV)")
        self.pls_load_y_button.setToolTip("Load a CSV file containing the target variable (Y) for regression.")
        self.pls_load_y_button.clicked.connect(self._load_pls_target_variable)
        layout.addRow(self.pls_load_y_button)
        
        self.pls_y_status_label = QLabel("No target variable loaded.")
        self.pls_y_status_label.setWordWrap(True)
        layout.addRow(self.pls_y_status_label)
        
        self.pls_n_components_spinbox = QSpinBox()
        self.pls_n_components_spinbox.setRange(1, 100)
        self.pls_n_components_spinbox.setValue(2)
        self.pls_n_components_spinbox.setToolTip("Number of latent variables (components) for PLS regression.")
        layout.addRow("Number of Components:", self.pls_n_components_spinbox)
        return group

    def _create_class_controls(self) -> QGroupBox:
        group = QGroupBox("Classification Settings")
        layout = QFormLayout(group)
        self.class_load_labels_button = QPushButton("Load Class Labels (CSV)")
        self.class_load_labels_button.setToolTip("Load a CSV file containing class labels for classification.")
        self.class_load_labels_button.clicked.connect(self._load_class_labels)
        layout.addRow(self.class_load_labels_button)
        
        self.class_labels_status_label = QLabel("No class labels loaded.")
        self.class_labels_status_label.setWordWrap(True)
        layout.addRow(self.class_labels_status_label)
        
        self.class_model_combo = QComboBox()
        self.class_model_combo.addItems(["LDA", "SVM", "k-NN", "RandomForest"])
        self.class_model_combo.setToolTip("Select the classifier model to train.")
        layout.addRow("Classifier Model:", self.class_model_combo)
        return group

    def _on_method_change(self, method_text: str):
        is_pca = "PCA" in method_text
        is_pls = "PLS-R" in method_text
        is_class = "Classification" in method_text

        self.pca_controls_group.setVisible(is_pca)
        self.pls_controls_group.setVisible(is_pls)
        self.class_controls_group.setVisible(is_class)
        
        parent_layout = self.method_combo.parentWidget().layout()
        if parent_layout:
            parent_layout.activate()

    # --- MODIFIED: New slot for dynamic baseline parameter UI ---
    def _on_baseline_method_change(self):
        method = self.preproc_baseline_combo.currentText()
        is_als = method == "ALS"
        is_poly = method == "Polynomial"

        self.als_lambda_label.setVisible(is_als)
        self.als_lambda_spinbox.setVisible(is_als)
        self.als_p_label.setVisible(is_als)
        self.als_p_spinbox.setVisible(is_als)
        
        self.poly_order_label.setVisible(is_poly)
        self.poly_order_spinbox.setVisible(is_poly)

    # --- MODIFIED: Rewritten to load from folder and use a worker ---
    def _load_spectral_dataset_from_folder(self):
        # Safer check for the deleted C++ object
        if self.worker_thread is not None:
            try:
                if self.worker_thread.isRunning():
                    QMessageBox.warning(self, "Busy", "A data loading process is already running.")
                    return
            except RuntimeError:
                # The C++ object was deleted but Python didn't know yet. 
                # Reset it and continue.
                self.worker_thread = None

        folder_path = QFileDialog.getExistingDirectory(self, "Select Folder Containing Spectra")
        if not folder_path:
            return

        self.update_status_message("Scanning folder for spectral files...", 0)
        valid_extensions = ('.txt', '.csv', '.asc', '.spc', '.dat')
        filepaths = [p for p in Path(folder_path).rglob('*') if p.is_file() and p.suffix.lower() in valid_extensions]

        if not filepaths:
            QMessageBox.information(self, "No Files", f"No files with supported extensions found in '{folder_path}'.")
            self.update_status_message("Scan complete: No files found.", 3000)
            return

        self._reset_chem_data()
        
        params = {
            "interpolation_step_nm": self.preproc_interp_step_spinbox.value() if self.preproc_interpolate_checkbox.isChecked() else None,
            "baseline_method": self.preproc_baseline_combo.currentText().lower() if self.preproc_baseline_combo.currentText() != "None" else None,
            "als_lambda": self.als_lambda_spinbox.value(),
            "als_p": self.als_p_spinbox.value(),
            "poly_order": self.poly_order_spinbox.value(),
            "normalization_method": self.preproc_norm_combo.currentText().lower() if self.preproc_norm_combo.currentText() != "None" else None,
        }
        
        progress = QProgressDialog("Loading and Preprocessing Spectra...", "Cancel", 0, len(filepaths) + 1, self)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(500)
        
        self.worker_thread = QThread()
        self.data_worker = ChemometricsDataWorker(filepaths, params)
        self.data_worker.moveToThread(self.worker_thread)

        progress.canceled.connect(self.data_worker.cancel)
        self.data_worker.progress.connect(progress.setValue)
        self.data_worker.progress.connect(lambda cur, tot, msg: progress.setLabelText(msg))
        self.data_worker.finished.connect(self._on_data_worker_finished)
        self.data_worker.finished.connect(progress.close)
        self.data_worker.finished.connect(self.worker_thread.quit)
        self.data_worker.finished.connect(self.data_worker.deleteLater)
        self.worker_thread.finished.connect(self.worker_thread.deleteLater)

        self.worker_thread.started.connect(self.data_worker.run)
        self.worker_thread.start()

    def _use_project_spectra_for_analysis(self):
        project = self.get_current_project()
        if not project or not project.spectra:
            QMessageBox.information(self, "No Project Spectra", "The active project has no loaded spectra.")
            self.update_status_message("Active project is empty.", 3000)
            return

        if self.worker_thread is not None:
            try:
                if self.worker_thread.isRunning():
                    QMessageBox.warning(self, "Busy", "A data loading process is already running.")
                    return
            except RuntimeError:
                self.worker_thread = None

        spectra_list = list(project.spectra.values())
        self._reset_chem_data()
        
        params = {
            "interpolation_step_nm": self.preproc_interp_step_spinbox.value() if self.preproc_interpolate_checkbox.isChecked() else None,
            "baseline_method": self.preproc_baseline_combo.currentText().lower() if self.preproc_baseline_combo.currentText() != "None" else None,
            "als_lambda": self.als_lambda_spinbox.value(),
            "als_p": self.als_p_spinbox.value(),
            "poly_order": self.poly_order_spinbox.value(),
            "normalization_method": self.preproc_norm_combo.currentText().lower() if self.preproc_norm_combo.currentText() != "None" else None,
        }
        
        progress = QProgressDialog("Processing Project Spectra...", "Cancel", 0, len(spectra_list) + 1, self)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(500)
        
        self.worker_thread = QThread()
        self.data_worker = ChemometricsDataWorker(spectra_list, params)
        self.data_worker.moveToThread(self.worker_thread)

        progress.canceled.connect(self.data_worker.cancel)
        self.data_worker.progress.connect(progress.setValue)
        self.data_worker.progress.connect(lambda cur, tot, msg: progress.setLabelText(msg))
        self.data_worker.finished.connect(self._on_data_worker_finished)
        self.data_worker.finished.connect(progress.close)
        self.data_worker.finished.connect(self.worker_thread.quit)
        self.data_worker.finished.connect(self.data_worker.deleteLater)
        self.worker_thread.finished.connect(self.worker_thread.deleteLater)

        self.worker_thread.started.connect(self.data_worker.run)
        self.worker_thread.start()

    def _on_data_worker_finished(self, result: dict):
        if result.get("error"):
            QMessageBox.critical(self, "Data Processing Error", f"Failed to load or process the dataset:\n{result['error']}")
            self.data_status_label.setText(f"Error: {result['error']}")
            self.update_status_message("Data processing failed.", 5000)
            return

        self.current_chem_data = result["X_matrix"]
        self.current_chem_wavelengths = result["wavelength_axis"]
        self.current_sample_ids = result["sample_ids"]

        num_samples, num_features = self.current_chem_data.shape
        self.data_status_label.setText(f"{num_samples} spectra loaded & processed.\n{num_features} features (wavelengths).")
        self.update_status_message("Dataset ready for analysis.", 3000)

        self.pca_n_components_spinbox.setRange(1, min(num_samples, num_features, 100))
        self.pls_n_components_spinbox.setRange(1, min(num_samples, num_features, 100))

    # The rest of the file (_load_target_or_labels_from_csv, _run_analysis, etc.) remains unchanged
    # as it correctly operates on the `self.current_chem_data` numpy array, which is now
    # populated by our new independent worker.

    def _load_target_or_labels_from_csv(self, purpose: str) -> Optional[np.ndarray]:
        if self.current_chem_data is None:
            QMessageBox.warning(self, "No Spectral Data", f"Please load and preprocess spectral data (X) before loading {purpose}.")
            return None

        filepath_str, _ = QFileDialog.getOpenFileName(self, f"Load {purpose}", "", "CSV Files (*.csv);;Text Files (*.txt)")
        if not filepath_str:
            return None
        
        filepath = Path(filepath_str)
        try:
            df = pd.read_csv(filepath, header=None) 
            if df.empty:
                raise ValueError("CSV file is empty.")
            
            if df.shape[1] > 1:
                QMessageBox.information(self, "Multiple Columns Found", 
                                       f"CSV file '{filepath.name}' has {df.shape[1]} columns. "
                                       f"Using the first column for {purpose}.")
            
            values = df.iloc[:, 0].values
            
            if purpose == "Target Variable (Y)":
                try:
                    values = values.astype(float)
                except ValueError:
                    raise ValueError(f"{purpose} column contains non-numeric data.")

            if len(values) != self.current_chem_data.shape[0]:
                raise ValueError(f"Number of {purpose} values ({len(values)}) does not match "
                                 f"number of spectra ({self.current_chem_data.shape[0]}).")
            
            logger.info(f"Loaded {purpose} from {filepath}, count: {len(values)}")
            return values
        except Exception as e:
            logger.error(f"Error loading {purpose} from {filepath}: {e}", exc_info=True)
            QMessageBox.critical(self, "Load Error", f"Failed to load {purpose} from '{filepath.name}':\n{e}")
            return None

    def _load_pls_target_variable(self):
        target_y = self._load_target_or_labels_from_csv("Target Variable (Y)")
        if target_y is not None:
            self.current_target_y = target_y
            self.pls_y_status_label.setText(f"{len(target_y)} target values loaded.")
        else:
            self.current_target_y = None
            self.pls_y_status_label.setText("Error loading target variable.")

    def _load_class_labels(self):
        class_labels = self._load_target_or_labels_from_csv("Class Labels")
        if class_labels is not None:
            self.current_class_labels = class_labels
            unique_labels, counts = np.unique(class_labels, return_counts=True)
            status_text = f"{len(class_labels)} labels loaded.\nUnique classes: {len(unique_labels)}."
            self.class_labels_status_label.setText(status_text)
        else:
            self.current_class_labels = None
            self.class_labels_status_label.setText("Error loading class labels.")

    def _run_analysis(self):
        if self.current_chem_data is None or self.current_chem_data.size == 0:
            QMessageBox.warning(self, "No Data", "No data available for analysis. Load and preprocess spectra first.")
            return

        method = self.method_combo.currentText()
        self._clear_results_display()
        
        self.update_status_message(f"Running {method}...", 0)
        QApplication.processEvents()

        try:
            if "PCA" in method: self._run_pca()
            elif "PLS-R" in method: self._run_pls_r()
            elif "Classification" in method: self._run_classification()
            self.update_status_message(f"{method} analysis complete.", 3000)
        except Exception as e:
            logger.error(f"Error during {method} analysis: {e}", exc_info=True)
            QMessageBox.critical(self, "Analysis Error", f"An error occurred during {method}:\n{e}")
            self.update_status_message(f"Error in {method} analysis.", 5000)

    def _run_pca(self):
        n_components = self.pca_n_components_spinbox.value()
        scale_data = self.pca_scale_checkbox.isChecked()

        pca_model, scores, loadings, explained_var_ratio = perform_pca(
            self.current_chem_data, n_components=n_components, scale_data=scale_data
        )
        if pca_model is None:
             QMessageBox.critical(self, "PCA Error", "PCA calculation failed or returned invalid results.")
             return

        if scores.shape[1] >= 2:
            self.results_plot_widget.plot_scatter(
                scores[:, 0], scores[:, 1],
                title=f"PCA Scores (PC1 vs PC2)",
                x_label=f"PC1 ({explained_var_ratio[0]:.1%})",
                y_label=f"PC2 ({explained_var_ratio[1]:.1%})",
                series_name="Samples", labels=self.current_sample_ids
            )
        else:
            self.results_plot_widget.show_message("PCA: Not enough components for scores plot.")

        self._populate_table_from_dict_list(
            [{"Component": f"PC{i+1}", "Explained Variance": f"{ratio:.2%}", "Cumulative": f"{np.sum(explained_var_ratio[:i+1]):.2%}"} 
             for i, ratio in enumerate(explained_var_ratio)],
        )

    def _run_pls_r(self):
        if self.current_target_y is None:
            QMessageBox.warning(self, "Missing Data", "Target variable (Y) for PLS-R is not loaded.")
            return

        n_components = self.pls_n_components_spinbox.value()
        results = perform_pls_regression(
            self.current_chem_data, self.current_target_y,
            n_components=n_components, scale_data=True, cross_validate=True
        )

        if "error" in results:
            QMessageBox.critical(self, "PLS-R Error", results["error"])
            return

        self.results_plot_widget.plot_scatter_regression(
            self.current_target_y, results.get('y_pred_cv', results['y_pred_train']),
            title=f"PLS-R: Predicted vs. Actual (CV R²={results.get('r2_cv', 'N/A'):.3f})",
            x_label="Actual Target Value", y_label="Predicted Target Value"
        )

        metrics_data = [{"Metric": "Train R²", "Value": f"{results['r2_train']:.4f}"}, {"Metric": "Train RMSE", "Value": f"{results['rmse_train']:.4f}"}]
        if "r2_cv" in results:
            metrics_data.extend([{"Metric": "CV R²", "Value": f"{results['r2_cv']:.4f}"}, {"Metric": "CV RMSE (RMSECV)", "Value": f"{results['rmsecv']:.4f}"}])
        self._populate_table_from_dict_list(metrics_data)

    def _run_classification(self):
        if self.current_class_labels is None:
            QMessageBox.warning(self, "Missing Data", "Class labels for classification are not loaded.")
            return

        model_type_str = self.class_model_combo.currentText().lower().replace("-", "")
        model_kwargs = {}
        if model_type_str == "knn": model_kwargs["n_neighbors"] = min(5, self.current_chem_data.shape[0] // 2 or 1)
        
        results = train_classifier_model(
            self.current_chem_data, self.current_class_labels,
            model_type=model_type_str, scale_data=True, test_size=0.3, **model_kwargs
        )
        if "error" in results:
            QMessageBox.critical(self, "Classification Error", results["error"])
            return

        self.results_plot_widget.show_message("Classification results shown in table.")

        cm = results['confusion_matrix']
        classes = results['label_encoder'].classes_
        cm_data = []
        for i, actual_class in enumerate(classes):
            row = {"Actual Class": actual_class}
            for j, pred_class in enumerate(classes):
                row[f"Predicted: {pred_class}"] = cm[i,j]
            cm_data.append(row)
        self._populate_table_from_dict_list(cm_data)
        
        QMessageBox.information(self, "Classification Accuracy", f"Overall Test Accuracy: {results['accuracy']:.3f}")

    def _clear_results_display(self):
        self.results_plot_widget.clear_plot()
        self.results_table_widget.clearContents()
        self.results_table_widget.setRowCount(0)
        self.results_table_widget.setColumnCount(0)

    def _populate_table_from_dict_list(self, data: List[Dict[str, Any]]):
        if not data:
            self.results_table_widget.setRowCount(0); self.results_table_widget.setColumnCount(0)
            return

        headers = list(data[0].keys())
        self.results_table_widget.setColumnCount(len(headers)); self.results_table_widget.setHorizontalHeaderLabels(headers)
        self.results_table_widget.setRowCount(len(data))

        for row_idx, row_dict in enumerate(data):
            for col_idx, header in enumerate(headers):
                self.results_table_widget.setItem(row_idx, col_idx, QTableWidgetItem(str(row_dict.get(header, ""))))
        
        self.results_table_widget.resizeColumnsToContents()

    def _reset_chem_data(self):
        self.current_chem_data = None; self.current_chem_wavelengths = None
        self.current_sample_ids = None; self.current_target_y = None
        self.current_class_labels = None; self.data_status_label.setText("No data loaded.")
        self.pls_y_status_label.setText("No target variable loaded."); self.class_labels_status_label.setText("No class labels loaded.")
        self.pca_n_components_spinbox.setRange(1,100); self.pls_n_components_spinbox.setRange(1,100)

    def on_project_loaded(self, project: Optional[LIBSProject] = None):
        super().on_project_loaded(project)
        self._reset_chem_data()
        self._clear_results_display()
        self.load_spectra_folder_button.setEnabled(True)
        self.use_project_spectra_button.setEnabled(True)

    def on_project_closed(self):
        super().on_project_closed()
        self._reset_chem_data()
        self._clear_results_display()
        self.use_project_spectra_button.setEnabled(False)
# team404/gui/tabs/base_tab.py

"""
BaseTab class for SpectraMapper Pro.
Provides common functionality and interface for all main application tabs.
"""

import logging
from typing import Optional, TYPE_CHECKING, Dict, Any

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QMessageBox
from PyQt5.QtCore import pyqtSignal

# Conditional import for type hinting to avoid circular dependencies
if TYPE_CHECKING:
    from ..main_window import MainWindow # To type hint main_window
    from ...core.project_manager import ProjectManager
    from ...core.data_models import LIBSpectrum, LIBSProject


logger = logging.getLogger(__name__)

class BaseTab(QWidget):
    """
    Base class for all tabs in the main application window.
    Handles common interactions with the ProjectManager and MainWindow.
    """
    # Signal emitted when a tab has modified the processed data of the active spectrum
    # The string argument is the spectrum_id.
    active_spectrum_processed_externally = pyqtSignal(str)

    # Signal emitted by a tab when it wishes to change the globally active spectrum
    # (e.g., ProjectDataTab when user selects a spectrum in its list)
    # The object argument is the LIBSpectrum object, or None.
    active_spectrum_selection_changed_signal = pyqtSignal(object)


    def __init__(self, project_manager: 'ProjectManager',
                 main_window: Optional['MainWindow'] = None,
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.project_manager = project_manager
        self.main_window = main_window # Reference to the main window for communication

        # Each tab will have a base_layout where its specific UI elements are added.
        # This is crucial: BaseTab sets its own layout. Subclasses should *add* to this layout.
        self.base_layout = QVBoxLayout(self)
        self.setLayout(self.base_layout) # Set the layout for the BaseTab widget itself

        # Subclasses should call their own _init_ui() method
        # and add their widgets to self.base_layout.

    def _init_ui(self):
        """
        Placeholder for UI initialization in subclasses.
        Subclasses should override this method to create their specific UI elements
        and add them to `self.base_layout`.
        """
        # Example: self.base_layout.addWidget(QLabel("Content for this tab..."))
        pass

    def get_current_project(self) -> Optional['LIBSProject']:
        """Convenience method to get the current project."""
        return self.project_manager.get_current_project()

    def get_active_spectrum(self) -> Optional['LIBSpectrum']:
        """Convenience method to get the currently active spectrum in the project."""
        return self.project_manager.get_active_spectrum()

    def mark_project_dirty(self, dirty: bool = True):
        """Marks the current project as dirty (modified)."""
        if self.main_window and hasattr(self.main_window, 'mark_project_dirty'):
             self.main_window.mark_project_dirty(dirty) # Delegate to MainWindow
        elif self.project_manager: # Fallback if no main_window reference or if it's direct
            self.project_manager.mark_project_dirty(dirty)
        else:
            logger.warning(f"Tab {self.__class__.__name__}: Cannot mark project dirty, no main_window or project_manager.")


    def update_status_message(self, message: str, timeout: int = 0):
        """Shows a message in the main window's status bar."""
        if self.main_window and hasattr(self.main_window, 'update_status_bar'):
            self.main_window.update_status_bar(main_message=message, timeout_ms=timeout)
        else:
            logger.info(f"Status (from {self.__class__.__name__}): {message}") # Fallback to log

    # --- Slots for global signals from MainWindow ---
    # Subclasses should override these methods to react to application-wide events.

    def on_tab_selected(self):
        """Called when this tab becomes the currently selected tab in the QTabWidget."""
        logger.debug(f"Tab selected: {self.__class__.__name__}")
        # Subclasses can update their UI or refresh data here.

    def on_project_loaded(self, project: Optional['LIBSProject']):
        """Called when a new project is loaded or created."""
        logger.debug(f"Tab {self.__class__.__name__} notified of project load: {project.project_name if project else 'None'}")
        # Subclasses should update their state based on the new project.

    def on_project_closed(self):
        """Called when the current project is closed."""
        logger.debug(f"Tab {self.__class__.__name__} notified of project close.")
        # Subclasses should clear their data and reset UI.

    def on_active_spectrum_changed(self, new_spectrum: Optional['LIBSpectrum']):
        """
        Called when the globally active spectrum in the project changes.
        Args:
            new_spectrum: The newly active LIBSpectrum object, or None if no spectrum is active.
        """
        spec_id = new_spectrum.spectrum_id if new_spectrum else "None"
        logger.debug(f"Tab {self.__class__.__name__} notified of active spectrum change: {spec_id}")
        # Subclasses should update to reflect the new active spectrum.

    def on_preferences_updated(self, new_settings: Dict[str, Any]):
        """Called when application preferences have been updated."""
        logger.debug(f"Tab {self.__class__.__name__} notified of preferences update.")
        # Subclasses can re-load relevant preferences.

    def closeEvent(self, event):
        """
        Handle cleanup when the tab itself is being closed (e.g., if tabs were dynamically closable).
        More relevant if the entire application/main_window is closing.
        This ensures worker threads are stopped if the tab is part of a widget that gets explicitly closed.
        """
        logger.debug(f"Close event for tab: {self.__class__.__name__}")
        # Subclasses with threads should override this to stop their threads.
        super().closeEvent(event)
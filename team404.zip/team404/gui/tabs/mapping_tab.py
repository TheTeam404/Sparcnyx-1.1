# team404/gui/tabs/mapping_tab.py

"""
MappingTab for SpectraMapper Pro.
Provides UI for generating and visualizing 2D elemental maps from LIBS data.
"""

import logging
import os
from pathlib import Path
import sys
from typing import List, Dict, Optional, Any, Tuple

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox, QApplication,
    QPushButton, QLabel, QLineEdit, QDoubleSpinBox, QComboBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QSplitter, QMessageBox,
    QProgressDialog, QSpinBox, QScrollArea, QSizePolicy, QSpacerItem, QFileDialog
)
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QObject
from PyQt5.QtGui import QColor
import numpy as np
import pandas as pd

from .base_tab import BaseTab
from ..widgets.spectrum_plot_widget import SpectrumPlotWidget
from ...core.data_models import LIBSpectrum, ElementalMapData, ProcessingStep, LIBSProject
from ...core.mapping_processor import MappingProcessor, INTENSITY_EXTRACTION_METHODS
from ...core.file_io import load_spectrum_from_file, load_mapping_data_from_hdf5

logger = logging.getLogger(__name__)

# --- Worker for Map Generation ---
class MapGenerationWorker(QObject):
    finished = pyqtSignal(ElementalMapData)
    progress = pyqtSignal(int, int)
    error = pyqtSignal(str)

    def __init__(self, mapping_processor: MappingProcessor,
                 element_label: str, target_wavelength: float,
                 quant_method: str, quant_params: dict):
        super().__init__()
        self.mapping_processor = mapping_processor
        self.element_label = element_label
        self.target_wavelength = target_wavelength
        self.quant_method = quant_method
        self.quant_params = quant_params
        self._is_interruption_requested = False

    def run(self):
        try:
            # The MappingProcessor's generate_elemental_map method must be adapted
            # to accept an interruption check callback for this to work perfectly.
            # Assuming it will be.
            map_data = self.mapping_processor.generate_elemental_map(
                element_label=self.element_label,
                target_wavelength=self.target_wavelength,
                quantification_method=self.quant_method,
                quant_params=self.quant_params,
                progress_callback=self.report_progress
            )
            if self._is_interruption_requested:
                logger.info("Map generation worker acknowledged interruption request.")
                self.error.emit("Map generation cancelled by user.") # Treat as error for cleanup
                return

            if map_data:
                self.finished.emit(map_data)
            else:
                self.error.emit("Map generation returned no data or was cancelled.")
        except Exception as e:
            if not self._is_interruption_requested: # Only log/emit error if not due to cancellation
                logger.error(f"Error during map generation worker: {e}", exc_info=True)
                self.error.emit(str(e))
            else: # If error during cancellation, still signal it as cancelled
                self.error.emit("Map generation cancelled by user (error during shutdown).")


    def report_progress(self, current, total):
        if not self._is_interruption_requested:
            self.progress.emit(current, total)

    def request_interruption(self):
        self._is_interruption_requested = True


class MappingTab(BaseTab):
    """Tab for setting up, generating, and visualizing 2D elemental maps."""
    display_map_point_spectrum_signal = pyqtSignal(LIBSpectrum)

    def __init__(self, project_manager, main_window=None, parent=None):
        super().__init__(project_manager, main_window, parent)

        self.map_spectra_collection: List[LIBSpectrum] = []
        self.map_dimensions: Tuple[int, int] = (0, 0)
        self.current_map_processor: Optional[MappingProcessor] = None
        self.generated_maps: Dict[str, ElementalMapData] = {}

        self.map_gen_thread: Optional[QThread] = None
        self.map_gen_worker: Optional[MapGenerationWorker] = None
        self.progress_dialog: Optional[QProgressDialog] = None
        
        self._init_ui() # Call from BaseTab's constructor or explicitly here

    def _init_ui(self):
        main_splitter = QSplitter(Qt.Horizontal, self)

        controls_widget_scroll = QScrollArea()
        controls_widget_scroll.setWidgetResizable(True)
        controls_widget_scroll.setMinimumWidth(380)
        controls_widget_scroll.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)

        controls_widget = QWidget()
        controls_layout = QVBoxLayout(controls_widget)
        controls_layout.setSpacing(10)

        # Data Import / Setup Group
        data_setup_group = QGroupBox("Map Data Setup")
        data_setup_layout = QFormLayout(data_setup_group)
        data_setup_layout.setSpacing(8)
        
        # --- MODIFIED: Use QHBoxLayout for import buttons ---
        import_buttons_layout = QHBoxLayout()
        self.import_map_folder_button = QPushButton("Import Folder...")
        self.import_map_folder_button.setToolTip("Import a folder containing individual spectral files for mapping.")
        self.import_map_folder_button.clicked.connect(self._import_map_data_folder)
        import_buttons_layout.addWidget(self.import_map_folder_button)

        self.import_map_hdf5_button = QPushButton("Import HDF5...")
        self.import_map_hdf5_button.setToolTip("Import a 2D map dataset from an HDF5 (.h5) file.")
        self.import_map_hdf5_button.clicked.connect(self._import_map_data_hdf5)
        import_buttons_layout.addWidget(self.import_map_hdf5_button)
        data_setup_layout.addRow("Import Spectra:", import_buttons_layout)
        # --- END MODIFICATION ---

        self.map_dim_x_spinbox = QSpinBox()
        self.map_dim_x_spinbox.setRange(1, 10000); self.map_dim_x_spinbox.setValue(10)
        self.map_dim_x_spinbox.setToolTip("Number of measurement points in the X direction of the map.")
        data_setup_layout.addRow("Map X Points:", self.map_dim_x_spinbox)
        
        self.map_dim_y_spinbox = QSpinBox()
        self.map_dim_y_spinbox.setRange(1, 10000); self.map_dim_y_spinbox.setValue(10)
        self.map_dim_y_spinbox.setToolTip("Number of measurement points in the Y direction of the map.")
        data_setup_layout.addRow("Map Y Points:", self.map_dim_y_spinbox)
        
        self.coord_filename_pattern_edit = QLineEdit() # Keep empty for now, simple ordered import
        self.coord_filename_pattern_edit.setPlaceholderText("e.g., map_x(\\d+)_y(\\d+).txt (optional)")
        self.coord_filename_pattern_edit.setToolTip(
            "Optional: Regular expression to extract X,Y coordinates from filenames. "
            "If empty, spectra are assumed to be ordered row-by-row or column-by-column."
        )
        data_setup_layout.addRow("Filename XY Pattern (Regex):", self.coord_filename_pattern_edit)
        
        self.data_load_status_label = QLabel("No map data loaded.")
        self.data_load_status_label.setWordWrap(True)
        data_setup_layout.addRow(self.data_load_status_label)
        
        self.setup_map_processor_button = QPushButton("Initialize Map Processor")
        self.setup_map_processor_button.setToolTip("Prepare loaded spectra and dimensions for map generation.")
        self.setup_map_processor_button.clicked.connect(self._initialize_map_processor)
        data_setup_layout.addRow(self.setup_map_processor_button)
        controls_layout.addWidget(data_setup_group)

        # Map Generation Parameters Group
        gen_params_group = QGroupBox("Map Generation Parameters")
        gen_params_layout = QFormLayout(gen_params_group)
        gen_params_layout.setSpacing(8)
        self.map_element_label_edit = QLineEdit()
        self.map_element_label_edit.setPlaceholderText("e.g., Ca II 393.366nm or Fe Concentration")
        self.map_element_label_edit.setToolTip("Descriptive label for the generated map (e.g., element, line, property).")
        gen_params_layout.addRow("Map Label:", self.map_element_label_edit)
        
        self.map_target_wl_spinbox = QDoubleSpinBox()
        self.map_target_wl_spinbox.setDecimals(3)
        self.map_target_wl_spinbox.setRange(100.0, 20000.0); self.map_target_wl_spinbox.setValue(393.366)
        self.map_target_wl_spinbox.setSuffix(" nm")
        self.map_target_wl_spinbox.setToolTip("Central wavelength of the spectral line or feature to map.")
        gen_params_layout.addRow("Target Wavelength:", self.map_target_wl_spinbox)

        self.map_quant_method_combo = QComboBox()
        self.map_quant_method_combo.addItems(list(INTENSITY_EXTRACTION_METHODS.keys()))
        self.map_quant_method_combo.setToolTip("Method to extract intensity/value at the target wavelength for each spectrum.")
        self.map_quant_method_combo.currentTextChanged.connect(self._on_quant_method_change)
        gen_params_layout.addRow("Quantification Method:", self.map_quant_method_combo)

        self.quant_params_widget_container = QWidget() # Container for dynamic params
        self.quant_params_layout = QFormLayout(self.quant_params_widget_container)
        self.quant_params_layout.setContentsMargins(0,0,0,0) # No extra margins
        self.quant_params_layout.setSpacing(8)
        
        self.map_integration_window_label = QLabel("Integration Window (nm):")
        self.map_integration_window_spinbox = QDoubleSpinBox()
        self.map_integration_window_spinbox.setDecimals(3); self.map_integration_window_spinbox.setRange(0.01, 10.0)
        self.map_integration_window_spinbox.setValue(0.1); self.map_integration_window_spinbox.setSuffix(" nm")
        self.map_integration_window_spinbox.setToolTip("Total width of the window around the target wavelength for integration.")
        self.quant_params_layout.addRow(self.map_integration_window_label, self.map_integration_window_spinbox)
        
        self.map_voigt_metric_label = QLabel("Voigt Fit Metric:")
        self.map_voigt_metric_combo = QComboBox()
        self.map_voigt_metric_combo.addItems(["amplitude", "area", "center"])
        self.map_voigt_metric_combo.setToolTip("Parameter to extract from Voigt fit (amplitude, area, or fitted center).")
        self.quant_params_layout.addRow(self.map_voigt_metric_label, self.map_voigt_metric_combo)

        self.map_voigt_fit_window_label = QLabel("Voigt Fit Window (nm):")
        self.map_voigt_fit_window_spinbox = QDoubleSpinBox()
        self.map_voigt_fit_window_spinbox.setDecimals(2); self.map_voigt_fit_window_spinbox.setRange(0.1,20.0) # Increased range
        self.map_voigt_fit_window_spinbox.setValue(1.0); self.map_voigt_fit_window_spinbox.setSuffix(" nm")
        self.map_voigt_fit_window_spinbox.setToolTip("Total window width around target wavelength for Voigt fitting.")
        self.quant_params_layout.addRow(self.map_voigt_fit_window_label, self.map_voigt_fit_window_spinbox)
        
        gen_params_layout.addRow(self.quant_params_widget_container)
        
        self.generate_map_button = QPushButton("Generate Elemental Map")
        self.generate_map_button.setToolTip("Start the map generation process with the current parameters.")
        self.generate_map_button.clicked.connect(self._generate_map)
        gen_params_layout.addRow(self.generate_map_button)
        controls_layout.addWidget(gen_params_group)
        
        disp_maps_group = QGroupBox("Displayed Maps")
        disp_maps_layout = QFormLayout(disp_maps_group) # Use QFormLayout for consistency
        self.map_selector_combo = QComboBox()
        self.map_selector_combo.setToolTip("Select a previously generated map to display.")
        self.map_selector_combo.currentTextChanged.connect(self._on_selected_map_change)
        disp_maps_layout.addRow("Select Map:", self.map_selector_combo)
        controls_layout.addWidget(disp_maps_group)

        controls_layout.addStretch()
        controls_widget_scroll.setWidget(controls_widget)
        main_splitter.addWidget(controls_widget_scroll)

        results_splitter = QSplitter(Qt.Vertical, self)
        self.map_display_widget = SpectrumPlotWidget(self)
        self.map_display_widget.set_title("Elemental Map Display")
        self.map_display_widget.enable_map_interactions(self._on_map_pixel_clicked)
        results_splitter.addWidget(self.map_display_widget)

        self.map_point_spectrum_widget = SpectrumPlotWidget(self)
        self.map_point_spectrum_widget.set_title("Spectrum at Map Point (X,Y)")
        results_splitter.addWidget(self.map_point_spectrum_widget)
        
        results_splitter.setSizes([int(self.height() * 0.65), int(self.height() * 0.35)])

        main_splitter.addWidget(results_splitter)
        main_splitter.setSizes([400, 700]) # Adjusted initial split

        self.base_layout.addWidget(main_splitter)
        self._on_quant_method_change(self.map_quant_method_combo.currentText()) # Set initial visibility of quant params

    def _import_map_data_folder(self):
        # Use global settings for default project dir, if available
        # For now, using hardcoded fallback or simple home dir.
        default_dir_str = self.project_manager.get_project_settings().get("paths",{}).get("default_project_dir", str(Path.home()))
        folder_path_str = QFileDialog.getExistingDirectory(self, "Select Folder Containing Map Spectra", default_dir_str)
        if not folder_path_str: return

        folder_path = Path(folder_path_str)
        self.map_spectra_collection = []
        filepaths_to_load = []
        valid_extensions = ('.txt', '.csv', '.asc', '.spc', '.dat') # Added .dat
        
        self.update_status_message(f"Scanning folder: {folder_path.name}...", 0)
        QApplication.processEvents()

        try:
            for item_path in folder_path.rglob('*'): # Recursive glob
                if item_path.is_file() and item_path.suffix.lower() in valid_extensions:
                    filepaths_to_load.append(item_path)
            
            if not filepaths_to_load:
                QMessageBox.information(self, "No Files", f"No files with extensions {valid_extensions} found in '{folder_path}'.")
                self.update_status_message("Import failed: No matching files found.", 3000)
                return

            # Sort filepaths naturally if possible (e.g. map_1.txt, map_2.txt, ..., map_10.txt)
            # Basic sort for now. Natural sort requires external library or more complex logic.
            filepaths_to_load.sort() 

            import_progress = QProgressDialog("Importing map spectra...", "Cancel", 0, len(filepaths_to_load), self)
            import_progress.setWindowModality(Qt.WindowModal); import_progress.setAutoClose(True); import_progress.setMinimumDuration(500)

            for i, fpath in enumerate(filepaths_to_load):
                import_progress.setValue(i)
                if import_progress.wasCanceled():
                    self.map_spectra_collection = []
                    break
                
                # TODO: Allow specifying import params via a FileFormatDialog if issues occur
                loaded_data = load_spectrum_from_file(fpath) 
                if loaded_data:
                    wl, inten, meta = loaded_data
                    spec = LIBSpectrum(wl, inten, filename=fpath.name, metadata=meta, filepath=str(fpath))
                    self.map_spectra_collection.append(spec)
                else:
                    logger.warning(f"Skipped map spectrum due to load failure: {fpath}")
            import_progress.setValue(len(filepaths_to_load))

            if self.map_spectra_collection:
                self.data_load_status_label.setText(f"{len(self.map_spectra_collection)} spectra imported for mapping.")
                logger.info(f"Imported {len(self.map_spectra_collection)} spectra for mapping.")
                # Auto-populate dimensions if simple square root or if pattern allows (not implemented here for auto)
                num_spectra = len(self.map_spectra_collection)
                sqrt_num = int(np.sqrt(num_spectra))
                if sqrt_num * sqrt_num == num_spectra: # Perfect square
                    self.map_dim_x_spinbox.setValue(sqrt_num)
                    self.map_dim_y_spinbox.setValue(sqrt_num)
                else: # Default to N x 1
                    self.map_dim_x_spinbox.setValue(num_spectra)
                    self.map_dim_y_spinbox.setValue(1)
            else:
                self.data_load_status_label.setText("No spectra successfully imported.")
        except Exception as e:
            logger.error(f"Error importing map data folder '{folder_path}': {e}", exc_info=True)
            QMessageBox.critical(self, "Import Error", f"Failed to import map data: {e}")
            self.data_load_status_label.setText(f"Error during import: {str(e)[:100]}")
        finally:
            self.update_status_message("Map data import process finished.", 3000)

    # --- ADDED: New slot for HDF5 import ---
    def _import_map_data_hdf5(self):
        default_dir_str = self.project_manager.get_project_settings().get("paths", {}).get("default_project_dir", str(Path.home()))
        filepath_str, _ = QFileDialog.getOpenFileName(self, "Import HDF5 Map File", default_dir_str, "HDF5 Files (*.h5 *.hdf5)")
        if not filepath_str:
            return

        self.update_status_message(f"Importing HDF5 file: {Path(filepath_str).name}...", 0)
        QApplication.processEvents()

        try:
            load_result = load_mapping_data_from_hdf5(filepath_str)
            if load_result is None:
                raise ValueError("The HDF5 loader returned no data. Check file structure and logs.")

            spectra_list, dimensions = load_result
            self.map_spectra_collection = spectra_list
            self.map_dim_x_spinbox.setValue(dimensions[0])
            self.map_dim_y_spinbox.setValue(dimensions[1])

            self.data_load_status_label.setText(f"{len(self.map_spectra_collection)} spectra imported from HDF5 file.")
            self.update_status_message("HDF5 import complete.", 3000)
            logger.info(f"Imported {len(self.map_spectra_collection)} spectra from {filepath_str}")

        except ImportError as ie:
            logger.critical(f"HDF5 Import Error: {ie}")
            QMessageBox.critical(self, "Dependency Missing", "The 'h5py' library is required to read HDF5 files.\nPlease install it via 'pip install h5py'.")
            self.data_load_status_label.setText("Import failed: h5py library not found.")
        except Exception as e:
            logger.error(f"Error importing HDF5 map data from '{filepath_str}': {e}", exc_info=True)
            QMessageBox.critical(self, "HDF5 Import Error", f"Failed to import HDF5 map data:\n{e}")
            self.data_load_status_label.setText(f"Error during HDF5 import: {str(e)[:100]}")
        finally:
            self.update_status_message("HDF5 import process finished.", 3000)
    # --- END ADDITION ---

    def _initialize_map_processor(self):
        if not self.map_spectra_collection:
            QMessageBox.warning(self, "No Spectra", "Please import map spectra first.")
            return

        num_x = self.map_dim_x_spinbox.value()
        num_y = self.map_dim_y_spinbox.value()

        expected_total = num_x * num_y
        actual_total = len(self.map_spectra_collection)

        if expected_total != actual_total:
            msg = (f"Specified map dimensions ({num_x}x{num_y} = {expected_total} points) "
                   f"do not match the number of loaded spectra ({actual_total}).\n\n"
                   "This can lead to errors or an incorrectly shaped map.\n"
                   "Please verify dimensions or ensure all spectra were loaded correctly.\n\n"
                   "Do you want to proceed with these dimensions anyway?")
            reply = QMessageBox.warning(self, "Dimension Mismatch", msg, QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.No: return
        
        self.map_dimensions = (num_x, num_y)
        
        self.update_status_message("Initializing map processor (may take time for preprocessing)...", 0)
        QApplication.processEvents()
        try:
            pipeline_for_map_spectra: List[ProcessingStep] = [] 

            # --- MODIFIED: Removed filename_coord_pattern from constructor call ---
            self.current_map_processor = MappingProcessor(
                spectra_collection=self.map_spectra_collection,
                map_dimensions=self.map_dimensions,
                preprocessing_pipeline=pipeline_for_map_spectra 
            )
            # --- END MODIFICATION ---

            nx, ny = self.current_map_processor.num_x_points, self.current_map_processor.num_y_points
            self.data_load_status_label.setText(
                f"Map processor initialized. Effective grid: {nx}x{ny}.\n"
                f"Spectra assigned coordinates and batch-preprocessed."
            )
            self.update_status_message("Map processor ready.", 3000)
            logger.info(f"MappingProcessor initialized. Grid: {nx}x{ny}. Spectra preprocessed.")
        except ValueError as ve:
            QMessageBox.critical(self, "Initialization Error", f"Dimension or coordinate assignment error: {ve}")
            self.current_map_processor = None
            self.data_load_status_label.setText(f"Processor init failed: {str(ve)[:100]}")
            self.update_status_message("Map processor initialization error.", 5000)
        except Exception as e:
            logger.error(f"Failed to initialize MappingProcessor: {e}", exc_info=True)
            QMessageBox.critical(self, "Initialization Error", f"An unexpected error occurred during processor setup: {e}")
            self.current_map_processor = None
            self.data_load_status_label.setText(f"Processor init failed: {str(e)[:100]}")
            self.update_status_message("Map processor initialization error.", 5000)

    def _on_quant_method_change(self, method_key: str):
        """Shows/hides UI elements specific to the quantification method."""
        is_area = method_key == "peak_area"
        is_voigt = method_key == "voigt_fit"
        
        self.map_integration_window_label.setVisible(is_area)
        self.map_integration_window_spinbox.setVisible(is_area)
        
        self.map_voigt_metric_label.setVisible(is_voigt)
        self.map_voigt_metric_combo.setVisible(is_voigt)
        self.map_voigt_fit_window_label.setVisible(is_voigt)
        self.map_voigt_fit_window_spinbox.setVisible(is_voigt)

    def _generate_map(self):
        if not self.current_map_processor:
            QMessageBox.warning(self, "Not Ready", "Map processor is not initialized. Import data and click 'Initialize'.")
            return

        element_label = self.map_element_label_edit.text().strip()
        if not element_label:
            QMessageBox.warning(self, "Input Required", "Please provide a label for the map (e.g., element name, line wavelength).")
            return
        if element_label in self.generated_maps:
            reply = QMessageBox.question(self, "Overwrite Map?", f"A map labeled '{element_label}' already exists. Overwrite it?",
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.No: return

        target_wl = self.map_target_wl_spinbox.value()
        quant_method_key = self.map_quant_method_combo.currentText()
        quant_params = {}
        if quant_method_key == "peak_area":
            quant_params["integration_window_nm"] = self.map_integration_window_spinbox.value()
        elif quant_method_key == "voigt_fit":
            quant_params["fit_metric"] = self.map_voigt_metric_combo.currentText()
            quant_params["fit_window_nm_map"] = self.map_voigt_fit_window_spinbox.value()

        if self.map_gen_thread and self.map_gen_thread.isRunning():
            QMessageBox.information(self, "Busy", "Map generation is already in progress. Please wait or cancel.")
            return

        self.generate_map_button.setEnabled(False)
        self.update_status_message(f"Generating map '{element_label}'...", 0)

        self.progress_dialog = QProgressDialog(
            f"Generating map: {element_label}...", "Cancel", 0,
            len(self.current_map_processor.spectra_collection), self
        )
        self.progress_dialog.setWindowModality(Qt.WindowModal); self.progress_dialog.setAutoClose(True)
        self.progress_dialog.setAutoReset(True); self.progress_dialog.setMinimumDuration(200)
        
        self.map_gen_thread = QThread(self)
        self.map_gen_worker = MapGenerationWorker(
            self.current_map_processor, element_label, target_wl, quant_method_key, quant_params
        )
        self.map_gen_worker.moveToThread(self.map_gen_thread)

        self.map_gen_thread.started.connect(self.map_gen_worker.run)
        self.map_gen_worker.finished.connect(self._on_map_generation_finished)
        self.map_gen_worker.error.connect(self._on_map_generation_error)
        self.map_gen_worker.progress.connect(self._on_map_generation_progress)
        
        self.map_gen_worker.finished.connect(self.map_gen_thread.quit)
        self.map_gen_worker.finished.connect(self.map_gen_worker.deleteLater)
        self.map_gen_thread.finished.connect(self.map_gen_thread.deleteLater)
        self.map_gen_thread.finished.connect(lambda: setattr(self, 'map_gen_thread', None))
        self.map_gen_thread.finished.connect(self._reset_progress_dialog_state)

        self.progress_dialog.canceled.connect(self._cancel_map_generation)
        self.map_gen_thread.start()

    def _on_map_generation_progress(self, current_step: int, total_steps: int):
        if self.progress_dialog:
            if self.progress_dialog.maximum() != total_steps:
                self.progress_dialog.setMaximum(total_steps)
            self.progress_dialog.setValue(current_step)

    def _on_map_generation_finished(self, map_data: ElementalMapData):
        self.generate_map_button.setEnabled(True)
        self.update_status_message(f"Map '{map_data.element_label}' generated successfully.", 3000)
        
        self.generated_maps[map_data.element_label] = map_data
        self._update_map_selector()
        self.map_selector_combo.setCurrentText(map_data.element_label)
        self.mark_project_dirty()

    def _on_map_generation_error(self, error_message: str):
        self.generate_map_button.setEnabled(True)
        self.update_status_message(f"Map generation error: {error_message}", 5000)
        if self.progress_dialog and not self.progress_dialog.isHidden():
            self.progress_dialog.cancel()
        QMessageBox.critical(self, "Map Generation Error", f"Failed to generate map:\n{error_message}")

    def _cancel_map_generation(self):
        if self.map_gen_worker:
            self.map_gen_worker.request_interruption()
            logger.info("Cancel requested for map generation worker.")
        self._reset_progress_dialog_state()

    def _reset_progress_dialog_state(self):
        if self.progress_dialog:
            pass


    def _update_map_selector(self):
        self.map_selector_combo.blockSignals(True)
        current_selection = self.map_selector_combo.currentText()
        self.map_selector_combo.clear()
        if self.generated_maps:
            self.map_selector_combo.addItems(sorted(self.generated_maps.keys()))
            if current_selection in self.generated_maps:
                self.map_selector_combo.setCurrentText(current_selection)
            else:
                self.map_selector_combo.setCurrentIndex(0)
        self.map_selector_combo.blockSignals(False)
        
        if self.map_selector_combo.count() > 0:
             self._on_selected_map_change(self.map_selector_combo.currentText())
        else:
            self.map_display_widget.clear_plot()
            self.map_display_widget.show_message("No maps generated or selected.")

    def _on_selected_map_change(self, map_label: str):
        if map_label and map_label in self.generated_maps:
            map_data = self.generated_maps[map_label]
            self.map_display_widget.plot_elemental_map(
                map_data.intensity_matrix,
                x_coords=map_data.x_coordinates_map,
                y_coords=map_data.y_coordinates_map,
                title=map_data.element_label
            )
            self.map_point_spectrum_widget.clear_plot()
            self.update_status_message(f"Displaying map: {map_label}", 2000)
        elif not map_label and not self.generated_maps:
             self.map_display_widget.clear_plot()
             self.map_display_widget.show_message("No maps available. Generate a map to display.")

    def _on_map_pixel_clicked(self, x_map_val: float, y_map_val: float, intensity_val: Optional[float]):
        if not self.current_map_processor or not self.current_map_processor.spectra_collection:
            self.map_point_spectrum_widget.show_message("Map processor not ready or no spectra.")
            return

        clicked_spectrum = self.current_map_processor.get_spectrum_at_coords(x_map_val, y_map_val)
        
        if clicked_spectrum:
            self.map_point_spectrum_widget.plot_spectrum(
                clicked_spectrum.wavelengths, clicked_spectrum.intensities,
                title=f"Spectrum @ ({clicked_spectrum.x_coord:.2f}, {clicked_spectrum.y_coord:.2f}) | File: {clicked_spectrum.filename}",
                x_label="Wavelength (nm)", y_label="Intensity (a.u.)"
            )
            self.display_map_point_spectrum_signal.emit(clicked_spectrum)
            status_intensity_str = f"{intensity_val:.2f}" if intensity_val is not None else "N/A"
            self.update_status_message(f"Showing spectrum for map point ({x_map_val:.2f}, {y_map_val:.2f}), Value: {status_intensity_str}", 3000)
        else:
            self.map_point_spectrum_widget.clear_plot()
            self.map_point_spectrum_widget.show_message(f"No spectrum found near ({x_map_val:.2f}, {y_map_val:.2f}).")

    # --- BaseTab Overrides ---
    def _reset_tab_state(self):
        self.map_spectra_collection = []
        self.map_dimensions = (self.map_dim_x_spinbox.value(), self.map_dim_y_spinbox.value())
        if self.current_map_processor:
            self.current_map_processor = None
        self.generated_maps = {}
        
        self.data_load_status_label.setText("No map data loaded.")
        self.coord_filename_pattern_edit.clear()
        self._update_map_selector()
        self.map_display_widget.clear_plot()
        self.map_display_widget.show_message("Import map data and initialize processor to begin.")
        self.map_point_spectrum_widget.clear_plot()
        self.map_point_spectrum_widget.show_message("Click on a map pixel to view its spectrum.")
        self.map_element_label_edit.clear()
        
        if self.map_gen_thread and self.map_gen_thread.isRunning():
            self._cancel_map_generation()
        self.map_gen_thread = None
        self.map_gen_worker = None
        if self.progress_dialog: self.progress_dialog.close()
        self.progress_dialog = None

    def on_project_loaded(self, project: Optional[LIBSProject] = None):
        super().on_project_loaded(project)
        self._reset_tab_state()

    def on_project_closed(self):
        super().on_project_closed()
        self._reset_tab_state()

    def closeEvent(self, event):
        """Ensure worker thread is properly terminated on tab/widget close."""
        if self.map_gen_thread and self.map_gen_thread.isRunning():
            logger.info("Stopping active map generation thread before closing Mapping tab.")
            self._cancel_map_generation()
            self.map_gen_thread.wait(2000)
            if self.map_gen_thread and self.map_gen_thread.isRunning():
                logger.warning("Map generation thread did not quit gracefully after cancel, terminating.")
                self.map_gen_thread.terminate()
                self.map_gen_thread.wait()
        super().closeEvent(event)

if __name__ == '__main__':
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

    app = QApplication(sys.argv)

    class MockProjectManager:
        def __init__(self): self.current_project = None
        def get_active_spectrum(self): return None
        def get_current_project(self): return self.current_project
        def get_project_settings(self): return {"paths": {"default_project_dir": str(Path.home())}}
        def mark_dirty(self): logger.info("MockProjectManager: Project marked dirty.")

    pm = MockProjectManager()

    main_win = QWidget()
    main_layout = QVBoxLayout(main_win)
    tab = MappingTab(project_manager=pm, main_window=main_win)
    main_layout.addWidget(tab)
    main_win.setWindowTitle("Mapping Tab Test")
    main_win.resize(1100, 800)
    
    tab.on_project_loaded(pm.current_project) 
    
    main_win.show()
    sys.exit(app.exec_())
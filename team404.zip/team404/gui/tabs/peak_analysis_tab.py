# team404/gui/tabs/peak_analysis_tab.py

import logging
import os
import datetime # For timestamp in export
from pathlib import Path
from typing import List, Dict, Optional, Any, TYPE_CHECKING

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QPushButton, QLabel, QDoubleSpinBox, QSpinBox, QCheckBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QSplitter, QMessageBox, QScrollArea, QSizePolicy, QComboBox, # Added QComboBox
    QProgressDialog, QApplication, QLineEdit, QFileDialog
)
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QObject
import numpy as np

from .base_tab import BaseTab
from ...core.data_models import LIBSpectrum, Peak, LIBSProject # Corrected type hint
from ...core.peak_algorithms import detect_peaks_scipy, fit_peak_voigt, DEFAULT_FIND_PEAKS_PARAMS
from ..dialogs.preferences_dialog import app_settings_manager

if TYPE_CHECKING:
    from ..main_window import MainWindow

logger = logging.getLogger(__name__)

class PeakFittingWorker(QObject):
    finished = pyqtSignal(int, int, list) # num_success, num_attempted, list_of_updated_peak_data_dicts
    progress = pyqtSignal(int, int) # current_peak_index, total_peaks
    error = pyqtSignal(str, str) # peak_identifier (e.g. wavelength), error_message

    def __init__(self, spectrum_wavelengths: np.ndarray, spectrum_intensities: np.ndarray,
                 peaks_to_fit_data: List[Dict], fit_window_nm: float, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.wavelengths = spectrum_wavelengths
        self.intensities = spectrum_intensities
        self.peaks_data_list = peaks_to_fit_data # List of dicts from Peak.to_dict()
        self.fit_window_nm = fit_window_nm
        self._is_interruption_requested = False

    def run(self):
        if not self.peaks_data_list:
            self.finished.emit(0, 0, [])
            return

        num_attempted = len(self.peaks_data_list)
        num_success = 0
        updated_peaks_data = [] # List to store updated peak data dicts

        for i, peak_data_dict in enumerate(self.peaks_data_list):
            if self._is_interruption_requested:
                logger.info("Peak fitting worker interruption acknowledged.")
                break
            
            peak_obj = Peak.from_dict(peak_data_dict) # Recreate Peak object
            try:
                success = fit_peak_voigt(peak_obj, self.wavelengths, self.intensities, fit_window_nm=self.fit_window_nm)
                if success:
                    num_success += 1
            except Exception as e:
                logger.error(f"Error fitting peak {peak_obj.peak_id} at ~{peak_obj.detected_wavelength_nm:.2f} nm: {e}", exc_info=False)
                self.error.emit(f"~{peak_obj.detected_wavelength_nm:.2f}" if peak_obj.detected_wavelength_nm else peak_obj.peak_id, str(e))
                peak_obj.is_fitted = False
            
            updated_peaks_data.append(peak_obj.to_dict())
            self.progress.emit(i + 1, num_attempted)
        
        self.finished.emit(num_success, num_attempted, updated_peaks_data)

    def request_interruption(self):
        self._is_interruption_requested = True


class PeakAnalysisTab(BaseTab):
    request_plot_update_signal = pyqtSignal(object)

    def __init__(self, project_manager, main_window: Optional['MainWindow'] = None, parent: Optional[QWidget] = None):
        super().__init__(project_manager, main_window, parent)
        self.fit_thread: Optional[QThread] = None
        self.fit_worker: Optional[PeakFittingWorker] = None
        self.fit_progress_dialog: Optional[QProgressDialog] = None
        self._original_peaks_for_subset_fit_ids: Optional[List[str]] = None

        self._init_ui()
        self._load_default_peak_params_from_settings()

    def _init_ui(self):
        main_splitter = QSplitter(Qt.Horizontal, self)
        
        controls_widget_scroll = QScrollArea()
        controls_widget_scroll.setWidgetResizable(True)
        controls_widget_scroll.setMinimumWidth(320)
        controls_widget_scroll.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        
        controls_widget = QWidget()
        self.controls_layout = QVBoxLayout(controls_widget)
        self.controls_layout.setSpacing(10)

        detect_group = QGroupBox("Peak Detection (Scipy find_peaks)")
        detect_layout = QFormLayout(detect_group)
        detect_layout.setSpacing(8)
        
        self.detect_height_edit = QLineEdit()
        self.detect_height_edit.setPlaceholderText("e.g., 100.0 or None")
        self.detect_height_edit.setToolTip("Minimum absolute peak height. Empty or 'None' for no filter.")
        detect_layout.addRow("Min Height:", self.detect_height_edit)
        
        self.detect_prominence_spinbox = QDoubleSpinBox()
        self.detect_prominence_spinbox.setDecimals(2)
        self.detect_prominence_spinbox.setRange(0.0, 1e7)
        self.detect_prominence_spinbox.setSingleStep(1.0)
        self.detect_prominence_spinbox.setToolTip("Minimum prominence. If value is >0 and <1, it's treated as relative to data range.")
        detect_layout.addRow("Min Prominence:", self.detect_prominence_spinbox)
        
        self.detect_distance_spinbox = QSpinBox()
        self.detect_distance_spinbox.setRange(1, 1000)
        self.detect_distance_spinbox.setSuffix(" data points")
        self.detect_distance_spinbox.setToolTip("Minimum horizontal distance (in number of data points) between neighboring peaks.")
        detect_layout.addRow("Min Distance:", self.detect_distance_spinbox)
        
        self.detect_width_edit = QLineEdit()
        self.detect_width_edit.setPlaceholderText("e.g., 3 or '3,50' (points)")
        self.detect_width_edit.setToolTip("Required peak width in data points. Single value (min width) or 'min,max' range.")
        detect_layout.addRow("Width (points):", self.detect_width_edit)
        
        self.detect_rel_height_spinbox = QDoubleSpinBox()
        self.detect_rel_height_spinbox.setDecimals(2)
        self.detect_rel_height_spinbox.setRange(0.01, 1.0)
        self.detect_rel_height_spinbox.setValue(0.50)
        self.detect_rel_height_spinbox.setToolTip("Relative height at which the peak width is measured (0.0 to 1.0).")
        detect_layout.addRow("Width Rel. Height:", self.detect_rel_height_spinbox)
        
        self.run_detection_button = QPushButton("Detect Peaks in Active Spectrum")
        self.run_detection_button.setToolTip("Run peak detection on the currently processed active spectrum using these parameters.")
        self.run_detection_button.clicked.connect(self._run_peak_detection)
        detect_layout.addRow(self.run_detection_button)
        
        self.controls_layout.addWidget(detect_group)

        fit_group = QGroupBox("Peak Fitting (Voigt Profile)")
        fit_layout = QFormLayout(fit_group)
        fit_layout.setSpacing(8)
        
        self.fit_window_spinbox = QDoubleSpinBox()
        self.fit_window_spinbox.setDecimals(2)
        self.fit_window_spinbox.setRange(0.05, 100.0)
        self.fit_window_spinbox.setSingleStep(0.1)
        self.fit_window_spinbox.setSuffix(" nm")
        self.fit_window_spinbox.setToolTip("Total wavelength window width around a detected peak center used for fitting its profile.")
        fit_layout.addRow("Fitting Window (total width):", self.fit_window_spinbox)
        
        self.run_fitting_button = QPushButton("Fit All Detected Peaks")
        self.run_fitting_button.setToolTip("Attempt to fit Voigt profiles to all peaks currently listed in the table.")
        self.run_fitting_button.clicked.connect(self._run_peak_fitting_on_all_detected)
        fit_layout.addRow(self.run_fitting_button)
        
        self.fit_selected_button = QPushButton("Fit Selected Peak(s) from Table")
        self.fit_selected_button.setToolTip("Fit Voigt profiles only to the peaks selected in the table.")
        self.fit_selected_button.clicked.connect(self._fit_selected_peaks_from_table)
        self.fit_selected_button.setEnabled(False)
        fit_layout.addRow(self.fit_selected_button)
        
        self.controls_layout.addWidget(fit_group)
        
        self.manage_peaks_group = QGroupBox("Manage Peaks")
        self.manage_peaks_layout = QHBoxLayout(self.manage_peaks_group)
        
        self.clear_all_peaks_button = QPushButton("Clear All Peaks")
        self.clear_all_peaks_button.setToolTip("Remove all detected and fitted peaks from the active spectrum.")
        self.clear_all_peaks_button.clicked.connect(self._clear_all_peaks_from_active_spectrum)
        self.manage_peaks_layout.addWidget(self.clear_all_peaks_button)

        self.export_peaks_button = QPushButton("Export Peaks to TXT")
        self.export_peaks_button.setToolTip("Export the current list of detected/fitted peak wavelengths to a text file.")
        self.export_peaks_button.clicked.connect(self._export_peaks_to_txt)
        self.export_peaks_button.setEnabled(False)
        self.manage_peaks_layout.addWidget(self.export_peaks_button)
        
        self.controls_layout.addWidget(self.manage_peaks_group)

        self.controls_layout.addStretch()
        controls_widget_scroll.setWidget(controls_widget)
        main_splitter.addWidget(controls_widget_scroll)

        results_widget = QWidget()
        results_layout = QVBoxLayout(results_widget)
        results_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        self.peaks_table = QTableWidget()
        self.peaks_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.peaks_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.peaks_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.peaks_table.setAlternatingRowColors(True)
        self.peaks_table.itemSelectionChanged.connect(self._on_peak_table_selection_change)
        self.peaks_table.setColumnCount(11)
        self.peaks_table.setHorizontalHeaderLabels([
            "ID", "Det. λ (nm)", "Det. Int.", "Fit λ (nm)", "Fit Amp.", 
            "σG (nm)", "γL (nm)", "FWHM (nm)", "R²", "Area", "Identified?"
        ])
        self.peaks_table.setToolTip("Table of detected and fitted peaks. Select rows to highlight peaks on the main plot or to fit selected peaks.")
        results_layout.addWidget(QLabel("Detected and Fitted Peaks:"))
        results_layout.addWidget(self.peaks_table)
        
        main_splitter.addWidget(results_widget)
        main_splitter.setSizes([350, 650])

        self.base_layout.addWidget(main_splitter)

    def _load_default_peak_params_from_settings(self):
        proj_settings = self.project_manager.get_project_settings()
        pd_params_proj = proj_settings.get("peak_detection_params", {}).get("scipy_find_peaks", {})
        pf_params_proj = proj_settings.get("peak_fitting_params", {})
        pd_defaults_app = app_settings_manager.get_default_settings().get("peak_detection", {}).get("scipy_find_peaks", DEFAULT_FIND_PEAKS_PARAMS.copy())
        pf_defaults_app = app_settings_manager.get_default_settings().get("peak_fitting", {}).get("voigt_defaults", {})
        final_pd_params = {**pd_defaults_app, **pd_params_proj}
        final_pf_window = pf_params_proj.get("default_fit_window_nm", pf_defaults_app.get("default_fit_window_nm", 1.0))
        self.detect_height_edit.setText(str(final_pd_params.get("height", "") or ""))
        self.detect_prominence_spinbox.setValue(float(final_pd_params.get("prominence", 0.1)))
        self.detect_distance_spinbox.setValue(int(final_pd_params.get("distance", 5)))
        width_val = final_pd_params.get("width", "")
        if isinstance(width_val, (list, tuple)) and len(width_val) == 2:
            self.detect_width_edit.setText(f"{width_val[0]},{width_val[1]}")
        else:
            self.detect_width_edit.setText(str(width_val or ""))
        self.detect_rel_height_spinbox.setValue(float(final_pd_params.get("rel_height", 0.5)))
        self.fit_window_spinbox.setValue(float(final_pf_window))

    def _collect_peak_detection_params(self) -> Dict[str, Any]:
        params = DEFAULT_FIND_PEAKS_PARAMS.copy()
        try:
            h_text = self.detect_height_edit.text().strip().lower()
            params["height"] = float(h_text) if h_text and h_text != "none" else None
            prom_val = self.detect_prominence_spinbox.value()
            params["prominence"] = prom_val if prom_val > 1e-9 else None
            params["distance"] = self.detect_distance_spinbox.value()
            w_text = self.detect_width_edit.text().strip().lower()
            if w_text and w_text != "none":
                if ',' in w_text:
                    parts = [float(p.strip()) for p in w_text.split(',')]
                    if len(parts) == 2 and parts[0] <= parts[1] and parts[0] > 0:
                        params["width"] = (parts[0], parts[1])
                    else:
                        raise ValueError("Width range must be 'min,max' with 0 < min <= max.")
                else:
                    width_single = float(w_text)
                    if width_single > 0:
                        params["width"] = width_single
                    else:
                        raise ValueError("Single width value must be positive.")
            else:
                params["width"] = None
            params["rel_height"] = self.detect_rel_height_spinbox.value()
        except ValueError as e:
            QMessageBox.warning(self, "Invalid Input", f"Peak detection parameter error: {e}")
            raise
        return params

    def _run_peak_detection(self):
        active_spectrum = self.get_active_spectrum()
        if not (active_spectrum and active_spectrum.is_valid_for_processing()):
            QMessageBox.warning(self, "No/Invalid Spectrum", "Active spectrum has no valid data for peak detection.")
            return
        try:
            detection_params = self._collect_peak_detection_params()
        except ValueError:
            return

        self.update_status_message("Detecting peaks...", 0)
        QApplication.processEvents()
        
        try:
            wl = active_spectrum.get_processed_wavelengths()
            inten = active_spectrum.get_processed_intensities()
            detected_peaks_list = detect_peaks_scipy(wl, inten, params=detection_params)
            active_spectrum.peaks = detected_peaks_list
            self._populate_peaks_table(active_spectrum.peaks)
            self._update_ui_for_active_spectrum() # Call this to update button states
            self.mark_project_dirty()
            self.update_status_message(f"Detected {len(detected_peaks_list)} peaks.", 3000)
            self.request_plot_update_signal.emit({"action": "show_spectrum_and_peaks", "spectrum": active_spectrum})
        except Exception as e:
            logger.error(f"Peak detection process failed: {e}", exc_info=True)
            QMessageBox.critical(self, "Peak Detection Error", f"An error occurred: {str(e)[:200]}")
            self.update_status_message("Peak detection failed.", 5000)
            self._update_ui_for_active_spectrum() # Update UI on error too

    def _start_peak_fitting_worker(self, peaks_to_fit_data: List[Dict]):
        active_spectrum = self.get_active_spectrum()
        if not (active_spectrum and active_spectrum.is_valid_for_processing()):
             QMessageBox.warning(self, "Invalid Spectrum", "Active spectrum data is not valid for fitting.")
             return
        if self.fit_thread and self.fit_thread.isRunning():
            QMessageBox.information(self, "Busy", "Peak fitting is already in progress. Please wait or cancel.")
            return
        fit_window = self.fit_window_spinbox.value()
        if fit_window <= 0:
            QMessageBox.warning(self, "Invalid Parameter", "Fitting window must be a positive value.")
            return
        self.run_fitting_button.setEnabled(False)
        self.fit_selected_button.setEnabled(False)
        self.update_status_message("Fitting peaks...", 0)
        num_peaks_to_fit = len(peaks_to_fit_data)
        self.fit_progress_dialog = QProgressDialog("Fitting peaks...", "Cancel", 0, num_peaks_to_fit, self)
        self.fit_progress_dialog.setWindowModality(Qt.WindowModal)
        self.fit_progress_dialog.setAutoClose(True)
        self.fit_progress_dialog.setAutoReset(True)
        self.fit_progress_dialog.setMinimumDuration(200)
        self.fit_progress_dialog.setValue(0)
        self.fit_thread = QThread(self)
        self.fit_worker = PeakFittingWorker(
            active_spectrum.get_processed_wavelengths().copy(),
            active_spectrum.get_processed_intensities().copy(),
            peaks_to_fit_data,
            fit_window,
            parent=None
        )
        self.fit_worker.moveToThread(self.fit_thread)
        self.fit_thread.started.connect(self.fit_worker.run)
        self.fit_worker.finished.connect(self._on_fitting_finished)
        self.fit_worker.progress.connect(self._on_fitting_progress)
        self.fit_worker.error.connect(self._on_fitting_error)
        self.fit_worker.finished.connect(self.fit_thread.quit)
        self.fit_worker.finished.connect(self.fit_worker.deleteLater)
        self.fit_thread.finished.connect(self.fit_thread.deleteLater)
        self.fit_thread.finished.connect(lambda: setattr(self, 'fit_thread', None))
        self.fit_thread.finished.connect(self._reset_fit_progress_dialog_state)
        if self.fit_progress_dialog:
            self.fit_progress_dialog.canceled.connect(self._cancel_peak_fitting)
        self.fit_thread.start()
        if num_peaks_to_fit > 0 and self.fit_progress_dialog:
            self.fit_progress_dialog.show()

    def _run_peak_fitting_on_all_detected(self):
        active_spectrum = self.get_active_spectrum()
        if not (active_spectrum and active_spectrum.peaks):
            QMessageBox.information(self, "No Peaks", "No detected peaks available to fit.")
            return
        self._original_peaks_for_subset_fit_ids = None
        peaks_data_to_fit = [p.to_dict() for p in active_spectrum.peaks]
        self._start_peak_fitting_worker(peaks_data_to_fit)

    def _fit_selected_peaks_from_table(self):
        selected_rows_indices = sorted(list(set(index.row() for index in self.peaks_table.selectedIndexes())))
        if not selected_rows_indices:
            QMessageBox.information(self, "No Selection", "Please select one or more peaks from the table to fit.")
            return
        active_spectrum = self.get_active_spectrum()
        if not (active_spectrum and active_spectrum.peaks):
            logger.warning("Fit selected called but no active spectrum or peaks.")
            return
        peaks_to_fit_data_list = []
        self._original_peaks_for_subset_fit_ids = []
        for row_idx in selected_rows_indices:
            if 0 <= row_idx < len(active_spectrum.peaks):
                peak_obj_to_fit = active_spectrum.peaks[row_idx]
                peaks_to_fit_data_list.append(peak_obj_to_fit.to_dict())
                self._original_peaks_for_subset_fit_ids.append(peak_obj_to_fit.peak_id)
        if peaks_to_fit_data_list:
            self._start_peak_fitting_worker(peaks_to_fit_data_list)
        else:
            QMessageBox.warning(self, "Selection Error", "Could not map selected table rows to valid peaks.")
            self._original_peaks_for_subset_fit_ids = None

    def _cancel_peak_fitting(self):
        if self.fit_worker:
            self.fit_worker.request_interruption()
            logger.info("Cancel requested for peak fitting worker by user (dialog).")
        if self.fit_progress_dialog:
            self.fit_progress_dialog.cancel()
        self._update_ui_for_active_spectrum()
        self.update_status_message("Peak fitting cancelled by user.", 3000)
        self._reset_fit_progress_dialog_state()

    def _reset_fit_progress_dialog_state(self):
        if self.fit_progress_dialog:
            self.fit_progress_dialog.reset()
            if self.fit_progress_dialog.isVisible():
                self.fit_progress_dialog.close()
        self.fit_progress_dialog = None

    def _on_fitting_progress(self, current_peak_idx: int, total_peaks: int):
        if self.fit_progress_dialog and not self.fit_progress_dialog.wasCanceled():
             if self.fit_progress_dialog.maximum() != total_peaks : self.fit_progress_dialog.setMaximum(total_peaks)
             self.fit_progress_dialog.setValue(current_peak_idx)
        self.update_status_message(f"Fitting peak {current_peak_idx}/{total_peaks}...", 0)

    def _on_fitting_finished(self, num_success: int, num_attempted: int, updated_peaks_data_list: List[Dict]):
        if self.fit_progress_dialog:
            self.fit_progress_dialog.setValue(num_attempted)
        self._update_ui_for_active_spectrum()
        self.update_status_message(f"Fitting complete. Success: {num_success}/{num_attempted}.", 5000)
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum:
            logger.error("Fitting finished, but no active spectrum found to update.")
            self._original_peaks_for_subset_fit_ids = None
            self._reset_fit_progress_dialog_state()
            return
        something_changed_in_data = False
        if self._original_peaks_for_subset_fit_ids:
            updated_peak_data_map = {pd['peak_id']: pd for pd in updated_peaks_data_list}
            for peak_obj in active_spectrum.peaks:
                if peak_obj.peak_id in updated_peak_data_map:
                    new_data = updated_peak_data_map[peak_obj.peak_id]
                    if peak_obj.is_fitted != new_data.get('is_fitted', False) or \
                       not np.allclose(peak_obj.fitted_wavelength_nm or -1, new_data.get('fitted_wavelength_nm', -2), equal_nan=True, atol=1e-6) or \
                       not np.allclose(peak_obj.fitted_amplitude or -1, new_data.get('fitted_amplitude', -2), equal_nan=True, atol=1e-4):
                        something_changed_in_data = True
                    peak_obj.update_from_dict(new_data)
        else:
            if len(active_spectrum.peaks) == len(updated_peaks_data_list):
                for i, updated_data in enumerate(updated_peaks_data_list):
                    original_peak = active_spectrum.peaks[i]
                    if original_peak.is_fitted != updated_data.get('is_fitted', False) or \
                       not np.allclose(original_peak.fitted_wavelength_nm or -1, updated_data.get('fitted_wavelength_nm', -2), equal_nan=True, atol=1e-6) or \
                       not np.allclose(original_peak.fitted_amplitude or -1, updated_data.get('fitted_amplitude', -2), equal_nan=True, atol=1e-4):
                        something_changed_in_data = True
                    original_peak.update_from_dict(updated_data)
            else:
                logger.warning("Peak count mismatch after full refit. Replacing peak list.")
                active_spectrum.peaks = [Peak.from_dict(pd) for pd in updated_peaks_data_list]
                something_changed_in_data = True
        self._populate_peaks_table(active_spectrum.peaks)
        if something_changed_in_data:
            self.mark_project_dirty()
        self.request_plot_update_signal.emit({"action": "show_spectrum_and_peaks", "spectrum": active_spectrum})
        self._original_peaks_for_subset_fit_ids = None
        self._reset_fit_progress_dialog_state()

    def _on_fitting_error(self, peak_identifier_str: str, error_message: str):
        logger.warning(f"Peak fitting error reported for peak around ~{peak_identifier_str} nm: {error_message}")
        self.update_status_message(f"Error fitting peak {peak_identifier_str}. See logs.", 4000)
        if self.fit_progress_dialog and not self.fit_progress_dialog.wasCanceled():
            self.fit_progress_dialog.cancel()
        self._update_ui_for_active_spectrum()
        self._reset_fit_progress_dialog_state()

    def _populate_peaks_table(self, peaks: Optional[List[Peak]]):
        self.peaks_table.blockSignals(True)
        self.peaks_table.setRowCount(0)
        if not peaks:
            self.peaks_table.setHorizontalHeaderLabels(["ID", "Det. λ (nm)", "Det. Int.", "Fit λ (nm)", "Fit Amp.", "σG (nm)", "γL (nm)", "FWHM (nm)", "R²", "Area", "Identified?"])
            self.peaks_table.blockSignals(False)
            return
        self.peaks_table.setRowCount(len(peaks))
        self.peaks_table.setHorizontalHeaderLabels([
            "ID", "Det. λ (nm)", "Det. Int.", "Fit λ (nm)", "Fit Amp.", 
            "σG (nm)", "γL (nm)", "FWHM (nm)", "R²", "Area", "Identified?"
        ])
        for row_idx, peak_obj in enumerate(peaks):
            def fmt_f(val, prec=3): return f"{val:.{prec}f}" if val is not None and not np.isnan(val) else "N/A"
            self.peaks_table.setItem(row_idx, 0, QTableWidgetItem(peak_obj.peak_id[:8]))
            self.peaks_table.setItem(row_idx, 1, QTableWidgetItem(fmt_f(peak_obj.detected_wavelength_nm)))
            self.peaks_table.setItem(row_idx, 2, QTableWidgetItem(fmt_f(peak_obj.detected_intensity, 2)))
            if peak_obj.is_fitted:
                self.peaks_table.setItem(row_idx, 3, QTableWidgetItem(fmt_f(peak_obj.fitted_wavelength_nm)))
                self.peaks_table.setItem(row_idx, 4, QTableWidgetItem(fmt_f(peak_obj.fitted_amplitude, 2)))
                self.peaks_table.setItem(row_idx, 5, QTableWidgetItem(fmt_f(peak_obj.gaussian_sigma_nm, 4)))
                self.peaks_table.setItem(row_idx, 6, QTableWidgetItem(fmt_f(peak_obj.lorentzian_gamma_nm, 4)))
                self.peaks_table.setItem(row_idx, 7, QTableWidgetItem(fmt_f(peak_obj.voigt_fwhm_nm)))
                self.peaks_table.setItem(row_idx, 8, QTableWidgetItem(fmt_f(peak_obj.fit_r_squared, 4)))
                self.peaks_table.setItem(row_idx, 9, QTableWidgetItem(fmt_f(peak_obj.peak_area, 2)))
            else:
                for col_idx in range(3, 10): self.peaks_table.setItem(row_idx, col_idx, QTableWidgetItem("-"))
            id_status = "Yes" if peak_obj.is_identified and peak_obj.identified_elements else "No"
            self.peaks_table.setItem(row_idx, 10, QTableWidgetItem(id_status))
        self.peaks_table.resizeColumnsToContents()
        self.peaks_table.blockSignals(False)

    def _on_peak_table_selection_change(self):
        selected_rows_exist = bool(self.peaks_table.selectionModel().selectedRows())
        self.fit_selected_button.setEnabled(selected_rows_exist) # Correctly enable based on selection
        active_spectrum = self.get_active_spectrum()
        if not (active_spectrum and active_spectrum.peaks):
            self.request_plot_update_signal.emit({"action": "highlight_on_plot", "peaks_info": []})
            return
        highlight_instructions: List[Dict[str, Any]] = []
        for model_index in self.peaks_table.selectionModel().selectedRows():
            try:
                peak_obj = active_spectrum.peaks[model_index.row()]
                wl_to_highlight = peak_obj.get_effective_wavelength()
                if wl_to_highlight is not None:
                    highlight_instructions.append({
                        "wavelength": wl_to_highlight,
                        "label": f"P{model_index.row()+1}"
                    })
            except IndexError:
                logger.warning(f"Index out of range accessing peak for row {model_index.row()}.")
        self.request_plot_update_signal.emit({"action": "highlight_on_plot", "peaks_info": highlight_instructions})

    def _clear_all_peaks_from_active_spectrum(self):
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum:
            QMessageBox.information(self, "No Spectrum", "No active spectrum selected.")
            return
        if not active_spectrum.peaks:
            QMessageBox.information(self, "No Peaks", "The active spectrum currently has no detected peaks.")
            return
        reply = QMessageBox.question(self, "Confirm Clear",
                                     f"Are you sure you want to remove all {len(active_spectrum.peaks)} peaks "
                                     f"from spectrum '{active_spectrum.filename or active_spectrum.spectrum_id}'?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            active_spectrum.peaks = []
            self._populate_peaks_table([])
            self._update_ui_for_active_spectrum() # Update button states
            self.mark_project_dirty()
            self.request_plot_update_signal.emit({"action": "show_spectrum_and_peaks", "spectrum": active_spectrum})
            self.update_status_message("All peaks cleared from active spectrum.", 3000)

    def _update_ui_for_active_spectrum(self):
        active_spectrum = self.get_active_spectrum()
        print(f"\n--- _update_ui_for_active_spectrum CALLED (PeakAnalysisTab) ---")

        enable_actions = False
        if active_spectrum:
            print(f"  Active Spectrum ID: {active_spectrum.spectrum_id}, Filename: {active_spectrum.filename}")
            is_valid_proc = active_spectrum.is_valid_for_processing()
            print(f"  Is Valid for Processing: {is_valid_proc}")
            enable_actions = is_valid_proc
        else:
            print("  No active spectrum.")

        has_peaks = False
        if active_spectrum and enable_actions:
            print(f"  Checking peaks for {active_spectrum.spectrum_id}:")
            if hasattr(active_spectrum, 'peaks') and active_spectrum.peaks is not None:
                print(f"    active_spectrum.peaks exists, type: {type(active_spectrum.peaks)}, len: {len(active_spectrum.peaks)}")
                has_peaks = bool(active_spectrum.peaks)
            else:
                print(f"    active_spectrum.peaks attribute missing or is None.")
        
        print(f"  Final enable_actions: {enable_actions}")
        print(f"  Final has_peaks: {has_peaks}")

        self.run_detection_button.setEnabled(enable_actions)
        self.run_fitting_button.setEnabled(has_peaks)
        self.clear_all_peaks_button.setEnabled(has_peaks)
        
        if hasattr(self, 'export_peaks_button'):
            print(f"  Setting export_peaks_button enabled state to: {has_peaks}")
            self.export_peaks_button.setEnabled(has_peaks)
        else:
            # This case should ideally not happen if _init_ui is correct
            print(f"  WARNING: self.export_peaks_button attribute does not exist!")
            
        self.fit_selected_button.setEnabled(has_peaks and bool(self.peaks_table.selectionModel().selectedRows()))
        
        # Plot updates / table population
        if active_spectrum:
            # Only repopulate table if the content might have changed relative to the current display
            # For simplicity in this update, if active_spectrum exists, ensure table reflects its peaks
            # A more optimized way would be to check if the table *needs* repopulating.
            current_table_peak_ids = set()
            for i in range(self.peaks_table.rowCount()):
                id_item = self.peaks_table.item(i, 0)
                if id_item: current_table_peak_ids.add(id_item.text())
            
            spectrum_peak_ids = set(p.peak_id[:8] for p in active_spectrum.peaks) if active_spectrum.peaks else set()

            if current_table_peak_ids != spectrum_peak_ids or self.peaks_table.rowCount() != len(spectrum_peak_ids):
                 logger.debug("Peak table content differs from active_spectrum.peaks, repopulating table.")
                 self._populate_peaks_table(active_spectrum.peaks)
            
            # self.request_plot_update_signal.emit({"action": "show_spectrum_and_peaks", "spectrum": active_spectrum})
        else:
            if self.peaks_table.rowCount() > 0: # Only clear if not already empty
                 self._populate_peaks_table(None)
            # self.request_plot_update_signal.emit({"action": "clear_plot"})
        print(f"--- _update_ui_for_active_spectrum END ---\n")


    def on_tab_selected(self):
        super().on_tab_selected()
        self._update_ui_for_active_spectrum()

    def on_project_loaded(self, project: Optional[LIBSProject] = None):
        super().on_project_loaded(project)
        self._load_default_peak_params_from_settings()
        self._update_ui_for_active_spectrum()

    def on_project_closed(self):
        super().on_project_closed()
        self._update_ui_for_active_spectrum()

    def on_active_spectrum_changed(self, new_spectrum: Optional[LIBSpectrum] = None):
        super().on_active_spectrum_changed(new_spectrum)
        self._update_ui_for_active_spectrum()

    def on_preferences_updated(self, new_settings: dict):
        super().on_preferences_updated(new_settings)
        self._load_default_peak_params_from_settings()
        
    def closeEvent(self, event):
        if self.fit_thread and self.fit_thread.isRunning():
            logger.info("Stopping active peak fitting thread before closing PeakAnalysisTab.")
            self._cancel_peak_fitting()
            if not self.fit_thread.wait(1000):
                logger.warning("Peak fitting thread did not quit gracefully, terminating.")
                self.fit_thread.terminate()
                self.fit_thread.wait()
        super().closeEvent(event)

    def _export_peaks_to_txt(self):
        active_spectrum = self.get_active_spectrum()
        if not (active_spectrum and active_spectrum.peaks):
            QMessageBox.information(self, "No Peaks", "There are no peaks in the active spectrum to export.")
            return

        sanitized_base_name = "".join(c if c.isalnum() or c in ['.', '_', '-'] else '_' for c in (active_spectrum.filename or active_spectrum.spectrum_id))
        if not sanitized_base_name:
            sanitized_base_name = "spectrum"
        default_filename = f"{sanitized_base_name}_peaks_with_intensities.txt" # Updated filename suggestion

        project_path_str = self.project_manager.get_current_project_filepath()
        default_dir = str(Path.home()) # Fallback
        if project_path_str:
            project_path = Path(project_path_str)
            # Check if project_path is a directory or a file's parent
            if project_path.is_file() and project_path.parent.exists():
                default_dir = str(project_path.parent)
            elif project_path.is_dir() and project_path.exists():
                default_dir = str(project_path)
        
        filepath_str, _ = QFileDialog.getSaveFileName(
            self, "Export Peaks to TXT",
            os.path.join(default_dir, default_filename),
            "Text Files (*.txt);;All Files (*)"
        )

        if not filepath_str:
            return # User cancelled

        try:
            with open(filepath_str, 'w', encoding='utf-8') as f:
                f.write(f"# Exported peak wavelengths (nm) and intensities from SpectraMapperPro\n")
                f.write(f"# Spectrum: {active_spectrum.filename or active_spectrum.spectrum_id}\n")
                f.write(f"# Date: {datetime.datetime.now().isoformat()}\n")
                f.write(f"# Format: Wavelength (nm)\tIntensity (a.u.)\n") # Updated format description
                f.write(f"# Total Peaks: {len(active_spectrum.peaks)}\n")
                f.write("# ---- Peak List ----\n")
                for peak_obj in active_spectrum.peaks:
                    # Use fitted wavelength and amplitude if available and valid, otherwise detected
                    wavelength_to_export = peak_obj.fitted_wavelength_nm if peak_obj.is_fitted and peak_obj.fitted_wavelength_nm is not None else peak_obj.detected_wavelength_nm
                    intensity_to_export = peak_obj.fitted_amplitude if peak_obj.is_fitted and peak_obj.fitted_amplitude is not None else peak_obj.detected_intensity
                    
                    if wavelength_to_export is not None and intensity_to_export is not None:
                        # Format wavelength to 4 decimal places, intensity to 2 decimal places (or adjust as needed)
                        f.write(f"{wavelength_to_export:.4f}\t{intensity_to_export:.2f}\n")
            
            self.update_status_message(f"Peaks with intensities exported to {Path(filepath_str).name}", 3000)
            QMessageBox.information(self, "Export Successful", f"Peak list with intensities successfully exported to:\n{filepath_str}")
            logger.info(f"Exported {len(active_spectrum.peaks)} peaks (wavelength & intensity) to {filepath_str}")

        except Exception as e:
            logger.error(f"Error exporting peaks with intensities to TXT: {e}", exc_info=True)
            QMessageBox.critical(self, "Export Error", f"Failed to export peaks: {e}")


if __name__ == '__main__':
    import sys
    try:
        from ...core.data_models import LIBSProject, LIBSpectrum, Peak
    except ImportError:
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))
        from team404.core.data_models import LIBSProject, LIBSpectrum, Peak
    from team404.gui.dialogs.preferences_dialog import app_settings_manager

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG, format='%(asctime)s - %(name)s [%(levelname)s] %(module)s:%(lineno)d - %(message)s')

    app = QApplication(sys.argv)
    QApplication.setOrganizationName("Team404Test")
    QApplication.setApplicationName("PeakAnalysisTabTestApp")

    class MockMainWindow(QWidget):
        def __init__(self, project_manager):
            super().__init__()
            self.project_manager = project_manager
            self.app_settings_manager = app_settings_manager
            self.statusBar = lambda: self
        def update_status_bar(self, main_message, project_message=None, timeout_ms=0):
            logger.info(f"STATUS_BAR: {main_message} | Project: {project_message}")
        def mark_project_dirty(self, dirty=True):
            self.project_manager.mark_project_dirty(dirty)

    class MockProjectManager:
        def __init__(self):
            self.current_project: Optional[LIBSProject] = None
        def get_active_spectrum(self) -> Optional[LIBSpectrum]:
            return self.current_project.get_active_spectrum() if self.current_project else None
        def get_current_project(self) -> Optional[LIBSProject]:
            return self.current_project
        def mark_project_dirty(self, dirty=True):
            if self.current_project:
                self.current_project.mark_dirty(dirty)
                logger.info(f"MockPM: Project '{self.current_project.project_name}' marked dirty={dirty}.")
            else:
                logger.warning("MockPM: Attempted to mark dirty, but no project open.")
        def get_project_settings(self) -> dict:
            base_defaults = app_settings_manager.get_default_settings()
            if self.current_project and self.current_project.settings:
                proj_specific = self.current_project.settings
                merged = {**base_defaults, **proj_specific}
                for key in base_defaults:
                    if key in proj_specific and isinstance(base_defaults[key], dict) and isinstance(proj_specific[key], dict):
                        merged[key] = {**base_defaults[key], **proj_specific[key]}
                return merged
            return base_defaults
        def get_current_project_filepath(self) -> Optional[str]:
             return self.current_project.project_filepath if self.current_project else None

    pm = MockProjectManager()
    mock_main_win = MockMainWindow(pm)
    
    test_project = LIBSProject("Test Project for Peaks")
    test_project.project_filepath = str(Path(os.getcwd()) / "test_peak_analysis_project.libs_proj")
    
    wl_data = np.linspace(200, 800, 1024)
    intensity_data = 100 * np.exp(-((wl_data - 300)**2) / (2 * 2**2)) + \
                     150 * np.exp(-((wl_data - 500)**2) / (2 * 3**2)) + \
                     np.random.normal(0, 5, size=wl_data.shape) + 20
    
    spectrum_obj = LIBSpectrum(wl_data, intensity_data, filename="test_spectrum.txt", spectrum_id="test001")
    test_project.add_spectrum(spectrum_obj)
    test_project.set_active_spectrum(spectrum_obj.spectrum_id)
    pm.current_project = test_project

    tab = PeakAnalysisTab(project_manager=pm, main_window=mock_main_win, parent=mock_main_win)
    
    main_layout = QVBoxLayout(mock_main_win)
    main_layout.addWidget(tab)
    mock_main_win.setLayout(main_layout)
    
    mock_main_win.setWindowTitle("Peak Analysis Tab Test Window")
    mock_main_win.resize(1000, 700)
    
    if pm.current_project:
        tab.on_project_loaded(pm.current_project)
        if pm.current_project.get_active_spectrum():
            tab.on_active_spectrum_changed(pm.current_project.get_active_spectrum())
    tab.on_tab_selected()

    mock_main_win.show()
    sys.exit(app.exec_())
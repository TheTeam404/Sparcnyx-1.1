# team404/gui/tabs/elemental_id_tab.py

import logging
from pathlib import Path
from typing import List, Dict, Optional, Any, Tuple, TYPE_CHECKING, Union

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QPushButton, QLabel, QLineEdit, QDoubleSpinBox, QCheckBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QSplitter, QMessageBox, QApplication, QScrollArea, QSizePolicy,
    QProgressDialog, QListWidgetItem, QListWidget, QFileDialog, QDialog
)
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QObject, QPoint
import numpy as np

from .base_tab import BaseTab
from ...core.data_models import LIBSpectrum, Peak, LIBSProject, ElementalLine
from ...database.database_manager import DatabaseManager
from ..dialogs.database_mapper_dialog import DatabaseMapperDialog
from ..dialogs.nist_search_dialog import NISTSearchDialog
from ..dialogs.manual_line_entry_dialog import ManualLineEntryDialog
from ..dialogs.preferences_dialog import app_settings_manager
from ...workers.nist_online_search_worker import NISTOnlineSearchWorker, ASTROQUERY_AVAILABLE as WORKER_ASTROQUERY_FLAG
from ...database.user_custom_db import UserCustomDB
from ...utils.helpers import get_app_data_directory
from ...utils.constants import USER_CUSTOM_DB_FILENAME, APP_NAME, ORG_NAME

if TYPE_CHECKING:
    from ..main_window import MainWindow
    from ...core.project_manager import ProjectManager

logger = logging.getLogger(__name__)

class MultiDBIdentificationWorker(QObject):
    finished = pyqtSignal(list)
    error = pyqtSignal(str)
    progress = pyqtSignal(int, int)

    def __init__(self, db_manager: DatabaseManager, peaks: List[Peak], tolerance: float, elements_filter: Optional[List[str]]):
        super().__init__()
        self.db_manager = db_manager
        self.peaks = [Peak.from_dict(p.to_dict()) for p in peaks]
        self.tolerance = tolerance
        self.elements_filter = elements_filter
        self._is_interruption_requested = False

    def run(self):
        try:
            total_peaks = len(self.peaks)
            for i, peak in enumerate(self.peaks):
                if self._is_interruption_requested: break
                wl = peak.get_effective_wavelength()
                if wl is None: continue
                
                # Clear previous identifications for this peak before re-running
                peak.is_identified = False
                peak.identified_elements = []
                
                matches = self.db_manager.search_all_databases(wl, self.tolerance, self.elements_filter)
                for match in matches: peak.identified_elements.append(match)
                if matches: peak.is_identified = True
                self.progress.emit(i + 1, total_peaks)
            
            self.finished.emit([p.to_dict() for p in self.peaks])
        except Exception as e:
            logger.error(f"Multi-DB worker error: {e}", exc_info=True)
            self.error.emit(str(e))

    def request_interruption(self):
        self._is_interruption_requested = True

class ElementalIdTab(BaseTab):
    request_peak_highlights_signal = pyqtSignal(list)

    def __init__(self, project_manager: 'ProjectManager', main_window: Optional['MainWindow'] = None, parent: Optional[QWidget] = None):
        super().__init__(project_manager, main_window, parent)
        self.db_manager = DatabaseManager()
        user_db_path = get_app_data_directory(APP_NAME, ORG_NAME)
        self.user_custom_db = UserCustomDB(str(Path(user_db_path) / USER_CUSTOM_DB_FILENAME))
        
        self.available_elements_stages: Dict[str, List[str]] = {}
        self.worker_thread: Optional[QThread] = None
        self.current_worker: Optional[QObject] = None
        self.progress_dialog: Optional[QProgressDialog] = None
        self.search_progress_dialog: Optional[QProgressDialog] = None
        
        self._init_ui()
        self._update_ui_for_active_spectrum()
        self._load_default_id_params_from_settings()

    def _init_ui(self):
        main_splitter = QSplitter(Qt.Horizontal, self)
        controls_widget_scroll = QScrollArea(); controls_widget_scroll.setWidgetResizable(True); controls_widget_scroll.setMinimumWidth(380)
        controls_widget = QWidget(); controls_layout = QVBoxLayout(controls_widget); controls_layout.setSpacing(10)
        
        db_management_group = QGroupBox("Active Local Databases")
        db_management_layout = QVBoxLayout(db_management_group)
        self.active_db_list = QListWidget(); self.active_db_list.setToolTip("List of currently loaded local database files.")
        db_management_layout.addWidget(self.active_db_list)
        db_buttons_layout = QHBoxLayout()
        self.add_db_button = QPushButton("Add Database..."); self.add_db_button.clicked.connect(self._add_database)
        self.remove_db_button = QPushButton("Remove Selected"); self.remove_db_button.clicked.connect(self._remove_database)
        db_buttons_layout.addWidget(self.add_db_button); db_buttons_layout.addWidget(self.remove_db_button)
        db_management_layout.addLayout(db_buttons_layout); controls_layout.addWidget(db_management_group)

        online_group = QGroupBox("Online Search Mode"); online_layout = QFormLayout(online_group)
        self.use_online_nist_checkbox = QCheckBox("Use Online NIST ASD Search")
        if not WORKER_ASTROQUERY_FLAG: self.use_online_nist_checkbox.setEnabled(False); self.use_online_nist_checkbox.setText("Use Online NIST (astroquery missing)")
        self.use_online_nist_checkbox.toggled.connect(self._on_search_mode_changed); online_layout.addRow(self.use_online_nist_checkbox)
        controls_layout.addWidget(online_group)

        el_select_group = QGroupBox("Element Filter"); el_select_layout = QVBoxLayout(el_select_group)
        self.element_list_widget = QListWidget(); self.element_list_widget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        el_select_layout.addWidget(self.element_list_widget)
        sel_btn_layout = QHBoxLayout(); self.select_all_elements_button = QPushButton("Select All"); self.deselect_all_elements_button = QPushButton("Deselect All")
        self.select_all_elements_button.clicked.connect(self.element_list_widget.selectAll); self.deselect_all_elements_button.clicked.connect(self.element_list_widget.clearSelection)
        sel_btn_layout.addWidget(self.select_all_elements_button); sel_btn_layout.addWidget(self.deselect_all_elements_button)
        el_select_layout.addLayout(sel_btn_layout); controls_layout.addWidget(el_select_group)

        id_params_group = QGroupBox("Search Parameters"); id_params_layout = QFormLayout(id_params_group)
        self.tolerance_spinbox = QDoubleSpinBox(); self.tolerance_spinbox.setDecimals(3); self.tolerance_spinbox.setRange(0.001, 10.0); self.tolerance_spinbox.setValue(0.05); self.tolerance_spinbox.setSuffix(" nm")
        id_params_layout.addRow("Wavelength Tolerance (±):", self.tolerance_spinbox); controls_layout.addWidget(id_params_group)

        actions_group = QGroupBox("Actions"); actions_layout = QVBoxLayout(actions_group)
        self.run_id_button = QPushButton("Identify Peaks in Active Spectrum"); self.run_id_button.clicked.connect(self._run_identification)
        actions_layout.addWidget(self.run_id_button)
        self.advanced_online_search_button = QPushButton("Advanced NIST Online Search..."); self.advanced_online_search_button.clicked.connect(self._show_advanced_online_search)
        actions_layout.addWidget(self.advanced_online_search_button)
        self.manual_entry_button = QPushButton("Add Line to User Database..."); self.manual_entry_button.setToolTip("Manually add a new spectral line to your personal database.")
        self.manual_entry_button.clicked.connect(self._show_manual_line_entry)
        actions_layout.addWidget(self.manual_entry_button)
        controls_layout.addWidget(actions_group)

        controls_layout.addStretch(); controls_widget_scroll.setWidget(controls_widget); main_splitter.addWidget(controls_widget_scroll)

        results_widget = QWidget(); results_layout = QVBoxLayout(results_widget)
        self.results_table = QTableWidget(); self.results_table.setEditTriggers(QTableWidget.NoEditTriggers); self.results_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.results_table.setAlternatingRowColors(True); self.results_table.itemSelectionChanged.connect(self._on_result_table_selection_change)
        self.results_table.setColumnCount(10); self.results_table.setHorizontalHeaderLabels(["Exp. λ (nm)", "DB λ (nm)", "Δλ (nm)", "Element", "Stage", "Aki (s⁻¹)", "E_k", "Rel.Int.(DB)", "Source", "DB ID/Notes"])
        results_layout.addWidget(QLabel("Identification Results:")); results_layout.addWidget(self.results_table)
        main_splitter.addWidget(results_widget); main_splitter.setSizes([400, 600])
        self.base_layout.addWidget(main_splitter); self._on_search_mode_changed()

    def _load_default_id_params_from_settings(self):
        tol = app_settings_manager.get_value("analysis", "default_element_id_tolerance_nm", 0.05)
        self.tolerance_spinbox.setValue(tol)

    def _prepare_common_id_params(self) -> Tuple[float, Optional[List[str]]]:
        tol = self.tolerance_spinbox.value()
        sel_el = self._get_selected_elements_for_query()
        return tol, sel_el
        
    def _get_selected_elements_for_query(self) -> Optional[List[str]]:
        selected_items = self.element_list_widget.selectedItems()
        if not selected_items and self.element_list_widget.count() > 0:
            return [self.element_list_widget.item(i).text() for i in range(self.element_list_widget.count())]
        return [item.text() for item in selected_items]

    def _add_database(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Database File", "", "Database Files (*.csv *.txt *.db *.sqlite);;All Files (*)")
        if not file_path: return
        ext = Path(file_path).suffix.lower()
        file_type = 'csv' if ext in ['.csv', '.txt', '.asc'] else 'sqlite' if ext in ['.db', '.sqlite', '.sqlite3'] else None
        if not file_type: QMessageBox.warning(self, "Unsupported File", f"Extension '{ext}' not supported."); return

        mapper_dialog = DatabaseMapperDialog(filepath=file_path, parent=self)
        if mapper_dialog.exec_() == QDialog.Accepted:
            mapping = mapper_dialog.get_mapping()
            if self.db_manager.add_database(file_path, file_type, mapping):
                self.update_status_message(f"Database '{Path(file_path).name}' added.", 3000)
                self._update_active_db_list()
                self._update_element_filter_list() # Refresh element list
            else:
                QMessageBox.critical(self, "Connection Failed", f"Could not connect to:\n{file_path}")

    def _remove_database(self):
        selected_item = self.active_db_list.currentItem()
        if not selected_item: return
        path_to_remove = selected_item.data(Qt.UserRole)
        if self.db_manager.remove_database(path_to_remove):
            self.update_status_message("Database removed.", 3000)
            self._update_active_db_list()
            self._update_element_filter_list() # Refresh element list

    def _update_active_db_list(self):
        self.active_db_list.clear()
        active_dbs = self.db_manager.get_active_databases()
        if not active_dbs:
            self.active_db_list.addItem("No local databases loaded.")
        else:
            for db_info in active_dbs:
                path = db_info['path']
                item = QListWidgetItem(Path(path).name); item.setData(Qt.UserRole, path); item.setToolTip(path)
                self.active_db_list.addItem(item)
        self._update_ui_for_active_spectrum()
        
    def _update_element_filter_list(self):
        self.available_elements_stages = self.db_manager.get_all_available_elements_stages()
        self._populate_element_list_widget()

    def _populate_element_list_widget(self):
        self.element_list_widget.clear()
        if not self.available_elements_stages:
            self.element_list_widget.addItem(QListWidgetItem("No elements in loaded DBs."))
            self.element_list_widget.setEnabled(False)
            return

        self.element_list_widget.setEnabled(True)
        all_items = []
        for el, stages in self.available_elements_stages.items():
            if stages: all_items.extend([f"{el} {st}" for st in stages])
            else: all_items.append(el)
        self.element_list_widget.addItems(sorted(all_items))

    def _run_identification(self):
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum or not active_spectrum.peaks:
            QMessageBox.warning(self, "Prerequisites Missing", "Please select an active spectrum and run peak detection first.")
            return

        if self.use_online_nist_checkbox.isChecked():
            # MODIFIED: THIS IS THE NEW, CORRECT WORKFLOW FOR ONLINE SEARCH
            self._execute_online_peak_identification_task()
        else:
            if not self.db_manager.connections:
                QMessageBox.critical(self, "No Databases", "No local databases loaded. Please add a database first.")
                return
            self._execute_local_identification_task()

    def _show_advanced_online_search(self):
        if not WORKER_ASTROQUERY_FLAG:
            QMessageBox.critical(self, "Dependency Error", "The 'astroquery' library is required for this feature.")
            return
        dialog = NISTSearchDialog(self)
        dialog.exec_()
    
    def _show_manual_line_entry(self):
        initial_wl = None
        selected_rows = self.results_table.selectionModel().selectedRows()
        if len(selected_rows) == 1:
            item = self.results_table.item(selected_rows[0].row(), 0)
            if item:
                try: initial_wl = float(item.text())
                except (ValueError, AttributeError): pass

        dialog = ManualLineEntryDialog(initial_wavelength=initial_wl, parent=self)
        if dialog.exec_() == QDialog.Accepted:
            line_data = dialog.get_line_data()
            notes = dialog.get_notes()
            if line_data and self.user_custom_db.add_line(line_data, notes=notes, source_reference="Manual Entry") is not None:
                self.update_status_message(f"Line for {line_data.element} {line_data.ion_stage} saved to user database.", 3000)
            else:
                QMessageBox.warning(self, "Save Failed", "Failed to save the line. It might be a duplicate or have invalid data.")

    def _execute_local_identification_task(self):
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum or (self.worker_thread and self.worker_thread.isRunning()): return
        tol, sel_el = self._prepare_common_id_params()
        self.run_id_button.setEnabled(False)
        self.update_status_message("Identifying peaks (Local DBs)...", 0)

        self.progress_dialog = QProgressDialog("Identifying Peaks...", "Cancel", 0, len(active_spectrum.peaks), self); self.progress_dialog.canceled.connect(self._cancel_worker); self.progress_dialog.show()
        self.worker_thread = QThread(self)
        self.current_worker = MultiDBIdentificationWorker(self.db_manager, active_spectrum.peaks, tol, sel_el)
        self.current_worker.moveToThread(self.worker_thread)
        self.worker_thread.started.connect(self.current_worker.run); self.current_worker.finished.connect(self._on_local_identification_finished)
        self.current_worker.error.connect(self._on_local_identification_error); self.current_worker.progress.connect(self.progress_dialog.setValue)
        self.current_worker.finished.connect(self.worker_thread.quit); self.current_worker.finished.connect(self.current_worker.deleteLater)
        self.worker_thread.finished.connect(self.worker_thread.deleteLater); self.worker_thread.finished.connect(self._reset_worker_state)
        self.worker_thread.start()

    def _on_local_identification_finished(self, updated_peaks_as_dicts: List[Dict]):
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum: return
        active_spectrum.peaks = [Peak.from_dict(p_dict) for p_dict in updated_peaks_as_dicts]
        self.mark_project_dirty()
        self._display_peak_id_results_in_table(active_spectrum.peaks)
        self._highlight_identified_peaks_on_plot(active_spectrum.peaks)
        self.update_status_message("Local identification complete.", 3000)
        self._reset_worker_state()

    def _on_local_identification_error(self, error_message: str):
        self.update_status_message(f"Local ID error: {error_message}", 5000)
        QMessageBox.critical(self, "Local Identification Error", f"An error occurred: {error_message}")
        self._reset_worker_state()
        
    def _cancel_worker(self):
        if self.current_worker and hasattr(self.current_worker, 'request_interruption'):
            self.current_worker.request_interruption()
    
    def _reset_worker_state(self):
        self.worker_thread = None; self.current_worker = None
        if self.progress_dialog: self.progress_dialog.close(); self.progress_dialog = None
        if self.search_progress_dialog: self.search_progress_dialog.close(); self.search_progress_dialog = None
        self._update_ui_for_active_spectrum()

    def _on_search_mode_changed(self):
        use_online = self.use_online_nist_checkbox.isChecked() and WORKER_ASTROQUERY_FLAG
        self.run_id_button.setText("Identify Peaks (Online)" if use_online else "Identify Peaks (Local DBs)")
        self._update_ui_for_active_spectrum()

    def _update_ui_for_active_spectrum(self):
        active_spectrum = self.get_active_spectrum()
        has_peaks = bool(active_spectrum and active_spectrum.peaks)
        use_online = self.use_online_nist_checkbox.isChecked() and WORKER_ASTROQUERY_FLAG
        local_dbs_loaded = bool(self.db_manager.connections)
        self.run_id_button.setEnabled((not use_online and local_dbs_loaded and has_peaks) or (use_online and bool(active_spectrum)))
        self.advanced_online_search_button.setEnabled(WORKER_ASTROQUERY_FLAG)

    def _execute_online_search_task(self, min_wl_nm: float, max_wl_nm: float, query_ref: Any):
        if self.worker_thread and self.worker_thread.isRunning(): return
        _, sel_el = self._prepare_common_id_params()
        self.run_id_button.setEnabled(False)
        self.update_status_message(f"Querying NIST Online...", 0)
        self.search_progress_dialog = QProgressDialog("Querying NIST...", "Cancel", 0, 100, self)
        self.search_progress_dialog.canceled.connect(self._cancel_worker); self.search_progress_dialog.show()
        self.worker_thread = QThread(self)
        self.current_worker = NISTOnlineSearchWorker(wavelength_min_nm=min_wl_nm, wavelength_max_nm=max_wl_nm, linename=" ".join(sel_el) if sel_el else None, query_reference=query_ref)
        self.current_worker.moveToThread(self.worker_thread)
        self.worker_thread.started.connect(self.current_worker.run); self.current_worker.finished.connect(self._on_online_search_finished)
        self.current_worker.error.connect(self._on_online_search_error); self.current_worker.progress.connect(self.search_progress_dialog.setValue)
        self.current_worker.finished.connect(self.worker_thread.quit); self.current_worker.finished.connect(self.current_worker.deleteLater)
        self.worker_thread.finished.connect(self.worker_thread.deleteLater); self.worker_thread.finished.connect(self._reset_worker_state)
        self.worker_thread.start()

    def _on_online_search_finished(self, success: bool, result_or_message: Union[Dict, str]):
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum: return # Should not happen if a search was running for it

        if success and isinstance(result_or_message, dict):
            lines_found: List[ElementalLine] = result_or_message.get("lines_found", [])
            message = result_or_message.get("message", f"Found {len(lines_found)} lines.")
            self.update_status_message(f"NIST Online: {message}", 3000)

            if not lines_found:
                QMessageBox.information(self, "Search Complete", "No lines found for this spectrum's range.")
                return

            # This is the crucial part: match results back to the peaks in the active spectrum
            peaks_updated = 0
            for peak in active_spectrum.peaks:
                peak.is_identified = False
                peak.identified_elements = [] # Clear previous results
                wl = peak.get_effective_wavelength()
                if wl is None: continue

                for line in lines_found:
                    if abs(line.wavelength_nm - wl) <= self.tolerance_spinbox.value():
                        match_dict = line.to_dict()
                        match_dict['experimental_wavelength_nm'] = wl
                        match_dict['delta_wavelength_nm'] = wl - line.wavelength_nm
                        peak.identified_elements.append(match_dict)
                        peak.is_identified = True
                        peaks_updated += 1
            
            logger.info(f"Matched {peaks_updated} online lines to detected peaks.")
            self.mark_project_dirty() # The project data (peaks) has changed!
            
            # Refresh the UI to show the new results
            self._display_peak_id_results_in_table(active_spectrum.peaks)
            self._highlight_identified_peaks_on_plot(active_spectrum.peaks)

        elif not success and isinstance(result_or_message, str):
            self._on_online_search_error("OnlineSearchFailed", result_or_message)

    
    def _on_online_search_error(self, error_type: str, error_message: str):
        self.update_status_message(f"NIST Online error: {error_message}", 5000)
        QMessageBox.critical(self, f"NIST Online Search Error ({error_type})", f"An error occurred: {error_message}")

    # REWORKED: This method now correctly populates the table based on the rich data
    # stored inside the Peak objects.
    def _display_peak_id_results_in_table(self, identified_peaks: List[Peak]):
        self.results_table.clearContents()
        self.results_table.setRowCount(0)
        
        all_matches_for_table = []
        for peak in identified_peaks:
            if peak.is_identified:
                for match in peak.identified_elements:
                    # Create a dictionary specifically for table display
                    table_row = {
                        "Exp. λ (nm)": peak.get_effective_wavelength(),
                        "DB λ (nm)": match.get('wavelength_nm'),
                        "Δλ (nm)": peak.get_effective_wavelength() - match.get('wavelength_nm', 0),
                        "Element": match.get('element'),
                        "Stage": match.get('ion_stage'),
                        "Aki (s⁻¹)": match.get('Aki'),
                        "E_k": match.get('Ek_ev'), # Assuming eV for now
                        "Rel.Int.(DB)": match.get('intensity_db_str'),
                        "Source": match.get('source_db'),
                        "DB ID/Notes": "" # Placeholder
                    }
                    all_matches_for_table.append(table_row)
        
        if all_matches_for_table:
            self.results_table.populate_from_list_of_dicts(all_matches_for_table)
            self.results_table.resizeColumnsToContents()


    def _populate_results_table_from_matches(self, matches_list:List[Dict[str,Any]]):
        self.results_table.setRowCount(0); self.results_table.setRowCount(len(matches_list))
        for r,m in enumerate(matches_list):
            def fmt(v,p=3): return f"{v:.{p}f}" if isinstance(v, (int, float)) and not np.isnan(v) else "N/A"
            def fmt_e(v): return f"{v:.2e}" if isinstance(v, (int, float)) and not np.isnan(v) else "N/A"
            self.results_table.setItem(r,0,QTableWidgetItem(fmt(m.get('experimental_wavelength_nm')))); self.results_table.setItem(r,1,QTableWidgetItem(fmt(m.get('wavelength_nm'))))
            self.results_table.setItem(r,2,QTableWidgetItem(fmt(m.get('delta_wavelength_nm'),4))); self.results_table.setItem(r,3,QTableWidgetItem(str(m.get('element','N/A'))))
            self.results_table.setItem(r,4,QTableWidgetItem(str(m.get('ion_stage','N/A')))); self.results_table.setItem(r,5,QTableWidgetItem(fmt_e(m.get('Aki'))))
            ek_val=m.get('Ek_ev'); ek_unit=" (eV)"
            if ek_val is None: ek_val=m.get('Ek_cm_inv'); ek_unit=" (cm⁻¹)"
            self.results_table.setItem(r,6,QTableWidgetItem(fmt(ek_val)+ek_unit if ek_val is not None else "N/A"))
            self.results_table.setItem(r,7,QTableWidgetItem(str(m.get('relative_intensity_db_str','N/A')))); self.results_table.setItem(r,8,QTableWidgetItem(str(m.get('source_db','N/A'))))
            self.results_table.setItem(r,9,QTableWidgetItem(''))
        self.results_table.resizeColumnsToContents()
    
    def _highlight_identified_peaks_on_plot(self, identified_peaks: List[Peak]):
        highlights = [{"wavelength": p.get_effective_wavelength(), "label": f"{p.identified_elements[0]['element']} {p.identified_elements[0]['ion_stage']}"} for p in identified_peaks if p.is_identified and p.identified_elements]
        self.request_peak_highlights_signal.emit(highlights)

    def _on_result_table_selection_change(self):
        highlights = []; unique_wls = set()
        for item in self.results_table.selectedItems():
            row = item.row()
            try:
                wl_str = self.results_table.item(row, 0).text()
                el_str = self.results_table.item(row, 3).text()
                st_str = self.results_table.item(row, 4).text()
                wl = float(wl_str)
                if wl not in unique_wls:
                    highlights.append({"wavelength": wl, "label": f"{el_str} {st_str}"}); unique_wls.add(wl)
            except (ValueError, AttributeError): continue
        self.request_peak_highlights_signal.emit(highlights)

    def on_tab_selected(self): super().on_tab_selected(); self._update_ui_for_active_spectrum()
    def on_project_loaded(self, project: Optional[LIBSProject] = None): super().on_project_loaded(project); self.db_manager.clear_all(); self._update_active_db_list(); self._update_element_filter_list(); self._load_default_id_params_from_settings(); self._update_ui_for_active_spectrum()
    def on_project_closed(self): super().on_project_closed(); self.db_manager.clear_all(); self._update_active_db_list(); self._update_element_filter_list(); self._update_ui_for_active_spectrum()
    def on_active_spectrum_changed(self, new_spectrum: Optional[LIBSpectrum] = None): super().on_active_spectrum_changed(new_spectrum); self._update_ui_for_active_spectrum()
    def on_preferences_updated(self, new_settings: dict): super().on_preferences_updated(new_settings); self._load_default_id_params_from_settings()

    def closeEvent(self, event):
        if self.worker_thread and self.worker_thread.isRunning():
            self._cancel_worker(); self.worker_thread.quit()
            if not self.worker_thread.wait(1000): self.worker_thread.terminate()
        super().closeEvent(event)
    
    def _execute_online_peak_identification_task(self):
        active_spectrum = self.get_active_spectrum()
        if not active_spectrum or not active_spectrum.peaks or (self.worker_thread and self.worker_thread.isRunning()):
            return

        tol, sel_el = self._prepare_common_id_params()
        
        # Get the list of peak wavelengths to search for
        peak_wavelengths = [p.get_effective_wavelength() for p in active_spectrum.peaks if p.get_effective_wavelength() is not None]
        if not peak_wavelengths:
            QMessageBox.information(self, "No Peaks", "No valid peak wavelengths to search.")
            return

        self.run_id_button.setEnabled(False)
        self.update_status_message("Identifying peaks (Online NIST)...", 0)

        self.progress_dialog = QProgressDialog("Querying NIST for each peak...", "Cancel", 0, len(peak_wavelengths), self)
        self.progress_dialog.canceled.connect(self._cancel_worker)
        self.progress_dialog.show()

        self.worker_thread = QThread(self)
        self.current_worker = NISTOnlineSearchWorker(
            peak_wavelengths_nm=peak_wavelengths,
            tolerance_nm=tol,
            linename=" ".join(sel_el) if sel_el else None,
            query_reference=active_spectrum.spectrum_id
        )
        self.current_worker.moveToThread(self.worker_thread)
        self.worker_thread.started.connect(self.current_worker.run)
        self.current_worker.finished.connect(self._on_online_search_finished) # This now handles peak-by-peak results
        self.current_worker.error.connect(self._on_online_search_error)
        self.current_worker.progress.connect(self.progress_dialog.setValue)
        
        self.current_worker.finished.connect(self.worker_thread.quit)
        self.worker_thread.finished.connect(self._reset_worker_state)
        self.worker_thread.start()
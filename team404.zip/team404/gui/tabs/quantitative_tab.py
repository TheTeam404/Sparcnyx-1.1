# team404/gui/tabs/quantitative_tab.py

"""
QuantitativeTab for SpectraMapper Pro.
Provides UI for quantitative analysis, primarily focusing on Boltzmann plots
for plasma temperature estimation. Calibration curve functionality can be added.
"""

import logging
from typing import List, Dict, Optional, Any, Tuple, TYPE_CHECKING

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QPushButton, QLabel, QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView, QSplitter, QMessageBox, QComboBox, QCheckBox,
    QScrollArea, QSizePolicy, QApplication
)
from PyQt5.QtCore import Qt, pyqtSignal
import numpy as np

from .base_tab import BaseTab
from ..widgets.spectrum_plot_widget import SpectrumPlotWidget
from ...core.data_models import LIBSpectrum, Peak, ElementalLine, LIBSProject # <<<< CORRECTED IMPORT HERE
from ...core.quantitative_analyzer import QuantitativeAnalyzer, BoltzmannLinePoint

if TYPE_CHECKING:
    from ..main_window import MainWindow # For type hinting main_window

logger = logging.getLogger(__name__)


class QuantitativeTab(BaseTab):
    """Tab for performing quantitative analysis like Boltzmann plots."""
    request_boltzmann_line_highlights_signal = pyqtSignal(list)

    def __init__(self, project_manager, main_window: Optional['MainWindow'] = None, parent: Optional[QWidget] = None):
        super().__init__(project_manager, main_window, parent)
        self.quantitative_analyzer = QuantitativeAnalyzer()
        self.selected_lines_for_boltzmann_data: List[Dict[str, Any]] = []

        self._init_ui()

    def _init_ui(self):
        main_splitter = QSplitter(Qt.Vertical, self)

        controls_widget_scroll = QScrollArea()
        controls_widget_scroll.setWidgetResizable(True)
        controls_widget_scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

        controls_widget_container = QWidget()
        controls_layout = QVBoxLayout(controls_widget_container)
        controls_layout.setSpacing(10)

        line_selection_group = QGroupBox("Boltzmann Plot: Line Selection")
        line_selection_layout = QVBoxLayout(line_selection_group)
        self.info_label = QLabel("Select an active spectrum with identified peaks. Then, choose lines of the "
                                 "*same element and ionization stage* from the table below for analysis.")
        self.info_label.setWordWrap(True); self.info_label.setStyleSheet("padding: 5px;")
        line_selection_layout.addWidget(self.info_label)

        self.identified_peaks_table = QTableWidget()
        self.identified_peaks_table.setColumnCount(7)
        self.identified_peaks_table.setHorizontalHeaderLabels([
            "Exp. λ (nm)", "Element", "Stage", "Intensity Source", "Aki (s⁻¹)", "E_k (Value)", "g_k"
        ])
        self.identified_peaks_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.identified_peaks_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.identified_peaks_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.identified_peaks_table.setAlternatingRowColors(True)
        self.identified_peaks_table.itemSelectionChanged.connect(self._on_identified_lines_selection_change)
        self.identified_peaks_table.setMinimumHeight(200)
        line_selection_layout.addWidget(self.identified_peaks_table)
        controls_layout.addWidget(line_selection_group)

        boltzmann_params_group = QGroupBox("Boltzmann Plot Parameters")
        boltzmann_params_layout = QFormLayout(boltzmann_params_group)
        boltzmann_params_layout.setSpacing(8)

        self.boltzmann_intensity_key_combo = QComboBox()
        self.boltzmann_intensity_key_combo.addItems(["Fitted Amplitude", "Peak Area", "Detected Intensity"])
        self.boltzmann_intensity_key_combo.setToolTip("Source of intensity values for the selected lines.")
        self.boltzmann_intensity_key_combo.currentTextChanged.connect(self._update_intensity_display_in_table)
        boltzmann_params_layout.addRow("Intensity Source:", self.boltzmann_intensity_key_combo)

        self.boltzmann_energy_unit_combo = QComboBox()
        self.boltzmann_energy_unit_combo.addItems(["eV", "cm-1"])
        self.boltzmann_energy_unit_combo.setToolTip("Units of the upper energy level (E_k) values from the database.")
        self.boltzmann_energy_unit_combo.currentTextChanged.connect(self._update_ek_display_in_table)
        boltzmann_params_layout.addRow("Energy Unit for E_k:", self.boltzmann_energy_unit_combo)

        self.boltzmann_use_ransac_checkbox = QCheckBox("Use RANSAC for robust fitting")
        self.boltzmann_use_ransac_checkbox.setToolTip("Employ RANSAC algorithm to make the linear fit more robust to outliers.")
        self.boltzmann_use_ransac_checkbox.setChecked(True)
        boltzmann_params_layout.addRow(self.boltzmann_use_ransac_checkbox)
        
        self.run_boltzmann_button = QPushButton("Calculate Boltzmann Plot & Temperature")
        self.run_boltzmann_button.setToolTip("Perform Boltzmann plot analysis using the selected lines and parameters.")
        self.run_boltzmann_button.clicked.connect(self._calculate_boltzmann_plot)
        self.run_boltzmann_button.setEnabled(False)
        boltzmann_params_layout.addRow(self.run_boltzmann_button)
        
        self.boltzmann_results_label = QLabel("Select lines and click 'Calculate' to see results.")
        self.boltzmann_results_label.setWordWrap(True); self.boltzmann_results_label.setStyleSheet("padding: 5px; font-style: italic;")
        boltzmann_params_layout.addRow(self.boltzmann_results_label)
        controls_layout.addWidget(boltzmann_params_group)
        
        controls_layout.addStretch()
        controls_widget_scroll.setWidget(controls_widget_container)
        main_splitter.addWidget(controls_widget_scroll)

        self.boltzmann_plot_widget = SpectrumPlotWidget(self)
        self.boltzmann_plot_widget.set_title("Boltzmann Plot Display")
        main_splitter.addWidget(self.boltzmann_plot_widget)
        
        main_splitter.setSizes([int(self.height() * 0.55) if self.height() > 100 else 300, 
                                int(self.height() * 0.45) if self.height() > 100 else 250])


        self.base_layout.addWidget(main_splitter)

    def _populate_identified_peaks_table(self):
        self.identified_peaks_table.setRowCount(0)
        self.selected_lines_for_boltzmann_data = []
        self.run_boltzmann_button.setEnabled(False)
        self.request_boltzmann_line_highlights_signal.emit([])

        active_spectrum = self.get_active_spectrum()
        if not active_spectrum or not active_spectrum.peaks:
            self.info_label.setText("No active spectrum or no identified peaks found. "
                                    "Perform peak detection and elemental ID first.")
            return

        self.info_label.setText("Select lines of the *same element and ionization stage* "
                                "from the table below for Boltzmann plot analysis.")
        
        current_intensity_source = self.boltzmann_intensity_key_combo.currentText()
        current_ek_unit = self.boltzmann_energy_unit_combo.currentText()
        
        row_idx = 0
        for peak_obj in active_spectrum.peaks:
            if peak_obj.is_identified and peak_obj.identified_elements:
                for match_dict in peak_obj.identified_elements:
                    has_aki = match_dict.get("Aki") is not None and not np.isnan(match_dict["Aki"])
                    has_gk = match_dict.get("gk") is not None and not np.isnan(match_dict["gk"])
                    has_ek_ev = match_dict.get("Ek_ev") is not None and not np.isnan(match_dict["Ek_ev"])
                    has_ek_cm = match_dict.get("Ek_cm-1") is not None and not np.isnan(match_dict["Ek_cm-1"])

                    if not (has_aki and has_gk and (has_ek_ev or has_ek_cm)):
                        logger.debug(f"Skipping line {match_dict.get('wavelength_nm')} due to missing atomic data for Boltzmann.")
                        continue
                        
                    self.identified_peaks_table.insertRow(row_idx)
                    exp_wl = peak_obj.get_effective_wavelength()
                    
                    line_point_data = {
                        "intensity_options": {
                            "Detected Intensity": peak_obj.detected_intensity,
                            "Fitted Amplitude": peak_obj.fitted_amplitude,
                            "Peak Area": peak_obj.peak_area
                        },
                        "wavelength_nm": exp_wl, "Aki": match_dict["Aki"], "gk": match_dict["gk"],
                        "Ek_ev": match_dict.get("Ek_ev"), "Ek_cm-1": match_dict.get("Ek_cm-1"),
                        "element": match_dict.get("element"), "ion_stage": match_dict.get("ion_stage"),
                        "original_peak_id": peak_obj.peak_id,
                        "db_line_wavelength_nm": match_dict.get("wavelength_nm")
                    }
                    
                    item_wl = QTableWidgetItem(f"{exp_wl:.3f}" if exp_wl is not None else "N/A")
                    item_wl.setData(Qt.UserRole, line_point_data)
                    self.identified_peaks_table.setItem(row_idx, 0, item_wl)
                    
                    self.identified_peaks_table.setItem(row_idx, 1, QTableWidgetItem(str(match_dict.get("element","N/A"))))
                    self.identified_peaks_table.setItem(row_idx, 2, QTableWidgetItem(str(match_dict.get("ion_stage","N/A"))))
                    
                    intensity_val = line_point_data["intensity_options"].get(current_intensity_source)
                    self.identified_peaks_table.setItem(row_idx, 3, QTableWidgetItem(f"{intensity_val:.2f}" if intensity_val is not None else "N/A"))
                    
                    self.identified_peaks_table.setItem(row_idx, 4, QTableWidgetItem(f"{match_dict['Aki']:.2e}"))
                    
                    ek_display_val = line_point_data.get(f"Ek_{current_ek_unit.lower().replace('-1','m-1')}")
                    self.identified_peaks_table.setItem(row_idx, 5, QTableWidgetItem(f"{ek_display_val:.3f}" if ek_display_val is not None else "N/A"))
                    
                    self.identified_peaks_table.setItem(row_idx, 6, QTableWidgetItem(str(match_dict['gk'])))
                    row_idx += 1

        self.identified_peaks_table.resizeColumnsToContents()

    def _update_intensity_display_in_table(self):
        current_intensity_source = self.boltzmann_intensity_key_combo.currentText()
        for row_idx in range(self.identified_peaks_table.rowCount()):
            item_data = self.identified_peaks_table.item(row_idx, 0).data(Qt.UserRole)
            if item_data and "intensity_options" in item_data:
                intensity_val = item_data["intensity_options"].get(current_intensity_source)
                self.identified_peaks_table.setItem(row_idx, 3, QTableWidgetItem(f"{intensity_val:.2f}" if intensity_val is not None else "N/A"))

    def _update_ek_display_in_table(self):
        current_ek_unit_display = self.boltzmann_energy_unit_combo.currentText()
        ek_key = f"Ek_{current_ek_unit_display.lower().replace('-1','m-1')}"

        for row_idx in range(self.identified_peaks_table.rowCount()):
            item_data = self.identified_peaks_table.item(row_idx, 0).data(Qt.UserRole)
            if item_data:
                ek_display_val = item_data.get(ek_key)
                self.identified_peaks_table.setItem(row_idx, 5, QTableWidgetItem(f"{ek_display_val:.3f}" if ek_display_val is not None else "N/A"))

    def _on_identified_lines_selection_change(self):
        self.selected_lines_for_boltzmann_data = []
        selected_indices = self.identified_peaks_table.selectionModel().selectedRows()
        
        highlights_wl = []
        species_set = set()

        for model_index in selected_indices:
            row_idx = model_index.row()
            item_data = self.identified_peaks_table.item(row_idx, 0).data(Qt.UserRole)
            if item_data:
                self.selected_lines_for_boltzmann_data.append(item_data)
                if item_data.get("wavelength_nm"): highlights_wl.append(item_data["wavelength_nm"])
                
                el, stage = item_data.get("element"), item_data.get("ion_stage")
                if el and stage: species_set.add(f"{el} {stage}")

        self.run_boltzmann_button.setEnabled(len(self.selected_lines_for_boltzmann_data) >= 2)
        self.request_boltzmann_line_highlights_signal.emit(highlights_wl)

        if not self.selected_lines_for_boltzmann_data:
             self.info_label.setText("Select lines of the *same element and ionization stage* "
                                    "from the table below for Boltzmann plot analysis.")
        elif len(species_set) > 1:
            self.info_label.setText(f"<font color='orange'>Warning: Selected lines belong to multiple species ({', '.join(sorted(list(species_set)))}). "
                                    "Boltzmann plot requires lines from a single element and ionization stage.</font>")
        elif species_set:
             self.info_label.setText(f"Selected {len(self.selected_lines_for_boltzmann_data)} lines for species: <b>{list(species_set)[0]}</b>. "
                                     "Ensure they span a good range of E_k values and have accurate atomic data.")
        else:
            self.info_label.setText("<font color='red'>Error: Selected lines have missing element/stage information.</font>")


    def _calculate_boltzmann_plot(self):
        if len(self.selected_lines_for_boltzmann_data) < 2:
            QMessageBox.warning(self, "Not Enough Lines", "Please select at least two spectral lines for the Boltzmann plot.")
            return

        first_line_species = (self.selected_lines_for_boltzmann_data[0].get("element"), self.selected_lines_for_boltzmann_data[0].get("ion_stage"))
        if not all(line.get("element") == first_line_species[0] and line.get("ion_stage") == first_line_species[1] for line in self.selected_lines_for_boltzmann_data):
            QMessageBox.critical(self, "Species Mismatch", "All selected lines must belong to the same element and ionization stage.")
            return
        
        intensity_source_key = self.boltzmann_intensity_key_combo.currentText()
        ek_unit_key = self.boltzmann_energy_unit_combo.currentText()
        use_ransac = self.boltzmann_use_ransac_checkbox.isChecked()

        boltzmann_points_to_process: List[BoltzmannLinePoint] = []
        for line_data in self.selected_lines_for_boltzmann_data:
            intensity = line_data["intensity_options"].get(intensity_source_key)
            ek_value_for_unit = line_data.get(f"Ek_{ek_unit_key.lower().replace('-1','m-1')}")

            if intensity is None or np.isnan(intensity):
                QMessageBox.warning(self, "Missing Intensity", f"Intensity source '{intensity_source_key}' not available or invalid for line at ~{line_data['wavelength_nm']:.2f} nm. Skipping this line.")
                continue
            if ek_value_for_unit is None or np.isnan(ek_value_for_unit):
                QMessageBox.warning(self, "Missing Energy", f"Upper energy level E_k in '{ek_unit_key}' not available or invalid for line at ~{line_data['wavelength_nm']:.2f} nm. Skipping this line.")
                continue

            try:
                bp = BoltzmannLinePoint(
                    intensity=float(intensity), wavelength_nm=float(line_data["wavelength_nm"]),
                    Aki=float(line_data["Aki"]), gk=float(line_data["gk"]), Ek=float(ek_value_for_unit),
                    element=line_data.get("element"), ion_stage=line_data.get("ion_stage")
                )
                boltzmann_points_to_process.append(bp)
            except (ValueError, TypeError) as e:
                QMessageBox.warning(self, "Data Conversion Error", f"Invalid data for line ~{line_data.get('wavelength_nm')}: {e}. Skipping.")
                continue
        
        if len(boltzmann_points_to_process) < 2:
            QMessageBox.warning(self, "Not Enough Valid Lines", "Fewer than two valid lines remain after checking data. Cannot perform Boltzmann plot.")
            return

        self.update_status_message("Calculating Boltzmann plot...", 0); QApplication.processEvents()

        ransac_params = {'min_samples': max(2, len(boltzmann_points_to_process) // 3), 'residual_threshold': 0.5} if use_ransac else None
        try:
            results = self.quantitative_analyzer.calculate_boltzmann_plot(
                boltzmann_points_to_process, energy_unit=ek_unit_key.lower(),
                use_ransac=use_ransac, ransac_params=ransac_params
            )
        except Exception as e:
            logger.error(f"Error in Boltzmann calculation: {e}", exc_info=True)
            QMessageBox.critical(self, "Calculation Error", f"Boltzmann plot calculation failed: {str(e)[:200]}")
            self.boltzmann_results_label.setText(f"Error: {str(e)[:100]}")
            self.boltzmann_plot_widget.clear_plot(); self.boltzmann_plot_widget.show_message("Calculation Error.")
            return
        finally:
            self.update_status_message("Boltzmann plot calculation finished.", 3000)

        if results and "error" not in results: # Check for error key from analyzer itself
            temp_k_str = f"{results['temperature_k']:.0f}" if results['temperature_k'] is not None and not np.isnan(results['temperature_k']) else "N/A"
            temp_unc_str = f"± {results['temperature_uncertainty_k']:.0f}" if results.get('temperature_uncertainty_k') is not None and not np.isnan(results['temperature_uncertainty_k']) else ""
            r_sq_str = f"{results['r_squared']:.4f}" if results['r_squared'] is not None and not np.isnan(results['r_squared']) else "N/A"

            result_html = (f"<b>Plasma Temperature (T<sub>e</sub>): {temp_k_str} {temp_unc_str} K</b><br>"
                           f"R-squared: {r_sq_str}<br>"
                           f"Slope: {results['slope']:.3e}, Intercept: {results['intercept']:.3f}<br>"
                           f"Points used: {results['n_points_used_in_fit']}/{results['n_points_valid_input']} (Method: {results['fit_method']})")
            self.boltzmann_results_label.setText(result_html)
            
            species_label = f"{first_line_species[0]} {first_line_species[1]}" if first_line_species[0] and first_line_species[1] else "Selected Lines"
            self.boltzmann_plot_widget.plot_boltzmann(
                results['x_values_all'], results['y_values_all'],
                slope=results['slope'], intercept=results['intercept'],
                inlier_mask=results.get('inlier_mask'),
                title=f"Boltzmann Plot: {species_label} (T<small>e</small> ≈ {temp_k_str} K)",
                x_label=f"Upper Energy Level, E_k ({ek_unit_key})",
                y_label="ln(Iλ / (A<small>ki</small> g<small>k</small>))"
            )
            self.mark_project_dirty()
        elif results and "error" in results:
            error_msg = results["error"]
            QMessageBox.critical(self, "Boltzmann Calculation Error", f"Could not calculate Boltzmann plot:\n{error_msg}")
            self.boltzmann_results_label.setText(f"Error: {error_msg}")
            self.boltzmann_plot_widget.clear_plot(); self.boltzmann_plot_widget.show_message(f"Error: {error_msg}")
        else: # General failure if results is None or unexpected
            self.boltzmann_results_label.setText("Boltzmann plot calculation did not yield results. Check selected lines and parameters.")
            self.boltzmann_plot_widget.clear_plot(); self.boltzmann_plot_widget.show_message("Calculation Failed.")

    def _reset_tab_state(self):
        self.identified_peaks_table.setRowCount(0)
        self.selected_lines_for_boltzmann_data = []
        self.boltzmann_plot_widget.clear_plot()
        self.boltzmann_plot_widget.show_message("Select lines from an identified spectrum to generate a Boltzmann plot.")
        self.boltzmann_results_label.setText("Select lines and click 'Calculate' to see results.")
        self.run_boltzmann_button.setEnabled(False)
        self.info_label.setText("Select an active spectrum with identified peaks. Then, choose lines for Boltzmann plot.")

    def on_tab_selected(self):
        super().on_tab_selected()
        self._populate_identified_peaks_table()

    def on_project_loaded(self, project: Optional[LIBSProject] = None): # Corrected type hint
        super().on_project_loaded(project)
        self._reset_tab_state()
        self._populate_identified_peaks_table()

    def on_project_closed(self):
        super().on_project_closed()
        self._reset_tab_state()

    def on_active_spectrum_changed(self, new_spectrum: Optional[LIBSpectrum] = None):
        super().on_active_spectrum_changed(new_spectrum)
        self._reset_tab_state()
        self._populate_identified_peaks_table()

    def on_preferences_updated(self, new_settings: dict):
        super().on_preferences_updated(new_settings)
        logger.info(f"{self.__class__.__name__} received preference update.")

if __name__ == '__main__':
    import sys
    from pathlib import Path
    try: from ...core.data_models import LIBSProject, LIBSpectrum, Peak, ElementalLine
    except ImportError:
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))
        from team404.core.data_models import LIBSProject, LIBSpectrum, Peak, ElementalLine

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG, format='%(asctime)s-%(name)s[%(levelname)s]%(module)s:%(lineno)d-%(message)s')

    app = QApplication(sys.argv)
    QApplication.setOrganizationName("Team404Test")
    QApplication.setApplicationName("QuantitativeTabTestApp")

    class MockProjectManager:
        def __init__(self): self.current_project: Optional[LIBSProject] = None
        def get_active_spectrum(self) -> Optional[LIBSpectrum]: return self.current_project.get_active_spectrum() if self.current_project else None
        def get_current_project(self) -> Optional[LIBSProject]: return self.current_project
        def mark_dirty(self): logger.info("MockProjectManager: Project marked dirty.")
        def get_project_settings(self) -> dict: return {} # Simplified

    pm = MockProjectManager()
    
    test_project = LIBSProject("TestQuantProject")
    wl = np.linspace(200, 800, 1000); noise = np.random.normal(0, 0.1, len(wl))
    intensity = 100 * np.exp(-((wl - 300.02)**2) / (2 * 0.08**2)) + \
                80 * np.exp(-((wl - 305.05)**2) / (2 * 0.1**2)) + \
                120 * np.exp(-((wl - 310.10)**2) / (2 * 0.09**2)) + noise
    active_spec = LIBSpectrum(wl, intensity, filename="quant_test_spec.txt", spectrum_id="quant_spec_01")
    # Add some dummy peaks with identification data needed for Boltzmann
    active_spec.peaks = [
        Peak(detected_wavelength_nm=300.015, detected_intensity=98.0, peak_id="p1", is_identified=True,
             identified_elements=[{'element': 'Fe', 'ion_stage': 'I', 'wavelength_nm': 300.010, 'Aki': 1.5e7, 'gk': 5, 'Ek_ev': 3.0, 'Ek_cm-1': 3.0*8065.54}]),
        Peak(detected_wavelength_nm=305.052, detected_intensity=78.0, peak_id="p2", is_identified=True,
             identified_elements=[{'element': 'Fe', 'ion_stage': 'I', 'wavelength_nm': 305.045, 'Aki': 2.2e7, 'gk': 7, 'Ek_ev': 3.5, 'Ek_cm-1': 3.5*8065.54}]),
        Peak(detected_wavelength_nm=310.101, detected_intensity=118.0, peak_id="p3", is_identified=True,
             identified_elements=[{'element': 'Fe', 'ion_stage': 'I', 'wavelength_nm': 310.095, 'Aki': 1.1e7, 'gk': 3, 'Ek_ev': 4.0, 'Ek_cm-1': 4.0*8065.54}]),
        Peak(detected_wavelength_nm=400.0, detected_intensity=50.0, peak_id="p4", is_identified=True, # Different element
             identified_elements=[{'element': 'Ca', 'ion_stage': 'II', 'wavelength_nm': 400.0, 'Aki': 1.0e8, 'gk': 2, 'Ek_ev': 3.12}])
    ]
    test_project.add_spectrum(active_spec); test_project.set_active_spectrum(active_spec.spectrum_id)
    pm.current_project = test_project
    
    main_win = QWidget()
    main_layout = QVBoxLayout(main_win)
    tab = QuantitativeTab(project_manager=pm, main_window=None, parent=main_win)
    main_layout.addWidget(tab)
    main_win.setWindowTitle("Quantitative Tab Test"); main_win.resize(800, 700)
    
    if pm.current_project:
        tab.on_project_loaded(pm.current_project)
        if pm.current_project.get_active_spectrum():
            tab.on_active_spectrum_changed(pm.current_project.get_active_spectrum())
    tab.on_tab_selected()
    
    main_win.show()
    sys.exit(app.exec_())
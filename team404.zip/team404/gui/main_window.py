# team404/gui/main_window.py

import logging
import os
import sys
from pathlib import Path
from typing import Optional

from PyQt5.QtWidgets import (
    QMainWindow, QAction, QTabWidget, QVBoxLayout, QWidget,
    QStatusBar, QMessageBox, QFileDialog, QApplication, QLabel
)
from PyQt5.QtGui import QIcon # QIcon is sufficient here, specific icons loaded by name
from PyQt5.QtCore import Qt, pyqtSignal, QSize

from team404.gui.widgets.spectrum_plot_widget import SpectrumPlotWidget # Added QSize for toolbar icons

from .. import app_config # For APP_NAME, APP_VERSION, etc.
from ..core.project_manager import ProjectManager
from ..gui.dialogs.preferences_dialog import PreferencesDialog, app_settings_manager
from ..gui.dialogs.about_dialog import AboutDialog
# from ..gui.dialogs.file_format_dialog import FileFormatDialog # Only if used directly by MW

# Import all tab widgets
from .tabs.project_data_tab import LIBSProjectTab
from .tabs.preprocessing_tab import PreprocessingTab
from .tabs.peak_analysis_tab import PeakAnalysisTab
from .tabs.elemental_id_tab import ElementalIdTab
from .tabs.quantitative_tab import QuantitativeTab
from .tabs.mapping_tab import MappingTab
from .tabs.chemometrics_tab import ChemometricsTab

from ..core.data_models import LIBSpectrum # For type hinting in signals/slots if needed

# from ..utils.ui_utils import get_icon # Decided to put get_icon in MainWindow for now

logger = logging.getLogger(__name__)

class MainWindow(QMainWindow):
    """Main application window for SpectraMapper Pro."""

    project_loaded_signal = pyqtSignal(object) 
    project_closed_signal = pyqtSignal()
    active_spectrum_changed_signal = pyqtSignal(object) 
    preferences_updated_signal = pyqtSignal(dict)

    def __init__(self, project_manager: ProjectManager):
        super().__init__()
        self.project_manager = project_manager
        self.app_settings_manager = app_settings_manager # Use the global instance

        self._init_ui()
        self._connect_signals()
        self.update_window_title()
        self.show_startup_message()

    def get_icon(self, icon_name: str) -> QIcon:
        try:
            # Assumes this file is in team404/gui/
            # So, base_path should go up two levels to team404/
            base_path = Path(__file__).resolve().parent.parent 
            icon_path = base_path / "assets" / "icons" / icon_name
            if icon_path.exists() and icon_path.is_file():
                return QIcon(str(icon_path))
            else:
                logger.warning(f"Icon not found: {icon_path}")
        except Exception as e:
            logger.error(f"Error loading icon {icon_name}: {e}", exc_info=True)
        return QIcon() 

    def _init_ui(self):
        self.setWindowTitle(app_config.APP_NAME)
        app_icon = self.get_icon("app_icon.png")
        if not app_icon.isNull():
            self.setWindowIcon(app_icon)
        
        self.resize(1280, 800) # Adjusted default size

        self.central_tab_widget = QTabWidget()
        self.setCentralWidget(self.central_tab_widget)

        self.project_data_tab = LIBSProjectTab(self.project_manager, main_window=self)
        self.preprocessing_tab = PreprocessingTab(self.project_manager, main_window=self)
        self.peak_analysis_tab = PeakAnalysisTab(self.project_manager, main_window=self)
        self.elemental_id_tab = ElementalIdTab(self.project_manager, main_window=self)
        self.quantitative_tab = QuantitativeTab(self.project_manager, main_window=self)
        self.mapping_tab = MappingTab(self.project_manager, main_window=self)
        self.chemometrics_tab = ChemometricsTab(self.project_manager, main_window=self)

        self.central_tab_widget.addTab(self.project_data_tab, "Project & Data") # Renamed for clarity
        self.central_tab_widget.addTab(self.preprocessing_tab, "Preprocessing")
        self.central_tab_widget.addTab(self.peak_analysis_tab, "Peak Analysis")
        self.central_tab_widget.addTab(self.elemental_id_tab, "Elemental ID")
        self.central_tab_widget.addTab(self.quantitative_tab, "Quantitative")
        self.central_tab_widget.addTab(self.mapping_tab, "2D Mapping")
        self.central_tab_widget.addTab(self.chemometrics_tab, "Chemometrics")

        self._create_actions()
        self._create_menus()
        self._create_toolbars()
        self._create_status_bar()

    def _create_actions(self):
        self.new_project_action = QAction(self.get_icon("new_project.png"), "&New Project...", self,
                                          shortcut="Ctrl+N", statusTip="Create a new LIBS analysis project",
                                          triggered=self._new_project)
        self.open_project_action = QAction(self.get_icon("open_project.png"), "&Open Project...", self,
                                           shortcut="Ctrl+O", statusTip="Open an existing LIBS project",
                                           triggered=self._open_project)
        self.save_project_action = QAction(self.get_icon("save_project.png"), "&Save Project", self,
                                           shortcut="Ctrl+S", statusTip="Save the current project",
                                           triggered=self._save_project)
        self.save_project_as_action = QAction(self.get_icon("save_as.png"), "Save Project &As...", self,
                                              shortcut="Ctrl+Shift+S", statusTip="Save the current project to a new file",
                                              triggered=self._save_project_as)
        self.exit_action = QAction(self.get_icon("exit.png"), "E&xit", self,
                                   shortcut="Ctrl+Q", statusTip="Exit the application",
                                   triggered=self.close)

        self.preferences_action = QAction(self.get_icon("settings.png"), "&Preferences...", self,
                                          statusTip="Configure application preferences",
                                          triggered=self._open_preferences)
        self.about_action = QAction(self.get_icon("help_about.png"), "&About " + app_config.APP_NAME, self,
                                    statusTip=f"Show information about {app_config.APP_NAME}",
                                    triggered=self._show_about_dialog)

    def _create_menus(self):
        file_menu = self.menuBar().addMenu("&File")
        file_menu.addAction(self.new_project_action); file_menu.addAction(self.open_project_action)
        file_menu.addSeparator(); file_menu.addAction(self.save_project_action)
        file_menu.addAction(self.save_project_as_action); file_menu.addSeparator()
        file_menu.addAction(self.exit_action)

        edit_menu = self.menuBar().addMenu("&Edit"); edit_menu.addAction(self.preferences_action)
        help_menu = self.menuBar().addMenu("&Help"); help_menu.addAction(self.about_action)

    def _create_toolbars(self):
        file_toolbar = self.addToolBar("File Toolbar"); file_toolbar.setObjectName("FileToolbar")
        file_toolbar.setIconSize(QSize(24,24))
        file_toolbar.addAction(self.new_project_action); file_toolbar.addAction(self.open_project_action)
        file_toolbar.addAction(self.save_project_action)
        # Add more toolbars and actions as needed

    def _create_status_bar(self):
        self.statusBar = QStatusBar(self)
        self.setStatusBar(self.statusBar)
        self.status_label_main = QLabel("Ready")
        self.status_label_project = QLabel("No project open")
        self.statusBar.addPermanentWidget(self.status_label_project, 1)
        self.statusBar.addWidget(self.status_label_main, 2)

    def update_status_bar(self, main_message: str, project_message: Optional[str] = None, timeout_ms: int = 0):
        if timeout_ms > 0: self.statusBar.showMessage(main_message, timeout_ms)
        else: self.status_label_main.setText(main_message) # Permanent part if no timeout
        
        if project_message is not None: self.status_label_project.setText(project_message)

    def _connect_signals(self):
        # MainWindow -> Tabs
        all_tabs = [
            self.project_data_tab, self.preprocessing_tab, self.peak_analysis_tab,
            self.elemental_id_tab, self.quantitative_tab, self.mapping_tab,
            self.chemometrics_tab
        ]
        for tab in all_tabs:
            self.project_loaded_signal.connect(tab.on_project_loaded)
            self.project_closed_signal.connect(tab.on_project_closed)
            self.active_spectrum_changed_signal.connect(tab.on_active_spectrum_changed)
            self.preferences_updated_signal.connect(tab.on_preferences_updated)
            # Connect tab's active_spectrum_processed_externally to MainWindow's handler
            if hasattr(tab, 'active_spectrum_processed_externally'):
                 tab.active_spectrum_processed_externally.connect(
                    lambda spec_id, source_tab=tab: self._handle_spectrum_data_update(spec_id, source_tab.__class__.__name__)
                )


        # Tabs -> MainWindow / Other Tabs
        self.project_data_tab.active_spectrum_selection_changed_signal.connect(self._on_gui_active_spectrum_changed)
        
        # Connect highlight requests to the ProjectDataTab's public slot
        # This assumes LIBSProjectTab has a slot `highlight_wavelengths_on_plot(self, highlights_info: List[Dict[str, Any]])`
        if hasattr(self.project_data_tab, 'highlight_wavelengths_on_plot'):
            self.elemental_id_tab.request_peak_highlights_signal.connect(
                self.project_data_tab.highlight_wavelengths_on_plot # <<<< CORRECTED CONNECTION
            )
            self.quantitative_tab.request_boltzmann_line_highlights_signal.connect(
                self.project_data_tab.highlight_wavelengths_on_plot # <<<< CORRECTED CONNECTION
            )
            # PeakAnalysisTab also needs to emit structured highlight data
            if hasattr(self.peak_analysis_tab, 'request_plot_update_signal'):
                # Need an adapter if request_plot_update_signal emits a different structure
                # For now, assuming it might also emit a list of dicts for highlights when appropriate
                # Or PeakAnalysisTab directly calls a highlight method on its own plot if it has one.
                # If it needs to update the main plot in ProjectDataTab:
                self.peak_analysis_tab.request_plot_update_signal.connect(
                    self._handle_peak_analysis_plot_update
                )

        self.mapping_tab.display_map_point_spectrum_signal.connect(self._display_map_point_spectrum_globally)

    def update_window_title(self):
        title = app_config.APP_NAME
        if self.project_manager.is_project_open() and self.project_manager.current_project:
            proj_name = self.project_manager.get_current_project_name()
            proj_path = self.project_manager.get_current_project_filepath()
            dirty_star = "*" if self.project_manager.is_project_dirty() else ""
            title += f" - {proj_name}{dirty_star}"
            if proj_path: title += f" [{Path(proj_path).name}]"
        self.setWindowTitle(title)
        self.update_status_bar("Ready", project_message=self.project_manager.get_current_project_name() or "No Project")

    def show_startup_message(self):
        self.update_status_bar(f"{app_config.APP_NAME} v{app_config.APP_VERSION} started.", timeout_ms=5000)

    def _confirm_unsaved_changes(self) -> bool:
        if self.project_manager.is_project_open() and self.project_manager.is_project_dirty():
            project_name = self.project_manager.get_current_project_name() or "Current Project"
            reply = QMessageBox.question(self, "Unsaved Changes",
                                         f"Project '{project_name}' has unsaved changes.\n"
                                         "Do you want to save them before proceeding?",
                                         QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
                                         QMessageBox.Save)
            if reply == QMessageBox.Save: return self._save_project()
            elif reply == QMessageBox.Cancel: return False
        return True

    def _new_project(self):
        if not self._confirm_unsaved_changes(): return
        default_projects_dir = self.app_settings_manager.get_value("paths", "default_project_dir", str(Path.home()))
        if self.project_manager.new_project(project_dir=default_projects_dir):
            self.project_loaded_signal.emit(self.project_manager.current_project)
            self.update_window_title()
            self.update_status_bar("New project created.", self.project_manager.get_current_project_name())
            logger.info("New project initiated.")
            if self.project_manager.current_project and not self.project_manager.current_project.project_filepath:
                 self.project_manager.mark_project_dirty(True) # Untitled is dirty
            self.update_window_title()

    def _open_project(self):
        if not self._confirm_unsaved_changes(): return
        default_dir = self.app_settings_manager.get_value("paths", "default_project_dir", str(Path.home()))
        filepath, _ = QFileDialog.getOpenFileName(self, "Open LIBS Project", default_dir, "LIBS Project Files (*.libs_proj);;All Files (*)")
        if filepath:
            if self.project_manager.load_project(filepath):
                self.project_loaded_signal.emit(self.project_manager.current_project)
                self.update_window_title()
                self.update_status_bar(f"Project '{Path(filepath).name}' loaded.", self.project_manager.get_current_project_name())
                logger.info(f"Project loaded from {filepath}")
            else: QMessageBox.critical(self, "Load Error", f"Failed to load project from:\n{filepath}")

    def _save_project(self) -> bool:
        if not self.project_manager.is_project_open() or not self.project_manager.current_project:
            QMessageBox.information(self, "No Project", "No project is currently open to save."); return False
        current_filepath = self.project_manager.get_current_project_filepath()
        if not current_filepath: return self._save_project_as()
        else:
            if self.project_manager.save_project():
                self.update_window_title() # Clears dirty star
                self.update_status_bar(f"Project saved to '{Path(current_filepath).name}'.", self.project_manager.get_current_project_name())
                logger.info(f"Project saved to {current_filepath}"); return True
            else: QMessageBox.critical(self, "Save Error", f"Failed to save project to:\n{current_filepath}"); return False

    def _save_project_as(self) -> bool:
        if not self.project_manager.is_project_open() or not self.project_manager.current_project:
            QMessageBox.information(self, "No Project", "No project is currently open to save."); return False

        default_dir = str(Path(self.project_manager.get_current_project_filepath() or \
                           self.app_settings_manager.get_value("paths", "default_project_dir", str(Path.home()))).parent)
        current_name = Path(self.project_manager.get_current_project_filepath() or \
                            f"{self.project_manager.get_current_project_name() or 'Untitled'}.libs_proj").name

        filepath, _ = QFileDialog.getSaveFileName(self, "Save Project As", os.path.join(default_dir, current_name),
                                                  "LIBS Project Files (*.libs_proj);;All Files (*)")
        if filepath:
            if self.project_manager.save_project_as(filepath):
                self.update_window_title() # Path and dirty star updated
                self.update_status_bar(f"Project saved as '{Path(filepath).name}'.", self.project_manager.get_current_project_name())
                logger.info(f"Project saved to new file: {filepath}"); return True
            else: QMessageBox.critical(self, "Save Error", f"Failed to save project to:\n{filepath}"); return False
        return False

    def _open_preferences(self):
        accepted = PreferencesDialog.edit_preferences(self)
        if accepted:
            logger.info("Preferences dialog accepted. Settings saved.")
            self.preferences_updated_signal.emit(self.app_settings_manager.settings) # Use global manager's current settings
            self.update_status_bar("Preferences updated.", timeout_ms=3000)

    def _show_about_dialog(self): AboutDialog.show_about_dialog(self)

    def closeEvent(self, event):
        if self._confirm_unsaved_changes():
            logger.info(f"{app_config.APP_NAME} is closing. Performing cleanup..."); event.accept()
            # Clean up any long-running worker threads in tabs
            all_tabs = [self.project_data_tab, self.preprocessing_tab, self.peak_analysis_tab,
                        self.elemental_id_tab, self.quantitative_tab, self.mapping_tab, self.chemometrics_tab]
            for tab in all_tabs:
                if hasattr(tab, 'closeEvent'): # If tab has specific cleanup
                    tab.closeEvent(event) # Allow tab to clean up its resources (like threads)
        else: event.ignore()

    def _on_gui_active_spectrum_changed(self, spectrum: Optional[LIBSpectrum]):
        if self.project_manager.current_project:
            new_active_id = spectrum.spectrum_id if spectrum else None
            # Only update if truly changed to avoid redundant signals
            if self.project_manager.current_project.active_spectrum_id != new_active_id:
                self.project_manager.set_active_spectrum(new_active_id) # This doesn't mark dirty
                self.active_spectrum_changed_signal.emit(spectrum)
                self.update_status_bar(f"Active spectrum: {spectrum.filename if spectrum else 'None'}",
                                       project_message=self.project_manager.get_current_project_name())
                logger.debug(f"GUI changed active spectrum to: {new_active_id}")

    def _handle_spectrum_data_update(self, spectrum_id: str, source_tab_name: str):
        logger.info(f"Spectrum '{spectrum_id}' updated by '{source_tab_name}' tab.")
        self.mark_project_dirty(True) # MainWindow's method handles PM and title
        
        active_spectrum = self.project_manager.get_active_spectrum()
        if active_spectrum and active_spectrum.spectrum_id == spectrum_id:
            self.active_spectrum_changed_signal.emit(active_spectrum) # Re-emit to refresh all tabs
            # ProjectDataTab's on_active_spectrum_changed will replot.

    def _handle_peak_analysis_plot_update(self, plot_instruction: dict):
        """Handles plot update requests from PeakAnalysisTab."""
        action = plot_instruction.get("action")
        spectrum_obj = plot_instruction.get("spectrum") # This is a LIBSpectrum object
        
        if action == "show_spectrum_and_peaks" and spectrum_obj:
            if hasattr(self.project_data_tab, 'update_plot_for_spectrum'):
                self.project_data_tab.update_plot_for_spectrum(spectrum_obj) # Show spectrum
            if hasattr(self.project_data_tab, 'highlight_wavelengths_on_plot') and spectrum_obj.peaks:
                highlights = []
                for peak in spectrum_obj.peaks:
                    wl = peak.get_effective_wavelength()
                    if wl is not None:
                         highlights.append({"wavelength": wl, "label": ""}) # Simple markers for detected peaks
                self.project_data_tab.highlight_wavelengths_on_plot(highlights)

        elif action == "highlight_on_plot": # For specific peak selections
            peaks_info = plot_instruction.get("peaks_info", []) # List of {"wavelength": wl, "label": lbl}
            if hasattr(self.project_data_tab, 'highlight_wavelengths_on_plot'):
                self.project_data_tab.highlight_wavelengths_on_plot(peaks_info)


    def _display_map_point_spectrum_globally(self, spectrum: LIBSpectrum):
        if spectrum and hasattr(self.project_data_tab, 'spectrum_preview_plot'):
            logger.info(f"Displaying spectrum from map point: {spectrum.filename or spectrum.spectrum_id} in main preview.")
            # Note: spectrum.wavelengths and .intensities are already batch-preprocessed by MappingProcessor
            self.project_data_tab.spectrum_preview_plot.plot_spectrum(
                spectrum.wavelengths, spectrum.intensities,
                title=f"Map Point: {spectrum.filename or spectrum.spectrum_id} (X:{spectrum.x_coord:.2f}, Y:{spectrum.y_coord:.2f})",
                series_name="Map Point Spectrum"
            )
            self.update_status_bar(f"Viewing spectrum from map point: {spectrum.filename or spectrum.spectrum_id}",
                                   project_message=self.project_manager.get_current_project_name())

    def get_main_plot_widget(self) -> Optional[SpectrumPlotWidget]:
        if hasattr(self.project_data_tab, 'spectrum_preview_plot'):
            return self.project_data_tab.spectrum_preview_plot
        logger.warning("Main plot widget (spectrum_preview_plot in LIBSProjectTab) not found.")
        return None

    def mark_project_dirty(self, dirty: bool = True): # Public method for tabs to call
        self.project_manager.mark_project_dirty(dirty)
        self.update_window_title()